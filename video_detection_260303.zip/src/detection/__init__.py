"""
Detection module for video monitoring.

This module provides components for:
- ROI (Region of Interest) type definitions and utilities
- Numeric value change detection with hybrid SSIM/OCR approach
- Line chart pattern detection
- Dynamic ROI auto-detection (text + waveform)
- Anchor-based dynamic ROI detection (snippet/text anchors)
- Shared cascade template matching engine

Typical usage:
    from detection import ROI, BoundingBox, ROIType
    from detection import ChangeDetector, ChartDetector

    # 사전 정의된 ROI 사용
    bbox = BoundingBox(x=100, y=200, width=50, height=30)
    roi = ROI(id="roi_1", bbox=bbox, roi_type=ROIType.NUMERIC)

    # 동적 ROI 자동 탐지
    from detection import DynamicROIDetector
    detector = DynamicROIDetector()
    rois = detector.detect(first_frame)

    # 앵커 기반 ROI 탐지
    from detection import AnchorDetector
    detector = AnchorDetector.from_yaml(Path("config/anchors.yaml"))
    rois = detector.detect(first_frame)
"""

from .anchor_detector import (
    AnchorDefinition,
    AnchorDetector,
    AnchorDetectorConfig,
    AnchorROIMapping,
    NormalizedOffset,
)
from .change_detector import ChangeDetector, ChangeDetectorConfig, ChangeEvent
from .chart_detector import ChartDetectionResult, ChartDetector, ChartDetectorConfig
from .color_template_detector import (
    ColorROIMapping,
    ColorTemplateConfig,
    ColorTemplateDetector,
)
from .dynamic_roi_detector import (
    DynamicROIConfig,
    DynamicROIDetector,
    WindowDetectionStrategy,
)
from .roi_types import ROI, BoundingBox, ROIType, load_rois, save_rois
from .template_matcher import MatcherConfig, MatchResult, TemplateMatcher
from .text_roi_detector import (
    PatternCategory,
    TextPattern,
    TextROIDetector,
    TextROIDetectorConfig,
)
from .waveform_detector import WaveformDetector, WaveformDetectorConfig
from .window_boundary_detector import WindowBoundaryConfig, WindowBoundaryDetector

__all__ = [
    # ROI Types (from roi_types.py)
    "ROI",
    "BoundingBox",
    "ROIType",
    "save_rois",
    "load_rois",
    # Change Detection
    "ChangeDetector",
    "ChangeEvent",
    "ChangeDetectorConfig",
    # Chart Detection
    "ChartDetector",
    "ChartDetectorConfig",
    "ChartDetectionResult",
    # Dynamic ROI Detection
    "DynamicROIDetector",
    "DynamicROIConfig",
    "TextROIDetector",
    "TextROIDetectorConfig",
    "TextPattern",
    "PatternCategory",
    "WaveformDetector",
    "WaveformDetectorConfig",
    # Window Boundary Detection
    "WindowBoundaryDetector",
    "WindowBoundaryConfig",
    "WindowDetectionStrategy",
    # Color Template Detection
    "ColorTemplateDetector",
    "ColorTemplateConfig",
    "ColorROIMapping",
    # Template Matching Engine
    "TemplateMatcher",
    "MatcherConfig",
    "MatchResult",
    # Anchor-based Detection
    "AnchorDetector",
    "AnchorDetectorConfig",
    "AnchorDefinition",
    "AnchorROIMapping",
    "NormalizedOffset",
]

__version__ = "0.4.0"
