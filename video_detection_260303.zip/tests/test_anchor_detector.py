"""앵커 기반 ROI 탐지기 단위 테스트

AnchorDetector의 핵심 기능을 검증합니다:
    - 데이터클래스 생성 및 속성 (AnchorDefinition, NormalizedOffset, AnchorROIMapping)
    - AnchorDetector 초기화 (설정 로딩, 스니펫 이미지 로딩)
    - ROI 좌표 계산 (_compute_rois) 및 클리핑
    - 전역 좌표 변환 (_remap_to_global)
    - 중복 ROI 병합 (_merge_overlapping)
    - 윈도우 경계 탐지 위임 (_detect_windows)
    - YAML 설정 로딩 (from_yaml)
    - ID 할당 패턴 (_assign_ids)
"""

import importlib.util
import logging
import sys
import types
from dataclasses import FrozenInstanceError
from pathlib import Path
from unittest.mock import MagicMock, patch

import cv2
import numpy as np
import pytest

# __init__.py 경유 시 skimage/numpy 바이너리 비호환 문제를 우회하기 위해
# 패키지를 스텁으로 등록한 뒤 하위 모듈을 직접 로드
_detection_dir = Path(__file__).resolve().parent.parent / "src" / "detection"


def _ensure_package_stub(pkg_name: str) -> types.ModuleType:
    """패키지 stub 모듈을 sys.modules에 등록 (__init__.py 실행 방지)"""
    if pkg_name not in sys.modules:
        mod = types.ModuleType(pkg_name)
        mod.__path__ = []  # type: ignore[attr-defined]
        mod.__package__ = pkg_name
        sys.modules[pkg_name] = mod
    return sys.modules[pkg_name]


def _load_module(name: str, path: str) -> types.ModuleType:
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    # 부모 패키지 속성에도 등록
    parts = name.rsplit(".", 1)
    if len(parts) == 2 and parts[0] in sys.modules:
        setattr(sys.modules[parts[0]], parts[1], mod)
    return mod


# 패키지 stub 등록 (상대 import 해결용)
_ensure_package_stub("src")
_det_pkg = _ensure_package_stub("src.detection")
_det_pkg.__path__ = [str(_detection_dir)]  # type: ignore[attr-defined]

# 의존성 순서대로 로드: roi_types → template_matcher → window_boundary_detector → anchor_detector
_roi_types = _load_module(
    "src.detection.roi_types", str(_detection_dir / "roi_types.py")
)
_tm = _load_module(
    "src.detection.template_matcher", str(_detection_dir / "template_matcher.py")
)
_wbd = _load_module(
    "src.detection.window_boundary_detector",
    str(_detection_dir / "window_boundary_detector.py"),
)
_ad = _load_module(
    "src.detection.anchor_detector", str(_detection_dir / "anchor_detector.py")
)

ROI = _roi_types.ROI
BoundingBox = _roi_types.BoundingBox
ROIType = _roi_types.ROIType
MatcherConfig = _tm.MatcherConfig
AnchorDefinition = _ad.AnchorDefinition
AnchorDetector = _ad.AnchorDetector
AnchorDetectorConfig = _ad.AnchorDetectorConfig
AnchorROIMapping = _ad.AnchorROIMapping
NormalizedOffset = _ad.NormalizedOffset

# ========================================
# 합성 이미지 생성 헬퍼
# ========================================


def create_blank_frame(
    width: int = 640, height: int = 480, color: tuple = (0, 0, 0)
) -> np.ndarray:
    """단색 배경 프레임 생성"""
    return np.full((height, width, 3), color, dtype=np.uint8)


def make_roi(
    bbox: BoundingBox,
    roi_type: ROIType = ROIType.NUMERIC,
    confidence: float = 0.9,
    label: str = "test",
    metadata: dict | None = None,
) -> ROI:
    """테스트용 ROI 간편 생성"""
    return ROI(
        id="",
        bbox=bbox,
        roi_type=roi_type,
        confidence=confidence,
        label=label,
        metadata=metadata or {},
    )


# ========================================
# 데이터클래스 테스트
# ========================================


class TestDataClasses:
    """데이터클래스 생성 및 속성 검증"""

    def test_anchor_definition_creation_with_all_fields(self):
        """AnchorDefinition 모든 필드를 지정하여 생성"""
        anchor = AnchorDefinition(
            name="temp_icon",
            anchor_type="snippet",
            snippet_path=Path("anchors/temp.png"),
            search_text=None,
            match_threshold=0.8,
            window_pattern="모니터링",
        )
        assert anchor.name == "temp_icon"
        assert anchor.anchor_type == "snippet"
        assert anchor.snippet_path == Path("anchors/temp.png")
        assert anchor.search_text is None
        assert anchor.match_threshold == 0.8
        assert anchor.window_pattern == "모니터링"

    def test_anchor_definition_defaults(self):
        """AnchorDefinition 기본값 확인"""
        anchor = AnchorDefinition(name="label", anchor_type="text")
        assert anchor.snippet_path is None
        assert anchor.search_text is None
        assert anchor.match_threshold == 0.7
        assert anchor.window_pattern is None

    def test_normalized_offset_frozen_immutability(self):
        """NormalizedOffset는 frozen=True로 불변"""
        offset = NormalizedOffset(nx=0.1, ny=0.2, nw=0.3, nh=0.4)
        assert offset.nx == 0.1
        assert offset.ny == 0.2
        assert offset.nw == 0.3
        assert offset.nh == 0.4

        with pytest.raises(FrozenInstanceError):
            offset.nx = 0.5  # type: ignore[misc]

    def test_anchor_roi_mapping_with_default_roi_type(self):
        """AnchorROIMapping 기본 roi_type은 NUMERIC"""
        mapping = AnchorROIMapping(
            anchor_name="icon",
            roi_name="value_field",
            offset=NormalizedOffset(nx=0.05, ny=0.0, nw=0.1, nh=0.03),
        )
        assert mapping.roi_type == ROIType.NUMERIC

    def test_anchor_roi_mapping_with_custom_roi_type(self):
        """AnchorROIMapping 커스텀 roi_type 설정"""
        mapping = AnchorROIMapping(
            anchor_name="chart_icon",
            roi_name="chart_area",
            offset=NormalizedOffset(nx=0.0, ny=0.1, nw=0.5, nh=0.3),
            roi_type=ROIType.CHART,
        )
        assert mapping.roi_type == ROIType.CHART


# ========================================
# AnchorDetector 초기화 테스트
# ========================================


class TestAnchorDetectorInit:
    """AnchorDetector 초기화 검증"""

    def test_default_config_creates_detector(self):
        """빈 기본 설정으로 탐지기 생성 시 오류 없음"""
        config = AnchorDetectorConfig(enable_window_detection=False)
        detector = AnchorDetector(config)
        assert detector.config is config
        assert detector._snippet_images == {}

    def test_snippet_anchors_load_images_on_init(self, tmp_path):
        """스니펫 앵커의 이미지가 초기화 시 사전 로딩됨"""
        # 임시 스니펫 이미지 생성
        snippet_img = np.zeros((50, 50, 3), dtype=np.uint8)
        cv2.rectangle(snippet_img, (10, 10), (40, 40), (0, 255, 0), -1)
        snippet_path = tmp_path / "test_snippet.png"
        cv2.imwrite(str(snippet_path), snippet_img)

        anchor = AnchorDefinition(
            name="test_anchor",
            anchor_type="snippet",
            snippet_path=snippet_path,
        )
        config = AnchorDetectorConfig(
            anchors=[anchor],
            enable_window_detection=False,
        )
        detector = AnchorDetector(config)

        assert "test_anchor" in detector._snippet_images
        loaded = detector._snippet_images["test_anchor"]
        assert loaded.shape == (50, 50, 3)

    def test_missing_snippet_file_logged_as_warning(self, tmp_path, caplog):
        """존재하지 않는 스니펫 파일은 경고 로그 출력"""
        missing_path = tmp_path / "nonexistent.png"
        anchor = AnchorDefinition(
            name="missing",
            anchor_type="snippet",
            snippet_path=missing_path,
        )
        config = AnchorDetectorConfig(
            anchors=[anchor],
            enable_window_detection=False,
        )

        with caplog.at_level(logging.WARNING):
            detector = AnchorDetector(config)

        assert "missing" not in detector._snippet_images
        # 경고 메시지가 로그에 기록됨
        assert any("존재하지 않습니다" in record.message for record in caplog.records)


# ========================================
# ROI 좌표 계산 테스트
# ========================================


class TestComputeRois:
    """_compute_rois 정규화 오프셋 → 절대 좌표 변환 테스트"""

    def _make_detector_with_mapping(
        self,
        offset: NormalizedOffset,
        roi_type: ROIType = ROIType.NUMERIC,
    ) -> AnchorDetector:
        """특정 오프셋으로 매핑이 하나 있는 탐지기 생성"""
        anchor = AnchorDefinition(name="icon", anchor_type="snippet")
        mapping = AnchorROIMapping(
            anchor_name="icon",
            roi_name="value",
            offset=offset,
            roi_type=roi_type,
        )
        config = AnchorDetectorConfig(
            anchors=[anchor],
            roi_mappings=[mapping],
            enable_window_detection=False,
        )
        return AnchorDetector(config)

    def test_correct_pixel_coordinate_from_normalized_offset(self):
        """정규화 오프셋이 올바른 픽셀 좌표로 변환됨"""
        offset = NormalizedOffset(nx=0.05, ny=0.1, nw=0.15, nh=0.08)
        detector = self._make_detector_with_mapping(offset)

        # 앵커가 (100, 200) 위치, 기준 영역 640x480
        anchors = {"icon": BoundingBox(x=100, y=200, width=50, height=50)}
        ref_bbox = BoundingBox(x=0, y=0, width=640, height=480)

        rois = detector._compute_rois(anchors, ref_bbox)
        assert len(rois) == 1

        roi = rois[0]
        # roi_x = 100 + 0.05 * 640 = 100 + 32 = 132
        assert roi.bbox.x == 132
        # roi_y = 200 + 0.1 * 480 = 200 + 48 = 248
        assert roi.bbox.y == 248
        # roi_w = 0.15 * 640 = 96
        assert roi.bbox.width == 96
        # roi_h = 0.08 * 480 = 38 (int)
        assert roi.bbox.height == 38

    def test_upper_bound_clipping(self):
        """기준 영역 상한 초과 시 클리핑"""
        # 앵커가 오른쪽 끝 근처, 오프셋이 넓은 ROI → 상한 클리핑
        offset = NormalizedOffset(nx=0.0, ny=0.0, nw=0.5, nh=0.5)
        detector = self._make_detector_with_mapping(offset)

        anchors = {"icon": BoundingBox(x=500, y=300, width=30, height=30)}
        ref_bbox = BoundingBox(x=0, y=0, width=640, height=480)

        rois = detector._compute_rois(anchors, ref_bbox)
        assert len(rois) == 1

        roi = rois[0]
        # roi_w = min(320, 640 - 500) = min(320, 140) = 140
        assert roi.bbox.width == 140
        # roi_h = min(240, 480 - 300) = min(240, 180) = 180
        assert roi.bbox.height == 180

    def test_lower_bound_clipping_negative_offset(self):
        """음수 오프셋으로 인한 좌표가 0으로 클램핑"""
        # 음수 오프셋 → roi_x/roi_y가 음수가 될 수 있음 → max(0, ...) 처리
        offset = NormalizedOffset(nx=-0.5, ny=-0.5, nw=0.1, nh=0.1)
        detector = self._make_detector_with_mapping(offset)

        anchors = {"icon": BoundingBox(x=10, y=10, width=20, height=20)}
        ref_bbox = BoundingBox(x=0, y=0, width=640, height=480)

        rois = detector._compute_rois(anchors, ref_bbox)
        assert len(rois) == 1

        roi = rois[0]
        # roi_x = max(0, 10 + (-0.5)*640) = max(0, 10 - 320) = max(0, -310) = 0
        assert roi.bbox.x == 0
        # roi_y = max(0, 10 + (-0.5)*480) = max(0, 10 - 240) = max(0, -230) = 0
        assert roi.bbox.y == 0


# ========================================
# 전역 좌표 변환 테스트
# ========================================


class TestRemapToGlobal:
    """_remap_to_global 윈도우 로컬 → 전체 프레임 좌표 변환"""

    def _make_detector(self) -> AnchorDetector:
        """최소 설정 탐지기"""
        config = AnchorDetectorConfig(enable_window_detection=False)
        return AnchorDetector(config)

    def test_adds_window_bbox_offset(self):
        """윈도우 오프셋이 ROI 좌표에 더해짐"""
        detector = self._make_detector()

        roi = make_roi(BoundingBox(x=50, y=30, width=100, height=60))
        window_bbox = BoundingBox(x=200, y=150, width=400, height=300)

        result = detector._remap_to_global([roi], window_bbox)
        assert len(result) == 1
        assert result[0].bbox.x == 250  # 50 + 200
        assert result[0].bbox.y == 180  # 30 + 150
        assert result[0].bbox.width == 100  # 변하지 않음
        assert result[0].bbox.height == 60  # 변하지 않음

    def test_noop_when_window_at_origin(self):
        """윈도우가 (0,0)이면 좌표 변경 없음"""
        detector = self._make_detector()

        roi = make_roi(BoundingBox(x=100, y=200, width=50, height=30))
        window_bbox = BoundingBox(x=0, y=0, width=640, height=480)

        result = detector._remap_to_global([roi], window_bbox)
        assert len(result) == 1
        assert result[0].bbox.x == 100
        assert result[0].bbox.y == 200

    def test_empty_rois_returns_empty(self):
        """빈 ROI 리스트는 그대로 반환"""
        detector = self._make_detector()
        window_bbox = BoundingBox(x=100, y=100, width=400, height=300)

        result = detector._remap_to_global([], window_bbox)
        assert result == []

    def test_window_offset_in_metadata(self):
        """변환 후 metadata에 window_offset이 추가됨"""
        detector = self._make_detector()

        roi = make_roi(BoundingBox(x=10, y=20, width=30, height=40))
        window_bbox = BoundingBox(x=50, y=60, width=400, height=300)

        result = detector._remap_to_global([roi], window_bbox)
        assert result[0].metadata["window_offset"] == (50, 60)


# ========================================
# 중복 ROI 병합 테스트
# ========================================


class TestMergeOverlapping:
    """_merge_overlapping IoU 기반 중복 제거 테스트"""

    def _make_detector(self, iou_threshold: float = 0.5) -> AnchorDetector:
        """특정 IoU 임계값의 탐지기"""
        config = AnchorDetectorConfig(
            iou_merge_threshold=iou_threshold,
            enable_window_detection=False,
        )
        return AnchorDetector(config)

    def test_no_merge_when_iou_below_threshold(self):
        """IoU가 임계값 미만이면 병합하지 않음"""
        detector = self._make_detector(iou_threshold=0.5)

        roi_a = make_roi(BoundingBox(x=0, y=0, width=100, height=100), confidence=0.9)
        roi_b = make_roi(
            BoundingBox(x=300, y=300, width=100, height=100), confidence=0.8
        )

        result = detector._merge_overlapping([roi_a, roi_b])
        assert len(result) == 2

    def test_higher_confidence_roi_survives_merge(self):
        """높은 신뢰도의 ROI가 병합에서 생존"""
        detector = self._make_detector(iou_threshold=0.3)

        # 겹치는 두 ROI
        roi_high = make_roi(
            BoundingBox(x=100, y=100, width=100, height=100),
            confidence=0.95,
            label="high",
        )
        roi_low = make_roi(
            BoundingBox(x=110, y=110, width=100, height=100),
            confidence=0.6,
            label="low",
        )

        result = detector._merge_overlapping([roi_high, roi_low])
        assert len(result) == 1
        assert result[0].label == "high"
        assert result[0].confidence == 0.95

    def test_single_roi_returns_unchanged(self):
        """단일 ROI는 그대로 반환"""
        detector = self._make_detector()

        roi = make_roi(BoundingBox(x=10, y=20, width=50, height=30))
        result = detector._merge_overlapping([roi])
        assert len(result) == 1
        assert result[0].bbox == roi.bbox

    def test_empty_list_returns_empty(self):
        """빈 리스트는 그대로 반환"""
        detector = self._make_detector()
        result = detector._merge_overlapping([])
        assert result == []


# ========================================
# 윈도우 경계 탐지 테스트
# ========================================


class TestDetectWindows:
    """_detect_windows 윈도우 경계 탐지 위임 테스트"""

    def test_returns_full_frame_when_detection_disabled(self):
        """윈도우 탐지 비활성화 시 전체 프레임 bbox 반환"""
        config = AnchorDetectorConfig(enable_window_detection=False)
        detector = AnchorDetector(config)

        frame = create_blank_frame(640, 480)
        windows = detector._detect_windows(frame)

        assert len(windows) == 1
        bbox, title = windows[0]
        assert bbox.x == 0
        assert bbox.y == 0
        assert bbox.width == 640
        assert bbox.height == 480
        assert title is None

    def test_pattern_filtering_matching_title_passes(self):
        """타이틀 패턴과 일치하는 윈도우만 통과"""
        config = AnchorDetectorConfig(
            enable_window_detection=True,
            window_title_patterns=["모니터링"],
        )
        detector = AnchorDetector(config)

        mock_bbox = BoundingBox(x=10, y=10, width=300, height=200)
        mock_windows = [(mock_bbox, "모니터링 시스템")]

        with patch.object(
            detector._window_detector,
            "detect_all_with_titles",
            return_value=mock_windows,
        ):
            frame = create_blank_frame(640, 480)
            windows = detector._detect_windows(frame)

        assert len(windows) == 1
        assert windows[0][1] == "모니터링 시스템"

    def test_pattern_filtering_non_matching_returns_full_frame(self):
        """타이틀 패턴과 불일치 시 전체 프레임 bbox 반환"""
        config = AnchorDetectorConfig(
            enable_window_detection=True,
            window_title_patterns=["모니터링"],
        )
        detector = AnchorDetector(config)

        mock_bbox = BoundingBox(x=10, y=10, width=300, height=200)
        mock_windows = [(mock_bbox, "설정 화면")]

        with patch.object(
            detector._window_detector,
            "detect_all_with_titles",
            return_value=mock_windows,
        ):
            frame = create_blank_frame(640, 480)
            windows = detector._detect_windows(frame)

        # 패턴 불일치 → 전체 프레임으로 폴백
        assert len(windows) == 1
        bbox, title = windows[0]
        assert bbox.width == 640
        assert bbox.height == 480
        assert title is None


# ========================================
# YAML 설정 로딩 테스트
# ========================================


class TestFromYaml:
    """from_yaml YAML 설정 파일 로딩 테스트"""

    def _write_yaml(self, tmp_path: Path, content: str) -> Path:
        """임시 YAML 파일 생성"""
        yaml_file = tmp_path / "anchors.yaml"
        yaml_file.write_text(content, encoding="utf-8")
        return yaml_file

    def test_valid_yaml_loads_correctly(self, tmp_path):
        """유효한 YAML이 올바르게 로드됨"""
        yaml_content = """\
anchors:
  - name: temp_icon
    anchor_type: snippet
    snippet_path: icon.png
    match_threshold: 0.8
  - name: pressure_label
    anchor_type: text
    search_text: "압력.*kPa"
    match_threshold: 0.6

roi_mappings:
  - anchor_name: temp_icon
    roi_name: temperature
    offset:
      nx: 0.05
      ny: 0.0
      nw: 0.1
      nh: 0.03
    roi_type: numeric

enable_window_detection: false
iou_merge_threshold: 0.4
"""
        yaml_file = self._write_yaml(tmp_path, yaml_content)
        detector = AnchorDetector.from_yaml(yaml_file)

        assert len(detector.config.anchors) == 2
        assert detector.config.anchors[0].name == "temp_icon"
        assert detector.config.anchors[0].match_threshold == 0.8
        assert detector.config.anchors[1].name == "pressure_label"
        assert detector.config.anchors[1].search_text == "압력.*kPa"

        assert len(detector.config.roi_mappings) == 1
        m = detector.config.roi_mappings[0]
        assert m.anchor_name == "temp_icon"
        assert m.roi_name == "temperature"
        assert m.offset.nx == 0.05
        assert m.roi_type == ROIType.NUMERIC

        assert detector.config.enable_window_detection is False
        assert detector.config.iou_merge_threshold == 0.4

    def test_invalid_anchor_name_in_roi_mapping_raises_value_error(self, tmp_path):
        """roi_mapping이 정의되지 않은 앵커를 참조하면 ValueError"""
        yaml_content = """\
anchors:
  - name: icon_a
    anchor_type: snippet

roi_mappings:
  - anchor_name: nonexistent_icon
    roi_name: value
    offset:
      nx: 0.0
      ny: 0.0
      nw: 0.1
      nh: 0.1
"""
        yaml_file = self._write_yaml(tmp_path, yaml_content)

        with pytest.raises(ValueError, match="nonexistent_icon"):
            AnchorDetector.from_yaml(yaml_file)

    def test_missing_yaml_file_raises_file_not_found(self, tmp_path):
        """존재하지 않는 YAML 파일은 FileNotFoundError"""
        missing_path = tmp_path / "nonexistent.yaml"

        with pytest.raises(FileNotFoundError):
            AnchorDetector.from_yaml(missing_path)

    def test_yaml_with_matcher_config(self, tmp_path):
        """YAML에서 matcher_config 커스텀 값 로딩"""
        yaml_content = """\
anchors: []
roi_mappings: []
enable_window_detection: false

matcher_config:
  edge_match_threshold: 0.6
  feature_match_min_count: 12
"""
        yaml_file = self._write_yaml(tmp_path, yaml_content)
        detector = AnchorDetector.from_yaml(yaml_file)

        assert detector.config.matcher_config.edge_match_threshold == 0.6
        assert detector.config.matcher_config.feature_match_min_count == 12
        # 지정하지 않은 값은 기본값 유지
        assert (
            detector.config.matcher_config.fallback_match_threshold
            == MatcherConfig().fallback_match_threshold
        )


# ========================================
# ID 할당 테스트
# ========================================


class TestAssignIds:
    """_assign_ids ID 할당 패턴 검증"""

    def test_ids_follow_anchor_type_index_pattern(self):
        """ID가 anchor_{type}_{index} 패턴을 따름"""
        rois = [
            make_roi(
                BoundingBox(x=10, y=20, width=30, height=40),
                roi_type=ROIType.NUMERIC,
            ),
            make_roi(
                BoundingBox(x=100, y=200, width=50, height=60),
                roi_type=ROIType.NUMERIC,
            ),
        ]

        result = AnchorDetector._assign_ids(rois)
        assert result[0].id == "anchor_numeric_0"
        assert result[1].id == "anchor_numeric_1"

    def test_mixed_types_get_separate_counters(self):
        """다른 타입은 별도의 카운터를 가짐"""
        rois = [
            make_roi(
                BoundingBox(x=0, y=0, width=10, height=10),
                roi_type=ROIType.NUMERIC,
            ),
            make_roi(
                BoundingBox(x=50, y=50, width=10, height=10),
                roi_type=ROIType.TEXT,
            ),
            make_roi(
                BoundingBox(x=100, y=100, width=10, height=10),
                roi_type=ROIType.NUMERIC,
            ),
            make_roi(
                BoundingBox(x=150, y=150, width=10, height=10),
                roi_type=ROIType.CHART,
            ),
        ]

        result = AnchorDetector._assign_ids(rois)
        assert result[0].id == "anchor_numeric_0"
        assert result[1].id == "anchor_text_0"
        assert result[2].id == "anchor_numeric_1"
        assert result[3].id == "anchor_chart_0"

    def test_empty_list_returns_empty(self):
        """빈 리스트는 빈 리스트 반환"""
        result = AnchorDetector._assign_ids([])
        assert result == []

    def test_original_metadata_preserved(self):
        """ID 할당 후 원본 metadata가 보존됨"""
        roi = make_roi(
            BoundingBox(x=5, y=5, width=20, height=20),
            roi_type=ROIType.TEXT,
            metadata={"source": "anchor", "anchor_name": "label"},
        )

        result = AnchorDetector._assign_ids([roi])
        assert result[0].metadata["source"] == "anchor"
        assert result[0].metadata["anchor_name"] == "label"
