# XML 템플릿 관리 시스템

XML 템플릿을 관리(생성/수정)하고, 외부에서 주어진 데이터와 템플릿을 바탕으로 새로운 XML을
생성하는 기능. 템플릿은 **MariaDB 에 저장**되고, XML 생성은 **Java 백엔드로 일원화**되어
있다 (프론트엔드의 미리보기도 백엔드 API 를 호출).

## 구성

| 구분 | 기술 | 역할 |
|------|------|------|
| `backend/` | Java 1.8 (외부 라이브러리: MariaDB Connector/J 만) | 템플릿 DB 저장(CRUD), XML 생성 엔진, HTTP API 서버 |
| `frontend/XmlTemplateDesigner/` | C# / WinForms (VS2013, .NET 4.5) | 템플릿 관리 화면 (운영용) |
| `frontend/react-app/` | React (Vite) | 템플릿 관리 화면 (기능 검증용 — C# 과 동일 기능, 브라우저 테스트 가능) |

두 프론트엔드는 같은 HTTP API 계약을 사용하며 기능이 동기화되어 있다
(3단 화면, 노드 편집 항목, 샘플 데이터 3종, 데모 템플릿, 검증 규칙 모두 동일).
차이는 브라우저 특성상 MessageBox 대신 상태 표시줄 + 2단계 삭제 확인을 쓰는 것뿐이다.

```
xml-template/
├── backend/
│   ├── lib/mariadb-java-client-2.7.12.jar
│   ├── sql/schema.sql                   MariaDB DDL (기동 시 자동 생성됨)
│   └── src/main/java/com/xmltemplate/
│       ├── model/        TemplateNode, ValueType, ValueDataType
│       ├── expression/   ExpressionEvaluator          (조건식 평가기)
│       ├── engine/       XmlGenerator                 (XML 생성 엔진)
│       ├── template/     TemplateSerializer           (템플릿 XML 직렬화)
│       ├── db/           TemplateRepository(인터페이스),
│       │                 MariaDbTemplateRepository, InMemoryTemplateRepository,
│       │                 DbConfig, RepositoryException
│       ├── server/       HttpApiServer                (JDK 내장 HTTP 서버, CORS 지원)
│       └── Main.java                                  (데모 + 로직 검증)
└── frontend/
    ├── XmlTemplateDesigner/              C# WinForms (운영용)
    │   ├── Model/        TemplateNode, NodeValueType, NodeDataType
    │   ├── Template/     TemplateSerializer           (전송 페이로드 직렬화)
    │   ├── Backend/      BackendClient                (HTTP 클라이언트)
    │   ├── MainForm.cs   3단 구성 메인 화면
    │   ├── TemplateListDialog.cs
    │   └── Program.cs
    └── react-app/                        React (기능 검증용)
        └── src/
            ├── model.js       노드 모델/데모 템플릿/샘플 (C# Model + 데모와 동일)
            ├── serializer.js  템플릿/previewRequest XML 직렬화 (C# TemplateSerializer 와 동일)
            ├── api.js         백엔드 클라이언트 (C# BackendClient 와 동일 계약)
            └── App.jsx        3단 구성 메인 화면
```

## 동작 구조

```
C# 프론트엔드                     Java 백엔드                Oracle
┌──────────────┐   템플릿 XML   ┌──────────────┐   JDBC   ┌─────────┐
│ Tree 편집     │ ─ PUT /templates → 파싱/저장  ─────────→ │ 템플릿   │
│ 노드 정보 입력 │ ← GET /templates ─ 직렬화    ←───────── │ 테이블   │
│ 샘플 데이터    │   previewRequest ┌──────────┐           └─────────┘
│ 미리보기      │ ─ POST /preview → │ XML 생성  │
└──────────────┘ ←  생성된 XML  ─  │ 엔진      │ ← POST /generate/{name} (외부 시스템)
                                  └──────────┘
```

## 노드 정보

### 노드 값 (입력타입 3가지 / DB: INPUT_TYPE, INPUT_VALUE)

| 유형 | 동작 | 예 |
|------|------|----|
| 고정값 (FIXED) | 입력한 텍스트 그대로 사용 | `품목` |
| 변수 (VARIABLE) | `{변수명}` 을 외부 데이터 값으로 치환 (없으면 빈 문자열) | `{ORDER_NO}` |
| 함수 (FUNCTION) | 삼항연산자 조건식 평가 결과 사용 | `{TYPE} == 'D' ? '국내' : '해외'` |

### 입력 데이터 타입 (DB: INPUT_DATA_TYPE)

- `STRING` (기본): 제약 없음
- `NUMBER`: 생성 시 최종 값이 비어 있지 않으면 숫자 형식인지 검증, 아니면 생성 오류

### 노드 속성

- **표시 조건** (DB: DISPLAY_COND): 조건식이 거짓이면 해당 노드(하위 포함)를 생성하지 않는다.
- **반복 조건** (DB: REPEAT_COND): 조건식이 참일 때만 반복 횟수 조건을 적용하고,
  거짓이면 1회만 생성한다. 비어 있으면 반복 횟수 조건을 그대로 적용.
- **반복 횟수 조건** (DB: REPEAT_COUNT_COND):
  - 숫자 `"3"` : 3회 반복 (`"0"` 이면 미생성)
  - 파라미터 `"{xxx}"` : 외부 데이터에 `xxx_1, xxx_2, ...` 가 **연속으로 존재하는 개수**만큼
    반복. 하나도 없으면 미생성.
  - 비어 있음 : 1회
- **반복 중 변수 해석**:
  - `{INDEX}` : 1부터 시작하는 현재 반복 회차
  - `{xxx}` 가 외부 데이터에 그 이름 그대로 없으면, 안쪽 반복부터 `xxx_회차` 를 찾아 치환.
    예) `ITEM_NAME_1=노트북, ITEM_NAME_2=마우스` 일 때 반복 2회차의 `{ITEM_NAME}` → `마우스`

### 조건식 문법

```
피연산자 : 노드 전체 경로        예) node1-1.node1-1-1   (해당 노드의 계산된 값)
          외부 데이터 변수       예) {PARAM}
          문자열 리터럴          예) 'VALUE'
          숫자                  예) 3, 1.5, -2
비교      : ==  !=  >  <  >=  <=   (양쪽이 숫자면 숫자 비교, 아니면 문자열 비교)
논리      : &&  ||  괄호 ( )
삼항      : 조건 ? 값1 : 값2       (중첩 가능, 함수 유형 노드 값에서 사용)
```

- 공백은 스페이스/탭/CR/LF 만 허용 (전각 공백 등은 명시적 오류).
- 존재하지 않는 변수/노드 경로는 빈 문자열로 평가.
- 노드 이름에 `:` 사용 불가 (네임스페이스 접두사로 해석되는 것을 차단).

## DB 스키마 (MariaDB, `backend/sql/schema.sql`)

접속 기본값: `jdbc:mariadb://127.0.0.1:13306/xml_template` (계정 `xml_template` / `xml_template`).
백엔드가 기동 시 `CREATE TABLE IF NOT EXISTS` 로 테이블을 자동 생성한다.

```
XML_TEMPLATE       TEMPLATE_NAME (PK), UPDATED_AT
XML_TEMPLATE_NODE  TEMPLATE_NAME + NODE_SN (PK)
```

| 컬럼 | 의미 |
|------|------|
| NODE_SN | 노드 일련번호 — 템플릿 내 DFS 전위 순서(1부터). ORDER BY 만으로 부모 우선 + 형제 순서 보존 |
| NODE_NAME | 노드 이름 |
| PARENT_SN | 부모 노드 일련번호 (루트는 NULL) |
| INPUT_TYPE | 입력타입 (FIXED / VARIABLE / FUNCTION) |
| INPUT_VALUE | 입력 내용 (노드 값) |
| INPUT_DATA_TYPE | 입력 데이터 타입 (STRING / NUMBER) |
| DISPLAY_COND | 표시 조건 |
| REPEAT_COND | 반복 조건 |
| REPEAT_COUNT_COND | 반복 횟수 조건 (숫자 또는 {파라미터}) |

읽을 때 NULL 컬럼은 빈 문자열로 복원한다.

## HTTP API (`HttpApiServer`)

| 메서드/경로 | 동작 | 본문 |
|------------|------|------|
| GET `/templates` | 템플릿 이름 목록 | - (응답: 줄바꿈 구분 텍스트) |
| GET `/templates/{name}` | 템플릿 조회 | - (응답: 템플릿 XML) |
| PUT `/templates/{name}` | 템플릿 저장 (POST 도 허용) | 템플릿 XML |
| DELETE `/templates/{name}` | 템플릿 삭제 | - |
| POST `/generate/{name}` | 저장된 템플릿으로 XML 생성 | `변수명=값` 줄 단위 (# 주석) |
| POST `/preview` | 저장하지 않은 템플릿 미리보기 | previewRequest XML |

previewRequest:

```xml
<previewRequest>
  <template name="..."> <node .../> </template>
  <data><param name="ORDER_NO">ORD-0001</param>...</data>
</previewRequest>
```

오류 응답: 400(요청/조건식/데이터 타입 오류), 404(템플릿 없음), 405(메서드), 500(서버/DB).
요청/응답 본문은 모두 UTF-8. 경로의 템플릿 이름은 percent-encoding 으로 전달한다
(`+`, `%`, 한글, 공백 왕복 검증됨). 단 `/` 와 `\` 는 템플릿 이름에 사용할 수 없다
(.NET Uri 가 경로의 %2F 를 '/' 로 되돌려 라우팅이 깨지므로 양쪽에서 차단).

## 템플릿 XML 포맷 (HTTP 페이로드)

```xml
<template name="order-template">
  <node name="ORDER">
    <value type="FIXED" dataType="STRING"/>
    <children>
      <node name="ITEM">
        <value type="VARIABLE" dataType="STRING">{ITEM_NAME}</value>
        <displayCondition>{SHOW} == 'Y'</displayCondition>
        <repeatCondition>{USE} == 'Y'</repeatCondition>
        <repeatCountExpr>{ITEM_NAME}</repeatCountExpr>
      </node>
    </children>
  </node>
</template>
```

구버전 포맷의 `<repeatCount>3</repeatCount>` 도 읽기 호환된다.

## 빌드 / 실행

### Backend

```bash
cd backend
javac --release 8 -encoding UTF-8 -cp lib/mariadb-java-client-2.7.12.jar \
      -d out $(find src -name "*.java")
java -cp out com.xmltemplate.Main                          # 데모 + 자체 검증

# API 서버 (기본: MariaDB 127.0.0.1:13306/xml_template)
java -cp out:lib/mariadb-java-client-2.7.12.jar com.xmltemplate.server.HttpApiServer 8080

# API 서버 (테스트: 메모리 저장소 - DB 불필요)
java -cp out com.xmltemplate.server.HttpApiServer 8080 --memory
```

접속 정보 변경은 환경 변수 `XMLTPL_DB_URL` / `XMLTPL_DB_USER` / `XMLTPL_DB_PASSWORD` 로.

### Frontend - React (기능 검증용)

```bash
cd frontend/react-app
npm install
npm run dev        # http://localhost:5173 (백엔드 8080 이 떠 있어야 미리보기 동작)
```

### Frontend - C# (Visual Studio 2013)

`frontend/XmlTemplateDesigner/XmlTemplateDesigner.csproj` 를 열고 빌드/실행.
툴바의 "서버" 주소(기본 `http://localhost:8080`)로 백엔드에 접속한다.
모든 .cs 파일은 UTF-8 with BOM (한국어 Windows 의 CP949 빌드 깨짐 방지 —
편집기에서 BOM 없는 UTF-8 로 재저장하지 말 것).

## 검증 상태

- Java: `javac --release 8` 컴파일 통과. `Main` 자체 검증 29건 전체 통과.
  MariaDB(13306) 실연결로 스키마 자동 생성 + API 왕복(저장/목록/조회/생성/삭제) 검증 완료.
- React: 브라우저(Chrome) 실기 테스트 완료 — 3단 화면 렌더링, 샘플 1/2/3 전환에 따른
  미리보기 변화(파라미터 기반 반복 3회/0회/5회, 함수 분기, 표시 조건), 노드 추가·편집·적용,
  MariaDB 저장/열기/삭제 왕복, 반복 횟수 형식 검증, 백엔드 조건식 오류의 미리보기 표시,
  2단계 삭제 확인까지 전 시나리오 통과. 콘솔 오류 0건.
- C#: 이번 라운드 변경 없음(백엔드 저장소 교체는 HTTP 계약에 영향 없음). 이전 정적 리뷰
  2회 통과 상태 유지. React 와 기능 동기화됨 (동일 데모 템플릿/샘플/검증 규칙/API 계약).
