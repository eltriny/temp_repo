# XML 템플릿 관리 시스템

XML 템플릿을 관리(생성/수정)하고, 외부에서 주어진 데이터와 템플릿을 바탕으로 새로운 XML을 생성하는 기능.

## 구성

| 구분 | 기술 | 역할 |
|------|------|------|
| `backend/` | Java 1.8 (외부 라이브러리 없음) | 템플릿 저장소 관리(CRUD), 외부 데이터 기반 XML 생성 엔진 |
| `frontend/` | C# / WinForms (Visual Studio 2013, .NET 4.5) | 템플릿 관리 화면 (Tree 편집 + 노드 정보 입력 + 미리보기) |

두 시스템은 **동일한 템플릿 파일 포맷**과 **동일한 생성 규칙**을 공유한다.
프론트엔드의 미리보기는 백엔드 호출 없이 동작하도록 생성 엔진을 C#으로 동일하게 구현했다.

```
xml-template/
├── backend/src/main/java/com/xmltemplate/
│   ├── model/        TemplateNode, ValueType        (템플릿 모델)
│   ├── expression/   ExpressionEvaluator            (조건식 평가기)
│   ├── engine/       XmlGenerator                   (XML 생성 엔진)
│   ├── template/     TemplateSerializer, TemplateManager (저장 포맷, CRUD)
│   └── Main.java                                    (데모 + 로직 검증)
└── frontend/XmlTemplateDesigner/
    ├── Model/        TemplateNode, NodeValueType
    ├── Engine/       ExpressionEvaluator, XmlGenerator (Java 와 동일 로직)
    ├── Template/     TemplateSerializer
    ├── MainForm.cs   3단 구성 메인 화면
    └── Program.cs
```

## 화면 구성 (frontend)

```
┌─────────────┬──────────────────┬──────────────────────────┐
│ XML 구조     │ 노드 정보          │ [샘플1] [샘플2] [샘플3]      │
│ (TreeView)  │  - 노드 이름        │ 샘플 데이터 (KEY=VALUE)     │
│             │  - 값 유형/노드 값   │──────────────────────────│
│ [자식 추가]  │  - 표시 조건        │ XML 미리보기               │
│ [노드 삭제]  │  - 반복 조건/횟수    │ (데이터 변경 시 즉시 갱신)   │
│             │  [적용]            │                          │
└─────────────┴──────────────────┴──────────────────────────┘
```

- 왼쪽: Tree 로 XML 구조 정의 (노드 추가/삭제)
- 가운데: 선택한 노드의 정보 입력 후 [적용]
- 오른쪽: 샘플 데이터 적용 버튼 + 데이터 편집 + 실시간 XML 미리보기
- 툴바: 새 템플릿 / 열기 / 저장 (템플릿 파일 포맷으로 저장 → 백엔드에서 그대로 사용)

## 노드 정보

### 노드 값 (3가지 유형)

| 유형 | 동작 | 예 |
|------|------|----|
| 고정값 (FIXED) | 입력한 텍스트 그대로 사용 | `품목` |
| 변수 (VARIABLE) | `{변수명}` 을 외부 데이터 값으로 치환 (없으면 빈 문자열) | `{ORDER_NO}`, `주문: {ORDER_NO}` |
| 함수 (FUNCTION) | 삼항연산자 조건식 평가 결과 사용 | `{TYPE} == 'D' ? '국내' : '해외'` |

### 노드 속성

- **표시 조건**: 조건식이 거짓이면 해당 노드(하위 포함)를 생성하지 않는다. 비어 있으면 항상 표시.
- **반복 조건 / 반복 횟수**: 반복 조건이 참이면 반복 횟수만큼 노드를 반복 생성.
  반복 조건이 비어 있고 반복 횟수가 2 이상이면 무조건 반복.
  반복 중에는 내장 변수 `{INDEX}` 가 1부터 시작하는 현재 회차로 치환된다.
  (루트 노드는 XML 규칙상 반복이 무시된다.)

### 조건식 문법

```
피연산자 : 노드 전체 경로        예) node1-1.node1-1-1   (해당 노드의 계산된 값)
          외부 데이터 변수       예) {PARAM}
          문자열 리터럴          예) 'VALUE'
          숫자                  예) 3, 1.5, -2
비교      : ==  !=  >  <  >=  <=   (양쪽이 숫자면 숫자 비교, 아니면 문자열 비교)
논리      : &&  ||  괄호 ( )
삼항      : 조건 ? 값1 : 값2       (중첩 가능, 함수 유형 노드 값에서 사용)
```

- 노드 경로는 루트 이름을 포함해도(`ORDER.HEADER.NO`) 루트 아래부터 시작해도(`HEADER.NO`) 된다.
- 존재하지 않는 변수/노드 경로는 빈 문자열로 평가된다 (미리보기 편의를 위한 관대한 처리).
- 노드 값의 순환 참조는 빈 문자열로 잘라서 무한 재귀를 막는다.

## 템플릿 파일 포맷 (공유 계약)

```xml
<template name="order-template">
  <node name="ORDER">
    <value type="FIXED"></value>
    <children>
      <node name="ITEM">
        <value type="VARIABLE">{ITEM_NAME}</value>
        <displayCondition>{SHOW} == 'Y'</displayCondition>
        <repeatCondition>{ITEM_COUNT} &gt; 1</repeatCondition>
        <repeatCount>3</repeatCount>
      </node>
    </children>
  </node>
</template>
```

노드 이름을 엘리먼트 이름이 아닌 `name` 속성에 저장하므로, 편집 중 아직 XML 이름 규칙에
맞지 않는 이름도 손실 없이 저장/복원된다.

## 외부 데이터 포맷

- 백엔드: `Map<String, String>` (변수명 → 값)
- 프론트엔드 샘플 데이터: 한 줄에 `변수명=값`, `#` 으로 시작하는 줄은 주석

## 빌드 / 실행

### Backend (Java 1.8)

```bash
cd backend
javac -encoding UTF-8 -d out $(find src -name "*.java")   # JDK 9+ 에서는 --release 8 추가
java -cp out com.xmltemplate.Main                          # 데모 + 자체 검증 실행
```

백엔드 API 사용 예:

```java
TemplateManager manager = new TemplateManager(new File("templates"));
manager.save("order-template", rootNode);            // 생성/수정
TemplateNode root = manager.load("order-template");  // 조회

Map<String, String> data = new HashMap<>();
data.put("ORDER_NO", "ORD-0001");
String xml = new XmlGenerator(root, data).generate(); // XML 생성
```

### Frontend (Visual Studio 2013)

`frontend/XmlTemplateDesigner/XmlTemplateDesigner.csproj` 를 VS2013 에서 열고 빌드/실행.
(UI 는 디자이너 파일 없이 코드로 구성되어 있어 csproj + cs 파일만으로 빌드된다.)

## Java / C# 구현 간 알려진 차이 (의도된 것)

- 출력 표기: Java 는 `<?xml ... standalone="no"?>` 와 `<A/>`, C# 은 `<?xml ...?>` 와
  `<A />` 로 직렬화 표기가 다르다. XML 의미와 템플릿 파일 호환성에는 영향 없음.
- 미리보기 보호 장치(프론트엔드 전용): 생성 엘리먼트 50,000개 초과 시 생성을 중단하고
  오류를 표시하며, 샘플 데이터 입력은 300ms 디바운스 후 갱신된다. 백엔드에는 제한 없음.

## 검증 상태

- Java: `javac --release 8` 컴파일 통과. `Main` 자체 검증(값 유형 3종 / 표시·반복 조건 /
  {INDEX} / 노드 경로 피연산자 / 직렬화 왕복 / CRUD / 오류 처리) 15건 +
  조건식 엣지 케이스(비교/논리/괄호/중첩 삼항/음수/오류 처리) 29건 전체 통과.
- C#: 작성 환경에 .NET 도구가 없어 정적 리뷰로 검증. 컴파일 오류 0건,
  C# 5.0 초과 문법 0건, .NET 4.5 에 없는 API 0건 확인.
  리뷰에서 나온 지적(소스 BOM, bool 비교 대소문자, 공백 집합/숫자 판정의 Java 와의
  차이, 콜론 노드명 오류 처리, 반복 횟수 절삭, 미리보기 프리즈, 도움말 라벨 잘림)은
  모두 수정 반영됨. 모든 .cs 파일은 UTF-8 with BOM (한국어 Windows 의 CP949 빌드
  깨짐 방지 — 편집기에서 BOM 없는 UTF-8 로 재저장하지 말 것).
