// 템플릿 노드 모델과 데모 데이터. (C# Model/TemplateNode.cs, MainForm 데모와 동기화)

let nextId = 1;

/** 새 템플릿 노드를 만든다. valueType: FIXED|VARIABLE|FUNCTION, dataType: STRING|NUMBER */
export function makeNode(name) {
  return {
    id: nextId++,
    name: name || '',
    valueType: 'FIXED',
    dataType: 'STRING',
    value: '',
    displayCondition: '',
    repeatCondition: '',
    repeatCountExpr: '',
    children: [],
  };
}

/** 트리에서 id 로 노드를 찾는다. */
export function findNode(root, id) {
  if (root.id === id) {
    return root;
  }
  for (const child of root.children) {
    const found = findNode(child, id);
    if (found) {
      return found;
    }
  }
  return null;
}

/** 트리에서 id 노드의 부모를 찾는다. (루트면 null) */
export function findParent(root, id) {
  for (const child of root.children) {
    if (child.id === id) {
      return root;
    }
    const found = findParent(child, id);
    if (found) {
      return found;
    }
  }
  return null;
}

/** 형제 중 중복되지 않는 이름을 만든다. (C# UniqueChildName 와 동일) */
export function uniqueChildName(parent, baseName) {
  let name = baseName;
  let suffix = 1;
  while (parent.children.some((c) => c.name === name)) {
    suffix++;
    name = baseName + '-' + suffix;
  }
  return name;
}

/** 트리 라벨. (C# BuildTreeLabel 와 동일 규칙) */
export function treeLabel(node) {
  let label = node.name;
  if (node.valueType === 'VARIABLE') {
    label += ' [변수]';
  } else if (node.valueType === 'FUNCTION') {
    label += ' [함수]';
  }
  if (node.displayCondition.trim().length > 0) {
    label += ' [표시조건]';
  }
  if (node.repeatCondition.trim().length > 0 || node.repeatCountExpr.length > 0) {
    label += ' [반복' + (node.repeatCountExpr ? ':' + node.repeatCountExpr : '') + ']';
  }
  return label;
}

/**
 * 데모 템플릿. (C# MainForm.BuildDemoTemplate 와 동일 구조)
 * ORDER
 *  ├─ HEADER (ORDER-NO / ORDER-TYPE-NAME(함수) / MEMO(표시조건))
 *  ├─ ITEMS ─ ITEM (반복 횟수 조건 {ITEM_NAME}) ─ SEQ/NAME/PRICE
 *  └─ DOMESTIC-ONLY (노드 경로 표시조건)
 */
export function buildDemoTemplate() {
  const root = makeNode('ORDER');

  const header = makeNode('HEADER');
  root.children.push(header);

  const orderNo = makeNode('ORDER-NO');
  orderNo.valueType = 'VARIABLE';
  orderNo.value = '{ORDER_NO}';
  header.children.push(orderNo);

  const typeName = makeNode('ORDER-TYPE-NAME');
  typeName.valueType = 'FUNCTION';
  typeName.value = "{ORDER_TYPE} == 'D' ? '국내' : '해외'";
  header.children.push(typeName);

  const memo = makeNode('MEMO');
  memo.valueType = 'VARIABLE';
  memo.value = '{MEMO}';
  memo.displayCondition = "{MEMO} != ''";
  header.children.push(memo);

  const items = makeNode('ITEMS');
  root.children.push(items);

  const item = makeNode('ITEM');
  item.repeatCountExpr = '{ITEM_NAME}';
  items.children.push(item);

  const seq = makeNode('SEQ');
  seq.valueType = 'VARIABLE';
  seq.value = '{INDEX}';
  seq.dataType = 'NUMBER';
  item.children.push(seq);

  const itemName = makeNode('NAME');
  itemName.valueType = 'VARIABLE';
  itemName.value = '{ITEM_NAME}';
  item.children.push(itemName);

  const itemPrice = makeNode('PRICE');
  itemPrice.valueType = 'VARIABLE';
  itemPrice.value = '{ITEM_PRICE}';
  itemPrice.dataType = 'NUMBER';
  item.children.push(itemPrice);

  const domesticOnly = makeNode('DOMESTIC-ONLY');
  domesticOnly.value = '국내 전용 항목';
  domesticOnly.displayCondition = "ORDER.HEADER.ORDER-TYPE-NAME == '국내'";
  root.children.push(domesticOnly);

  return root;
}

/* 샘플 데이터 3종 (C# Sample1/2/3 와 동일) */

export const SAMPLE_1 =
  '# 국내 주문 (품목 3건)\n' +
  'ORDER_NO=ORD-2026-0001\n' +
  'ORDER_TYPE=D\n' +
  'MEMO=빠른 배송 요청\n' +
  'ITEM_NAME_1=노트북\n' +
  'ITEM_PRICE_1=1500000\n' +
  'ITEM_NAME_2=마우스\n' +
  'ITEM_PRICE_2=30000\n' +
  'ITEM_NAME_3=키보드\n' +
  'ITEM_PRICE_3=80000';

export const SAMPLE_2 =
  '# 해외 주문 (품목 파라미터 없음 -> ITEM 미생성)\n' +
  'ORDER_NO=ORD-2026-0002\n' +
  'ORDER_TYPE=O\n' +
  'MEMO=';

export const SAMPLE_3 =
  '# 대량 주문 (품목 5건)\n' +
  'ORDER_NO=ORD-2026-0003\n' +
  'ORDER_TYPE=D\n' +
  'MEMO=대량 주문 할인 적용\n' +
  'ITEM_NAME_1=모니터\n' +
  'ITEM_PRICE_1=350000\n' +
  'ITEM_NAME_2=거치대\n' +
  'ITEM_PRICE_2=45000\n' +
  'ITEM_NAME_3=케이블\n' +
  'ITEM_PRICE_3=12000\n' +
  'ITEM_NAME_4=허브\n' +
  'ITEM_PRICE_4=55000\n' +
  'ITEM_NAME_5=웹캠\n' +
  'ITEM_PRICE_5=89000';
