// Java 백엔드 HTTP API 클라이언트. (C# Backend/BackendClient.cs 와 동일 계약)
//
//  GET    /templates          템플릿 이름 목록 (줄바꿈 구분)
//  GET    /templates/{name}   템플릿 XML 조회
//  PUT    /templates/{name}   템플릿 저장 (body: 템플릿 XML)
//  DELETE /templates/{name}   템플릿 삭제
//  POST   /preview            미리보기 생성 (body: previewRequest XML)

const TIMEOUT_MS = 10000;

async function request(baseUrl, method, path, body) {
  const url = (baseUrl || '').trim().replace(/\/+$/, '') + path;
  if (!/^https?:\/\//.test(url)) {
    throw new Error('서버 주소가 올바르지 않습니다 (http:// 또는 https:// 필요): ' + baseUrl);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let res;
  try {
    res = await fetch(url, {
      method,
      body: body != null ? body : undefined,
      headers: body != null ? { 'Content-Type': 'application/xml; charset=utf-8' } : undefined,
      signal: controller.signal,
    });
  } catch (e) {
    if (e.name === 'AbortError') {
      throw new Error('백엔드 응답 시간 초과: ' + baseUrl);
    }
    throw new Error('백엔드 서버에 연결할 수 없습니다: ' + baseUrl);
  } finally {
    clearTimeout(timer);
  }

  const text = await res.text();
  if (!res.ok) {
    throw new Error(text.trim() || 'HTTP ' + res.status);
  }
  return text;
}

export async function listTemplates(baseUrl) {
  const body = await request(baseUrl, 'GET', '/templates');
  return body.split('\n').map((s) => s.trim()).filter((s) => s.length > 0);
}

export function getTemplate(baseUrl, name) {
  return request(baseUrl, 'GET', '/templates/' + encodeURIComponent(name));
}

export function saveTemplate(baseUrl, name, templateXml) {
  return request(baseUrl, 'PUT', '/templates/' + encodeURIComponent(name), templateXml);
}

export function deleteTemplate(baseUrl, name) {
  return request(baseUrl, 'DELETE', '/templates/' + encodeURIComponent(name));
}

export function preview(baseUrl, previewRequestXml) {
  return request(baseUrl, 'POST', '/preview', previewRequestXml);
}
