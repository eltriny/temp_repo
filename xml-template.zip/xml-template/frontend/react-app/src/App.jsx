// XML 템플릿 관리 - React 프론트엔드 (기능 검증용)
//
// C# WinForms(XmlTemplateDesigner)와 동일한 기능/화면 구성:
//  - 왼쪽  : XML 구조 Tree (노드 추가/삭제)
//  - 가운데: 선택 노드 정보 입력 (이름/값 유형/데이터 타입/값/표시 조건/반복 조건/반복 횟수)
//  - 오른쪽: 샘플 데이터 버튼 + 데이터 입력 + XML 미리보기 (백엔드 /preview 호출, 400ms 디바운스)
//  - 툴바  : 새 템플릿 / 서버에서 열기 / 서버에 저장 / 서버에서 삭제 / 서버 주소 / 템플릿 이름
//
// 차이점: 브라우저 환경이므로 MessageBox 대신 상태 표시줄 + 2단계 삭제 확인을 쓴다.

import { useCallback, useEffect, useRef, useState } from 'react';
import './App.css';

import {
  buildDemoTemplate, findNode, findParent, makeNode,
  SAMPLE_1, SAMPLE_2, SAMPLE_3, treeLabel, uniqueChildName,
} from './model';
import {
  buildPreviewRequest, isValidRepeatCountExpr, isValidTemplateName,
  parseSampleData, templateToXml, xmlToTemplate,
} from './serializer';
import * as api from './api';

const DEBOUNCE_MS = 400;

export default function App() {
  const [root, setRoot] = useState(() => buildDemoTemplate());
  const [selectedId, setSelectedId] = useState(root.id);
  const [templateName, setTemplateName] = useState('order-template');
  const [serverUrl, setServerUrl] = useState('http://localhost:8080');
  const [sampleData, setSampleData] = useState(SAMPLE_1);

  const [preview, setPreview] = useState('');
  const [previewError, setPreviewError] = useState('');
  const [status, setStatus] = useState('준비');
  const [busy, setBusy] = useState(false);
  const [openList, setOpenList] = useState(null); // null = 닫힘, 배열 = 목록 표시
  const [confirmDelete, setConfirmDelete] = useState(false);

  const previewSeq = useRef(0);

  /* ---------------- 미리보기 (디바운스 + 마지막 요청만 반영) ---------------- */

  const refreshPreview = useCallback(async () => {
    const seq = ++previewSeq.current;
    try {
      const requestXml = buildPreviewRequest(
        templateName.trim(), root, parseSampleData(sampleData));
      const xml = await api.preview(serverUrl, requestXml);
      if (seq !== previewSeq.current) return;
      setPreview(xml);
      setPreviewError('');
    } catch (e) {
      if (seq !== previewSeq.current) return;
      setPreviewError(e.message);
    }
  }, [root, sampleData, serverUrl, templateName]);

  useEffect(() => {
    const timer = setTimeout(refreshPreview, DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [refreshPreview]);

  /* ---------------- 트리 조작 ---------------- */

  const selected = findNode(root, selectedId);

  function updateTree(mutate) {
    const next = structuredClone(root);
    mutate(next);
    setRoot(next);
  }

  function addChild() {
    if (!selected) {
      setStatus('자식을 추가할 노드를 먼저 선택하세요.');
      return;
    }
    let newId = null;
    updateTree((next) => {
      const parent = findNode(next, selectedId);
      const child = makeNode(uniqueChildName(parent, 'NEW-NODE'));
      parent.children.push(child);
      newId = child.id;
    });
    setSelectedId(newId);
    setStatus('노드를 추가했습니다.');
  }

  function deleteNode() {
    if (!selected) {
      setStatus('삭제할 노드를 먼저 선택하세요.');
      return;
    }
    if (selected.id === root.id) {
      setStatus('루트 노드는 삭제할 수 없습니다.');
      return;
    }
    updateTree((next) => {
      const parent = findParent(next, selectedId);
      parent.children = parent.children.filter((c) => c.id !== selectedId);
    });
    setSelectedId(root.id);
    setStatus(`'${selected.name}' 노드를 삭제했습니다.`);
  }

  function applyEditor(form) {
    const name = form.name.trim();
    if (name.length === 0) {
      setStatus('노드 이름을 입력하세요.');
      return;
    }
    const countExpr = form.repeatCountExpr.trim();
    if (!isValidRepeatCountExpr(countExpr)) {
      setStatus('반복 횟수는 0 이상의 숫자 또는 {파라미터} 형식이어야 합니다. 예) 3 또는 {ITEM_NAME}');
      return;
    }
    updateTree((next) => {
      const node = findNode(next, selectedId);
      node.name = name;
      node.valueType = form.valueType;
      node.dataType = form.dataType;
      node.value = form.value;
      node.displayCondition = form.displayCondition.trim();
      node.repeatCondition = form.repeatCondition.trim();
      node.repeatCountExpr = countExpr;
    });
    setStatus('적용했습니다.');
  }

  /* ---------------- 템플릿 저장/열기/삭제 (백엔드 API) ---------------- */

  function newTemplate() {
    const newRoot = makeNode('ROOT');
    setRoot(newRoot);
    setSelectedId(newRoot.id);
    setTemplateName('새 템플릿');
    setStatus('새 템플릿을 만들었습니다.');
  }

  async function openTemplateList() {
    if (busy) return;
    setBusy(true);
    try {
      const names = await api.listTemplates(serverUrl);
      if (names.length === 0) {
        setStatus('서버에 저장된 템플릿이 없습니다.');
        setOpenList(null);
      } else {
        setOpenList(names);
        setStatus('열 템플릿을 선택하세요.');
      }
    } catch (e) {
      setStatus('열기 실패: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function openTemplate(name) {
    setOpenList(null);
    setBusy(true);
    try {
      const xml = await api.getTemplate(serverUrl, name);
      const parsed = xmlToTemplate(xml, makeNode);
      setRoot(parsed.root);
      setSelectedId(parsed.root.id);
      setTemplateName(parsed.templateName.trim() || name);
      setStatus(`'${name}' 템플릿을 열었습니다.`);
    } catch (e) {
      setStatus('열기 실패: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function saveTemplate() {
    if (busy) return;
    const name = templateName.trim();
    if (name.length === 0) {
      setStatus('템플릿 이름을 입력하세요.');
      return;
    }
    if (!isValidTemplateName(name)) {
      setStatus("템플릿 이름에 '/' 또는 '\\' 은 사용할 수 없습니다.");
      return;
    }
    setBusy(true);
    try {
      const message = await api.saveTemplate(serverUrl, name, templateToXml(name, root));
      setStatus(message.trim());
    } catch (e) {
      setStatus('저장 실패: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function deleteTemplate() {
    if (busy) return;
    const name = templateName.trim();
    if (name.length === 0) {
      setStatus('삭제할 템플릿 이름을 입력하세요.');
      return;
    }
    if (!isValidTemplateName(name)) {
      setStatus("템플릿 이름에 '/' 또는 '\\' 은 사용할 수 없습니다.");
      return;
    }
    if (!confirmDelete) {
      /* 브라우저 confirm() 대신 2단계 클릭으로 확인 */
      setConfirmDelete(true);
      setStatus(`한 번 더 누르면 서버에서 '${name}' 템플릿을 삭제합니다.`);
      return;
    }
    setConfirmDelete(false);
    setBusy(true);
    try {
      const message = await api.deleteTemplate(serverUrl, name);
      setStatus(message.trim());
    } catch (e) {
      setStatus('삭제 실패: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  /* ---------------- 렌더 ---------------- */

  return (
    <div className="app">
      <header className="toolbar">
        <button onClick={newTemplate}>새 템플릿</button>
        <button onClick={openTemplateList} disabled={busy}>서버에서 열기...</button>
        <button onClick={saveTemplate} disabled={busy}>서버에 저장</button>
        <button
          onClick={deleteTemplate}
          disabled={busy}
          className={confirmDelete ? 'danger' : ''}
        >
          {confirmDelete ? '정말 삭제' : '서버에서 삭제'}
        </button>
        <span className="toolbar-label">서버:</span>
        <input
          className="toolbar-input"
          value={serverUrl}
          onChange={(e) => setServerUrl(e.target.value)}
        />
        <span className="toolbar-label">템플릿 이름:</span>
        <input
          className="toolbar-input"
          value={templateName}
          onChange={(e) => setTemplateName(e.target.value)}
        />
      </header>

      <div className="status-bar" data-testid="status">{status}</div>

      {openList && (
        <div className="open-panel">
          <b>서버 템플릿 목록</b>
          <ul>
            {openList.map((name) => (
              <li key={name}>
                <button onClick={() => openTemplate(name)}>{name}</button>
              </li>
            ))}
          </ul>
          <button onClick={() => setOpenList(null)}>닫기</button>
        </div>
      )}

      <main className="panes">
        <section className="pane tree-pane">
          <h3>XML 구조</h3>
          <div className="tree" data-testid="tree">
            <TreeNode node={root} selectedId={selectedId} onSelect={setSelectedId} />
          </div>
          <div className="tree-buttons">
            <button onClick={addChild}>자식 노드 추가</button>
            <button onClick={deleteNode}>노드 삭제</button>
          </div>
        </section>

        <section className="pane editor-pane">
          <h3>노드 정보</h3>
          {selected
            ? <NodeEditor key={selected.id} node={selected} onApply={applyEditor} />
            : <p>노드를 선택하세요.</p>}
        </section>

        <section className="pane preview-pane">
          <div className="sample-buttons">
            <button onClick={() => setSampleData(SAMPLE_1)}>샘플 1: 국내 주문</button>
            <button onClick={() => setSampleData(SAMPLE_2)}>샘플 2: 해외 주문</button>
            <button onClick={() => setSampleData(SAMPLE_3)}>샘플 3: 대량 주문</button>
          </div>
          <h3>샘플 데이터 (한 줄에 변수명=값, # 은 주석)</h3>
          <textarea
            className="sample-data"
            value={sampleData}
            onChange={(e) => setSampleData(e.target.value)}
            spellCheck={false}
          />
          <h3>XML 미리보기 (백엔드 생성 결과)</h3>
          {previewError
            ? <pre className="preview error" data-testid="preview">{'[미리보기 오류]\n' + previewError}</pre>
            : <pre className="preview" data-testid="preview">{preview}</pre>}
        </section>
      </main>
    </div>
  );
}

/* 트리 재귀 렌더 */
function TreeNode({ node, selectedId, onSelect }) {
  return (
    <div className="tree-node">
      <div
        className={'tree-item' + (node.id === selectedId ? ' selected' : '')}
        onClick={() => onSelect(node.id)}
      >
        {treeLabel(node)}
      </div>
      {node.children.length > 0 && (
        <div className="tree-children">
          {node.children.map((child) => (
            <TreeNode key={child.id} node={child} selectedId={selectedId} onSelect={onSelect} />
          ))}
        </div>
      )}
    </div>
  );
}

/* 노드 정보 편집 폼. key={node.id} 로 선택이 바뀌면 폼이 리셋된다. */
function NodeEditor({ node, onApply }) {
  const [form, setForm] = useState({
    name: node.name,
    valueType: node.valueType,
    dataType: node.dataType,
    value: node.value,
    displayCondition: node.displayCondition,
    repeatCondition: node.repeatCondition,
    repeatCountExpr: node.repeatCountExpr,
  });

  function set(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  return (
    <div className="editor-form">
      <label>노드 이름</label>
      <input value={form.name} onChange={(e) => set('name', e.target.value)} />

      <label>값 유형</label>
      <select value={form.valueType} onChange={(e) => set('valueType', e.target.value)}>
        <option value="FIXED">고정값</option>
        <option value="VARIABLE">변수</option>
        <option value="FUNCTION">함수</option>
      </select>

      <label>데이터 타입</label>
      <select value={form.dataType} onChange={(e) => set('dataType', e.target.value)}>
        <option value="STRING">문자열</option>
        <option value="NUMBER">숫자</option>
      </select>

      <label>노드 값</label>
      <textarea
        rows={3}
        value={form.value}
        onChange={(e) => set('value', e.target.value)}
        spellCheck={false}
      />

      <p className="help">
        고정값: 입력한 텍스트 그대로 사용<br />
        변수: {'{변수명}'} 을 외부 데이터로 치환 — 예) {'{ORDER_NO}'}<br />
        함수: 조건 ? 값1 : 값2 — 예) {"{TYPE} == 'D' ? '국내' : '해외'"}<br />
        데이터 타입 &#39;숫자&#39; 는 생성 시 숫자 형식 검증
      </p>

      <label>표시 조건</label>
      <input
        value={form.displayCondition}
        onChange={(e) => set('displayCondition', e.target.value)}
        spellCheck={false}
      />

      <label>반복 조건</label>
      <input
        value={form.repeatCondition}
        onChange={(e) => set('repeatCondition', e.target.value)}
        spellCheck={false}
      />

      <label>반복 횟수</label>
      <input
        value={form.repeatCountExpr}
        onChange={(e) => set('repeatCountExpr', e.target.value)}
        spellCheck={false}
      />

      <p className="help">
        피연산자: 노드 전체 경로 / {'{변수}'}<br />
        예) node1-1.node1-1-1 == &#39;VALUE&#39; &nbsp; {"{PARAM} == 'VALUE'"}<br />
        연산자: == != &gt; &lt; &gt;= &lt;= &amp;&amp; ||<br />
        반복 횟수: 숫자 또는 {'{파라미터}'} — {'{xxx}'} 는 xxx_1, xxx_2, ... 개수만큼 반복<br />
        반복 중 {'{xxx}'} 는 xxx_회차 값으로, {'{INDEX}'} 는 현재 회차로 치환<br />
        표시 조건이 거짓이면 노드를 생성하지 않음
      </p>

      <button className="apply" onClick={() => onApply(form)}>적용</button>
    </div>
  );
}
