// 템플릿 <-> XML 문자열 직렬화.
// C# Template/TemplateSerializer.cs 와 동일한 포맷 (Java 백엔드와 공유 계약).
//
// 템플릿 포맷:
//   <template name="템플릿이름">
//     <node name="ROOT">
//       <value type="FIXED" dataType="STRING">값</value>
//       <displayCondition>조건식</displayCondition>
//       <repeatCondition>조건식</repeatCondition>
//       <repeatCountExpr>3 또는 {파라미터}</repeatCountExpr>
//       <children> <node .../> </children>
//     </node>
//   </template>

const XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>\n';

/** 템플릿을 백엔드로 보낼 XML 문자열로 직렬화한다. */
export function templateToXml(templateName, root) {
  const doc = document.implementation.createDocument(null, 'template', null);
  doc.documentElement.setAttribute('name', templateName || '');
  doc.documentElement.appendChild(writeNode(doc, root));
  return XML_DECL + new XMLSerializer().serializeToString(doc);
}

/** 미리보기 요청(previewRequest) XML 문자열을 만든다. */
export function buildPreviewRequest(templateName, root, dataMap) {
  const doc = document.implementation.createDocument(null, 'previewRequest', null);
  const requestEl = doc.documentElement;

  const templateEl = doc.createElement('template');
  templateEl.setAttribute('name', templateName || '');
  templateEl.appendChild(writeNode(doc, root));
  requestEl.appendChild(templateEl);

  const dataEl = doc.createElement('data');
  Object.keys(dataMap).forEach((key) => {
    const paramEl = doc.createElement('param');
    paramEl.setAttribute('name', key);
    paramEl.textContent = dataMap[key];
    dataEl.appendChild(paramEl);
  });
  requestEl.appendChild(dataEl);

  return XML_DECL + new XMLSerializer().serializeToString(doc);
}

function writeNode(doc, node) {
  const el = doc.createElement('node');
  el.setAttribute('name', node.name || '');

  const valueEl = doc.createElement('value');
  valueEl.setAttribute('type', node.valueType);
  valueEl.setAttribute('dataType', node.dataType);
  valueEl.textContent = node.value || '';
  el.appendChild(valueEl);

  if (node.displayCondition) {
    const dcEl = doc.createElement('displayCondition');
    dcEl.textContent = node.displayCondition;
    el.appendChild(dcEl);
  }
  if (node.repeatCondition) {
    const rcEl = doc.createElement('repeatCondition');
    rcEl.textContent = node.repeatCondition;
    el.appendChild(rcEl);
  }
  if (node.repeatCountExpr) {
    const countEl = doc.createElement('repeatCountExpr');
    countEl.textContent = node.repeatCountExpr;
    el.appendChild(countEl);
  }

  if (node.children.length > 0) {
    const childrenEl = doc.createElement('children');
    node.children.forEach((child) => childrenEl.appendChild(writeNode(doc, child)));
    el.appendChild(childrenEl);
  }
  return el;
}

/**
 * 백엔드에서 받은 템플릿 XML 을 해석한다.
 * 반환: { templateName, root }  (makeNode 는 model.js 의 노드 생성 함수)
 */
export function xmlToTemplate(xml, makeNode) {
  const doc = new DOMParser().parseFromString(xml, 'application/xml');
  if (doc.querySelector('parsererror')) {
    throw new Error('템플릿 XML 해석 실패');
  }
  const templateEl = doc.documentElement;
  if (templateEl.tagName !== 'template') {
    throw new Error('템플릿 XML 이 아닙니다. (루트 엘리먼트: template 필요)');
  }
  const rootNodeEl = firstChildElement(templateEl, 'node');
  if (!rootNodeEl) {
    throw new Error('템플릿에 루트 node 가 없습니다.');
  }
  return {
    templateName: templateEl.getAttribute('name') || '',
    root: readNode(rootNodeEl, makeNode),
  };
}

function readNode(el, makeNode) {
  const node = makeNode(el.getAttribute('name') || '');

  const valueEl = firstChildElement(el, 'value');
  if (valueEl) {
    node.valueType = normalizeValueType(valueEl.getAttribute('type'));
    node.dataType = normalizeDataType(valueEl.getAttribute('dataType'));
    node.value = valueEl.textContent || '';
  }
  const dcEl = firstChildElement(el, 'displayCondition');
  if (dcEl) {
    node.displayCondition = dcEl.textContent || '';
  }
  const rcEl = firstChildElement(el, 'repeatCondition');
  if (rcEl) {
    node.repeatCondition = rcEl.textContent || '';
  }
  const countEl = firstChildElement(el, 'repeatCountExpr');
  if (countEl) {
    node.repeatCountExpr = (countEl.textContent || '').trim();
  } else {
    // 구버전 포맷 호환: <repeatCount>3</repeatCount>
    const oldCountEl = firstChildElement(el, 'repeatCount');
    if (oldCountEl) {
      const oldCount = parseInt((oldCountEl.textContent || '').trim(), 10);
      if (!isNaN(oldCount) && oldCount > 1) {
        node.repeatCountExpr = String(oldCount);
      }
    }
  }

  const childrenEl = firstChildElement(el, 'children');
  if (childrenEl) {
    for (const child of childrenEl.children) {
      if (child.tagName === 'node') {
        node.children.push(readNode(child, makeNode));
      }
    }
  }
  return node;
}

function firstChildElement(parent, tagName) {
  for (const child of parent.children) {
    if (child.tagName === tagName) {
      return child;
    }
  }
  return null;
}

function normalizeValueType(s) {
  const t = (s || '').trim().toUpperCase();
  return t === 'VARIABLE' || t === 'FUNCTION' ? t : 'FIXED';
}

function normalizeDataType(s) {
  return (s || '').trim().toUpperCase() === 'NUMBER' ? 'NUMBER' : 'STRING';
}

/** 샘플 데이터 텍스트를 변수 맵으로 해석한다. (한 줄에 KEY=VALUE, # 주석) */
export function parseSampleData(text) {
  const data = {};
  (text || '').split('\n').forEach((rawLine) => {
    const line = rawLine.trim();
    if (line.length === 0 || line.startsWith('#')) {
      return;
    }
    const eq = line.indexOf('=');
    if (eq < 1) {
      return;
    }
    data[line.substring(0, eq).trim()] = line.substring(eq + 1).trim();
  });
  return data;
}

/** 반복 횟수 조건 형식 검사: 빈 값 / 0 이상 숫자 / {파라미터} (C# IsValidRepeatCountExpr 와 동일) */
export function isValidRepeatCountExpr(expr) {
  if (expr.length === 0) {
    return true;
  }
  if (expr.startsWith('{') && expr.endsWith('}')) {
    return expr.substring(1, expr.length - 1).trim().length > 0;
  }
  return /^\+?\d+$/.test(expr);
}

/** 템플릿 이름 검사: '/', '\' 차단 (C# IsValidTemplateName 와 동일) */
export function isValidTemplateName(name) {
  return name.indexOf('/') < 0 && name.indexOf('\\') < 0;
}
