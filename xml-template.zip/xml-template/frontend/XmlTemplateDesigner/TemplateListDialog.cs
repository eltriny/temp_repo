﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace XmlTemplateDesigner
{
    /// <summary>
    /// 서버에 저장된 템플릿 목록에서 하나를 선택하는 다이얼로그.
    /// </summary>
    public class TemplateListDialog : Form
    {
        private readonly ListBox _list;

        public TemplateListDialog(string[] templateNames)
        {
            Text = "템플릿 열기";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            Size = new Size(360, 420);

            _list = new ListBox();
            _list.Dock = DockStyle.Fill;
            _list.Items.AddRange(templateNames);
            if (_list.Items.Count > 0)
            {
                _list.SelectedIndex = 0;
            }
            _list.DoubleClick += delegate(object sender, EventArgs e)
            {
                if (_list.SelectedItem != null)
                {
                    DialogResult = DialogResult.OK;
                }
            };

            Button ok = new Button();
            ok.Text = "열기";
            ok.DialogResult = DialogResult.OK;
            Button cancel = new Button();
            cancel.Text = "취소";
            cancel.DialogResult = DialogResult.Cancel;

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Bottom;
            buttons.FlowDirection = FlowDirection.RightToLeft;
            buttons.Height = 40;
            buttons.Padding = new Padding(6);
            buttons.Controls.Add(cancel);
            buttons.Controls.Add(ok);

            Controls.Add(_list);
            Controls.Add(buttons);
            _list.BringToFront();

            AcceptButton = ok;
            CancelButton = cancel;
        }

        /// <summary>선택된 템플릿 이름. 선택이 없으면 null.</summary>
        public string SelectedTemplateName
        {
            get { return (_list.SelectedItem == null) ? null : _list.SelectedItem.ToString(); }
        }
    }
}
