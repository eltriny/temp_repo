﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace XmlTemplateDesigner.Engine
{
    /// <summary>
    /// 템플릿 조건식 평가기. (Java 백엔드의 ExpressionEvaluator 와 동일한 문법/동작)
    ///
    /// 지원 문법 (우선순위 낮은 것부터):
    ///   expr       := ternary
    ///   ternary    := or ( '?' ternary ':' ternary )?
    ///   or         := and ( '||' and )*
    ///   and        := comparison ( '&amp;&amp;' comparison )*
    ///   comparison := operand ( ('=='|'!='|'&gt;='|'&lt;='|'&gt;'|'&lt;') operand )?
    ///   operand    := '(' expr ')' | STRING | NUMBER | VARIABLE | NODEPATH
    ///
    ///   STRING   : 작은따옴표 문자열. 예) 'VALUE'
    ///   NUMBER   : 정수/실수. 예) 3, 1.5, -2
    ///   VARIABLE : 외부 데이터 변수. 예) {PARAM}
    ///   NODEPATH : 노드 전체 경로. 예) node1-1.node1-1-1
    /// </summary>
    public class ExpressionEvaluator
    {
        /// <summary>노드 경로/외부 변수의 값을 제공하는 인터페이스. XML 생성기가 구현한다.</summary>
        public interface IResolver
        {
            string ResolveNodePath(string path);
            string ResolveVariable(string name);
        }

        /// <summary>식이 잘못되었을 때 발생하는 예외.</summary>
        public class ExpressionException : Exception
        {
            public ExpressionException(string message) : base(message)
            {
            }
        }

        private readonly IResolver _resolver;

        public ExpressionEvaluator(IResolver resolver)
        {
            _resolver = resolver;
        }

        /// <summary>식을 평가한다. 결과는 bool(조건식) 또는 string(값 식)이다.</summary>
        public object Evaluate(string expression)
        {
            List<Token> tokens = Tokenize(expression);
            Parser parser = new Parser(this, tokens);
            object result = parser.ParseExpression();
            parser.ExpectEnd();
            return result;
        }

        /// <summary>조건식을 평가해서 참/거짓을 반환한다.</summary>
        public bool EvaluateCondition(string expression)
        {
            return IsTruthy(Evaluate(expression));
        }

        public static bool IsTruthy(object value)
        {
            if (value == null)
            {
                return false;
            }
            if (value is bool)
            {
                return (bool)value;
            }
            return string.Equals(Convert.ToString(value).Trim(), "true",
                StringComparison.OrdinalIgnoreCase);
        }

        /* ------------------------------------------------------------------ */
        /* 어휘 분석 (Lexer)                                                    */
        /* ------------------------------------------------------------------ */

        private enum TokenType { String, Number, Variable, NodePath, Op, End }

        private sealed class Token
        {
            public readonly TokenType Type;
            public readonly string Text;

            public Token(TokenType type, string text)
            {
                Type = type;
                Text = text;
            }
        }

        private static List<Token> Tokenize(string expr)
        {
            if (expr == null)
            {
                throw new ExpressionException("식이 비어 있습니다.");
            }
            List<Token> tokens = new List<Token>();
            int i = 0;
            int len = expr.Length;

            while (i < len)
            {
                char c = expr[i];

                if (IsSpace(c))
                {
                    i++;
                    continue;
                }

                /* 문자열 리터럴 'xxx' */
                if (c == '\'')
                {
                    int end = expr.IndexOf('\'', i + 1);
                    if (end < 0)
                    {
                        throw new ExpressionException("문자열이 닫히지 않았습니다: " + expr.Substring(i));
                    }
                    tokens.Add(new Token(TokenType.String, expr.Substring(i + 1, end - i - 1)));
                    i = end + 1;
                    continue;
                }

                /* 외부 데이터 변수 {NAME} */
                if (c == '{')
                {
                    int end = expr.IndexOf('}', i + 1);
                    if (end < 0)
                    {
                        throw new ExpressionException("변수가 닫히지 않았습니다: " + expr.Substring(i));
                    }
                    string name = expr.Substring(i + 1, end - i - 1).Trim();
                    if (name.Length == 0)
                    {
                        throw new ExpressionException("변수 이름이 비어 있습니다.");
                    }
                    tokens.Add(new Token(TokenType.Variable, name));
                    i = end + 1;
                    continue;
                }

                /* 2문자 연산자 */
                if (i + 1 < len)
                {
                    string two = expr.Substring(i, 2);
                    if (two == "==" || two == "!=" || two == ">=" ||
                        two == "<=" || two == "&&" || two == "||")
                    {
                        tokens.Add(new Token(TokenType.Op, two));
                        i += 2;
                        continue;
                    }
                }

                /* 1문자 연산자 */
                if (c == '>' || c == '<' || c == '?' || c == ':' || c == '(' || c == ')')
                {
                    tokens.Add(new Token(TokenType.Op, c.ToString()));
                    i++;
                    continue;
                }

                /* 음수: 피연산자 위치에서 '-' 뒤에 숫자가 오는 경우 */
                if (c == '-' && i + 1 < len && char.IsDigit(expr[i + 1]) && ExpectsOperand(tokens))
                {
                    int start = i;
                    i++;
                    i = ConsumeNumber(expr, i);
                    tokens.Add(new Token(TokenType.Number, expr.Substring(start, i - start)));
                    continue;
                }

                /* 숫자 */
                if (char.IsDigit(c))
                {
                    int start = i;
                    i = ConsumeNumber(expr, i);
                    if (i < len && IsPathChar(expr[i]))
                    {
                        i = ConsumePath(expr, i);
                        tokens.Add(new Token(TokenType.NodePath, expr.Substring(start, i - start)));
                    }
                    else
                    {
                        tokens.Add(new Token(TokenType.Number, expr.Substring(start, i - start)));
                    }
                    continue;
                }

                /* 노드 경로 */
                if (IsPathStartChar(c))
                {
                    int start = i;
                    i = ConsumePath(expr, i);
                    tokens.Add(new Token(TokenType.NodePath, expr.Substring(start, i - start)));
                    continue;
                }

                throw new ExpressionException(
                    "해석할 수 없는 문자입니다: '" + c + "' (위치 " + i + ")");
            }

            tokens.Add(new Token(TokenType.End, ""));
            return tokens;
        }

        /// <summary>
        /// 식에서 무시하는 공백. Java 백엔드와 동일하게 명시적 집합으로 제한한다.
        /// (char.IsWhiteSpace 와 Character.isWhitespace 는 U+00A0 등에서 판정이 다르다.)
        /// </summary>
        private static bool IsSpace(char c)
        {
            return c == ' ' || c == '\t' || c == '\r' || c == '\n';
        }

        /// <summary>직전 토큰 기준으로 다음에 피연산자가 와야 하는 위치인지 판단 (음수 판별용).</summary>
        private static bool ExpectsOperand(List<Token> tokens)
        {
            if (tokens.Count == 0)
            {
                return true;
            }
            Token last = tokens[tokens.Count - 1];
            return last.Type == TokenType.Op && last.Text != ")";
        }

        private static int ConsumeNumber(string expr, int i)
        {
            int len = expr.Length;
            while (i < len && char.IsDigit(expr[i]))
            {
                i++;
            }
            if (i < len && expr[i] == '.' && i + 1 < len && char.IsDigit(expr[i + 1]))
            {
                i++;
                while (i < len && char.IsDigit(expr[i]))
                {
                    i++;
                }
            }
            return i;
        }

        private static bool IsPathStartChar(char c)
        {
            return char.IsLetter(c) || c == '_';
        }

        private static bool IsPathChar(char c)
        {
            return char.IsLetterOrDigit(c) || c == '_' || c == '-' || c == '.';
        }

        private static int ConsumePath(string expr, int i)
        {
            int len = expr.Length;
            while (i < len && IsPathChar(expr[i]))
            {
                i++;
            }
            /* 경로 끝의 '.' 은 경로에 포함하지 않는다. */
            while (i > 0 && expr[i - 1] == '.')
            {
                i--;
            }
            return i;
        }

        /* ------------------------------------------------------------------ */
        /* 구문 분석 + 평가 (Parser)                                            */
        /* ------------------------------------------------------------------ */

        private sealed class Parser
        {
            private readonly ExpressionEvaluator _owner;
            private readonly List<Token> _tokens;
            private int _pos;

            public Parser(ExpressionEvaluator owner, List<Token> tokens)
            {
                _owner = owner;
                _tokens = tokens;
                _pos = 0;
            }

            public object ParseExpression()
            {
                return ParseTernary();
            }

            /* ternary := or ( '?' ternary ':' ternary )? */
            private object ParseTernary()
            {
                object cond = ParseOr();
                if (MatchOp("?"))
                {
                    object whenTrue = ParseTernary();
                    ExpectOp(":");
                    object whenFalse = ParseTernary();
                    return IsTruthy(cond) ? whenTrue : whenFalse;
                }
                return cond;
            }

            /* or := and ( '||' and )* */
            private object ParseOr()
            {
                object left = ParseAnd();
                while (MatchOp("||"))
                {
                    object right = ParseAnd();
                    left = IsTruthy(left) || IsTruthy(right);
                }
                return left;
            }

            /* and := comparison ( '&&' comparison )* */
            private object ParseAnd()
            {
                object left = ParseComparison();
                while (MatchOp("&&"))
                {
                    object right = ParseComparison();
                    left = IsTruthy(left) && IsTruthy(right);
                }
                return left;
            }

            /* comparison := operand ( op operand )? */
            private object ParseComparison()
            {
                object left = ParseOperand();
                Token t = Peek();
                if (t.Type == TokenType.Op && IsComparisonOp(t.Text))
                {
                    _pos++;
                    object right = ParseOperand();
                    return Compare(left, right, t.Text);
                }
                return left;
            }

            private object ParseOperand()
            {
                Token t = Peek();
                switch (t.Type)
                {
                    case TokenType.String:
                        _pos++;
                        return t.Text;
                    case TokenType.Number:
                        _pos++;
                        return t.Text;
                    case TokenType.Variable:
                        _pos++;
                        return NullToEmpty(_owner._resolver.ResolveVariable(t.Text));
                    case TokenType.NodePath:
                        _pos++;
                        return NullToEmpty(_owner._resolver.ResolveNodePath(t.Text));
                    case TokenType.Op:
                        if (t.Text == "(")
                        {
                            _pos++;
                            object inner = ParseExpression();
                            ExpectOp(")");
                            return inner;
                        }
                        break;
                }
                throw new ExpressionException(
                    "피연산자가 필요한 위치에 '" + t.Text + "' 이(가) 있습니다.");
            }

            private bool MatchOp(string op)
            {
                Token t = Peek();
                if (t.Type == TokenType.Op && t.Text == op)
                {
                    _pos++;
                    return true;
                }
                return false;
            }

            private void ExpectOp(string op)
            {
                if (!MatchOp(op))
                {
                    throw new ExpressionException(
                        "'" + op + "' 이(가) 필요합니다. (현재: '" + Peek().Text + "')");
                }
            }

            public void ExpectEnd()
            {
                if (Peek().Type != TokenType.End)
                {
                    throw new ExpressionException(
                        "식 끝에 해석할 수 없는 내용이 있습니다: '" + Peek().Text + "'");
                }
            }

            private Token Peek()
            {
                return _tokens[_pos];
            }
        }

        private static bool IsComparisonOp(string op)
        {
            return op == "==" || op == "!=" || op == ">" ||
                   op == "<" || op == ">=" || op == "<=";
        }

        private static string NullToEmpty(string s)
        {
            return s ?? "";
        }

        /// <summary>
        /// 값을 문자열로 변환한다. bool 은 Java 와 동일하게 소문자 "true"/"false" 로
        /// 변환한다. (C# 의 Convert.ToString(bool) 은 "True"/"False" 를 반환하므로)
        /// </summary>
        private static string ToStringValue(object value)
        {
            if (value is bool)
            {
                return ((bool)value) ? "true" : "false";
            }
            return Convert.ToString(value);
        }

        /// <summary>두 값을 비교한다. 양쪽 모두 숫자면 숫자 비교, 아니면 문자열 비교.</summary>
        private static bool Compare(object left, object right, string op)
        {
            string ls = ToStringValue(left);
            string rs = ToStringValue(right);
            double ln, rn;
            bool leftIsNum = TryParseNumber(ls, out ln);
            bool rightIsNum = TryParseNumber(rs, out rn);

            int cmp;
            if (leftIsNum && rightIsNum)
            {
                cmp = ln.CompareTo(rn);
            }
            else
            {
                cmp = string.CompareOrdinal(ls, rs);
            }

            switch (op)
            {
                case "==": return cmp == 0;
                case "!=": return cmp != 0;
                case ">": return cmp > 0;
                case "<": return cmp < 0;
                case ">=": return cmp >= 0;
                default: return cmp <= 0; /* <= */
            }
        }

        private static bool TryParseNumber(string s, out double value)
        {
            value = 0;
            if (s == null || s.Trim().Length == 0)
            {
                return false;
            }
            return double.TryParse(s.Trim(), NumberStyles.Float,
                CultureInfo.InvariantCulture, out value);
        }
    }
}
