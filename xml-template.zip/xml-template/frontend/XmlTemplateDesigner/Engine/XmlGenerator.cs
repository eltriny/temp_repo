﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

using XmlTemplateDesigner.Model;

namespace XmlTemplateDesigner.Engine
{
    /// <summary>
    /// 템플릿 + 외부 데이터 -> XML 문자열 생성 엔진.
    /// (Java 백엔드의 XmlGenerator 와 동일한 규칙 - 미리보기 용도)
    ///
    /// 생성 규칙:
    ///  1. 표시 조건이 있고 false 로 평가되면 해당 노드(하위 포함)를 생성하지 않는다.
    ///  2. 반복 조건이 있고 true 로 평가되면 RepeatCount 만큼 반복 생성한다.
    ///     반복 조건이 없고 RepeatCount 가 2 이상이면 무조건 반복한다.
    ///  3. 자식이 있는 노드는 자식 엘리먼트를 갖고, 자식이 없는 노드는 값(텍스트)을 갖는다.
    ///  4. 값 유형별 처리: Fixed(그대로) / Variable({변수} 치환) / Function(조건식 평가)
    ///  5. 반복 중에는 내장 변수 {INDEX} 가 1부터 시작하는 현재 반복 회차로 치환된다.
    /// </summary>
    public class XmlGenerator : ExpressionEvaluator.IResolver
    {
        /// <summary>반복 회차를 나타내는 내장 변수 이름.</summary>
        public const string IndexVariable = "INDEX";

        public class GenerationException : Exception
        {
            public GenerationException(string message) : base(message)
            {
            }
        }

        private readonly TemplateNode _root;
        private readonly IDictionary<string, string> _data;
        private readonly ExpressionEvaluator _evaluator;

        /// <summary>생성 엘리먼트 수 상한 (0 = 무제한). 미리보기 UI 프리즈 방지용.</summary>
        private readonly int _maxElements;
        private int _elementCount;

        /// <summary>현재 반복 컨텍스트 (중첩 반복 시 가장 안쪽이 top).</summary>
        private readonly Stack<int> _indexStack = new Stack<int>();

        /// <summary>노드 값 계산 중 순환 참조 감지용.</summary>
        private readonly HashSet<TemplateNode> _resolving = new HashSet<TemplateNode>();

        private static readonly Regex VariablePattern = new Regex(@"\{([^{}]+)\}");

        public XmlGenerator(TemplateNode root, IDictionary<string, string> data)
            : this(root, data, 0)
        {
        }

        /// <param name="maxElements">생성 엘리먼트 수 상한 (0 = 무제한).
        /// 초과하면 GenerationException. 미리보기처럼 UI 스레드에서 동기 생성할 때 사용.</param>
        public XmlGenerator(TemplateNode root, IDictionary<string, string> data, int maxElements)
        {
            _root = root;
            _data = data ?? new Dictionary<string, string>();
            _maxElements = maxElements;
            _evaluator = new ExpressionEvaluator(this);
        }

        /// <summary>XML 문자열을 생성한다. 오류 시 GenerationException.</summary>
        public string Generate()
        {
            try
            {
                _elementCount = 0;
                XmlDocument doc = new XmlDocument();

                /* 루트는 XML 규칙상 1개만 허용되므로 반복 설정을 무시하고 1개만 생성한다. */
                List<XmlElement> rootElements = BuildElements(doc, _root, true);
                if (rootElements.Count == 0)
                {
                    throw new GenerationException(
                        "루트 노드가 표시 조건에 의해 제외되어 XML 을 생성할 수 없습니다.");
                }
                doc.AppendChild(doc.CreateXmlDeclaration("1.0", "UTF-8", null));
                doc.AppendChild(rootElements[0]);
                return Serialize(doc);
            }
            catch (GenerationException)
            {
                throw;
            }
            catch (ExpressionEvaluator.ExpressionException e)
            {
                throw new GenerationException("조건식 오류: " + e.Message);
            }
            catch (Exception e)
            {
                throw new GenerationException("XML 생성 실패: " + e.Message);
            }
        }

        /* ------------------------------------------------------------------ */
        /* 노드 -> 엘리먼트 변환                                                */
        /* ------------------------------------------------------------------ */

        private List<XmlElement> BuildElements(XmlDocument doc, TemplateNode node, bool isRoot)
        {
            List<XmlElement> result = new List<XmlElement>();

            /* 1. 표시 조건 */
            string displayCond = Trim(node.DisplayCondition);
            if (displayCond.Length > 0 && !EvaluateCondition(node, "표시 조건", displayCond))
            {
                return result;
            }

            /* 2. 반복 횟수 결정 */
            int count = 1;
            string repeatCond = Trim(node.RepeatCondition);
            bool isRepeating = repeatCond.Length > 0 || node.RepeatCount > 1;
            if (repeatCond.Length > 0)
            {
                if (EvaluateCondition(node, "반복 조건", repeatCond))
                {
                    count = Math.Max(1, node.RepeatCount);
                }
            }
            else if (node.RepeatCount > 1)
            {
                count = node.RepeatCount;
            }
            if (isRoot)
            {
                count = 1;
                isRepeating = false;
            }

            /*
             * 3. count 만큼 엘리먼트 생성.
             * 인덱스 스택은 반복 설정이 있는 노드만 사용한다.
             * 모든 노드가 push 하면 자식 노드의 인덱스(항상 1)가
             * 조상 반복 노드의 회차를 가려서 {INDEX} 가 늘 1이 되기 때문이다.
             */
            for (int i = 1; i <= count; i++)
            {
                if (isRepeating)
                {
                    _indexStack.Push(i);
                }
                try
                {
                    XmlElement el = CreateElement(doc, node);
                    if (node.HasChildren)
                    {
                        foreach (TemplateNode child in node.Children)
                        {
                            foreach (XmlElement childEl in BuildElements(doc, child, false))
                            {
                                el.AppendChild(childEl);
                            }
                        }
                    }
                    else
                    {
                        string value = ResolveNodeValue(node);
                        if (value.Length > 0)
                        {
                            el.AppendChild(doc.CreateTextNode(value));
                        }
                    }
                    result.Add(el);
                }
                finally
                {
                    if (isRepeating)
                    {
                        _indexStack.Pop();
                    }
                }
            }
            return result;
        }

        private XmlElement CreateElement(XmlDocument doc, TemplateNode node)
        {
            string name = Trim(node.Name);
            if (name.Length == 0)
            {
                throw new GenerationException(
                    "이름이 비어 있는 노드가 있습니다. (경로: " + node.GetPath() + ")");
            }
            /*
             * ':' 은 XML 네임스페이스 접두사로 해석된다. 네임스페이스 미선언 상태에서는
             * 환경(Java DOM / C# XmlDocument)에 따라 동작이 갈리므로 명시적으로 거부한다.
             * (Java 백엔드와 동일한 규칙)
             */
            if (name.IndexOf(':') >= 0)
            {
                throw new GenerationException(
                    "노드 이름에 ':' 은 사용할 수 없습니다: '" + name + "' (경로: " +
                    node.GetPath() + ")");
            }
            _elementCount++;
            if (_maxElements > 0 && _elementCount > _maxElements)
            {
                throw new GenerationException(
                    "생성되는 엘리먼트 수가 미리보기 제한(" + _maxElements +
                    "개)을 초과했습니다. 반복 조건/횟수를 확인하세요.");
            }
            try
            {
                /* CreateElement 는 이름 검증을 느슨하게 하므로 명시적으로 검증한다.
                 * VerifyNCName 은 콜론 없는 이름(NCName) 기준으로 검사한다. */
                XmlConvert.VerifyNCName(name);
                return doc.CreateElement(name);
            }
            catch (XmlException)
            {
                throw new GenerationException(
                    "'" + name + "' 은(는) XML 엘리먼트 이름으로 사용할 수 없습니다. (경로: " +
                    node.GetPath() + ")");
            }
            catch (ArgumentException)
            {
                throw new GenerationException(
                    "'" + name + "' 은(는) XML 엘리먼트 이름으로 사용할 수 없습니다. (경로: " +
                    node.GetPath() + ")");
            }
        }

        private bool EvaluateCondition(TemplateNode node, string kind, string condition)
        {
            try
            {
                return _evaluator.EvaluateCondition(condition);
            }
            catch (ExpressionEvaluator.ExpressionException e)
            {
                throw new GenerationException(
                    "노드 '" + node.GetPath() + "' 의 " + kind + " 오류: " + e.Message);
            }
        }

        /* ------------------------------------------------------------------ */
        /* 값 계산                                                              */
        /* ------------------------------------------------------------------ */

        /// <summary>노드의 값을 계산한다. 순환 참조가 감지되면 빈 문자열을 반환한다.</summary>
        private string ResolveNodeValue(TemplateNode node)
        {
            if (!_resolving.Add(node))
            {
                return "";
            }
            try
            {
                string raw = node.Value;
                if (raw == null)
                {
                    return "";
                }
                switch (node.ValueType)
                {
                    case NodeValueType.Variable:
                        return SubstituteVariables(raw);
                    case NodeValueType.Function:
                        string expr = Trim(raw);
                        if (expr.Length == 0)
                        {
                            return "";
                        }
                        object result = _evaluator.Evaluate(expr);
                        if (result is bool)
                        {
                            return ((bool)result) ? "true" : "false";
                        }
                        return Convert.ToString(result);
                    default:
                        return raw;
                }
            }
            catch (ExpressionEvaluator.ExpressionException e)
            {
                throw new GenerationException(
                    "노드 '" + node.GetPath() + "' 의 값(함수) 오류: " + e.Message);
            }
            finally
            {
                _resolving.Remove(node);
            }
        }

        /// <summary>문자열 안의 {변수명} 을 모두 외부 데이터 값으로 치환한다.</summary>
        private string SubstituteVariables(string text)
        {
            return VariablePattern.Replace(text, delegate(Match m)
            {
                return LookupVariable(m.Groups[1].Value.Trim());
            });
        }

        private string LookupVariable(string name)
        {
            if (name == IndexVariable)
            {
                return (_indexStack.Count == 0)
                    ? ""
                    : _indexStack.Peek().ToString(System.Globalization.CultureInfo.InvariantCulture);
            }
            string value;
            if (_data.TryGetValue(name, out value) && value != null)
            {
                return value;
            }
            return "";
        }

        /* ------------------------------------------------------------------ */
        /* IResolver 구현 (조건식의 피연산자 해석)                                */
        /* ------------------------------------------------------------------ */

        public string ResolveNodePath(string path)
        {
            TemplateNode node = FindNode(path);
            return (node == null) ? "" : ResolveNodeValue(node);
        }

        public string ResolveVariable(string name)
        {
            return LookupVariable(name);
        }

        /* ------------------------------------------------------------------ */
        /* 노드 경로 탐색                                                        */
        /* ------------------------------------------------------------------ */

        /// <summary>
        /// 전체 경로(예: "node1-1.node1-1-1")로 노드를 찾는다.
        /// 루트 이름을 포함한 경로와 루트 바로 아래부터 시작하는 경로 둘 다 허용한다.
        /// </summary>
        private TemplateNode FindNode(string path)
        {
            if (path == null || path.Trim().Length == 0)
            {
                return null;
            }
            string[] segments = path.Trim().Split('.');

            TemplateNode found = MatchFrom(_root, segments, 0);
            if (found != null)
            {
                return found;
            }
            foreach (TemplateNode child in _root.Children)
            {
                found = MatchFrom(child, segments, 0);
                if (found != null)
                {
                    return found;
                }
            }
            return null;
        }

        private static TemplateNode MatchFrom(TemplateNode node, string[] segments, int index)
        {
            if (node.Name != segments[index])
            {
                return null;
            }
            if (index == segments.Length - 1)
            {
                return node;
            }
            foreach (TemplateNode child in node.Children)
            {
                TemplateNode found = MatchFrom(child, segments, index + 1);
                if (found != null)
                {
                    return found;
                }
            }
            return null;
        }

        /* ------------------------------------------------------------------ */
        /* 직렬화                                                               */
        /* ------------------------------------------------------------------ */

        private static string Serialize(XmlDocument doc)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.Encoding = new UTF8Encoding(false);

            using (Utf8StringWriter sw = new Utf8StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    doc.Save(writer);
                }
                return sw.ToString();
            }
        }

        /// <summary>
        /// StringWriter 는 Encoding 이 UTF-16 이라 XML 선언이 utf-16 으로 찍힌다.
        /// Java 백엔드 출력과 맞추기 위해 UTF-8 로 보고하는 StringWriter.
        /// </summary>
        private sealed class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding
            {
                get { return Encoding.UTF8; }
            }
        }

        private static string Trim(string s)
        {
            return (s == null) ? "" : s.Trim();
        }
    }
}
