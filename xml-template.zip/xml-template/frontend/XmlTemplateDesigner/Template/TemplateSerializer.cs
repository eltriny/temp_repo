﻿using System;
using System.IO;
using System.Text;
using System.Xml;

using XmlTemplateDesigner.Model;

namespace XmlTemplateDesigner.Template
{
    /// <summary>
    /// 템플릿 &lt;-&gt; 템플릿 파일(XML) 직렬화. (Java 백엔드와 동일한 파일 포맷)
    ///
    /// 파일 포맷:
    ///   &lt;template name="템플릿이름"&gt;
    ///     &lt;node name="ROOT"&gt;
    ///       &lt;value type="FIXED"&gt;값&lt;/value&gt;
    ///       &lt;displayCondition&gt;조건식&lt;/displayCondition&gt;
    ///       &lt;repeatCondition&gt;조건식&lt;/repeatCondition&gt;
    ///       &lt;repeatCount&gt;3&lt;/repeatCount&gt;
    ///       &lt;children&gt; &lt;node ...&gt; ... &lt;/children&gt;
    ///     &lt;/node&gt;
    ///   &lt;/template&gt;
    /// </summary>
    public static class TemplateSerializer
    {
        public class SerializationException : Exception
        {
            public SerializationException(string message) : base(message)
            {
            }

            public SerializationException(string message, Exception inner) : base(message, inner)
            {
            }
        }

        /* ------------------------------------------------------------------ */
        /* 쓰기                                                                */
        /* ------------------------------------------------------------------ */

        public static void Save(string filePath, string templateName, TemplateNode root)
        {
            try
            {
                XmlDocument doc = ToDocument(templateName, root);
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.IndentChars = "  ";
                settings.Encoding = new UTF8Encoding(false);
                using (XmlWriter writer = XmlWriter.Create(filePath, settings))
                {
                    doc.Save(writer);
                }
            }
            catch (SerializationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new SerializationException("템플릿 파일 저장 실패: " + filePath, e);
            }
        }

        private static XmlDocument ToDocument(string templateName, TemplateNode root)
        {
            XmlDocument doc = new XmlDocument();
            doc.AppendChild(doc.CreateXmlDeclaration("1.0", "UTF-8", null));

            XmlElement templateEl = doc.CreateElement("template");
            templateEl.SetAttribute("name", templateName ?? "");
            doc.AppendChild(templateEl);
            templateEl.AppendChild(WriteNode(doc, root));
            return doc;
        }

        private static XmlElement WriteNode(XmlDocument doc, TemplateNode node)
        {
            XmlElement el = doc.CreateElement("node");
            el.SetAttribute("name", node.Name ?? "");

            XmlElement valueEl = doc.CreateElement("value");
            valueEl.SetAttribute("type", NodeValueTypeUtil.ToSerialString(node.ValueType));
            valueEl.InnerText = node.Value;
            el.AppendChild(valueEl);

            if (node.DisplayCondition.Length > 0)
            {
                XmlElement dcEl = doc.CreateElement("displayCondition");
                dcEl.InnerText = node.DisplayCondition;
                el.AppendChild(dcEl);
            }
            if (node.RepeatCondition.Length > 0)
            {
                XmlElement rcEl = doc.CreateElement("repeatCondition");
                rcEl.InnerText = node.RepeatCondition;
                el.AppendChild(rcEl);
            }
            if (node.RepeatCount > 1)
            {
                XmlElement countEl = doc.CreateElement("repeatCount");
                countEl.InnerText = node.RepeatCount.ToString(
                    System.Globalization.CultureInfo.InvariantCulture);
                el.AppendChild(countEl);
            }

            if (node.HasChildren)
            {
                XmlElement childrenEl = doc.CreateElement("children");
                foreach (TemplateNode child in node.Children)
                {
                    childrenEl.AppendChild(WriteNode(doc, child));
                }
                el.AppendChild(childrenEl);
            }
            return el;
        }

        /* ------------------------------------------------------------------ */
        /* 읽기                                                                */
        /* ------------------------------------------------------------------ */

        /// <summary>파일에서 템플릿을 읽는다. templateName 으로 템플릿 이름이 반환된다.</summary>
        public static TemplateNode Load(string filePath, out string templateName)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(filePath);

                XmlElement templateEl = doc.DocumentElement;
                if (templateEl == null || templateEl.Name != "template")
                {
                    throw new SerializationException(
                        "템플릿 파일이 아닙니다. (루트 엘리먼트: template 필요)");
                }
                templateName = templateEl.GetAttribute("name");

                XmlElement rootNodeEl = FirstChildElement(templateEl, "node");
                if (rootNodeEl == null)
                {
                    throw new SerializationException("템플릿에 루트 node 가 없습니다.");
                }
                return ReadNode(rootNodeEl);
            }
            catch (SerializationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new SerializationException("템플릿 파일 읽기 실패: " + filePath, e);
            }
        }

        private static TemplateNode ReadNode(XmlElement el)
        {
            TemplateNode node = new TemplateNode(el.GetAttribute("name"));

            XmlElement valueEl = FirstChildElement(el, "value");
            if (valueEl != null)
            {
                node.ValueType = NodeValueTypeUtil.FromSerialString(valueEl.GetAttribute("type"));
                node.Value = valueEl.InnerText;
            }

            XmlElement dcEl = FirstChildElement(el, "displayCondition");
            if (dcEl != null)
            {
                node.DisplayCondition = dcEl.InnerText;
            }
            XmlElement rcEl = FirstChildElement(el, "repeatCondition");
            if (rcEl != null)
            {
                node.RepeatCondition = rcEl.InnerText;
            }
            XmlElement countEl = FirstChildElement(el, "repeatCount");
            if (countEl != null)
            {
                node.RepeatCount = ParseIntSafe(countEl.InnerText, 1);
            }

            XmlElement childrenEl = FirstChildElement(el, "children");
            if (childrenEl != null)
            {
                foreach (XmlNode child in childrenEl.ChildNodes)
                {
                    XmlElement childEl = child as XmlElement;
                    if (childEl != null && childEl.Name == "node")
                    {
                        node.AddChild(ReadNode(childEl));
                    }
                }
            }
            return node;
        }

        /* ------------------------------------------------------------------ */
        /* 유틸                                                                 */
        /* ------------------------------------------------------------------ */

        private static XmlElement FirstChildElement(XmlElement parent, string tagName)
        {
            foreach (XmlNode child in parent.ChildNodes)
            {
                XmlElement el = child as XmlElement;
                if (el != null && el.Name == tagName)
                {
                    return el;
                }
            }
            return null;
        }

        private static int ParseIntSafe(string s, int defaultValue)
        {
            int value;
            if (s != null && int.TryParse(s.Trim(), out value))
            {
                return value;
            }
            return defaultValue;
        }
    }
}
