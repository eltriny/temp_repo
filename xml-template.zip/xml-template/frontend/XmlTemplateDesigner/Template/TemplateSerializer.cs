﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

using XmlTemplateDesigner.Model;

namespace XmlTemplateDesigner.Template
{
    /// <summary>
    /// 템플릿 &lt;-&gt; XML 문자열 직렬화.
    /// Java 백엔드와 HTTP 로 주고받는 페이로드를 만들고 해석한다.
    ///
    /// 템플릿 포맷:
    ///   &lt;template name="템플릿이름"&gt;
    ///     &lt;node name="ROOT"&gt;
    ///       &lt;value type="FIXED" dataType="STRING"&gt;값&lt;/value&gt;
    ///       &lt;displayCondition&gt;조건식&lt;/displayCondition&gt;
    ///       &lt;repeatCondition&gt;조건식&lt;/repeatCondition&gt;
    ///       &lt;repeatCountExpr&gt;3 또는 {파라미터}&lt;/repeatCountExpr&gt;
    ///       &lt;children&gt; &lt;node ...&gt; ... &lt;/children&gt;
    ///     &lt;/node&gt;
    ///   &lt;/template&gt;
    ///
    /// 미리보기 요청 포맷 (POST /preview):
    ///   &lt;previewRequest&gt;
    ///     &lt;template ...&gt; ... &lt;/template&gt;
    ///     &lt;data&gt;&lt;param name="K"&gt;V&lt;/param&gt;...&lt;/data&gt;
    ///   &lt;/previewRequest&gt;
    /// </summary>
    public static class TemplateSerializer
    {
        public class SerializationException : Exception
        {
            public SerializationException(string message) : base(message)
            {
            }

            public SerializationException(string message, Exception inner) : base(message, inner)
            {
            }
        }

        /* ------------------------------------------------------------------ */
        /* 쓰기                                                                */
        /* ------------------------------------------------------------------ */

        /// <summary>템플릿을 백엔드로 보낼 XML 문자열로 직렬화한다.</summary>
        public static string ToXmlString(string templateName, TemplateNode root)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.AppendChild(doc.CreateXmlDeclaration("1.0", "UTF-8", null));

                XmlElement templateEl = doc.CreateElement("template");
                templateEl.SetAttribute("name", templateName ?? "");
                doc.AppendChild(templateEl);
                templateEl.AppendChild(WriteNode(doc, root));
                return Serialize(doc);
            }
            catch (SerializationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new SerializationException("템플릿 직렬화 실패: " + e.Message, e);
            }
        }

        /// <summary>미리보기 요청(previewRequest) XML 문자열을 만든다.</summary>
        public static string ToPreviewRequestString(string templateName, TemplateNode root,
            IDictionary<string, string> data)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.AppendChild(doc.CreateXmlDeclaration("1.0", "UTF-8", null));

                XmlElement requestEl = doc.CreateElement("previewRequest");
                doc.AppendChild(requestEl);

                XmlElement templateEl = doc.CreateElement("template");
                templateEl.SetAttribute("name", templateName ?? "");
                templateEl.AppendChild(WriteNode(doc, root));
                requestEl.AppendChild(templateEl);

                XmlElement dataEl = doc.CreateElement("data");
                if (data != null)
                {
                    foreach (KeyValuePair<string, string> entry in data)
                    {
                        XmlElement paramEl = doc.CreateElement("param");
                        paramEl.SetAttribute("name", entry.Key);
                        paramEl.InnerText = entry.Value ?? "";
                        dataEl.AppendChild(paramEl);
                    }
                }
                requestEl.AppendChild(dataEl);
                return Serialize(doc);
            }
            catch (SerializationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new SerializationException("미리보기 요청 직렬화 실패: " + e.Message, e);
            }
        }

        private static XmlElement WriteNode(XmlDocument doc, TemplateNode node)
        {
            XmlElement el = doc.CreateElement("node");
            el.SetAttribute("name", node.Name ?? "");

            XmlElement valueEl = doc.CreateElement("value");
            valueEl.SetAttribute("type", NodeValueTypeUtil.ToSerialString(node.ValueType));
            valueEl.SetAttribute("dataType", NodeDataTypeUtil.ToSerialString(node.DataType));
            valueEl.InnerText = node.Value;
            el.AppendChild(valueEl);

            if (node.DisplayCondition.Length > 0)
            {
                XmlElement dcEl = doc.CreateElement("displayCondition");
                dcEl.InnerText = node.DisplayCondition;
                el.AppendChild(dcEl);
            }
            if (node.RepeatCondition.Length > 0)
            {
                XmlElement rcEl = doc.CreateElement("repeatCondition");
                rcEl.InnerText = node.RepeatCondition;
                el.AppendChild(rcEl);
            }
            if (node.RepeatCountExpr.Length > 0)
            {
                XmlElement countEl = doc.CreateElement("repeatCountExpr");
                countEl.InnerText = node.RepeatCountExpr;
                el.AppendChild(countEl);
            }

            if (node.HasChildren)
            {
                XmlElement childrenEl = doc.CreateElement("children");
                foreach (TemplateNode child in node.Children)
                {
                    childrenEl.AppendChild(WriteNode(doc, child));
                }
                el.AppendChild(childrenEl);
            }
            return el;
        }

        /* ------------------------------------------------------------------ */
        /* 읽기                                                                */
        /* ------------------------------------------------------------------ */

        /// <summary>백엔드에서 받은 템플릿 XML 을 해석한다. templateName 으로 템플릿 이름이 반환된다.</summary>
        public static TemplateNode FromXmlString(string xml, out string templateName)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xml);

                XmlElement templateEl = doc.DocumentElement;
                if (templateEl == null || templateEl.Name != "template")
                {
                    throw new SerializationException(
                        "템플릿 XML 이 아닙니다. (루트 엘리먼트: template 필요)");
                }
                templateName = templateEl.GetAttribute("name");

                XmlElement rootNodeEl = FirstChildElement(templateEl, "node");
                if (rootNodeEl == null)
                {
                    throw new SerializationException("템플릿에 루트 node 가 없습니다.");
                }
                return ReadNode(rootNodeEl);
            }
            catch (SerializationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new SerializationException("템플릿 XML 해석 실패: " + e.Message, e);
            }
        }

        private static TemplateNode ReadNode(XmlElement el)
        {
            TemplateNode node = new TemplateNode(el.GetAttribute("name"));

            XmlElement valueEl = FirstChildElement(el, "value");
            if (valueEl != null)
            {
                node.ValueType = NodeValueTypeUtil.FromSerialString(valueEl.GetAttribute("type"));
                node.DataType = NodeDataTypeUtil.FromSerialString(valueEl.GetAttribute("dataType"));
                node.Value = valueEl.InnerText;
            }

            XmlElement dcEl = FirstChildElement(el, "displayCondition");
            if (dcEl != null)
            {
                node.DisplayCondition = dcEl.InnerText;
            }
            XmlElement rcEl = FirstChildElement(el, "repeatCondition");
            if (rcEl != null)
            {
                node.RepeatCondition = rcEl.InnerText;
            }
            XmlElement countEl = FirstChildElement(el, "repeatCountExpr");
            if (countEl != null)
            {
                node.RepeatCountExpr = countEl.InnerText;
            }
            else
            {
                /* 구버전 포맷 호환: <repeatCount>3</repeatCount> */
                XmlElement oldCountEl = FirstChildElement(el, "repeatCount");
                if (oldCountEl != null)
                {
                    int oldCount;
                    if (int.TryParse(oldCountEl.InnerText.Trim(), out oldCount) && oldCount > 1)
                    {
                        node.RepeatCountExpr = oldCount.ToString(
                            System.Globalization.CultureInfo.InvariantCulture);
                    }
                }
            }

            XmlElement childrenEl = FirstChildElement(el, "children");
            if (childrenEl != null)
            {
                foreach (XmlNode child in childrenEl.ChildNodes)
                {
                    XmlElement childEl = child as XmlElement;
                    if (childEl != null && childEl.Name == "node")
                    {
                        node.AddChild(ReadNode(childEl));
                    }
                }
            }
            return node;
        }

        /* ------------------------------------------------------------------ */
        /* 유틸                                                                 */
        /* ------------------------------------------------------------------ */

        private static string Serialize(XmlDocument doc)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.Encoding = new UTF8Encoding(false);

            using (Utf8StringWriter sw = new Utf8StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sw, settings))
                {
                    doc.Save(writer);
                }
                return sw.ToString();
            }
        }

        /// <summary>XML 선언에 UTF-8 로 표기되도록 하는 StringWriter.</summary>
        private sealed class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding
            {
                get { return Encoding.UTF8; }
            }
        }

        private static XmlElement FirstChildElement(XmlElement parent, string tagName)
        {
            foreach (XmlNode child in parent.ChildNodes)
            {
                XmlElement el = child as XmlElement;
                if (el != null && el.Name == tagName)
                {
                    return el;
                }
            }
            return null;
        }
    }
}
