﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("XmlTemplateDesigner")]
[assembly: AssemblyDescription("XML 템플릿 관리 도구")]
[assembly: AssemblyProduct("XmlTemplateDesigner")]
[assembly: ComVisible(false)]
[assembly: Guid("3f9c1a2e-8b4d-4c6a-9e0f-1d2b3c4a5e6f")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
