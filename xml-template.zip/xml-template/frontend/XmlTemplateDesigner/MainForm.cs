﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using XmlTemplateDesigner.Engine;
using XmlTemplateDesigner.Model;

namespace XmlTemplateDesigner
{
    /// <summary>
    /// 템플릿 관리 메인 화면.
    ///
    /// 3단 구성:
    ///  - 왼쪽  : XML 구조를 정의하는 Tree 영역 (노드 추가/삭제)
    ///  - 가운데: 선택된 노드의 정보 입력 영역 (이름/값/표시 조건/반복 조건)
    ///  - 오른쪽: 샘플 데이터 적용 버튼 + 데이터 입력 + XML 미리보기
    /// </summary>
    public class MainForm : Form
    {
        /* 왼쪽: 트리 */
        private TreeView _tree;
        private Button _btnAddChild;
        private Button _btnDeleteNode;

        /* 가운데: 노드 정보 편집 */
        private TextBox _txtName;
        private ComboBox _cboValueType;
        private TextBox _txtValue;
        private TextBox _txtDisplayCondition;
        private TextBox _txtRepeatCondition;
        private NumericUpDown _numRepeatCount;
        private Button _btnApply;
        private TableLayoutPanel _editorPanel;

        /* 오른쪽: 샘플 데이터 + 미리보기 */
        private TextBox _txtSampleData;
        private TextBox _txtPreview;

        /* 툴바 */
        private ToolStripTextBox _txtTemplateName;

        /* 레이아웃 */
        private SplitContainer _splitOuter;
        private SplitContainer _splitInner;

        /* 미리보기 갱신 디바운스 (키 입력마다 전체 재생성하지 않도록) */
        private Timer _previewTimer;

        /* 미리보기에서 생성을 허용하는 최대 엘리먼트 수 (UI 프리즈 방지) */
        private const int PreviewMaxElements = 50000;

        /* 모델 */
        private TemplateNode _rootNode;

        private const string Sample1 =
            "# 국내 주문 (반복 3회, 메모 있음)\r\n" +
            "ORDER_NO=ORD-2026-0001\r\n" +
            "ORDER_TYPE=D\r\n" +
            "ITEM_COUNT=3\r\n" +
            "MEMO=빠른 배송 요청";

        private const string Sample2 =
            "# 해외 주문 (반복 없음, 메모 없음)\r\n" +
            "ORDER_NO=ORD-2026-0002\r\n" +
            "ORDER_TYPE=O\r\n" +
            "ITEM_COUNT=0\r\n" +
            "MEMO=";

        private const string Sample3 =
            "# 대량 주문\r\n" +
            "ORDER_NO=ORD-2026-0003\r\n" +
            "ORDER_TYPE=D\r\n" +
            "ITEM_COUNT=10\r\n" +
            "MEMO=대량 주문 할인 적용";

        public MainForm()
        {
            InitializeUi();

            _previewTimer = new Timer();
            _previewTimer.Interval = 300;
            _previewTimer.Tick += OnPreviewTimerTick;

            _txtSampleData.Text = Sample1;
            LoadTemplate(BuildDemoTemplate(), "order-template");
        }

        protected override void Dispose(bool disposing)
        {
            /*
             * Timer 는 Control 이 아니라 폼 종료 시 자동 Dispose 대상이 아니다.
             * Enabled 상태로 남으면 종료 처리 중 WM_TIMER 가 Dispose 된 컨트롤에
             * 접근할 수 있고, GCHandle 로 폼까지 계속 살아 있게 된다.
             */
            if (disposing && _previewTimer != null)
            {
                _previewTimer.Stop();
                _previewTimer.Dispose();
                _previewTimer = null;
            }
            base.Dispose(disposing);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            /*
             * SplitterDistance 는 컨트롤이 실제 크기를 가진 뒤에 설정한다.
             * 레이아웃 전(기본 크기 150px)에 설정하면 Width - Panel2MinSize 를
             * 초과해서 예외가 발생할 수 있다.
             */
            _splitOuter.SplitterDistance = 280;
            _splitInner.SplitterDistance = 380;
        }

        /* ------------------------------------------------------------------ */
        /* UI 구성                                                              */
        /* ------------------------------------------------------------------ */

        private void InitializeUi()
        {
            Text = "XML 템플릿 관리";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1200, 720);
            MinimumSize = new Size(900, 550);

            ToolStrip toolStrip = BuildToolStrip();

            _splitOuter = new SplitContainer();
            _splitOuter.Dock = DockStyle.Fill;
            _splitOuter.Orientation = Orientation.Vertical;

            _splitInner = new SplitContainer();
            _splitInner.Dock = DockStyle.Fill;
            _splitInner.Orientation = Orientation.Vertical;

            _splitOuter.Panel2.Controls.Add(_splitInner);

            BuildTreePane(_splitOuter.Panel1);
            BuildEditorPane(_splitInner.Panel1);
            BuildPreviewPane(_splitInner.Panel2);

            Controls.Add(_splitOuter);
            Controls.Add(toolStrip);
            _splitOuter.BringToFront();
        }

        private ToolStrip BuildToolStrip()
        {
            ToolStrip strip = new ToolStrip();
            strip.GripStyle = ToolStripGripStyle.Hidden;

            ToolStripButton btnNew = new ToolStripButton("새 템플릿");
            btnNew.Click += OnNewTemplate;
            ToolStripButton btnOpen = new ToolStripButton("열기...");
            btnOpen.Click += OnOpenTemplate;
            ToolStripButton btnSave = new ToolStripButton("저장...");
            btnSave.Click += OnSaveTemplate;

            _txtTemplateName = new ToolStripTextBox();
            _txtTemplateName.Text = "새 템플릿";
            _txtTemplateName.Size = new Size(200, 25);

            strip.Items.Add(btnNew);
            strip.Items.Add(btnOpen);
            strip.Items.Add(btnSave);
            strip.Items.Add(new ToolStripSeparator());
            strip.Items.Add(new ToolStripLabel("템플릿 이름:"));
            strip.Items.Add(_txtTemplateName);
            return strip;
        }

        private void BuildTreePane(Control parent)
        {
            Label title = new Label();
            title.Text = "XML 구조";
            title.Dock = DockStyle.Top;
            title.Height = 22;
            title.TextAlign = ContentAlignment.MiddleLeft;
            title.Font = new Font(Font, FontStyle.Bold);

            _tree = new TreeView();
            _tree.Dock = DockStyle.Fill;
            _tree.HideSelection = false;
            _tree.AfterSelect += OnTreeAfterSelect;

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Bottom;
            buttons.Height = 34;
            buttons.FlowDirection = FlowDirection.LeftToRight;
            buttons.Padding = new Padding(2);

            _btnAddChild = new Button();
            _btnAddChild.Text = "자식 노드 추가";
            _btnAddChild.AutoSize = true;
            _btnAddChild.Click += OnAddChildNode;

            _btnDeleteNode = new Button();
            _btnDeleteNode.Text = "노드 삭제";
            _btnDeleteNode.AutoSize = true;
            _btnDeleteNode.Click += OnDeleteNode;

            buttons.Controls.Add(_btnAddChild);
            buttons.Controls.Add(_btnDeleteNode);

            parent.Controls.Add(_tree);
            parent.Controls.Add(title);
            parent.Controls.Add(buttons);
            _tree.BringToFront();
        }

        private void BuildEditorPane(Control parent)
        {
            _editorPanel = new TableLayoutPanel();
            _editorPanel.Dock = DockStyle.Fill;
            _editorPanel.ColumnCount = 2;
            _editorPanel.Padding = new Padding(8);
            _editorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80F));
            _editorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            Label title = new Label();
            title.Text = "노드 정보";
            title.Font = new Font(Font, FontStyle.Bold);
            title.AutoSize = true;
            AddEditorRow(title, null);

            _txtName = new TextBox();
            _txtName.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("노드 이름"), _txtName);

            _cboValueType = new ComboBox();
            _cboValueType.DropDownStyle = ComboBoxStyle.DropDownList;
            _cboValueType.Items.Add("고정값");
            _cboValueType.Items.Add("변수");
            _cboValueType.Items.Add("함수");
            _cboValueType.SelectedIndex = 0;
            _cboValueType.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("값 유형"), _cboValueType);

            _txtValue = new TextBox();
            _txtValue.Multiline = true;
            _txtValue.Height = 52;
            _txtValue.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("노드 값"), _txtValue, 56);

            AddEditorRow(null, MakeHelpLabel(
                "고정값: 입력한 텍스트 그대로 사용\r\n" +
                "변수: {변수명} 을 외부 데이터로 치환\r\n" +
                "  예) {ORDER_NO}\r\n" +
                "함수: 조건 ? 값1 : 값2\r\n" +
                "  예) {TYPE} == 'D' ? '국내' : '해외'"));

            _txtDisplayCondition = new TextBox();
            _txtDisplayCondition.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("표시 조건"), _txtDisplayCondition);

            _txtRepeatCondition = new TextBox();
            _txtRepeatCondition.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("반복 조건"), _txtRepeatCondition);

            _numRepeatCount = new NumericUpDown();
            _numRepeatCount.Minimum = 1;
            _numRepeatCount.Maximum = 9999;
            _numRepeatCount.Value = 1;
            _numRepeatCount.Width = 100;
            AddEditorRow(MakeLabel("반복 횟수"), _numRepeatCount);

            AddEditorRow(null, MakeHelpLabel(
                "피연산자: 노드 전체 경로 / {변수}\r\n" +
                "  예) node1-1.node1-1-1 == 'VALUE'\r\n" +
                "  예) {PARAM} == 'VALUE'\r\n" +
                "연산자: == != > < >= <= && ||\r\n" +
                "반복 조건이 참이면 반복 횟수만큼 생성\r\n" +
                "  (반복 중 {INDEX} = 현재 회차)\r\n" +
                "표시 조건이 거짓이면 노드를 생성하지 않음"));

            _btnApply = new Button();
            _btnApply.Text = "적용";
            _btnApply.AutoSize = true;
            _btnApply.Click += OnApplyEditor;
            AddEditorRow(null, _btnApply);

            /* 남는 공간 흡수용 빈 행 */
            _editorPanel.RowCount = _editorPanel.RowCount + 1;
            _editorPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            parent.Controls.Add(_editorPanel);
        }

        private int _editorRow;

        private void AddEditorRow(Control left, Control right)
        {
            AddEditorRow(left, right, 0);
        }

        private void AddEditorRow(Control left, Control right, int fixedHeight)
        {
            _editorPanel.RowCount = _editorRow + 1;
            if (fixedHeight > 0)
            {
                _editorPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, fixedHeight));
            }
            else
            {
                _editorPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            }

            if (left != null && right != null)
            {
                _editorPanel.Controls.Add(left, 0, _editorRow);
                _editorPanel.Controls.Add(right, 1, _editorRow);
            }
            else if (left != null)
            {
                _editorPanel.Controls.Add(left, 0, _editorRow);
                _editorPanel.SetColumnSpan(left, 2);
            }
            else if (right != null)
            {
                _editorPanel.Controls.Add(right, 1, _editorRow);
            }
            _editorRow++;
        }

        private static Label MakeLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Margin = new Padding(0, 8, 4, 0);
            return label;
        }

        private static Label MakeHelpLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.ForeColor = Color.DimGray;
            label.Margin = new Padding(0, 2, 0, 8);
            return label;
        }

        private void BuildPreviewPane(Control parent)
        {
            TableLayoutPanel panel = new TableLayoutPanel();
            panel.Dock = DockStyle.Fill;
            panel.ColumnCount = 1;
            panel.RowCount = 5;
            panel.Padding = new Padding(4);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 샘플 버튼 */
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 데이터 라벨 */
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 130F));    /* 데이터 입력 */
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 미리보기 라벨 */
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));     /* 미리보기 */

            FlowLayoutPanel sampleButtons = new FlowLayoutPanel();
            sampleButtons.AutoSize = true;
            sampleButtons.Dock = DockStyle.Fill;
            sampleButtons.FlowDirection = FlowDirection.LeftToRight;

            sampleButtons.Controls.Add(MakeSampleButton("샘플 1: 국내 주문", Sample1));
            sampleButtons.Controls.Add(MakeSampleButton("샘플 2: 해외 주문", Sample2));
            sampleButtons.Controls.Add(MakeSampleButton("샘플 3: 대량 주문", Sample3));

            Label dataLabel = new Label();
            dataLabel.Text = "샘플 데이터 (한 줄에 변수명=값, # 은 주석)";
            dataLabel.Font = new Font(Font, FontStyle.Bold);
            dataLabel.AutoSize = true;

            _txtSampleData = new TextBox();
            _txtSampleData.Multiline = true;
            _txtSampleData.ScrollBars = ScrollBars.Vertical;
            _txtSampleData.Dock = DockStyle.Fill;
            _txtSampleData.Font = new Font(FontFamily.GenericMonospace, 9F);
            _txtSampleData.TextChanged += OnSampleDataChanged;

            Label previewLabel = new Label();
            previewLabel.Text = "XML 미리보기";
            previewLabel.Font = new Font(Font, FontStyle.Bold);
            previewLabel.AutoSize = true;

            _txtPreview = new TextBox();
            _txtPreview.Multiline = true;
            _txtPreview.ReadOnly = true;
            _txtPreview.ScrollBars = ScrollBars.Both;
            _txtPreview.WordWrap = false;
            _txtPreview.Dock = DockStyle.Fill;
            _txtPreview.Font = new Font(FontFamily.GenericMonospace, 9F);
            _txtPreview.BackColor = Color.White;

            panel.Controls.Add(sampleButtons, 0, 0);
            panel.Controls.Add(dataLabel, 0, 1);
            panel.Controls.Add(_txtSampleData, 0, 2);
            panel.Controls.Add(previewLabel, 0, 3);
            panel.Controls.Add(_txtPreview, 0, 4);

            parent.Controls.Add(panel);
        }

        private Button MakeSampleButton(string caption, string data)
        {
            Button button = new Button();
            button.Text = caption;
            button.AutoSize = true;
            button.Tag = data;
            button.Click += delegate(object sender, EventArgs e)
            {
                _txtSampleData.Text = (string)((Button)sender).Tag;
            };
            return button;
        }

        /* ------------------------------------------------------------------ */
        /* 트리 <-> 모델                                                        */
        /* ------------------------------------------------------------------ */

        private void LoadTemplate(TemplateNode root, string templateName)
        {
            _rootNode = root;
            _txtTemplateName.Text = templateName;

            _tree.BeginUpdate();
            _tree.Nodes.Clear();
            TreeNode rootTreeNode = BuildTreeNode(root);
            _tree.Nodes.Add(rootTreeNode);
            _tree.ExpandAll();
            _tree.EndUpdate();
            _tree.SelectedNode = rootTreeNode;

            /* 폼 핸들 생성 전에는 AfterSelect 가 지연될 수 있어 명시적으로 로드한다. */
            LoadNodeToEditor(root);
            RefreshPreview();
        }

        private static TreeNode BuildTreeNode(TemplateNode model)
        {
            TreeNode treeNode = new TreeNode(BuildTreeLabel(model));
            treeNode.Tag = model;
            foreach (TemplateNode child in model.Children)
            {
                treeNode.Nodes.Add(BuildTreeNode(child));
            }
            return treeNode;
        }

        private static string BuildTreeLabel(TemplateNode node)
        {
            StringBuilder sb = new StringBuilder(node.Name);
            if (node.ValueType == NodeValueType.Variable)
            {
                sb.Append(" [변수]");
            }
            else if (node.ValueType == NodeValueType.Function)
            {
                sb.Append(" [함수]");
            }
            if (node.DisplayCondition.Trim().Length > 0)
            {
                sb.Append(" [표시조건]");
            }
            if (node.RepeatCondition.Trim().Length > 0 || node.RepeatCount > 1)
            {
                sb.Append(" [반복");
                if (node.RepeatCount > 1)
                {
                    sb.Append("x").Append(node.RepeatCount);
                }
                sb.Append("]");
            }
            return sb.ToString();
        }

        private TemplateNode SelectedModel()
        {
            if (_tree.SelectedNode == null)
            {
                return null;
            }
            return (TemplateNode)_tree.SelectedNode.Tag;
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 트리                                                          */
        /* ------------------------------------------------------------------ */

        private void OnTreeAfterSelect(object sender, TreeViewEventArgs e)
        {
            LoadNodeToEditor(SelectedModel());
        }

        private void OnAddChildNode(object sender, EventArgs e)
        {
            TreeNode parentTreeNode = _tree.SelectedNode;
            if (parentTreeNode == null)
            {
                MessageBox.Show(this, "자식을 추가할 노드를 먼저 선택하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TemplateNode parentModel = (TemplateNode)parentTreeNode.Tag;

            TemplateNode child = new TemplateNode(UniqueChildName(parentModel, "NEW-NODE"));
            parentModel.AddChild(child);

            TreeNode childTreeNode = BuildTreeNode(child);
            parentTreeNode.Nodes.Add(childTreeNode);
            parentTreeNode.Expand();
            _tree.SelectedNode = childTreeNode;

            RefreshPreview();
        }

        private static string UniqueChildName(TemplateNode parent, string baseName)
        {
            string name = baseName;
            int suffix = 1;
            while (HasChildNamed(parent, name))
            {
                suffix++;
                name = baseName + "-" + suffix;
            }
            return name;
        }

        private static bool HasChildNamed(TemplateNode parent, string name)
        {
            foreach (TemplateNode child in parent.Children)
            {
                if (child.Name == name)
                {
                    return true;
                }
            }
            return false;
        }

        private void OnDeleteNode(object sender, EventArgs e)
        {
            TreeNode treeNode = _tree.SelectedNode;
            if (treeNode == null)
            {
                MessageBox.Show(this, "삭제할 노드를 먼저 선택하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TemplateNode model = (TemplateNode)treeNode.Tag;
            if (model.Parent == null)
            {
                MessageBox.Show(this, "루트 노드는 삭제할 수 없습니다.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult answer = MessageBox.Show(this,
                "'" + model.Name + "' 노드와 하위 노드를 모두 삭제할까요?", "노드 삭제",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            model.Parent.RemoveChild(model);
            treeNode.Remove();
            RefreshPreview();
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 노드 정보 편집                                                 */
        /* ------------------------------------------------------------------ */

        private void LoadNodeToEditor(TemplateNode node)
        {
            bool enabled = (node != null);
            _editorPanel.Enabled = enabled;
            if (!enabled)
            {
                return;
            }

            _txtName.Text = node.Name;
            switch (node.ValueType)
            {
                case NodeValueType.Variable:
                    _cboValueType.SelectedIndex = 1;
                    break;
                case NodeValueType.Function:
                    _cboValueType.SelectedIndex = 2;
                    break;
                default:
                    _cboValueType.SelectedIndex = 0;
                    break;
            }
            _txtValue.Text = node.Value;
            _txtDisplayCondition.Text = node.DisplayCondition;
            _txtRepeatCondition.Text = node.RepeatCondition;

            /*
             * 백엔드에는 반복 횟수 상한이 없다. 상한을 넘는 템플릿을 열었을 때
             * [적용] 시 조용히 절삭되지 않도록 Maximum 을 모델 값에 맞춰 늘린다.
             */
            int repeatCount = node.RepeatCount;
            if (repeatCount > (int)_numRepeatCount.Maximum)
            {
                _numRepeatCount.Maximum = repeatCount;
            }
            if (repeatCount < (int)_numRepeatCount.Minimum)
            {
                repeatCount = (int)_numRepeatCount.Minimum;
            }
            _numRepeatCount.Value = repeatCount;
        }

        private void OnApplyEditor(object sender, EventArgs e)
        {
            TemplateNode node = SelectedModel();
            if (node == null)
            {
                return;
            }

            string name = _txtName.Text.Trim();
            if (name.Length == 0)
            {
                MessageBox.Show(this, "노드 이름을 입력하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            node.Name = name;
            switch (_cboValueType.SelectedIndex)
            {
                case 1:
                    node.ValueType = NodeValueType.Variable;
                    break;
                case 2:
                    node.ValueType = NodeValueType.Function;
                    break;
                default:
                    node.ValueType = NodeValueType.Fixed;
                    break;
            }
            node.Value = _txtValue.Text;
            node.DisplayCondition = _txtDisplayCondition.Text.Trim();
            node.RepeatCondition = _txtRepeatCondition.Text.Trim();
            node.RepeatCount = (int)_numRepeatCount.Value;

            _tree.SelectedNode.Text = BuildTreeLabel(node);
            RefreshPreview();
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 샘플 데이터 / 미리보기                                          */
        /* ------------------------------------------------------------------ */

        private void OnSampleDataChanged(object sender, EventArgs e)
        {
            /* 키 입력마다 즉시 재생성하지 않고 입력이 멈춘 뒤 한 번만 갱신한다. */
            if (_previewTimer != null)
            {
                _previewTimer.Stop();
                _previewTimer.Start();
            }
        }

        private void OnPreviewTimerTick(object sender, EventArgs e)
        {
            _previewTimer.Stop();
            RefreshPreview();
        }

        /// <summary>샘플 데이터 텍스트를 변수 맵으로 해석한다. (한 줄에 KEY=VALUE, # 주석)</summary>
        private Dictionary<string, string> ParseSampleData()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            string[] lines = _txtSampleData.Text.Split('\n');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line.Length == 0 || line.StartsWith("#"))
                {
                    continue;
                }
                int eq = line.IndexOf('=');
                if (eq < 1)
                {
                    continue;
                }
                string key = line.Substring(0, eq).Trim();
                string value = line.Substring(eq + 1).Trim();
                data[key] = value;
            }
            return data;
        }

        private void RefreshPreview()
        {
            if (IsDisposed || Disposing || _rootNode == null || _txtPreview == null)
            {
                return;
            }
            try
            {
                XmlGenerator generator =
                    new XmlGenerator(_rootNode, ParseSampleData(), PreviewMaxElements);
                string xml = generator.Generate();
                _txtPreview.ForeColor = Color.Black;
                _txtPreview.Text = NormalizeNewLines(xml);
            }
            catch (XmlGenerator.GenerationException ex)
            {
                _txtPreview.ForeColor = Color.Firebrick;
                _txtPreview.Text = "[생성 오류]\r\n" + ex.Message;
            }
        }

        private static string NormalizeNewLines(string text)
        {
            return text.Replace("\r\n", "\n").Replace("\n", "\r\n");
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 템플릿 파일                                                    */
        /* ------------------------------------------------------------------ */

        private void OnNewTemplate(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show(this,
                "새 템플릿을 만들까요? 저장하지 않은 내용은 사라집니다.", "새 템플릿",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }
            LoadTemplate(new TemplateNode("ROOT"), "새 템플릿");
        }

        private void OnOpenTemplate(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "템플릿 파일 (*.xml)|*.xml|모든 파일 (*.*)|*.*";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    string templateName;
                    TemplateNode root = Template.TemplateSerializer.Load(dialog.FileName, out templateName);
                    if (templateName == null || templateName.Trim().Length == 0)
                    {
                        templateName = System.IO.Path.GetFileNameWithoutExtension(dialog.FileName);
                    }
                    LoadTemplate(root, templateName);
                }
                catch (Template.TemplateSerializer.SerializationException ex)
                {
                    MessageBox.Show(this, ex.Message, "열기 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void OnSaveTemplate(object sender, EventArgs e)
        {
            string templateName = _txtTemplateName.Text.Trim();
            if (templateName.Length == 0)
            {
                MessageBox.Show(this, "템플릿 이름을 입력하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "템플릿 파일 (*.xml)|*.xml";
                dialog.FileName = templateName + ".xml";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }
                try
                {
                    Template.TemplateSerializer.Save(dialog.FileName, templateName, _rootNode);
                    MessageBox.Show(this, "저장했습니다.", "저장",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Template.TemplateSerializer.SerializationException ex)
                {
                    MessageBox.Show(this, ex.Message, "저장 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /* ------------------------------------------------------------------ */
        /* 데모 템플릿 (시작 시 로드)                                              */
        /* ------------------------------------------------------------------ */

        private static TemplateNode BuildDemoTemplate()
        {
            TemplateNode root = new TemplateNode("ORDER");

            TemplateNode header = new TemplateNode("HEADER");
            root.AddChild(header);

            TemplateNode orderNo = new TemplateNode("ORDER-NO");
            orderNo.ValueType = NodeValueType.Variable;
            orderNo.Value = "{ORDER_NO}";
            header.AddChild(orderNo);

            TemplateNode typeName = new TemplateNode("ORDER-TYPE-NAME");
            typeName.ValueType = NodeValueType.Function;
            typeName.Value = "{ORDER_TYPE} == 'D' ? '국내' : '해외'";
            header.AddChild(typeName);

            TemplateNode memo = new TemplateNode("MEMO");
            memo.ValueType = NodeValueType.Variable;
            memo.Value = "{MEMO}";
            memo.DisplayCondition = "{MEMO} != ''";
            header.AddChild(memo);

            TemplateNode items = new TemplateNode("ITEMS");
            root.AddChild(items);

            TemplateNode item = new TemplateNode("ITEM");
            item.RepeatCondition = "{ITEM_COUNT} > 1";
            item.RepeatCount = 3;
            items.AddChild(item);

            TemplateNode seq = new TemplateNode("SEQ");
            seq.ValueType = NodeValueType.Variable;
            seq.Value = "{INDEX}";
            item.AddChild(seq);

            TemplateNode label = new TemplateNode("LABEL");
            label.ValueType = NodeValueType.Fixed;
            label.Value = "품목";
            item.AddChild(label);

            TemplateNode domesticOnly = new TemplateNode("DOMESTIC-ONLY");
            domesticOnly.ValueType = NodeValueType.Fixed;
            domesticOnly.Value = "국내 전용 항목";
            domesticOnly.DisplayCondition = "ORDER.HEADER.ORDER-TYPE-NAME == '국내'";
            root.AddChild(domesticOnly);

            return root;
        }
    }
}
