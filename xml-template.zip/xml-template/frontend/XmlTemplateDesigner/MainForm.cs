﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using XmlTemplateDesigner.Backend;
using XmlTemplateDesigner.Model;
using XmlTemplateDesigner.Template;

namespace XmlTemplateDesigner
{
    /// <summary>
    /// 템플릿 관리 메인 화면.
    ///
    /// 3단 구성:
    ///  - 왼쪽  : XML 구조를 정의하는 Tree 영역 (노드 추가/삭제)
    ///  - 가운데: 선택된 노드의 정보 입력 영역
    ///  - 오른쪽: 샘플 데이터 적용 버튼 + 데이터 입력 + XML 미리보기
    ///
    /// 템플릿 저장/열기/삭제와 XML 미리보기는 모두 Java 백엔드 HTTP API 를
    /// 호출한다 (생성 로직 일원화). 백엔드는 템플릿을 Oracle DB 에 저장한다.
    /// </summary>
    public class MainForm : Form
    {
        /* 왼쪽: 트리 */
        private TreeView _tree;
        private Button _btnAddChild;
        private Button _btnDeleteNode;

        /* 가운데: 노드 정보 편집 */
        private TextBox _txtName;
        private ComboBox _cboValueType;
        private ComboBox _cboDataType;
        private TextBox _txtValue;
        private TextBox _txtDisplayCondition;
        private TextBox _txtRepeatCondition;
        private TextBox _txtRepeatCountExpr;
        private Button _btnApply;
        private TableLayoutPanel _editorPanel;

        /* 오른쪽: 샘플 데이터 + 미리보기 */
        private TextBox _txtSampleData;
        private TextBox _txtPreview;

        /* 툴바 */
        private ToolStripButton _btnOpenTemplate;
        private ToolStripButton _btnSaveTemplate;
        private ToolStripButton _btnDeleteTemplate;
        private ToolStripTextBox _txtServerUrl;
        private ToolStripTextBox _txtTemplateName;

        /* 서버 작업(열기/저장/삭제) 진행 중 재진입 방지 */
        private bool _serverBusy;

        /* 레이아웃 */
        private SplitContainer _splitOuter;
        private SplitContainer _splitInner;

        /* 미리보기 갱신 디바운스 (키 입력마다 백엔드를 호출하지 않도록) */
        private Timer _previewTimer;

        /* 진행 중 미리보기 요청 무효화용 시퀀스 (마지막 요청만 반영) */
        private int _previewSeq;

        /* 모델 */
        private TemplateNode _rootNode;

        private const string Sample1 =
            "# 국내 주문 (품목 3건)\r\n" +
            "ORDER_NO=ORD-2026-0001\r\n" +
            "ORDER_TYPE=D\r\n" +
            "MEMO=빠른 배송 요청\r\n" +
            "ITEM_NAME_1=노트북\r\n" +
            "ITEM_PRICE_1=1500000\r\n" +
            "ITEM_NAME_2=마우스\r\n" +
            "ITEM_PRICE_2=30000\r\n" +
            "ITEM_NAME_3=키보드\r\n" +
            "ITEM_PRICE_3=80000";

        private const string Sample2 =
            "# 해외 주문 (품목 파라미터 없음 -> ITEM 미생성)\r\n" +
            "ORDER_NO=ORD-2026-0002\r\n" +
            "ORDER_TYPE=O\r\n" +
            "MEMO=";

        private const string Sample3 =
            "# 대량 주문 (품목 5건)\r\n" +
            "ORDER_NO=ORD-2026-0003\r\n" +
            "ORDER_TYPE=D\r\n" +
            "MEMO=대량 주문 할인 적용\r\n" +
            "ITEM_NAME_1=모니터\r\n" +
            "ITEM_PRICE_1=350000\r\n" +
            "ITEM_NAME_2=거치대\r\n" +
            "ITEM_PRICE_2=45000\r\n" +
            "ITEM_NAME_3=케이블\r\n" +
            "ITEM_PRICE_3=12000\r\n" +
            "ITEM_NAME_4=허브\r\n" +
            "ITEM_PRICE_4=55000\r\n" +
            "ITEM_NAME_5=웹캠\r\n" +
            "ITEM_PRICE_5=89000";

        public MainForm()
        {
            InitializeUi();

            _previewTimer = new Timer();
            _previewTimer.Interval = 400;
            _previewTimer.Tick += OnPreviewTimerTick;
        }

        protected override void Dispose(bool disposing)
        {
            /* Timer 는 Control 이 아니라 폼 종료 시 자동 Dispose 대상이 아니다. */
            if (disposing && _previewTimer != null)
            {
                _previewTimer.Stop();
                _previewTimer.Dispose();
                _previewTimer = null;
            }
            base.Dispose(disposing);
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            /* SplitterDistance 는 컨트롤이 실제 크기를 가진 뒤에 설정한다. */
            _splitOuter.SplitterDistance = 280;
            _splitInner.SplitterDistance = 380;

            /*
             * 초기 템플릿 로드(→ 비동기 미리보기 시작)는 반드시 OnLoad 이후에 한다.
             * 생성자 시점에는 WindowsFormsSynchronizationContext 가 아직 설치되지
             * 않아(설치 지점은 핸들 생성/메시지 루프) await 재개가 스레드풀에서
             * 실행되어 UI 컨트롤에 크로스 스레드로 접근하게 되기 때문이다.
             */
            _txtSampleData.Text = Sample1;
            LoadTemplate(BuildDemoTemplate(), "order-template");
            /* 위 Text 대입의 TextChanged 가 예약한 중복 미리보기 요청 취소
             * (LoadTemplate 이 이미 즉시 갱신했음) */
            _previewTimer.Stop();
        }

        /* ------------------------------------------------------------------ */
        /* UI 구성                                                              */
        /* ------------------------------------------------------------------ */

        private void InitializeUi()
        {
            Text = "XML 템플릿 관리";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1200, 720);
            MinimumSize = new Size(900, 550);

            ToolStrip toolStrip = BuildToolStrip();

            _splitOuter = new SplitContainer();
            _splitOuter.Dock = DockStyle.Fill;
            _splitOuter.Orientation = Orientation.Vertical;

            _splitInner = new SplitContainer();
            _splitInner.Dock = DockStyle.Fill;
            _splitInner.Orientation = Orientation.Vertical;

            _splitOuter.Panel2.Controls.Add(_splitInner);

            BuildTreePane(_splitOuter.Panel1);
            BuildEditorPane(_splitInner.Panel1);
            BuildPreviewPane(_splitInner.Panel2);

            Controls.Add(_splitOuter);
            Controls.Add(toolStrip);
            _splitOuter.BringToFront();
        }

        private ToolStrip BuildToolStrip()
        {
            ToolStrip strip = new ToolStrip();
            strip.GripStyle = ToolStripGripStyle.Hidden;

            ToolStripButton btnNew = new ToolStripButton("새 템플릿");
            btnNew.Click += OnNewTemplate;
            _btnOpenTemplate = new ToolStripButton("서버에서 열기...");
            _btnOpenTemplate.Click += OnOpenTemplate;
            _btnSaveTemplate = new ToolStripButton("서버에 저장");
            _btnSaveTemplate.Click += OnSaveTemplate;
            _btnDeleteTemplate = new ToolStripButton("서버에서 삭제");
            _btnDeleteTemplate.Click += OnDeleteTemplate;

            _txtServerUrl = new ToolStripTextBox();
            _txtServerUrl.Text = "http://localhost:8080";
            _txtServerUrl.Size = new Size(180, 25);

            _txtTemplateName = new ToolStripTextBox();
            _txtTemplateName.Text = "새 템플릿";
            _txtTemplateName.Size = new Size(160, 25);

            strip.Items.Add(btnNew);
            strip.Items.Add(_btnOpenTemplate);
            strip.Items.Add(_btnSaveTemplate);
            strip.Items.Add(_btnDeleteTemplate);
            strip.Items.Add(new ToolStripSeparator());
            strip.Items.Add(new ToolStripLabel("서버:"));
            strip.Items.Add(_txtServerUrl);
            strip.Items.Add(new ToolStripSeparator());
            strip.Items.Add(new ToolStripLabel("템플릿 이름:"));
            strip.Items.Add(_txtTemplateName);
            return strip;
        }

        private void BuildTreePane(Control parent)
        {
            Label title = new Label();
            title.Text = "XML 구조";
            title.Dock = DockStyle.Top;
            title.Height = 22;
            title.TextAlign = ContentAlignment.MiddleLeft;
            title.Font = new Font(Font, FontStyle.Bold);

            _tree = new TreeView();
            _tree.Dock = DockStyle.Fill;
            _tree.HideSelection = false;
            _tree.AfterSelect += OnTreeAfterSelect;

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.Dock = DockStyle.Bottom;
            buttons.Height = 34;
            buttons.FlowDirection = FlowDirection.LeftToRight;
            buttons.Padding = new Padding(2);

            _btnAddChild = new Button();
            _btnAddChild.Text = "자식 노드 추가";
            _btnAddChild.AutoSize = true;
            _btnAddChild.Click += OnAddChildNode;

            _btnDeleteNode = new Button();
            _btnDeleteNode.Text = "노드 삭제";
            _btnDeleteNode.AutoSize = true;
            _btnDeleteNode.Click += OnDeleteNode;

            buttons.Controls.Add(_btnAddChild);
            buttons.Controls.Add(_btnDeleteNode);

            parent.Controls.Add(_tree);
            parent.Controls.Add(title);
            parent.Controls.Add(buttons);
            _tree.BringToFront();
        }

        private void BuildEditorPane(Control parent)
        {
            _editorPanel = new TableLayoutPanel();
            _editorPanel.Dock = DockStyle.Fill;
            _editorPanel.ColumnCount = 2;
            _editorPanel.Padding = new Padding(8);
            _editorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80F));
            _editorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            Label title = new Label();
            title.Text = "노드 정보";
            title.Font = new Font(Font, FontStyle.Bold);
            title.AutoSize = true;
            AddEditorRow(title, null);

            _txtName = new TextBox();
            _txtName.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("노드 이름"), _txtName);

            _cboValueType = new ComboBox();
            _cboValueType.DropDownStyle = ComboBoxStyle.DropDownList;
            _cboValueType.Items.Add("고정값");
            _cboValueType.Items.Add("변수");
            _cboValueType.Items.Add("함수");
            _cboValueType.SelectedIndex = 0;
            _cboValueType.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("값 유형"), _cboValueType);

            _cboDataType = new ComboBox();
            _cboDataType.DropDownStyle = ComboBoxStyle.DropDownList;
            _cboDataType.Items.Add("문자열");
            _cboDataType.Items.Add("숫자");
            _cboDataType.SelectedIndex = 0;
            _cboDataType.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("데이터 타입"), _cboDataType);

            _txtValue = new TextBox();
            _txtValue.Multiline = true;
            _txtValue.Height = 52;
            _txtValue.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("노드 값"), _txtValue, 56);

            AddEditorRow(null, MakeHelpLabel(
                "고정값: 입력한 텍스트 그대로 사용\r\n" +
                "변수: {변수명} 을 외부 데이터로 치환\r\n" +
                "  예) {ORDER_NO}\r\n" +
                "함수: 조건 ? 값1 : 값2\r\n" +
                "  예) {TYPE} == 'D' ? '국내' : '해외'\r\n" +
                "데이터 타입 '숫자' 는 생성 시 숫자 형식 검증"));

            _txtDisplayCondition = new TextBox();
            _txtDisplayCondition.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("표시 조건"), _txtDisplayCondition);

            _txtRepeatCondition = new TextBox();
            _txtRepeatCondition.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("반복 조건"), _txtRepeatCondition);

            _txtRepeatCountExpr = new TextBox();
            _txtRepeatCountExpr.Dock = DockStyle.Fill;
            AddEditorRow(MakeLabel("반복 횟수"), _txtRepeatCountExpr);

            AddEditorRow(null, MakeHelpLabel(
                "피연산자: 노드 전체 경로 / {변수}\r\n" +
                "  예) node1-1.node1-1-1 == 'VALUE'\r\n" +
                "  예) {PARAM} == 'VALUE'\r\n" +
                "연산자: == != > < >= <= && ||\r\n" +
                "반복 횟수: 숫자 또는 {파라미터}\r\n" +
                "  {xxx} 는 xxx_1, xxx_2, ... 개수만큼 반복\r\n" +
                "  반복 중 {xxx} 는 xxx_회차 값으로 치환\r\n" +
                "  반복 중 {INDEX} = 현재 회차\r\n" +
                "표시 조건이 거짓이면 노드를 생성하지 않음"));

            _btnApply = new Button();
            _btnApply.Text = "적용";
            _btnApply.AutoSize = true;
            _btnApply.Click += OnApplyEditor;
            AddEditorRow(null, _btnApply);

            /* 남는 공간 흡수용 빈 행 */
            _editorPanel.RowCount = _editorPanel.RowCount + 1;
            _editorPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            parent.Controls.Add(_editorPanel);
        }

        private int _editorRow;

        private void AddEditorRow(Control left, Control right)
        {
            AddEditorRow(left, right, 0);
        }

        private void AddEditorRow(Control left, Control right, int fixedHeight)
        {
            _editorPanel.RowCount = _editorRow + 1;
            if (fixedHeight > 0)
            {
                _editorPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, fixedHeight));
            }
            else
            {
                _editorPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            }

            if (left != null && right != null)
            {
                _editorPanel.Controls.Add(left, 0, _editorRow);
                _editorPanel.Controls.Add(right, 1, _editorRow);
            }
            else if (left != null)
            {
                _editorPanel.Controls.Add(left, 0, _editorRow);
                _editorPanel.SetColumnSpan(left, 2);
            }
            else if (right != null)
            {
                _editorPanel.Controls.Add(right, 1, _editorRow);
            }
            _editorRow++;
        }

        private static Label MakeLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Margin = new Padding(0, 8, 4, 0);
            return label;
        }

        private static Label MakeHelpLabel(string text)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.ForeColor = Color.DimGray;
            label.Margin = new Padding(0, 2, 0, 8);
            return label;
        }

        private void BuildPreviewPane(Control parent)
        {
            TableLayoutPanel panel = new TableLayoutPanel();
            panel.Dock = DockStyle.Fill;
            panel.ColumnCount = 1;
            panel.RowCount = 5;
            panel.Padding = new Padding(4);
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 샘플 버튼 */
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 데이터 라벨 */
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 150F));    /* 데이터 입력 */
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));          /* 미리보기 라벨 */
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));     /* 미리보기 */

            FlowLayoutPanel sampleButtons = new FlowLayoutPanel();
            sampleButtons.AutoSize = true;
            sampleButtons.Dock = DockStyle.Fill;
            sampleButtons.FlowDirection = FlowDirection.LeftToRight;

            sampleButtons.Controls.Add(MakeSampleButton("샘플 1: 국내 주문", Sample1));
            sampleButtons.Controls.Add(MakeSampleButton("샘플 2: 해외 주문", Sample2));
            sampleButtons.Controls.Add(MakeSampleButton("샘플 3: 대량 주문", Sample3));

            Label dataLabel = new Label();
            dataLabel.Text = "샘플 데이터 (한 줄에 변수명=값, # 은 주석)";
            dataLabel.Font = new Font(Font, FontStyle.Bold);
            dataLabel.AutoSize = true;

            _txtSampleData = new TextBox();
            _txtSampleData.Multiline = true;
            _txtSampleData.ScrollBars = ScrollBars.Vertical;
            _txtSampleData.Dock = DockStyle.Fill;
            _txtSampleData.Font = new Font(FontFamily.GenericMonospace, 9F);
            _txtSampleData.TextChanged += OnSampleDataChanged;

            Label previewLabel = new Label();
            previewLabel.Text = "XML 미리보기 (백엔드 생성 결과)";
            previewLabel.Font = new Font(Font, FontStyle.Bold);
            previewLabel.AutoSize = true;

            _txtPreview = new TextBox();
            _txtPreview.Multiline = true;
            _txtPreview.ReadOnly = true;
            _txtPreview.ScrollBars = ScrollBars.Both;
            _txtPreview.WordWrap = false;
            _txtPreview.Dock = DockStyle.Fill;
            _txtPreview.Font = new Font(FontFamily.GenericMonospace, 9F);
            _txtPreview.BackColor = Color.White;

            panel.Controls.Add(sampleButtons, 0, 0);
            panel.Controls.Add(dataLabel, 0, 1);
            panel.Controls.Add(_txtSampleData, 0, 2);
            panel.Controls.Add(previewLabel, 0, 3);
            panel.Controls.Add(_txtPreview, 0, 4);

            parent.Controls.Add(panel);
        }

        private Button MakeSampleButton(string caption, string data)
        {
            Button button = new Button();
            button.Text = caption;
            button.AutoSize = true;
            button.Tag = data;
            button.Click += delegate(object sender, EventArgs e)
            {
                _txtSampleData.Text = (string)((Button)sender).Tag;
            };
            return button;
        }

        /* ------------------------------------------------------------------ */
        /* 트리 <-> 모델                                                        */
        /* ------------------------------------------------------------------ */

        private void LoadTemplate(TemplateNode root, string templateName)
        {
            _rootNode = root;
            _txtTemplateName.Text = templateName;

            _tree.BeginUpdate();
            _tree.Nodes.Clear();
            TreeNode rootTreeNode = BuildTreeNode(root);
            _tree.Nodes.Add(rootTreeNode);
            _tree.ExpandAll();
            _tree.EndUpdate();
            _tree.SelectedNode = rootTreeNode;

            /* 폼 핸들 생성 전에는 AfterSelect 가 지연될 수 있어 명시적으로 로드한다. */
            LoadNodeToEditor(root);
            RefreshPreview();
        }

        private static TreeNode BuildTreeNode(TemplateNode model)
        {
            TreeNode treeNode = new TreeNode(BuildTreeLabel(model));
            treeNode.Tag = model;
            foreach (TemplateNode child in model.Children)
            {
                treeNode.Nodes.Add(BuildTreeNode(child));
            }
            return treeNode;
        }

        private static string BuildTreeLabel(TemplateNode node)
        {
            StringBuilder sb = new StringBuilder(node.Name);
            if (node.ValueType == NodeValueType.Variable)
            {
                sb.Append(" [변수]");
            }
            else if (node.ValueType == NodeValueType.Function)
            {
                sb.Append(" [함수]");
            }
            if (node.DisplayCondition.Trim().Length > 0)
            {
                sb.Append(" [표시조건]");
            }
            if (node.RepeatCondition.Trim().Length > 0 || node.RepeatCountExpr.Length > 0)
            {
                sb.Append(" [반복");
                if (node.RepeatCountExpr.Length > 0)
                {
                    sb.Append(":").Append(node.RepeatCountExpr);
                }
                sb.Append("]");
            }
            return sb.ToString();
        }

        private TemplateNode SelectedModel()
        {
            if (_tree.SelectedNode == null)
            {
                return null;
            }
            return (TemplateNode)_tree.SelectedNode.Tag;
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 트리                                                          */
        /* ------------------------------------------------------------------ */

        private void OnTreeAfterSelect(object sender, TreeViewEventArgs e)
        {
            LoadNodeToEditor(SelectedModel());
        }

        private void OnAddChildNode(object sender, EventArgs e)
        {
            TreeNode parentTreeNode = _tree.SelectedNode;
            if (parentTreeNode == null)
            {
                MessageBox.Show(this, "자식을 추가할 노드를 먼저 선택하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TemplateNode parentModel = (TemplateNode)parentTreeNode.Tag;

            TemplateNode child = new TemplateNode(UniqueChildName(parentModel, "NEW-NODE"));
            parentModel.AddChild(child);

            TreeNode childTreeNode = BuildTreeNode(child);
            parentTreeNode.Nodes.Add(childTreeNode);
            parentTreeNode.Expand();
            _tree.SelectedNode = childTreeNode;

            RefreshPreview();
        }

        private static string UniqueChildName(TemplateNode parent, string baseName)
        {
            string name = baseName;
            int suffix = 1;
            while (HasChildNamed(parent, name))
            {
                suffix++;
                name = baseName + "-" + suffix;
            }
            return name;
        }

        private static bool HasChildNamed(TemplateNode parent, string name)
        {
            foreach (TemplateNode child in parent.Children)
            {
                if (child.Name == name)
                {
                    return true;
                }
            }
            return false;
        }

        private void OnDeleteNode(object sender, EventArgs e)
        {
            TreeNode treeNode = _tree.SelectedNode;
            if (treeNode == null)
            {
                MessageBox.Show(this, "삭제할 노드를 먼저 선택하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TemplateNode model = (TemplateNode)treeNode.Tag;
            if (model.Parent == null)
            {
                MessageBox.Show(this, "루트 노드는 삭제할 수 없습니다.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult answer = MessageBox.Show(this,
                "'" + model.Name + "' 노드와 하위 노드를 모두 삭제할까요?", "노드 삭제",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }

            model.Parent.RemoveChild(model);
            treeNode.Remove();
            RefreshPreview();
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 노드 정보 편집                                                 */
        /* ------------------------------------------------------------------ */

        private void LoadNodeToEditor(TemplateNode node)
        {
            bool enabled = (node != null);
            _editorPanel.Enabled = enabled;
            if (!enabled)
            {
                return;
            }

            _txtName.Text = node.Name;
            switch (node.ValueType)
            {
                case NodeValueType.Variable:
                    _cboValueType.SelectedIndex = 1;
                    break;
                case NodeValueType.Function:
                    _cboValueType.SelectedIndex = 2;
                    break;
                default:
                    _cboValueType.SelectedIndex = 0;
                    break;
            }
            _cboDataType.SelectedIndex = (node.DataType == NodeDataType.NumberType) ? 1 : 0;
            _txtValue.Text = node.Value;
            _txtDisplayCondition.Text = node.DisplayCondition;
            _txtRepeatCondition.Text = node.RepeatCondition;
            _txtRepeatCountExpr.Text = node.RepeatCountExpr;
        }

        private void OnApplyEditor(object sender, EventArgs e)
        {
            TemplateNode node = SelectedModel();
            if (node == null)
            {
                return;
            }

            string name = _txtName.Text.Trim();
            if (name.Length == 0)
            {
                MessageBox.Show(this, "노드 이름을 입력하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string countExpr = _txtRepeatCountExpr.Text.Trim();
            if (!IsValidRepeatCountExpr(countExpr))
            {
                MessageBox.Show(this,
                    "반복 횟수는 0 이상의 숫자 또는 {파라미터} 형식이어야 합니다.\r\n" +
                    "예) 3  또는  {ITEM_NAME}", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            node.Name = name;
            switch (_cboValueType.SelectedIndex)
            {
                case 1:
                    node.ValueType = NodeValueType.Variable;
                    break;
                case 2:
                    node.ValueType = NodeValueType.Function;
                    break;
                default:
                    node.ValueType = NodeValueType.Fixed;
                    break;
            }
            node.DataType = (_cboDataType.SelectedIndex == 1)
                ? NodeDataType.NumberType
                : NodeDataType.StringType;
            node.Value = _txtValue.Text;
            node.DisplayCondition = _txtDisplayCondition.Text.Trim();
            node.RepeatCondition = _txtRepeatCondition.Text.Trim();
            node.RepeatCountExpr = countExpr;

            _tree.SelectedNode.Text = BuildTreeLabel(node);
            RefreshPreview();
        }

        /// <summary>반복 횟수 조건 형식 검사: 빈 값 / 0 이상 숫자 / {파라미터}</summary>
        private static bool IsValidRepeatCountExpr(string expr)
        {
            if (expr.Length == 0)
            {
                return true;
            }
            if (expr.StartsWith("{") && expr.EndsWith("}"))
            {
                return expr.Substring(1, expr.Length - 2).Trim().Length > 0;
            }
            int n;
            return int.TryParse(expr, out n) && n >= 0;
        }

        /* ------------------------------------------------------------------ */
        /* 미리보기 (백엔드 호출)                                                 */
        /* ------------------------------------------------------------------ */

        private void OnSampleDataChanged(object sender, EventArgs e)
        {
            /* 키 입력마다 백엔드를 호출하지 않고 입력이 멈춘 뒤 한 번만 호출한다. */
            if (_previewTimer != null)
            {
                _previewTimer.Stop();
                _previewTimer.Start();
            }
        }

        private void OnPreviewTimerTick(object sender, EventArgs e)
        {
            _previewTimer.Stop();
            RefreshPreview();
        }

        /// <summary>샘플 데이터 텍스트를 변수 맵으로 해석한다. (한 줄에 KEY=VALUE, # 주석)</summary>
        private Dictionary<string, string> ParseSampleData()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            string[] lines = _txtSampleData.Text.Split('\n');
            foreach (string rawLine in lines)
            {
                string line = rawLine.Trim();
                if (line.Length == 0 || line.StartsWith("#"))
                {
                    continue;
                }
                int eq = line.IndexOf('=');
                if (eq < 1)
                {
                    continue;
                }
                string key = line.Substring(0, eq).Trim();
                string value = line.Substring(eq + 1).Trim();
                data[key] = value;
            }
            return data;
        }

        /// <summary>
        /// 백엔드 /preview 를 호출해서 미리보기를 갱신한다.
        /// 연속 호출 시 마지막 요청의 응답만 화면에 반영한다.
        /// </summary>
        private async void RefreshPreview()
        {
            if (IsDisposed || Disposing || _rootNode == null || _txtPreview == null)
            {
                return;
            }
            int seq = ++_previewSeq;

            string requestXml;
            try
            {
                requestXml = TemplateSerializer.ToPreviewRequestString(
                    _txtTemplateName.Text.Trim(), _rootNode, ParseSampleData());
            }
            catch (TemplateSerializer.SerializationException ex)
            {
                ShowPreviewError(ex.Message);
                return;
            }

            try
            {
                BackendClient client = new BackendClient(_txtServerUrl.Text);
                string xml = await client.PreviewAsync(requestXml);
                if (seq != _previewSeq || IsDisposed)
                {
                    return;
                }
                _txtPreview.ForeColor = Color.Black;
                _txtPreview.Text = NormalizeNewLines(xml);
            }
            catch (BackendClient.BackendException ex)
            {
                if (seq != _previewSeq || IsDisposed)
                {
                    return;
                }
                ShowPreviewError(ex.Message);
            }
        }

        private void ShowPreviewError(string message)
        {
            _txtPreview.ForeColor = Color.Firebrick;
            _txtPreview.Text = "[미리보기 오류]\r\n" + NormalizeNewLines(message);
        }

        private static string NormalizeNewLines(string text)
        {
            return text.Replace("\r\n", "\n").Replace("\n", "\r\n");
        }

        /* ------------------------------------------------------------------ */
        /* 이벤트: 템플릿 저장/열기/삭제 (백엔드 API)                                */
        /* ------------------------------------------------------------------ */

        /// <summary>서버 작업 시작. 이미 진행 중이면 false (재진입/중복 요청 방지).</summary>
        private bool BeginServerWork()
        {
            if (_serverBusy)
            {
                return false;
            }
            _serverBusy = true;
            SetServerButtonsEnabled(false);
            return true;
        }

        private void EndServerWork()
        {
            _serverBusy = false;
            if (!IsDisposed)
            {
                SetServerButtonsEnabled(true);
            }
        }

        private void SetServerButtonsEnabled(bool enabled)
        {
            _btnOpenTemplate.Enabled = enabled;
            _btnSaveTemplate.Enabled = enabled;
            _btnDeleteTemplate.Enabled = enabled;
        }

        /// <summary>
        /// URL 경로에서 안전하게 왕복되지 않는 문자를 차단한다.
        /// ('/' 는 .NET Uri 가 %2F 를 다시 '/' 로 풀어 경로가 깨진다)
        /// </summary>
        private static bool IsValidTemplateName(string name)
        {
            return name.IndexOf('/') < 0 && name.IndexOf('\\') < 0;
        }

        private void WarnInvalidTemplateName()
        {
            MessageBox.Show(this, "템플릿 이름에 '/' 또는 '\\' 은 사용할 수 없습니다.", "알림",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void OnNewTemplate(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show(this,
                "새 템플릿을 만들까요? 저장하지 않은 내용은 사라집니다.", "새 템플릿",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }
            LoadTemplate(new TemplateNode("ROOT"), "새 템플릿");
        }

        private async void OnOpenTemplate(object sender, EventArgs e)
        {
            if (!BeginServerWork())
            {
                return;
            }
            try
            {
                BackendClient client = new BackendClient(_txtServerUrl.Text);
                string[] names = await client.ListTemplatesAsync();
                if (IsDisposed)
                {
                    return;
                }
                if (names.Length == 0)
                {
                    MessageBox.Show(this, "서버에 저장된 템플릿이 없습니다.", "알림",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string selected = null;
                using (TemplateListDialog dialog = new TemplateListDialog(names))
                {
                    if (dialog.ShowDialog(this) == DialogResult.OK)
                    {
                        selected = dialog.SelectedTemplateName;
                    }
                }
                if (selected == null)
                {
                    return;
                }

                string xml = await client.GetTemplateAsync(selected);
                if (IsDisposed)
                {
                    return;
                }
                string templateName;
                TemplateNode root = TemplateSerializer.FromXmlString(xml, out templateName);
                if (templateName == null || templateName.Trim().Length == 0)
                {
                    templateName = selected;
                }
                LoadTemplate(root, templateName);
            }
            catch (BackendClient.BackendException ex)
            {
                if (!IsDisposed)
                {
                    MessageBox.Show(this, ex.Message, "열기 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (TemplateSerializer.SerializationException ex)
            {
                if (!IsDisposed)
                {
                    MessageBox.Show(this, ex.Message, "열기 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                EndServerWork();
            }
        }

        private async void OnSaveTemplate(object sender, EventArgs e)
        {
            string templateName = _txtTemplateName.Text.Trim();
            if (templateName.Length == 0)
            {
                MessageBox.Show(this, "템플릿 이름을 입력하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!IsValidTemplateName(templateName))
            {
                WarnInvalidTemplateName();
                return;
            }
            if (!BeginServerWork())
            {
                return;
            }
            try
            {
                string xml = TemplateSerializer.ToXmlString(templateName, _rootNode);
                BackendClient client = new BackendClient(_txtServerUrl.Text);
                string message = await client.SaveTemplateAsync(templateName, xml);
                if (IsDisposed)
                {
                    return;
                }
                MessageBox.Show(this, message, "저장",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (BackendClient.BackendException ex)
            {
                if (!IsDisposed)
                {
                    MessageBox.Show(this, ex.Message, "저장 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (TemplateSerializer.SerializationException ex)
            {
                if (!IsDisposed)
                {
                    MessageBox.Show(this, ex.Message, "저장 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                EndServerWork();
            }
        }

        private async void OnDeleteTemplate(object sender, EventArgs e)
        {
            string templateName = _txtTemplateName.Text.Trim();
            if (templateName.Length == 0)
            {
                MessageBox.Show(this, "삭제할 템플릿 이름을 입력하세요.", "알림",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!IsValidTemplateName(templateName))
            {
                WarnInvalidTemplateName();
                return;
            }
            DialogResult answer = MessageBox.Show(this,
                "서버에서 '" + templateName + "' 템플릿을 삭제할까요?", "템플릿 삭제",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes)
            {
                return;
            }
            if (!BeginServerWork())
            {
                return;
            }
            try
            {
                BackendClient client = new BackendClient(_txtServerUrl.Text);
                string message = await client.DeleteTemplateAsync(templateName);
                if (IsDisposed)
                {
                    return;
                }
                MessageBox.Show(this, message, "삭제",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (BackendClient.BackendException ex)
            {
                if (!IsDisposed)
                {
                    MessageBox.Show(this, ex.Message, "삭제 실패",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                EndServerWork();
            }
        }

        /* ------------------------------------------------------------------ */
        /* 데모 템플릿 (시작 시 로드)                                              */
        /* ------------------------------------------------------------------ */

        private static TemplateNode BuildDemoTemplate()
        {
            TemplateNode root = new TemplateNode("ORDER");

            TemplateNode header = new TemplateNode("HEADER");
            root.AddChild(header);

            TemplateNode orderNo = new TemplateNode("ORDER-NO");
            orderNo.ValueType = NodeValueType.Variable;
            orderNo.Value = "{ORDER_NO}";
            header.AddChild(orderNo);

            TemplateNode typeName = new TemplateNode("ORDER-TYPE-NAME");
            typeName.ValueType = NodeValueType.Function;
            typeName.Value = "{ORDER_TYPE} == 'D' ? '국내' : '해외'";
            header.AddChild(typeName);

            TemplateNode memo = new TemplateNode("MEMO");
            memo.ValueType = NodeValueType.Variable;
            memo.Value = "{MEMO}";
            memo.DisplayCondition = "{MEMO} != ''";
            header.AddChild(memo);

            TemplateNode items = new TemplateNode("ITEMS");
            root.AddChild(items);

            TemplateNode item = new TemplateNode("ITEM");
            item.RepeatCountExpr = "{ITEM_NAME}";
            items.AddChild(item);

            TemplateNode seq = new TemplateNode("SEQ");
            seq.ValueType = NodeValueType.Variable;
            seq.Value = "{INDEX}";
            seq.DataType = NodeDataType.NumberType;
            item.AddChild(seq);

            TemplateNode itemName = new TemplateNode("NAME");
            itemName.ValueType = NodeValueType.Variable;
            itemName.Value = "{ITEM_NAME}";
            item.AddChild(itemName);

            TemplateNode itemPrice = new TemplateNode("PRICE");
            itemPrice.ValueType = NodeValueType.Variable;
            itemPrice.Value = "{ITEM_PRICE}";
            itemPrice.DataType = NodeDataType.NumberType;
            item.AddChild(itemPrice);

            TemplateNode domesticOnly = new TemplateNode("DOMESTIC-ONLY");
            domesticOnly.ValueType = NodeValueType.Fixed;
            domesticOnly.Value = "국내 전용 항목";
            domesticOnly.DisplayCondition = "ORDER.HEADER.ORDER-TYPE-NAME == '국내'";
            root.AddChild(domesticOnly);

            return root;
        }
    }
}
