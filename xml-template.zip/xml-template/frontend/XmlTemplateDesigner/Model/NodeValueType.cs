﻿using System;

namespace XmlTemplateDesigner.Model
{
    /// <summary>
    /// 노드 값의 유형.
    /// Fixed    : 입력된 텍스트를 그대로 노드 값으로 사용
    /// Variable : 값 안의 {변수명} 을 외부 데이터에서 찾아 치환
    /// Function : 삼항연산자 조건식을 평가한 결과를 노드 값으로 사용
    /// </summary>
    public enum NodeValueType
    {
        Fixed,
        Variable,
        Function
    }

    public static class NodeValueTypeUtil
    {
        /// <summary>템플릿 파일(Java 백엔드와 공유)의 type 문자열로 변환.</summary>
        public static string ToSerialString(NodeValueType type)
        {
            switch (type)
            {
                case NodeValueType.Variable: return "VARIABLE";
                case NodeValueType.Function: return "FUNCTION";
                default: return "FIXED";
            }
        }

        /// <summary>type 문자열로부터 복원. 알 수 없는 값은 Fixed 로 처리.</summary>
        public static NodeValueType FromSerialString(string s)
        {
            if (s == null)
            {
                return NodeValueType.Fixed;
            }
            string t = s.Trim().ToUpperInvariant();
            if (t == "VARIABLE")
            {
                return NodeValueType.Variable;
            }
            if (t == "FUNCTION")
            {
                return NodeValueType.Function;
            }
            return NodeValueType.Fixed;
        }
    }
}
