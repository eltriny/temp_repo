﻿using System;

namespace XmlTemplateDesigner.Model
{
    /// <summary>
    /// 노드 값의 데이터 타입 (DB 컬럼: INPUT_DATA_TYPE).
    /// StringType : 제약 없음 (기본값)
    /// NumberType : 생성 시 값이 비어 있지 않으면 백엔드가 숫자 형식인지 검증한다.
    /// </summary>
    public enum NodeDataType
    {
        StringType,
        NumberType
    }

    public static class NodeDataTypeUtil
    {
        /// <summary>직렬화 문자열(Java 백엔드와 공유)로 변환.</summary>
        public static string ToSerialString(NodeDataType type)
        {
            return (type == NodeDataType.NumberType) ? "NUMBER" : "STRING";
        }

        /// <summary>직렬화 문자열로부터 복원. 알 수 없는 값은 StringType.</summary>
        public static NodeDataType FromSerialString(string s)
        {
            if (s != null && s.Trim().ToUpperInvariant() == "NUMBER")
            {
                return NodeDataType.NumberType;
            }
            return NodeDataType.StringType;
        }
    }
}
