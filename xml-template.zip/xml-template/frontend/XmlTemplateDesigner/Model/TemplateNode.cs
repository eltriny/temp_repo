﻿using System;
using System.Collections.Generic;

namespace XmlTemplateDesigner.Model
{
    /// <summary>
    /// XML 템플릿의 한 노드. (Java 백엔드의 TemplateNode 와 동일한 모델)
    ///
    /// - Name             : 생성될 XML 엘리먼트 이름
    /// - ValueType/Value  : 노드 값 (고정값 / 외부 데이터 변수 / 삼항연산자 함수)
    /// - DisplayCondition : 표시 조건식. 비어 있으면 항상 표시.
    /// - RepeatCondition  : 반복 조건식. true 면 RepeatCount 만큼 반복.
    ///                      비어 있으면 RepeatCount 가 2 이상일 때 무조건 반복.
    /// - RepeatCount      : 반복 횟수 (기본 1)
    /// </summary>
    public class TemplateNode
    {
        private string _name;
        private string _value;
        private string _displayCondition;
        private string _repeatCondition;
        private int _repeatCount;
        private readonly List<TemplateNode> _children;

        public TemplateNode(string name)
        {
            _name = name ?? "";
            _value = "";
            _displayCondition = "";
            _repeatCondition = "";
            _repeatCount = 1;
            ValueType = NodeValueType.Fixed;
            _children = new List<TemplateNode>();
        }

        public string Name
        {
            get { return _name; }
            set { _name = value ?? ""; }
        }

        public NodeValueType ValueType { get; set; }

        public string Value
        {
            get { return _value; }
            set { _value = value ?? ""; }
        }

        public string DisplayCondition
        {
            get { return _displayCondition; }
            set { _displayCondition = value ?? ""; }
        }

        public string RepeatCondition
        {
            get { return _repeatCondition; }
            set { _repeatCondition = value ?? ""; }
        }

        public int RepeatCount
        {
            get { return _repeatCount; }
            set { _repeatCount = (value < 1) ? 1 : value; }
        }

        public TemplateNode Parent { get; private set; }

        public IList<TemplateNode> Children
        {
            get { return _children; }
        }

        public bool HasChildren
        {
            get { return _children.Count > 0; }
        }

        public void AddChild(TemplateNode child)
        {
            child.Parent = this;
            _children.Add(child);
        }

        public void RemoveChild(TemplateNode child)
        {
            if (_children.Remove(child))
            {
                child.Parent = null;
            }
        }

        /// <summary>루트로부터의 전체 경로 (예: "ROOT.node1-1.node1-1-1")</summary>
        public string GetPath()
        {
            if (Parent == null)
            {
                return Name;
            }
            return Parent.GetPath() + "." + Name;
        }
    }
}
