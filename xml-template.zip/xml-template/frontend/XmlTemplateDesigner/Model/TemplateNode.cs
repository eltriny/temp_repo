﻿using System;
using System.Collections.Generic;

namespace XmlTemplateDesigner.Model
{
    /// <summary>
    /// XML 템플릿의 한 노드. (Java 백엔드의 TemplateNode 와 동일한 모델)
    ///
    /// - Name             : 생성될 XML 엘리먼트 이름 (DB: NODE_NAME)
    /// - ValueType/Value  : 노드 값 - 고정값/변수/함수 (DB: INPUT_TYPE / INPUT_VALUE)
    /// - DataType         : 값의 데이터 타입 - STRING/NUMBER (DB: INPUT_DATA_TYPE)
    /// - DisplayCondition : 표시 조건식 (DB: DISPLAY_COND)
    /// - RepeatCondition  : 반복 조건식 (DB: REPEAT_COND)
    /// - RepeatCountExpr  : 반복 횟수 조건 (DB: REPEAT_COUNT_COND)
    ///                      숫자("3") 또는 파라미터 기준("{xxx}").
    ///                      "{xxx}" 는 외부 데이터에 xxx_1, xxx_2, ... 가 연속으로
    ///                      존재하는 개수만큼 반복한다는 뜻이다.
    /// </summary>
    public class TemplateNode
    {
        private string _name;
        private string _value;
        private string _displayCondition;
        private string _repeatCondition;
        private string _repeatCountExpr;
        private readonly List<TemplateNode> _children;

        public TemplateNode(string name)
        {
            _name = name ?? "";
            _value = "";
            _displayCondition = "";
            _repeatCondition = "";
            _repeatCountExpr = "";
            ValueType = NodeValueType.Fixed;
            DataType = NodeDataType.StringType;
            _children = new List<TemplateNode>();
        }

        public string Name
        {
            get { return _name; }
            set { _name = value ?? ""; }
        }

        public NodeValueType ValueType { get; set; }

        public NodeDataType DataType { get; set; }

        public string Value
        {
            get { return _value; }
            set { _value = value ?? ""; }
        }

        public string DisplayCondition
        {
            get { return _displayCondition; }
            set { _displayCondition = value ?? ""; }
        }

        public string RepeatCondition
        {
            get { return _repeatCondition; }
            set { _repeatCondition = value ?? ""; }
        }

        /// <summary>반복 횟수 조건: 숫자("3") 또는 파라미터 기준("{xxx}"). 빈 문자열이면 1회.</summary>
        public string RepeatCountExpr
        {
            get { return _repeatCountExpr; }
            set { _repeatCountExpr = (value == null) ? "" : value.Trim(); }
        }

        public TemplateNode Parent { get; private set; }

        public IList<TemplateNode> Children
        {
            get { return _children; }
        }

        public bool HasChildren
        {
            get { return _children.Count > 0; }
        }

        public void AddChild(TemplateNode child)
        {
            child.Parent = this;
            _children.Add(child);
        }

        public void RemoveChild(TemplateNode child)
        {
            if (_children.Remove(child))
            {
                child.Parent = null;
            }
        }

        /// <summary>루트로부터의 전체 경로 (예: "ROOT.node1-1.node1-1-1")</summary>
        public string GetPath()
        {
            if (Parent == null)
            {
                return Name;
            }
            return Parent.GetPath() + "." + Name;
        }
    }
}
