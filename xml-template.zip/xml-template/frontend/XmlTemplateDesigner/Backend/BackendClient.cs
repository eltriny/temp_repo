﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace XmlTemplateDesigner.Backend
{
    /// <summary>
    /// Java 백엔드 HTTP API 클라이언트.
    ///
    ///  GET    /templates          템플릿 이름 목록 (줄바꿈 구분)
    ///  GET    /templates/{name}   템플릿 XML 조회
    ///  PUT    /templates/{name}   템플릿 저장 (body: 템플릿 XML)
    ///  DELETE /templates/{name}   템플릿 삭제
    ///  POST   /preview            미리보기 생성 (body: previewRequest XML)
    ///
    /// 인스턴스는 요청마다 만들어도 된다. HttpClient 는 정적으로 공유한다.
    /// </summary>
    public class BackendClient
    {
        /// <summary>백엔드가 오류를 보고했을 때 (4xx/5xx + 메시지 본문).</summary>
        public class BackendException : Exception
        {
            public BackendException(string message) : base(message)
            {
            }
        }

        private static readonly HttpClient Http = CreateHttpClient();

        private readonly string _baseUrl;

        public BackendClient(string baseUrl)
        {
            if (baseUrl == null || baseUrl.Trim().Length == 0)
            {
                throw new BackendException("서버 주소가 비어 있습니다.");
            }
            _baseUrl = baseUrl.Trim().TrimEnd('/');

            /*
             * 잘못된 주소(스킴 누락, 공백 등)를 여기서 걸러 BackendException 으로
             * 통일한다. HttpClient 까지 가면 UriFormatException /
             * InvalidOperationException 이 되어 호출부의 catch 를 벗어난다.
             */
            Uri parsed;
            if (!Uri.TryCreate(_baseUrl, UriKind.Absolute, out parsed)
                || (parsed.Scheme != Uri.UriSchemeHttp && parsed.Scheme != Uri.UriSchemeHttps))
            {
                throw new BackendException(
                    "서버 주소가 올바르지 않습니다 (http:// 또는 https:// 필요): " + baseUrl);
            }
        }

        private static HttpClient CreateHttpClient()
        {
            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromSeconds(10);
            return client;
        }

        /* ------------------------------------------------------------------ */
        /* API                                                                 */
        /* ------------------------------------------------------------------ */

        public async Task<string[]> ListTemplatesAsync()
        {
            string body = await GetAsync("/templates").ConfigureAwait(false);
            List<string> names = new List<string>();
            foreach (string line in body.Split('\n'))
            {
                string name = line.Trim();
                if (name.Length > 0)
                {
                    names.Add(name);
                }
            }
            return names.ToArray();
        }

        public Task<string> GetTemplateAsync(string name)
        {
            return GetAsync("/templates/" + Uri.EscapeDataString(name));
        }

        public Task<string> SaveTemplateAsync(string name, string templateXml)
        {
            return SendAsync(HttpMethod.Put,
                "/templates/" + Uri.EscapeDataString(name), templateXml);
        }

        public Task<string> DeleteTemplateAsync(string name)
        {
            return SendAsync(HttpMethod.Delete,
                "/templates/" + Uri.EscapeDataString(name), null);
        }

        public Task<string> PreviewAsync(string previewRequestXml)
        {
            return SendAsync(HttpMethod.Post, "/preview", previewRequestXml);
        }

        /* ------------------------------------------------------------------ */
        /* HTTP 공통                                                            */
        /* ------------------------------------------------------------------ */

        private Task<string> GetAsync(string path)
        {
            return SendAsync(HttpMethod.Get, path, null);
        }

        private async Task<string> SendAsync(HttpMethod method, string path, string body)
        {
            HttpRequestMessage request;
            try
            {
                request = new HttpRequestMessage(method, _baseUrl + path);
            }
            catch (UriFormatException)
            {
                throw new BackendException("서버 주소가 올바르지 않습니다: " + _baseUrl);
            }
            try
            {
                if (body != null)
                {
                    request.Content = new StringContent(body, Encoding.UTF8, "application/xml");
                }

                HttpResponseMessage response;
                try
                {
                    response = await Http.SendAsync(request).ConfigureAwait(false);
                }
                catch (HttpRequestException e)
                {
                    throw new BackendException(
                        "백엔드 서버에 연결할 수 없습니다: " + _baseUrl
                        + (e.InnerException != null
                            ? " (" + e.InnerException.Message + ")"
                            : " (" + e.Message + ")"));
                }
                catch (TaskCanceledException)
                {
                    throw new BackendException("백엔드 응답 시간 초과: " + _baseUrl);
                }
                catch (InvalidOperationException e)
                {
                    /* 절대 URI 가 아니거나 http/https 가 아닌 스킴 등 */
                    throw new BackendException(
                        "서버 주소가 올바르지 않습니다: " + _baseUrl + " (" + e.Message + ")");
                }

                try
                {
                    string text = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    if (!response.IsSuccessStatusCode)
                    {
                        string message = (text != null && text.Trim().Length > 0)
                            ? text.Trim()
                            : "HTTP " + (int)response.StatusCode;
                        throw new BackendException(message);
                    }
                    return text;
                }
                finally
                {
                    response.Dispose();
                }
            }
            finally
            {
                request.Dispose();
            }
        }
    }
}
