-- XML 템플릿 저장 스키마 (MariaDB)
--
-- 백엔드가 기동 시 CREATE TABLE IF NOT EXISTS 로 자동 생성하므로
-- 이 스크립트는 수동 적용용 참고 자료다.
--
-- 노드 일련번호(NODE_SN)는 템플릿 내 DFS 전위 순서로 부여된다.
-- ORDER BY NODE_SN 조회만으로 부모가 자식보다 먼저 나오고 형제 순서가 보존된다.

CREATE TABLE IF NOT EXISTS XML_TEMPLATE (
    TEMPLATE_NAME  VARCHAR(100)  NOT NULL,   -- 템플릿 이름
    UPDATED_AT     DATETIME      NOT NULL,   -- 마지막 저장 시각
    PRIMARY KEY (TEMPLATE_NAME)
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS XML_TEMPLATE_NODE (
    TEMPLATE_NAME      VARCHAR(100)   NOT NULL,   -- 템플릿 이름
    NODE_SN            INT            NOT NULL,   -- 노드 일련번호 (DFS 전위 순서, 1부터)
    NODE_NAME          VARCHAR(200)   NOT NULL,   -- 노드 이름
    PARENT_SN          INT            NULL,       -- 부모 노드 일련번호 (루트는 NULL)
    INPUT_TYPE         VARCHAR(20)    NOT NULL,   -- 입력타입: FIXED / VARIABLE / FUNCTION
    INPUT_VALUE        TEXT           NULL,       -- 입력 내용 (노드 값)
    INPUT_DATA_TYPE    VARCHAR(20)    NOT NULL,   -- 입력 데이터 타입: STRING / NUMBER
    DISPLAY_COND       VARCHAR(1000)  NULL,       -- 표시 조건
    REPEAT_COND        VARCHAR(1000)  NULL,       -- 반복 조건
    REPEAT_COUNT_COND  VARCHAR(200)   NULL,       -- 반복 횟수 조건 (숫자 또는 {파라미터})
    PRIMARY KEY (TEMPLATE_NAME, NODE_SN),
    CONSTRAINT FK_XML_TEMPLATE_NODE FOREIGN KEY (TEMPLATE_NAME)
        REFERENCES XML_TEMPLATE (TEMPLATE_NAME)
) DEFAULT CHARSET=utf8mb4;
