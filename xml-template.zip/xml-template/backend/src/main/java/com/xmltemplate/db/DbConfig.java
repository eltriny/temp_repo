package com.xmltemplate.db;

/**
 * MariaDB 접속 설정.
 *
 * 기본값: jdbc:mariadb://127.0.0.1:13306/xml_template (xml_template / xml_template)
 * 환경 변수 XMLTPL_DB_URL / XMLTPL_DB_USER / XMLTPL_DB_PASSWORD 로 재정의할 수 있다.
 */
public class DbConfig {

    public static final String DEFAULT_URL = "jdbc:mariadb://127.0.0.1:13306/xml_template";
    public static final String DEFAULT_USER = "xml_template";
    public static final String DEFAULT_PASSWORD = "xml_template";

    private final String url;
    private final String user;
    private final String password;

    public DbConfig(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    /** 환경 변수가 있으면 사용하고, 없으면 기본값을 쓴다. */
    public static DbConfig fromEnvironment() {
        String url = envOr("XMLTPL_DB_URL", DEFAULT_URL);
        String user = envOr("XMLTPL_DB_USER", DEFAULT_USER);
        String password = envOr("XMLTPL_DB_PASSWORD", DEFAULT_PASSWORD);
        return new DbConfig(url, user, password);
    }

    private static String envOr(String name, String defaultValue) {
        String value = System.getenv(name);
        return (value == null || value.trim().isEmpty()) ? defaultValue : value;
    }

    public String getUrl() {
        return url;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }
}
