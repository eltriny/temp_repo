package com.xmltemplate.model;

/**
 * 노드 값의 유형.
 *
 * FIXED    : 입력된 텍스트를 그대로 노드 값으로 사용한다.
 * VARIABLE : 값 안의 {변수명} 을 외부 데이터에서 찾아 치환한다. (예: "{ORDER_NO}", "주문번호: {ORDER_NO}")
 * FUNCTION : 삼항연산자 조건식을 평가한 결과를 노드 값으로 사용한다.
 *            (예: "{TYPE} == 'A' ? '국내' : '해외'")
 */
public enum ValueType {
    FIXED,
    VARIABLE,
    FUNCTION;

    /** 직렬화 문자열로부터 복원. 알 수 없는 값은 FIXED 로 처리한다. */
    public static ValueType fromString(String s) {
        if (s == null) {
            return FIXED;
        }
        for (ValueType t : values()) {
            if (t.name().equalsIgnoreCase(s.trim())) {
                return t;
            }
        }
        return FIXED;
    }
}
