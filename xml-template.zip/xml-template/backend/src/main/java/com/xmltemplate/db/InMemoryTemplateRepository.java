package com.xmltemplate.db;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.template.TemplateSerializer;

/**
 * 메모리 기반 템플릿 저장소.
 *
 * DB 없이 서버를 기동해서 API 를 검증하거나 로컬 개발할 때 사용한다.
 * 템플릿을 XML 문자열로 보관하므로 save 이후 원본 트리를 수정해도
 * 저장본에는 영향이 없다 (DB 저장과 동일한 격리 특성).
 */
public class InMemoryTemplateRepository implements TemplateRepository {

    private final Map<String, String> store = new ConcurrentHashMap<String, String>();

    @Override
    public void save(String templateName, TemplateNode root) {
        TemplateRepository.validateName(templateName);
        store.put(templateName, TemplateSerializer.toXmlString(templateName, root));
    }

    @Override
    public TemplateNode load(String templateName) {
        TemplateRepository.validateName(templateName);
        String xml = store.get(templateName);
        return (xml == null) ? null : TemplateSerializer.fromXmlString(xml);
    }

    @Override
    public List<String> list() {
        List<String> names = new ArrayList<String>(store.keySet());
        Collections.sort(names);
        return names;
    }

    @Override
    public boolean delete(String templateName) {
        TemplateRepository.validateName(templateName);
        return store.remove(templateName) != null;
    }

    @Override
    public boolean exists(String templateName) {
        TemplateRepository.validateName(templateName);
        return store.containsKey(templateName);
    }
}
