package com.xmltemplate.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import com.xmltemplate.db.DbConfig;
import com.xmltemplate.db.InMemoryTemplateRepository;
import com.xmltemplate.db.MariaDbTemplateRepository;
import com.xmltemplate.db.RepositoryException;
import com.xmltemplate.db.TemplateRepository;
import com.xmltemplate.engine.XmlGenerator;
import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.template.TemplateSerializer;

/**
 * 템플릿 관리 / XML 생성 HTTP API 서버.
 *
 * C# 프론트엔드가 호출하는 엔드포인트:
 *
 *  GET    /templates          저장된 템플릿 이름 목록 (줄바꿈 구분 텍스트)
 *  GET    /templates/{name}   템플릿 XML 조회
 *  PUT    /templates/{name}   템플릿 저장 (body: 템플릿 XML) - POST 도 허용
 *  DELETE /templates/{name}   템플릿 삭제
 *  POST   /generate/{name}    저장된 템플릿으로 XML 생성
 *                             (body: 한 줄에 변수명=값, # 은 주석)
 *  POST   /preview            저장하지 않은 템플릿의 미리보기 생성
 *                             (body: previewRequest XML - 아래 참조)
 *
 * previewRequest 포맷:
 * <pre>
 * &lt;previewRequest&gt;
 *   &lt;template name="..."&gt; ...템플릿 노드들... &lt;/template&gt;
 *   &lt;data&gt;
 *     &lt;param name="ORDER_NO"&gt;ORD-0001&lt;/param&gt;
 *   &lt;/data&gt;
 * &lt;/previewRequest&gt;
 * </pre>
 *
 * 응답: 성공 200 + XML(또는 텍스트), 요청 오류 400, 없음 404, 서버 오류 500.
 * 본문 인코딩은 요청/응답 모두 UTF-8.
 */
public class HttpApiServer {

    private final TemplateRepository repository;
    private HttpServer server;

    public HttpApiServer(TemplateRepository repository) {
        this.repository = repository;
    }

    public void start(int port) throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", new RootHandler());
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("HTTP API 서버 시작: http://localhost:" + port);
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    /**
     * 기동 인자:
     *   [포트] [--memory]
     * --memory 를 주면 메모리 저장소(테스트용), 아니면 MariaDB
     * (기본: jdbc:mariadb://127.0.0.1:13306/xml_template,
     *  환경 변수 XMLTPL_DB_URL / XMLTPL_DB_USER / XMLTPL_DB_PASSWORD 로 재정의).
     */
    public static void main(String[] args) throws IOException {
        int port = 8080;
        boolean memory = false;
        for (String arg : args) {
            if ("--memory".equals(arg)) {
                memory = true;
            } else {
                try {
                    port = Integer.parseInt(arg);
                } catch (NumberFormatException e) {
                    System.err.println("알 수 없는 인자: " + arg);
                    System.exit(1);
                }
            }
        }
        DbConfig config = DbConfig.fromEnvironment();
        TemplateRepository repo = memory
                ? new InMemoryTemplateRepository()
                : new MariaDbTemplateRepository(config);
        System.out.println("저장소: " + (memory ? "메모리 (테스트용)" : "MariaDB (" + config.getUrl() + ")"));
        new HttpApiServer(repo).start(port);
    }

    /* ------------------------------------------------------------------ */
    /* 라우팅                                                               */
    /* ------------------------------------------------------------------ */

    private class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                route(exchange);
            } catch (XmlGenerator.GenerationException e) {
                send(exchange, 400, e.getMessage(), false);
            } catch (TemplateSerializer.SerializationException e) {
                send(exchange, 400, e.getMessage(), false);
            } catch (RepositoryException e) {
                send(exchange, 500, e.getMessage(), false);
            } catch (BadRequestException e) {
                send(exchange, 400, e.getMessage(), false);
            } catch (Exception e) {
                send(exchange, 500, "서버 오류: " + e, false);
            } finally {
                exchange.close();
            }
        }
    }

    private static class BadRequestException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        BadRequestException(String message) {
            super(message);
        }
    }

    private void route(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();

        /* CORS preflight (React 프론트엔드가 다른 포트에서 호출) */
        if ("OPTIONS".equals(method)) {
            addCorsHeaders(exchange);
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        /*
         * getRawPath() 를 쓴다. getPath() 는 이미 %XX 를 디코딩한 값이라
         * 뒤에서 decode() 를 또 하면 이중 디코딩이 된다.
         * (예: "a%2Bb" -> getPath "a+b" -> URLDecoder "a b" 로 변조)
         */
        String path = exchange.getRequestURI().getRawPath();
        String[] segments = splitPath(path);

        if (segments.length == 1 && "templates".equals(segments[0])) {
            if ("GET".equals(method)) {
                handleList(exchange);
                return;
            }
            send(exchange, 405, "허용되지 않는 메서드입니다: " + method, false);
            return;
        }

        if (segments.length == 2 && "templates".equals(segments[0])) {
            String name = validatedName(decode(segments[1]));
            if ("GET".equals(method)) {
                handleGet(exchange, name);
            } else if ("PUT".equals(method) || "POST".equals(method)) {
                handleSave(exchange, name);
            } else if ("DELETE".equals(method)) {
                handleDelete(exchange, name);
            } else {
                send(exchange, 405, "허용되지 않는 메서드입니다: " + method, false);
            }
            return;
        }

        if (segments.length == 2 && "generate".equals(segments[0])) {
            if ("POST".equals(method)) {
                handleGenerate(exchange, validatedName(decode(segments[1])));
                return;
            }
            send(exchange, 405, "허용되지 않는 메서드입니다: " + method, false);
            return;
        }

        if (segments.length == 1 && "preview".equals(segments[0])) {
            if ("POST".equals(method)) {
                handlePreview(exchange);
                return;
            }
            send(exchange, 405, "허용되지 않는 메서드입니다: " + method, false);
            return;
        }

        send(exchange, 404, "알 수 없는 경로입니다: " + path, false);
    }

    /* ------------------------------------------------------------------ */
    /* 핸들러                                                               */
    /* ------------------------------------------------------------------ */

    private void handleList(HttpExchange exchange) throws IOException {
        List<String> names = repository.list();
        StringBuilder sb = new StringBuilder();
        for (String name : names) {
            sb.append(name).append('\n');
        }
        send(exchange, 200, sb.toString(), false);
    }

    private void handleGet(HttpExchange exchange, String name) throws IOException {
        TemplateNode root = repository.load(name);
        if (root == null) {
            send(exchange, 404, "템플릿이 존재하지 않습니다: " + name, false);
            return;
        }
        send(exchange, 200, TemplateSerializer.toXmlString(name, root), true);
    }

    private void handleSave(HttpExchange exchange, String name) throws IOException {
        String body = readBody(exchange);
        if (body.trim().isEmpty()) {
            throw new BadRequestException("요청 본문에 템플릿 XML 이 없습니다.");
        }
        TemplateNode root = TemplateSerializer.fromXmlString(body);
        repository.save(name, root);
        send(exchange, 200, "저장되었습니다: " + name, false);
    }

    private void handleDelete(HttpExchange exchange, String name) throws IOException {
        if (repository.delete(name)) {
            send(exchange, 200, "삭제되었습니다: " + name, false);
        } else {
            send(exchange, 404, "템플릿이 존재하지 않습니다: " + name, false);
        }
    }

    private void handleGenerate(HttpExchange exchange, String name) throws IOException {
        TemplateNode root = repository.load(name);
        if (root == null) {
            send(exchange, 404, "템플릿이 존재하지 않습니다: " + name, false);
            return;
        }
        Map<String, String> data = parseKeyValueData(readBody(exchange));
        String xml = new XmlGenerator(root, data).generate();
        send(exchange, 200, xml, true);
    }

    private void handlePreview(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        PreviewRequest request = parsePreviewRequest(body);
        String xml = new XmlGenerator(request.template, request.data).generate();
        send(exchange, 200, xml, true);
    }

    /* ------------------------------------------------------------------ */
    /* 요청 해석                                                             */
    /* ------------------------------------------------------------------ */

    private static class PreviewRequest {
        final TemplateNode template;
        final Map<String, String> data;

        PreviewRequest(TemplateNode template, Map<String, String> data) {
            this.template = template;
            this.data = data;
        }
    }

    /** previewRequest XML 을 해석한다. */
    private static PreviewRequest parsePreviewRequest(String body) {
        if (body == null || body.trim().isEmpty()) {
            throw new BadRequestException("요청 본문이 비어 있습니다.");
        }
        Document doc;
        try {
            doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                    .parse(new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new BadRequestException("previewRequest XML 해석 실패: " + e.getMessage());
        }
        Element rootEl = doc.getDocumentElement();
        if (rootEl == null || !"previewRequest".equals(rootEl.getTagName())) {
            throw new BadRequestException("루트 엘리먼트는 previewRequest 여야 합니다.");
        }

        Element templateEl = firstChildElement(rootEl, "template");
        if (templateEl == null) {
            throw new BadRequestException("previewRequest 에 template 이 없습니다.");
        }
        Element rootNodeEl = firstChildElement(templateEl, "node");
        if (rootNodeEl == null) {
            throw new BadRequestException("template 에 루트 node 가 없습니다.");
        }
        TemplateNode template = TemplateSerializer.readNode(rootNodeEl);

        Map<String, String> data = new HashMap<String, String>();
        Element dataEl = firstChildElement(rootEl, "data");
        if (dataEl != null) {
            NodeList params = dataEl.getChildNodes();
            for (int i = 0; i < params.getLength(); i++) {
                Node child = params.item(i);
                if (child.getNodeType() == Node.ELEMENT_NODE
                        && "param".equals(((Element) child).getTagName())) {
                    Element param = (Element) child;
                    String paramName = param.getAttribute("name");
                    if (!paramName.isEmpty()) {
                        data.put(paramName, param.getTextContent());
                    }
                }
            }
        }
        return new PreviewRequest(template, data);
    }

    /** "변수명=값" 줄 단위 데이터를 해석한다. '#' 으로 시작하는 줄은 주석. */
    private static Map<String, String> parseKeyValueData(String body) {
        Map<String, String> data = new HashMap<String, String>();
        if (body == null) {
            return data;
        }
        for (String rawLine : body.split("\n")) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            int eq = line.indexOf('=');
            if (eq < 1) {
                continue;
            }
            data.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim());
        }
        return data;
    }

    /* ------------------------------------------------------------------ */
    /* HTTP 유틸                                                             */
    /* ------------------------------------------------------------------ */

    private static String[] splitPath(String path) {
        String trimmed = path;
        while (trimmed.startsWith("/")) {
            trimmed = trimmed.substring(1);
        }
        while (trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed.isEmpty() ? new String[0] : trimmed.split("/");
    }

    /** 템플릿 이름 검증. 위반 시 400 으로 응답되도록 BadRequestException 으로 변환. */
    private static String validatedName(String name) {
        try {
            TemplateRepository.validateName(name);
        } catch (RepositoryException e) {
            throw new BadRequestException(e.getMessage());
        }
        return name;
    }

    private static String decode(String segment) {
        try {
            /*
             * URLDecoder 는 폼 인코딩 규칙이라 '+' 를 공백으로 바꾼다.
             * URL 경로에서 '+' 는 리터럴이므로 %2B 로 보호한 뒤 디코딩한다.
             */
            return URLDecoder.decode(segment.replace("+", "%2B"), "UTF-8");
        } catch (Exception e) {
            throw new BadRequestException("경로 인코딩이 잘못되었습니다: " + segment);
        }
    }

    private static String readBody(HttpExchange exchange) throws IOException {
        InputStream in = exchange.getRequestBody();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = in.read(buffer)) >= 0) {
            out.write(buffer, 0, read);
        }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    /** 브라우저 기반 프론트엔드(React 개발 서버 등)의 교차 출처 호출 허용. */
    private static void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods",
                "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    private static void send(HttpExchange exchange, int status, String body, boolean isXml)
            throws IOException {
        byte[] bytes = ((body == null) ? "" : body).getBytes(StandardCharsets.UTF_8);
        String contentType = isXml
                ? "application/xml; charset=utf-8"
                : "text/plain; charset=utf-8";
        addCorsHeaders(exchange);
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.sendResponseHeaders(status, bytes.length);
        OutputStream out = exchange.getResponseBody();
        try {
            out.write(bytes);
        } finally {
            out.close();
        }
    }

    private static Element firstChildElement(Element parent, String tagName) {
        NodeList list = parent.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            Node child = list.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE
                    && tagName.equals(((Element) child).getTagName())) {
                return (Element) child;
            }
        }
        return null;
    }
}
