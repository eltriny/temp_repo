package com.xmltemplate.engine;

import java.io.StringWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xmltemplate.expression.ExpressionEvaluator;
import com.xmltemplate.model.TemplateNode;

/**
 * 템플릿 + 외부 데이터 -> XML 문자열 생성 엔진.
 *
 * 생성 규칙:
 *  1. 표시 조건이 있고 false 로 평가되면 해당 노드(하위 포함)를 생성하지 않는다.
 *  2. 반복 조건이 있고 true 로 평가되면 repeatCount 만큼 반복 생성한다.
 *     반복 조건이 없고 repeatCount 가 2 이상이면 무조건 반복한다.
 *  3. 자식이 있는 노드는 자식 엘리먼트를 갖고, 자식이 없는 노드는 값(텍스트)을 갖는다.
 *  4. 값 유형별 처리:
 *     - FIXED    : 입력 텍스트 그대로
 *     - VARIABLE : {변수명} 을 외부 데이터 값으로 치환 (없으면 빈 문자열)
 *     - FUNCTION : 삼항연산자 조건식 평가 결과
 *  5. 반복 중에는 내장 변수 {INDEX} 가 1부터 시작하는 현재 반복 회차로 치환된다.
 *
 * 조건식의 피연산자로 노드 경로(예: node1-1.node1-1-1)가 오면
 * 해당 노드의 "값" 을 재귀적으로 계산해서 비교에 사용한다.
 * (순환 참조는 빈 문자열로 처리해서 무한 재귀를 막는다.)
 */
public class XmlGenerator {

    /** 반복 회차를 나타내는 내장 변수 이름. */
    public static final String INDEX_VARIABLE = "INDEX";

    private final TemplateNode root;
    private final Map<String, String> data;
    private final ExpressionEvaluator evaluator;

    /** 현재 반복 컨텍스트 (중첩 반복 시 가장 안쪽이 top). */
    private final Deque<Integer> indexStack = new ArrayDeque<Integer>();

    /** 노드 값 계산 중 순환 참조 감지용. */
    private final Set<TemplateNode> resolving = new HashSet<TemplateNode>();

    private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\{([^{}]+)\\}");

    public XmlGenerator(TemplateNode root, Map<String, String> data) {
        this.root = root;
        this.data = (data == null) ? new HashMap<String, String>() : data;
        this.evaluator = new ExpressionEvaluator(new ExpressionEvaluator.Resolver() {
            @Override
            public String resolveNodePath(String path) {
                TemplateNode node = findNode(path);
                return (node == null) ? "" : resolveNodeValue(node);
            }

            @Override
            public String resolveVariable(String name) {
                return lookupVariable(name);
            }
        });
    }

    /**
     * XML 문자열을 생성한다.
     *
     * @throws GenerationException 노드 이름이 XML 엘리먼트 이름으로 부적합하거나 조건식 오류가 있을 때
     */
    public String generate() {
        try {
            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();

            /* 루트는 XML 규칙상 1개만 허용되므로 반복 설정을 무시하고 1개만 생성한다. */
            List<Element> rootElements = buildElements(doc, root, true);
            if (rootElements.isEmpty()) {
                throw new GenerationException(
                        "루트 노드가 표시 조건에 의해 제외되어 XML 을 생성할 수 없습니다.");
            }
            doc.appendChild(rootElements.get(0));
            return serialize(doc);
        } catch (GenerationException e) {
            throw e;
        } catch (ExpressionEvaluator.ExpressionException e) {
            throw new GenerationException("조건식 오류: " + e.getMessage());
        } catch (Exception e) {
            throw new GenerationException("XML 생성 실패: " + e.getMessage());
        }
    }

    public static class GenerationException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public GenerationException(String message) {
            super(message);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 노드 -> 엘리먼트 변환                                                */
    /* ------------------------------------------------------------------ */

    private List<Element> buildElements(Document doc, TemplateNode node, boolean isRoot) {
        List<Element> result = new ArrayList<Element>();

        /* 1. 표시 조건 */
        String displayCond = trim(node.getDisplayCondition());
        if (!displayCond.isEmpty() && !evaluateCondition(node, "표시 조건", displayCond)) {
            return result;
        }

        /* 2. 반복 횟수 결정 */
        int count = 1;
        String repeatCond = trim(node.getRepeatCondition());
        boolean isRepeating = !repeatCond.isEmpty() || node.getRepeatCount() > 1;
        if (!repeatCond.isEmpty()) {
            if (evaluateCondition(node, "반복 조건", repeatCond)) {
                count = Math.max(1, node.getRepeatCount());
            }
        } else if (node.getRepeatCount() > 1) {
            count = node.getRepeatCount();
        }
        if (isRoot) {
            count = 1;
            isRepeating = false;
        }

        /*
         * 3. count 만큼 엘리먼트 생성.
         * 인덱스 스택은 반복 설정이 있는 노드만 사용한다.
         * 모든 노드가 push 하면 자식 노드의 인덱스(항상 1)가
         * 조상 반복 노드의 회차를 가려서 {INDEX} 가 늘 1이 되기 때문이다.
         */
        for (int i = 1; i <= count; i++) {
            if (isRepeating) {
                indexStack.push(Integer.valueOf(i));
            }
            try {
                Element el = createElement(doc, node);
                if (node.hasChildren()) {
                    for (TemplateNode child : node.getChildren()) {
                        for (Element childEl : buildElements(doc, child, false)) {
                            el.appendChild(childEl);
                        }
                    }
                } else {
                    String value = resolveNodeValue(node);
                    if (!value.isEmpty()) {
                        el.appendChild(doc.createTextNode(value));
                    }
                }
                result.add(el);
            } finally {
                if (isRepeating) {
                    indexStack.pop();
                }
            }
        }
        return result;
    }

    private Element createElement(Document doc, TemplateNode node) {
        String name = trim(node.getName());
        if (name.isEmpty()) {
            throw new GenerationException("이름이 비어 있는 노드가 있습니다. (경로: " + node.getPath() + ")");
        }
        /*
         * ':' 은 XML 네임스페이스 접두사로 해석된다. 네임스페이스 미선언 상태에서는
         * 환경(Java DOM / C# XmlDocument)에 따라 동작이 갈리므로 명시적으로 거부한다.
         */
        if (name.indexOf(':') >= 0) {
            throw new GenerationException(
                    "노드 이름에 ':' 은 사용할 수 없습니다: '" + name + "' (경로: " + node.getPath() + ")");
        }
        try {
            return doc.createElement(name);
        } catch (org.w3c.dom.DOMException e) {
            throw new GenerationException(
                    "'" + name + "' 은(는) XML 엘리먼트 이름으로 사용할 수 없습니다. (경로: " + node.getPath() + ")");
        }
    }

    private boolean evaluateCondition(TemplateNode node, String kind, String condition) {
        try {
            return evaluator.evaluateCondition(condition);
        } catch (ExpressionEvaluator.ExpressionException e) {
            throw new GenerationException(
                    "노드 '" + node.getPath() + "' 의 " + kind + " 오류: " + e.getMessage());
        }
    }

    /* ------------------------------------------------------------------ */
    /* 값 계산                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * 노드의 값을 계산한다. 조건식에서 노드 경로 피연산자를 만나도 이 메서드를 사용한다.
     * 순환 참조가 감지되면 빈 문자열을 반환한다.
     */
    private String resolveNodeValue(TemplateNode node) {
        if (!resolving.add(node)) {
            return "";
        }
        try {
            String raw = node.getValue();
            if (raw == null) {
                return "";
            }
            switch (node.getValueType()) {
                case VARIABLE:
                    return substituteVariables(raw);
                case FUNCTION: {
                    String expr = trim(raw);
                    if (expr.isEmpty()) {
                        return "";
                    }
                    Object result = evaluator.evaluate(expr);
                    return String.valueOf(result);
                }
                case FIXED:
                default:
                    return raw;
            }
        } catch (ExpressionEvaluator.ExpressionException e) {
            throw new GenerationException(
                    "노드 '" + node.getPath() + "' 의 값(함수) 오류: " + e.getMessage());
        } finally {
            resolving.remove(node);
        }
    }

    /** 문자열 안의 {변수명} 을 모두 외부 데이터 값으로 치환한다. */
    private String substituteVariables(String text) {
        Matcher m = VARIABLE_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String value = lookupVariable(m.group(1).trim());
            m.appendReplacement(sb, Matcher.quoteReplacement(value));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private String lookupVariable(String name) {
        if (INDEX_VARIABLE.equals(name)) {
            Integer top = indexStack.peek();
            return (top == null) ? "" : String.valueOf(top);
        }
        String value = data.get(name);
        return (value == null) ? "" : value;
    }

    /* ------------------------------------------------------------------ */
    /* 노드 경로 탐색                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * 전체 경로(예: "node1-1.node1-1-1")로 노드를 찾는다.
     * 루트 이름을 포함한 경로("ROOT.node1-1...")와
     * 루트 바로 아래부터 시작하는 경로("node1-1...") 둘 다 허용한다.
     */
    private TemplateNode findNode(String path) {
        if (path == null || path.trim().isEmpty()) {
            return null;
        }
        String[] segments = path.trim().split("\\.");

        TemplateNode found = matchFrom(root, segments, 0);
        if (found != null) {
            return found;
        }
        for (TemplateNode child : root.getChildren()) {
            found = matchFrom(child, segments, 0);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    private TemplateNode matchFrom(TemplateNode node, String[] segments, int index) {
        if (!node.getName().equals(segments[index])) {
            return null;
        }
        if (index == segments.length - 1) {
            return node;
        }
        for (TemplateNode child : node.getChildren()) {
            TemplateNode found = matchFrom(child, segments, index + 1);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* 직렬화                                                               */
    /* ------------------------------------------------------------------ */

    private static String serialize(Document doc) throws Exception {
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        return writer.toString();
    }

    private static String trim(String s) {
        return (s == null) ? "" : s.trim();
    }
}
