package com.xmltemplate.expression;

import java.util.ArrayList;
import java.util.List;

/**
 * 템플릿 조건식 평가기.
 *
 * 지원 문법 (우선순위 낮은 것부터):
 *   expr       := ternary
 *   ternary    := or ( '?' ternary ':' ternary )?
 *   or         := and ( '||' and )*
 *   and        := comparison ( '&&' comparison )*
 *   comparison := operand ( ('=='|'!='|'>='|'<='|'>'|'<') operand )?
 *   operand    := '(' expr ')' | STRING | NUMBER | VARIABLE | NODEPATH
 *
 *   STRING   : 작은따옴표 문자열. 예) 'VALUE'  (따옴표 이스케이프는 지원하지 않음)
 *   NUMBER   : 정수/실수. 예) 3, 1.5, -2
 *   VARIABLE : 외부 데이터 변수. 예) {PARAM}
 *   NODEPATH : 노드 전체 경로. 예) node1-1.node1-1-1
 *
 * 피연산자(노드 경로, 변수)의 실제 값은 {@link Resolver} 를 통해 얻는다.
 * 비교 시 양쪽 모두 숫자로 해석되면 숫자 비교, 아니면 문자열 비교를 한다.
 */
public class ExpressionEvaluator {

    /** 노드 경로/외부 변수의 값을 제공하는 인터페이스. XML 생성기가 구현한다. */
    public interface Resolver {
        String resolveNodePath(String path);
        String resolveVariable(String name);
    }

    /** 식이 잘못되었을 때 발생하는 예외. */
    public static class ExpressionException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public ExpressionException(String message) {
            super(message);
        }
    }

    private final Resolver resolver;

    public ExpressionEvaluator(Resolver resolver) {
        this.resolver = resolver;
    }

    /**
     * 식을 평가한다. 결과는 Boolean(조건식) 또는 String(값 식)이다.
     */
    public Object evaluate(String expression) {
        List<Token> tokens = tokenize(expression);
        Parser parser = new Parser(tokens);
        Object result = parser.parseExpression();
        parser.expectEnd();
        return result;
    }

    /**
     * 조건식을 평가해서 참/거짓을 반환한다.
     * Boolean 이 아닌 결과는 문자열 "true"(대소문자 무시)일 때만 참으로 본다.
     */
    public boolean evaluateCondition(String expression) {
        Object result = evaluate(expression);
        return isTruthy(result);
    }

    public static boolean isTruthy(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        return "true".equalsIgnoreCase(String.valueOf(value).trim());
    }

    /* ------------------------------------------------------------------ */
    /* 어휘 분석 (Lexer)                                                    */
    /* ------------------------------------------------------------------ */

    private enum TokenType { STRING, NUMBER, VARIABLE, NODEPATH, OP, END }

    private static final class Token {
        final TokenType type;
        final String text;

        Token(TokenType type, String text) {
            this.type = type;
            this.text = text;
        }
    }

    private List<Token> tokenize(String expr) {
        if (expr == null) {
            throw new ExpressionException("식이 비어 있습니다.");
        }
        List<Token> tokens = new ArrayList<Token>();
        int i = 0;
        int len = expr.length();

        while (i < len) {
            char c = expr.charAt(i);

            if (isSpace(c)) {
                i++;
                continue;
            }

            /* 문자열 리터럴 'xxx' */
            if (c == '\'') {
                int end = expr.indexOf('\'', i + 1);
                if (end < 0) {
                    throw new ExpressionException("문자열이 닫히지 않았습니다: " + expr.substring(i));
                }
                tokens.add(new Token(TokenType.STRING, expr.substring(i + 1, end)));
                i = end + 1;
                continue;
            }

            /* 외부 데이터 변수 {NAME} */
            if (c == '{') {
                int end = expr.indexOf('}', i + 1);
                if (end < 0) {
                    throw new ExpressionException("변수가 닫히지 않았습니다: " + expr.substring(i));
                }
                String name = expr.substring(i + 1, end).trim();
                if (name.isEmpty()) {
                    throw new ExpressionException("변수 이름이 비어 있습니다.");
                }
                tokens.add(new Token(TokenType.VARIABLE, name));
                i = end + 1;
                continue;
            }

            /* 2문자 연산자 */
            if (i + 1 < len) {
                String two = expr.substring(i, i + 2);
                if (two.equals("==") || two.equals("!=") || two.equals(">=")
                        || two.equals("<=") || two.equals("&&") || two.equals("||")) {
                    tokens.add(new Token(TokenType.OP, two));
                    i += 2;
                    continue;
                }
            }

            /* 1문자 연산자 */
            if (c == '>' || c == '<' || c == '?' || c == ':' || c == '(' || c == ')') {
                tokens.add(new Token(TokenType.OP, String.valueOf(c)));
                i++;
                continue;
            }

            /* 음수: 피연산자 위치에서 '-' 뒤에 숫자가 오는 경우 */
            if (c == '-' && i + 1 < len && Character.isDigit(expr.charAt(i + 1))
                    && expectsOperand(tokens)) {
                int start = i;
                i++;
                i = consumeNumber(expr, i);
                tokens.add(new Token(TokenType.NUMBER, expr.substring(start, i)));
                continue;
            }

            /* 숫자 */
            if (Character.isDigit(c)) {
                int start = i;
                i = consumeNumber(expr, i);
                /* 숫자 뒤에 노드 이름 문자가 이어지면 노드 경로로 본다. 예) 1abc (드문 경우) */
                if (i < len && isPathChar(expr.charAt(i))) {
                    i = consumePath(expr, i);
                    tokens.add(new Token(TokenType.NODEPATH, expr.substring(start, i)));
                } else {
                    tokens.add(new Token(TokenType.NUMBER, expr.substring(start, i)));
                }
                continue;
            }

            /* 노드 경로 (이름에 영문/숫자/한글/'-'/'_'/'.' 허용) */
            if (isPathStartChar(c)) {
                int start = i;
                i = consumePath(expr, i);
                tokens.add(new Token(TokenType.NODEPATH, expr.substring(start, i)));
                continue;
            }

            throw new ExpressionException("해석할 수 없는 문자입니다: '" + c + "' (위치 " + i + ")");
        }

        tokens.add(new Token(TokenType.END, ""));
        return tokens;
    }

    /**
     * 식에서 무시하는 공백. C# 프론트엔드와 동일하게 명시적 집합으로 제한한다.
     * (Character.isWhitespace 와 char.IsWhiteSpace 는 U+00A0 등에서 판정이 다르다.)
     */
    private static boolean isSpace(char c) {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n';
    }

    /** 직전 토큰 기준으로 다음에 피연산자가 와야 하는 위치인지 판단 (음수 판별용). */
    private static boolean expectsOperand(List<Token> tokens) {
        if (tokens.isEmpty()) {
            return true;
        }
        Token last = tokens.get(tokens.size() - 1);
        return last.type == TokenType.OP && !last.text.equals(")");
    }

    private static int consumeNumber(String expr, int i) {
        int len = expr.length();
        while (i < len && Character.isDigit(expr.charAt(i))) {
            i++;
        }
        if (i < len && expr.charAt(i) == '.' && i + 1 < len && Character.isDigit(expr.charAt(i + 1))) {
            i++;
            while (i < len && Character.isDigit(expr.charAt(i))) {
                i++;
            }
        }
        return i;
    }

    private static boolean isPathStartChar(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isPathChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '-' || c == '.';
    }

    private static int consumePath(String expr, int i) {
        int len = expr.length();
        while (i < len && isPathChar(expr.charAt(i))) {
            i++;
        }
        /* 경로 끝의 '.' 은 경로에 포함하지 않는다. */
        while (i > 0 && expr.charAt(i - 1) == '.') {
            i--;
        }
        return i;
    }

    /* ------------------------------------------------------------------ */
    /* 구문 분석 + 평가 (Parser)                                            */
    /* ------------------------------------------------------------------ */

    private final class Parser {
        private final List<Token> tokens;
        private int pos = 0;

        Parser(List<Token> tokens) {
            this.tokens = tokens;
        }

        Object parseExpression() {
            return parseTernary();
        }

        /** ternary := or ( '?' ternary ':' ternary )? */
        private Object parseTernary() {
            Object cond = parseOr();
            if (matchOp("?")) {
                Object whenTrue = parseTernary();
                expectOp(":");
                Object whenFalse = parseTernary();
                return isTruthy(cond) ? whenTrue : whenFalse;
            }
            return cond;
        }

        /** or := and ( '||' and )* */
        private Object parseOr() {
            Object left = parseAnd();
            while (matchOp("||")) {
                Object right = parseAnd();
                left = Boolean.valueOf(isTruthy(left) || isTruthy(right));
            }
            return left;
        }

        /** and := comparison ( '&&' comparison )* */
        private Object parseAnd() {
            Object left = parseComparison();
            while (matchOp("&&")) {
                Object right = parseComparison();
                left = Boolean.valueOf(isTruthy(left) && isTruthy(right));
            }
            return left;
        }

        /** comparison := operand ( op operand )? */
        private Object parseComparison() {
            Object left = parseOperand();
            Token t = peek();
            if (t.type == TokenType.OP && isComparisonOp(t.text)) {
                pos++;
                Object right = parseOperand();
                return Boolean.valueOf(compare(left, right, t.text));
            }
            return left;
        }

        private Object parseOperand() {
            Token t = peek();
            switch (t.type) {
                case STRING:
                    pos++;
                    return t.text;
                case NUMBER:
                    pos++;
                    return t.text;
                case VARIABLE:
                    pos++;
                    return nullToEmpty(resolver.resolveVariable(t.text));
                case NODEPATH:
                    pos++;
                    return nullToEmpty(resolver.resolveNodePath(t.text));
                case OP:
                    if (t.text.equals("(")) {
                        pos++;
                        Object inner = parseExpression();
                        expectOp(")");
                        return inner;
                    }
                    break;
                default:
                    break;
            }
            throw new ExpressionException("피연산자가 필요한 위치에 '" + t.text + "' 이(가) 있습니다.");
        }

        private boolean matchOp(String op) {
            Token t = peek();
            if (t.type == TokenType.OP && t.text.equals(op)) {
                pos++;
                return true;
            }
            return false;
        }

        private void expectOp(String op) {
            if (!matchOp(op)) {
                throw new ExpressionException("'" + op + "' 이(가) 필요합니다. (현재: '" + peek().text + "')");
            }
        }

        void expectEnd() {
            if (peek().type != TokenType.END) {
                throw new ExpressionException("식 끝에 해석할 수 없는 내용이 있습니다: '" + peek().text + "'");
            }
        }

        private Token peek() {
            return tokens.get(pos);
        }
    }

    private static boolean isComparisonOp(String op) {
        return op.equals("==") || op.equals("!=") || op.equals(">")
                || op.equals("<") || op.equals(">=") || op.equals("<=");
    }

    private static String nullToEmpty(String s) {
        return (s == null) ? "" : s;
    }

    /**
     * 두 값을 비교한다. 양쪽 모두 숫자면 숫자 비교, 아니면 문자열 비교.
     */
    private static boolean compare(Object left, Object right, String op) {
        String ls = String.valueOf(left);
        String rs = String.valueOf(right);
        Double ln = tryParseNumber(ls);
        Double rn = tryParseNumber(rs);

        int cmp;
        if (ln != null && rn != null) {
            cmp = ln.compareTo(rn);
        } else {
            cmp = ls.compareTo(rs);
        }

        if (op.equals("==")) {
            return cmp == 0;
        }
        if (op.equals("!=")) {
            return cmp != 0;
        }
        if (op.equals(">")) {
            return cmp > 0;
        }
        if (op.equals("<")) {
            return cmp < 0;
        }
        if (op.equals(">=")) {
            return cmp >= 0;
        }
        return cmp <= 0; /* <= */
    }

    private static Double tryParseNumber(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        if (t.isEmpty()) {
            return null;
        }
        /*
         * Double.valueOf 는 "10d", "1.5f", "0x1p3" 같은 자바 전용 표기도 허용하지만
         * C# 프론트엔드의 double.TryParse 는 거부한다. 판정을 일치시키기 위해 차단한다.
         */
        char last = t.charAt(t.length() - 1);
        if (last == 'd' || last == 'D' || last == 'f' || last == 'F') {
            return null;
        }
        String body = (t.charAt(0) == '+' || t.charAt(0) == '-') ? t.substring(1) : t;
        if (body.startsWith("0x") || body.startsWith("0X")) {
            return null;
        }
        try {
            return Double.valueOf(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
