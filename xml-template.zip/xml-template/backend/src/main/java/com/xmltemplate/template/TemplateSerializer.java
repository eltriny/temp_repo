package com.xmltemplate.template;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.model.ValueType;

/**
 * 템플릿 <-> 템플릿 파일(XML) 직렬화.
 *
 * 파일 포맷 (C# 프론트엔드와 공유):
 * <pre>
 * &lt;template name="템플릿이름"&gt;
 *   &lt;node name="ROOT"&gt;
 *     &lt;value type="FIXED"&gt;값&lt;/value&gt;
 *     &lt;displayCondition&gt;조건식&lt;/displayCondition&gt;
 *     &lt;repeatCondition&gt;조건식&lt;/repeatCondition&gt;
 *     &lt;repeatCount&gt;3&lt;/repeatCount&gt;
 *     &lt;children&gt;
 *       &lt;node ...&gt; ... &lt;/node&gt;
 *     &lt;/children&gt;
 *   &lt;/node&gt;
 * &lt;/template&gt;
 * </pre>
 *
 * 노드 이름은 XML 엘리먼트 이름이 아닌 name 속성에 저장하므로,
 * 편집 중 아직 유효하지 않은 이름도 손실 없이 저장/복원된다.
 */
public final class TemplateSerializer {

    private TemplateSerializer() {
    }

    public static class SerializationException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public SerializationException(String message, Throwable cause) {
            super(message, cause);
        }

        public SerializationException(String message) {
            super(message);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 쓰기                                                                */
    /* ------------------------------------------------------------------ */

    public static String toXmlString(String templateName, TemplateNode root) {
        try {
            Document doc = newDocument();
            Element templateEl = doc.createElement("template");
            templateEl.setAttribute("name", (templateName == null) ? "" : templateName);
            doc.appendChild(templateEl);
            templateEl.appendChild(writeNode(doc, root));

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            return writer.toString();
        } catch (Exception e) {
            throw new SerializationException("템플릿 직렬화 실패: " + e.getMessage(), e);
        }
    }

    public static void save(File file, String templateName, TemplateNode root) {
        String xml = toXmlString(templateName, root);
        try {
            OutputStream out = new FileOutputStream(file);
            try {
                out.write(xml.getBytes(StandardCharsets.UTF_8));
            } finally {
                out.close();
            }
        } catch (Exception e) {
            throw new SerializationException("템플릿 파일 저장 실패: " + file.getPath(), e);
        }
    }

    private static Element writeNode(Document doc, TemplateNode node) {
        Element el = doc.createElement("node");
        el.setAttribute("name", (node.getName() == null) ? "" : node.getName());

        Element valueEl = doc.createElement("value");
        valueEl.setAttribute("type", node.getValueType().name());
        valueEl.setTextContent(node.getValue());
        el.appendChild(valueEl);

        if (!node.getDisplayCondition().isEmpty()) {
            Element dcEl = doc.createElement("displayCondition");
            dcEl.setTextContent(node.getDisplayCondition());
            el.appendChild(dcEl);
        }
        if (!node.getRepeatCondition().isEmpty()) {
            Element rcEl = doc.createElement("repeatCondition");
            rcEl.setTextContent(node.getRepeatCondition());
            el.appendChild(rcEl);
        }
        if (node.getRepeatCount() > 1) {
            Element countEl = doc.createElement("repeatCount");
            countEl.setTextContent(String.valueOf(node.getRepeatCount()));
            el.appendChild(countEl);
        }

        if (node.hasChildren()) {
            Element childrenEl = doc.createElement("children");
            for (TemplateNode child : node.getChildren()) {
                childrenEl.appendChild(writeNode(doc, child));
            }
            el.appendChild(childrenEl);
        }
        return el;
    }

    /* ------------------------------------------------------------------ */
    /* 읽기                                                                */
    /* ------------------------------------------------------------------ */

    public static TemplateNode fromXmlString(String xml) {
        try {
            InputStream in = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
            return read(in);
        } catch (SerializationException e) {
            throw e;
        } catch (Exception e) {
            throw new SerializationException("템플릿 해석 실패: " + e.getMessage(), e);
        }
    }

    public static TemplateNode load(File file) {
        try {
            InputStream in = new FileInputStream(file);
            try {
                return read(in);
            } finally {
                in.close();
            }
        } catch (SerializationException e) {
            throw e;
        } catch (Exception e) {
            throw new SerializationException("템플릿 파일 읽기 실패: " + file.getPath(), e);
        }
    }

    private static TemplateNode read(InputStream in) throws Exception {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.parse(in);
        Element templateEl = doc.getDocumentElement();
        if (templateEl == null || !"template".equals(templateEl.getTagName())) {
            throw new SerializationException("템플릿 파일이 아닙니다. (루트 엘리먼트: template 필요)");
        }
        Element rootNodeEl = firstChildElement(templateEl, "node");
        if (rootNodeEl == null) {
            throw new SerializationException("템플릿에 루트 node 가 없습니다.");
        }
        return readNode(rootNodeEl);
    }

    private static TemplateNode readNode(Element el) {
        TemplateNode node = new TemplateNode(el.getAttribute("name"));

        Element valueEl = firstChildElement(el, "value");
        if (valueEl != null) {
            node.setValueType(ValueType.fromString(valueEl.getAttribute("type")));
            node.setValue(valueEl.getTextContent());
        }

        Element dcEl = firstChildElement(el, "displayCondition");
        if (dcEl != null) {
            node.setDisplayCondition(dcEl.getTextContent());
        }
        Element rcEl = firstChildElement(el, "repeatCondition");
        if (rcEl != null) {
            node.setRepeatCondition(rcEl.getTextContent());
        }
        Element countEl = firstChildElement(el, "repeatCount");
        if (countEl != null) {
            node.setRepeatCount(parseIntSafe(countEl.getTextContent(), 1));
        }

        Element childrenEl = firstChildElement(el, "children");
        if (childrenEl != null) {
            NodeList list = childrenEl.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node child = list.item(i);
                if (child.getNodeType() == Node.ELEMENT_NODE
                        && "node".equals(((Element) child).getTagName())) {
                    node.addChild(readNode((Element) child));
                }
            }
        }
        return node;
    }

    /** 파일에서 템플릿 이름(template 엘리먼트의 name 속성)을 읽는다. */
    public static String readTemplateName(File file) {
        try {
            InputStream in = new FileInputStream(file);
            try {
                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                Document doc = builder.parse(in);
                return doc.getDocumentElement().getAttribute("name");
            } finally {
                in.close();
            }
        } catch (Exception e) {
            return "";
        }
    }

    /* ------------------------------------------------------------------ */
    /* 유틸                                                                 */
    /* ------------------------------------------------------------------ */

    private static Element firstChildElement(Element parent, String tagName) {
        NodeList list = parent.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            Node child = list.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE
                    && tagName.equals(((Element) child).getTagName())) {
                return (Element) child;
            }
        }
        return null;
    }

    private static int parseIntSafe(String s, int defaultValue) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private static Document newDocument() throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    }
}
