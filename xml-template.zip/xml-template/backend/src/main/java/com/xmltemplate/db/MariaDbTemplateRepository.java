package com.xmltemplate.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.model.ValueDataType;
import com.xmltemplate.model.ValueType;

/**
 * MariaDB 기반 템플릿 저장소.
 *
 * 테이블 구성 (backend/sql/schema.sql — 기동 시 자동 생성):
 *
 *  XML_TEMPLATE      : TEMPLATE_NAME (PK), UPDATED_AT
 *  XML_TEMPLATE_NODE :
 *    TEMPLATE_NAME     템플릿 이름 (FK)
 *    NODE_SN           노드 일련번호 - 템플릿 내 DFS 전위 순서 (1부터)
 *    NODE_NAME         노드 이름
 *    PARENT_SN         부모 노드 일련번호 (루트는 NULL)
 *    INPUT_TYPE        입력타입 (FIXED / VARIABLE / FUNCTION)
 *    INPUT_VALUE       입력 내용
 *    INPUT_DATA_TYPE   입력 데이터 타입 (STRING / NUMBER)
 *    DISPLAY_COND      표시 조건
 *    REPEAT_COND       반복 조건
 *    REPEAT_COUNT_COND 반복 횟수 조건 (숫자 또는 {파라미터})
 *
 * 일련번호를 DFS 전위 순서로 부여하므로 ORDER BY NODE_SN 조회만으로
 * 부모가 자식보다 먼저 나오고 형제 순서도 보존된다.
 */
public class MariaDbTemplateRepository implements TemplateRepository {

    private static final String CREATE_MASTER_SQL =
            "CREATE TABLE IF NOT EXISTS XML_TEMPLATE ("
                    + "TEMPLATE_NAME VARCHAR(100) NOT NULL, "
                    + "UPDATED_AT DATETIME NOT NULL, "
                    + "PRIMARY KEY (TEMPLATE_NAME)"
                    + ") DEFAULT CHARSET=utf8mb4";

    private static final String CREATE_NODE_SQL =
            "CREATE TABLE IF NOT EXISTS XML_TEMPLATE_NODE ("
                    + "TEMPLATE_NAME VARCHAR(100) NOT NULL, "
                    + "NODE_SN INT NOT NULL, "
                    + "NODE_NAME VARCHAR(200) NOT NULL, "
                    + "PARENT_SN INT NULL, "
                    + "INPUT_TYPE VARCHAR(20) NOT NULL, "
                    + "INPUT_VALUE TEXT NULL, "
                    + "INPUT_DATA_TYPE VARCHAR(20) NOT NULL, "
                    + "DISPLAY_COND VARCHAR(1000) NULL, "
                    + "REPEAT_COND VARCHAR(1000) NULL, "
                    + "REPEAT_COUNT_COND VARCHAR(200) NULL, "
                    + "PRIMARY KEY (TEMPLATE_NAME, NODE_SN), "
                    + "CONSTRAINT FK_XML_TEMPLATE_NODE FOREIGN KEY (TEMPLATE_NAME) "
                    + "REFERENCES XML_TEMPLATE (TEMPLATE_NAME)"
                    + ") DEFAULT CHARSET=utf8mb4";

    private static final String INSERT_NODE_SQL =
            "INSERT INTO XML_TEMPLATE_NODE ("
                    + "TEMPLATE_NAME, NODE_SN, NODE_NAME, PARENT_SN, "
                    + "INPUT_TYPE, INPUT_VALUE, INPUT_DATA_TYPE, "
                    + "DISPLAY_COND, REPEAT_COND, REPEAT_COUNT_COND"
                    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_NODES_SQL =
            "SELECT NODE_SN, NODE_NAME, PARENT_SN, "
                    + "INPUT_TYPE, INPUT_VALUE, INPUT_DATA_TYPE, "
                    + "DISPLAY_COND, REPEAT_COND, REPEAT_COUNT_COND "
                    + "FROM XML_TEMPLATE_NODE WHERE TEMPLATE_NAME = ? ORDER BY NODE_SN";

    private final DbConfig config;

    public MariaDbTemplateRepository(DbConfig config) {
        this.config = config;
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RepositoryException(
                    "MariaDB JDBC 드라이버를 찾을 수 없습니다. "
                            + "mariadb-java-client jar 를 클래스패스에 추가하세요.", e);
        }
        ensureSchema();
    }

    private Connection open() throws SQLException {
        return DriverManager.getConnection(config.getUrl(), config.getUser(), config.getPassword());
    }

    /** 테이블이 없으면 만든다. (기능 검증 환경에서 스키마 수동 적용 없이 기동 가능) */
    private void ensureSchema() {
        Connection conn = null;
        try {
            conn = open();
            Statement st = conn.createStatement();
            try {
                st.executeUpdate(CREATE_MASTER_SQL);
                st.executeUpdate(CREATE_NODE_SQL);
            } finally {
                st.close();
            }
        } catch (SQLException e) {
            throw new RepositoryException("스키마 생성/확인 실패: " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 저장                                                                */
    /* ------------------------------------------------------------------ */

    @Override
    public void save(String templateName, TemplateNode root) {
        TemplateRepository.validateName(templateName);
        if (root == null) {
            throw new RepositoryException("저장할 템플릿이 비어 있습니다.");
        }
        Connection conn = null;
        try {
            conn = open();
            conn.setAutoCommit(false);

            deleteInternal(conn, templateName);

            PreparedStatement master = conn.prepareStatement(
                    "INSERT INTO XML_TEMPLATE (TEMPLATE_NAME, UPDATED_AT) VALUES (?, NOW())");
            try {
                master.setString(1, templateName);
                master.executeUpdate();
            } finally {
                master.close();
            }

            PreparedStatement nodes = conn.prepareStatement(INSERT_NODE_SQL);
            try {
                insertNodes(nodes, templateName, root, null, new int[] { 0 });
                nodes.executeBatch();
            } finally {
                nodes.close();
            }

            conn.commit();
        } catch (SQLException e) {
            rollbackQuietly(conn);
            throw new RepositoryException("템플릿 저장 실패: " + templateName + " - " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    /** DFS 전위 순서로 일련번호를 부여하며 INSERT 배치에 추가한다. */
    private void insertNodes(PreparedStatement ps, String templateName, TemplateNode node,
            Integer parentSn, int[] counter) throws SQLException {
        counter[0]++;
        int sn = counter[0];

        ps.setString(1, templateName);
        ps.setInt(2, sn);
        ps.setString(3, node.getName());
        if (parentSn == null) {
            ps.setNull(4, java.sql.Types.INTEGER);
        } else {
            ps.setInt(4, parentSn.intValue());
        }
        ps.setString(5, node.getValueType().name());
        ps.setString(6, node.getValue());
        ps.setString(7, node.getValueDataType().name());
        ps.setString(8, node.getDisplayCondition());
        ps.setString(9, node.getRepeatCondition());
        ps.setString(10, node.getRepeatCountExpr());
        ps.addBatch();

        for (TemplateNode child : node.getChildren()) {
            insertNodes(ps, templateName, child, Integer.valueOf(sn), counter);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 조회                                                                */
    /* ------------------------------------------------------------------ */

    @Override
    public TemplateNode load(String templateName) {
        TemplateRepository.validateName(templateName);
        Connection conn = null;
        try {
            conn = open();
            PreparedStatement ps = conn.prepareStatement(SELECT_NODES_SQL);
            try {
                ps.setString(1, templateName);
                ResultSet rs = ps.executeQuery();
                try {
                    return buildTree(rs, templateName);
                } finally {
                    rs.close();
                }
            } finally {
                ps.close();
            }
        } catch (SQLException e) {
            throw new RepositoryException("템플릿 조회 실패: " + templateName + " - " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    /**
     * NODE_SN 순 행들로 트리를 복원한다.
     * 전위 순서 저장이므로 부모 행이 자식 행보다 항상 먼저 나온다.
     */
    private TemplateNode buildTree(ResultSet rs, String templateName) throws SQLException {
        Map<Integer, TemplateNode> bySn = new HashMap<Integer, TemplateNode>();
        TemplateNode root = null;

        while (rs.next()) {
            int sn = rs.getInt("NODE_SN");

            TemplateNode node = new TemplateNode(nullToEmpty(rs.getString("NODE_NAME")));
            node.setValueType(ValueType.fromString(rs.getString("INPUT_TYPE")));
            node.setValue(nullToEmpty(rs.getString("INPUT_VALUE")));
            node.setValueDataType(ValueDataType.fromString(rs.getString("INPUT_DATA_TYPE")));
            node.setDisplayCondition(nullToEmpty(rs.getString("DISPLAY_COND")));
            node.setRepeatCondition(nullToEmpty(rs.getString("REPEAT_COND")));
            node.setRepeatCountExpr(nullToEmpty(rs.getString("REPEAT_COUNT_COND")));

            int parentSn = rs.getInt("PARENT_SN");
            boolean isRoot = rs.wasNull();

            bySn.put(Integer.valueOf(sn), node);
            if (isRoot) {
                if (root != null) {
                    throw new RepositoryException(
                            "템플릿 '" + templateName + "' 에 루트 노드가 2개 이상 있습니다.");
                }
                root = node;
            } else {
                TemplateNode parent = bySn.get(Integer.valueOf(parentSn));
                if (parent == null) {
                    throw new RepositoryException("템플릿 '" + templateName + "' 의 노드 " + sn
                            + " 이(가) 존재하지 않는 부모 " + parentSn + " 을(를) 참조합니다.");
                }
                parent.addChild(node);
            }
        }
        return root;
    }

    @Override
    public List<String> list() {
        Connection conn = null;
        try {
            conn = open();
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT TEMPLATE_NAME FROM XML_TEMPLATE ORDER BY TEMPLATE_NAME");
            try {
                ResultSet rs = ps.executeQuery();
                try {
                    List<String> names = new ArrayList<String>();
                    while (rs.next()) {
                        names.add(rs.getString(1));
                    }
                    return names;
                } finally {
                    rs.close();
                }
            } finally {
                ps.close();
            }
        } catch (SQLException e) {
            throw new RepositoryException("템플릿 목록 조회 실패: " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    @Override
    public boolean exists(String templateName) {
        TemplateRepository.validateName(templateName);
        Connection conn = null;
        try {
            conn = open();
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?");
            try {
                ps.setString(1, templateName);
                ResultSet rs = ps.executeQuery();
                try {
                    return rs.next() && rs.getInt(1) > 0;
                } finally {
                    rs.close();
                }
            } finally {
                ps.close();
            }
        } catch (SQLException e) {
            throw new RepositoryException("템플릿 존재 확인 실패: " + templateName + " - " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 삭제                                                                */
    /* ------------------------------------------------------------------ */

    @Override
    public boolean delete(String templateName) {
        TemplateRepository.validateName(templateName);
        Connection conn = null;
        try {
            conn = open();
            conn.setAutoCommit(false);
            boolean deleted = deleteInternal(conn, templateName);
            conn.commit();
            return deleted;
        } catch (SQLException e) {
            rollbackQuietly(conn);
            throw new RepositoryException("템플릿 삭제 실패: " + templateName + " - " + e.getMessage(), e);
        } finally {
            closeQuietly(conn);
        }
    }

    private boolean deleteInternal(Connection conn, String templateName) throws SQLException {
        PreparedStatement delNodes = conn.prepareStatement(
                "DELETE FROM XML_TEMPLATE_NODE WHERE TEMPLATE_NAME = ?");
        try {
            delNodes.setString(1, templateName);
            delNodes.executeUpdate();
        } finally {
            delNodes.close();
        }
        PreparedStatement delMaster = conn.prepareStatement(
                "DELETE FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?");
        try {
            delMaster.setString(1, templateName);
            return delMaster.executeUpdate() > 0;
        } finally {
            delMaster.close();
        }
    }

    /* ------------------------------------------------------------------ */
    /* 유틸                                                                 */
    /* ------------------------------------------------------------------ */

    private static String nullToEmpty(String s) {
        return (s == null) ? "" : s;
    }

    private static void rollbackQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException ignored) {
                /* 롤백 실패는 원래 예외를 가리지 않도록 무시 */
            }
        }
    }

    private static void closeQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ignored) {
                /* 닫기 실패는 무시 */
            }
        }
    }
}
