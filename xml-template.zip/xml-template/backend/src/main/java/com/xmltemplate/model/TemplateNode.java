package com.xmltemplate.model;

import java.util.ArrayList;
import java.util.List;

/**
 * XML 템플릿의 한 노드.
 *
 * 트리 구조로 XML 의 구조를 표현하며, 노드마다 아래 정보를 가진다.
 *  - name             : 생성될 XML 엘리먼트 이름
 *  - valueType/value  : 노드 값 (고정값 / 외부 데이터 변수 / 삼항연산자 함수)
 *  - displayCondition : 표시 조건식. 비어 있으면 항상 표시, 조건식이 false 면 노드(하위 포함)를 생성하지 않는다.
 *  - repeatCondition  : 반복 조건식. 조건식이 true 이면 repeatCount 만큼 노드를 반복 생성한다.
 *                       비어 있으면 repeatCount 가 2 이상일 때 무조건 반복한다.
 *  - repeatCount      : 반복 횟수 (기본 1)
 *
 * 자식이 있는 노드는 값 대신 자식 엘리먼트를 갖는다 (value 는 무시).
 */
public class TemplateNode {

    private String name;
    private ValueType valueType = ValueType.FIXED;
    private String value = "";
    private String displayCondition = "";
    private String repeatCondition = "";
    private int repeatCount = 1;

    private TemplateNode parent;
    private final List<TemplateNode> children = new ArrayList<TemplateNode>();

    public TemplateNode(String name) {
        this.name = name;
    }

    /* ------------------------------------------------------------------ */
    /* 트리 조작                                                           */
    /* ------------------------------------------------------------------ */

    public void addChild(TemplateNode child) {
        child.parent = this;
        children.add(child);
    }

    public void removeChild(TemplateNode child) {
        if (children.remove(child)) {
            child.parent = null;
        }
    }

    public List<TemplateNode> getChildren() {
        return children;
    }

    public TemplateNode getParent() {
        return parent;
    }

    public boolean hasChildren() {
        return !children.isEmpty();
    }

    /** 루트로부터의 전체 경로 (예: "ROOT.node1-1.node1-1-1") */
    public String getPath() {
        if (parent == null) {
            return name;
        }
        return parent.getPath() + "." + name;
    }

    /* ------------------------------------------------------------------ */
    /* 속성 접근자                                                          */
    /* ------------------------------------------------------------------ */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ValueType getValueType() {
        return valueType;
    }

    public void setValueType(ValueType valueType) {
        this.valueType = (valueType == null) ? ValueType.FIXED : valueType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = (value == null) ? "" : value;
    }

    public String getDisplayCondition() {
        return displayCondition;
    }

    public void setDisplayCondition(String displayCondition) {
        this.displayCondition = (displayCondition == null) ? "" : displayCondition;
    }

    public String getRepeatCondition() {
        return repeatCondition;
    }

    public void setRepeatCondition(String repeatCondition) {
        this.repeatCondition = (repeatCondition == null) ? "" : repeatCondition;
    }

    public int getRepeatCount() {
        return repeatCount;
    }

    public void setRepeatCount(int repeatCount) {
        this.repeatCount = (repeatCount < 1) ? 1 : repeatCount;
    }

    @Override
    public String toString() {
        return "TemplateNode[" + getPath() + "]";
    }
}
