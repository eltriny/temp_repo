package com.xmltemplate.model;

import java.util.ArrayList;
import java.util.List;

/**
 * XML 템플릿의 한 노드.
 *
 * 트리 구조로 XML 의 구조를 표현하며, 노드마다 아래 정보를 가진다.
 *  - name             : 생성될 XML 엘리먼트 이름 (DB: NODE_NAME)
 *  - valueType/value  : 노드 값 - 고정값/변수/함수 (DB: INPUT_TYPE / INPUT_VALUE)
 *  - valueDataType    : 값의 데이터 타입 - STRING/NUMBER (DB: INPUT_DATA_TYPE)
 *  - displayCondition : 표시 조건식 (DB: DISPLAY_COND). 비어 있으면 항상 표시,
 *                       조건식이 false 면 노드(하위 포함)를 생성하지 않는다.
 *  - repeatCondition  : 반복 조건식 (DB: REPEAT_COND). 조건식이 true 이면
 *                       반복 횟수 조건이 정하는 만큼 반복 생성한다.
 *  - repeatCountExpr  : 반복 횟수 조건 (DB: REPEAT_COUNT_COND).
 *                       숫자("3") 또는 파라미터 기준("{xxx}").
 *                       "{xxx}" 는 외부 데이터에 xxx_1, xxx_2, ... 가 연속으로
 *                       존재하는 개수만큼 반복한다는 뜻이다.
 *
 * 자식이 있는 노드는 값 대신 자식 엘리먼트를 갖는다 (value 는 무시).
 */
public class TemplateNode {

    private String name;
    private ValueType valueType = ValueType.FIXED;
    private ValueDataType valueDataType = ValueDataType.STRING;
    private String value = "";
    private String displayCondition = "";
    private String repeatCondition = "";
    private String repeatCountExpr = "";

    private TemplateNode parent;
    private final List<TemplateNode> children = new ArrayList<TemplateNode>();

    public TemplateNode(String name) {
        this.name = name;
    }

    /* ------------------------------------------------------------------ */
    /* 트리 조작                                                           */
    /* ------------------------------------------------------------------ */

    public void addChild(TemplateNode child) {
        child.parent = this;
        children.add(child);
    }

    public void removeChild(TemplateNode child) {
        if (children.remove(child)) {
            child.parent = null;
        }
    }

    public List<TemplateNode> getChildren() {
        return children;
    }

    public TemplateNode getParent() {
        return parent;
    }

    public boolean hasChildren() {
        return !children.isEmpty();
    }

    /** 루트로부터의 전체 경로 (예: "ROOT.node1-1.node1-1-1") */
    public String getPath() {
        if (parent == null) {
            return name;
        }
        return parent.getPath() + "." + name;
    }

    /* ------------------------------------------------------------------ */
    /* 속성 접근자                                                          */
    /* ------------------------------------------------------------------ */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ValueType getValueType() {
        return valueType;
    }

    public void setValueType(ValueType valueType) {
        this.valueType = (valueType == null) ? ValueType.FIXED : valueType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = (value == null) ? "" : value;
    }

    public String getDisplayCondition() {
        return displayCondition;
    }

    public void setDisplayCondition(String displayCondition) {
        this.displayCondition = (displayCondition == null) ? "" : displayCondition;
    }

    public String getRepeatCondition() {
        return repeatCondition;
    }

    public void setRepeatCondition(String repeatCondition) {
        this.repeatCondition = (repeatCondition == null) ? "" : repeatCondition;
    }

    public String getRepeatCountExpr() {
        return repeatCountExpr;
    }

    public void setRepeatCountExpr(String repeatCountExpr) {
        this.repeatCountExpr = (repeatCountExpr == null) ? "" : repeatCountExpr.trim();
    }

    public ValueDataType getValueDataType() {
        return valueDataType;
    }

    public void setValueDataType(ValueDataType valueDataType) {
        this.valueDataType = (valueDataType == null) ? ValueDataType.STRING : valueDataType;
    }

    @Override
    public String toString() {
        return "TemplateNode[" + getPath() + "]";
    }
}
