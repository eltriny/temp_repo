package com.xmltemplate.template;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.xmltemplate.model.TemplateNode;

/**
 * 템플릿 저장소 관리 (생성/수정/조회/삭제).
 *
 * 지정한 디렉터리에 "템플릿이름.xml" 파일로 저장한다.
 * 같은 이름으로 저장하면 덮어쓰기(수정)가 된다.
 */
public class TemplateManager {

    private final File directory;

    public TemplateManager(File directory) {
        this.directory = directory;
        if (!directory.exists() && !directory.mkdirs()) {
            throw new TemplateSerializer.SerializationException(
                    "템플릿 디렉터리를 만들 수 없습니다: " + directory.getPath());
        }
        if (!directory.isDirectory()) {
            throw new TemplateSerializer.SerializationException(
                    "템플릿 저장 경로가 디렉터리가 아닙니다: " + directory.getPath());
        }
    }

    /** 템플릿 저장 (신규 생성 또는 덮어쓰기 수정). */
    public void save(String templateName, TemplateNode root) {
        validateName(templateName);
        TemplateSerializer.save(fileOf(templateName), templateName, root);
    }

    /** 템플릿 로드. 없으면 예외. */
    public TemplateNode load(String templateName) {
        validateName(templateName);
        File file = fileOf(templateName);
        if (!file.exists()) {
            throw new TemplateSerializer.SerializationException(
                    "템플릿이 존재하지 않습니다: " + templateName);
        }
        return TemplateSerializer.load(file);
    }

    /** 저장된 템플릿 이름 목록. */
    public List<String> list() {
        List<String> names = new ArrayList<String>();
        File[] files = directory.listFiles();
        if (files != null) {
            for (File f : files) {
                String fileName = f.getName();
                if (f.isFile() && fileName.toLowerCase().endsWith(".xml")) {
                    names.add(fileName.substring(0, fileName.length() - 4));
                }
            }
        }
        Collections.sort(names);
        return names;
    }

    public boolean exists(String templateName) {
        validateName(templateName);
        return fileOf(templateName).exists();
    }

    /** 템플릿 삭제. 삭제했으면 true. */
    public boolean delete(String templateName) {
        validateName(templateName);
        File file = fileOf(templateName);
        return file.exists() && file.delete();
    }

    private File fileOf(String templateName) {
        return new File(directory, templateName + ".xml");
    }

    /** 파일 이름으로 쓸 수 없는 문자/경로 조작을 차단한다. */
    private static void validateName(String templateName) {
        if (templateName == null || templateName.trim().isEmpty()) {
            throw new TemplateSerializer.SerializationException("템플릿 이름이 비어 있습니다.");
        }
        if (templateName.matches(".*[\\\\/:*?\"<>|].*") || templateName.contains("..")) {
            throw new TemplateSerializer.SerializationException(
                    "템플릿 이름에 사용할 수 없는 문자가 있습니다: " + templateName);
        }
    }
}
