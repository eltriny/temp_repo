package com.xmltemplate.model;

/**
 * 노드 값의 데이터 타입 (DB 컬럼: INPUT_DATA_TYPE).
 *
 * STRING : 제약 없음 (기본값)
 * NUMBER : 생성 시 노드의 최종 값이 비어 있지 않으면 숫자 형식인지 검증한다.
 */
public enum ValueDataType {
    STRING,
    NUMBER;

    /** 직렬화 문자열로부터 복원. 알 수 없는 값은 STRING 으로 처리한다. */
    public static ValueDataType fromString(String s) {
        if (s == null) {
            return STRING;
        }
        for (ValueDataType t : values()) {
            if (t.name().equalsIgnoreCase(s.trim())) {
                return t;
            }
        }
        return STRING;
    }
}
