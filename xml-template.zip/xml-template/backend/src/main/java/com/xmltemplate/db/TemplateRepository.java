package com.xmltemplate.db;

import java.util.List;

import com.xmltemplate.model.TemplateNode;

/**
 * 템플릿 저장소 인터페이스.
 *
 * 운영: OracleTemplateRepository (Oracle DB)
 * 테스트/로컬: InMemoryTemplateRepository
 */
public interface TemplateRepository {

    /** 템플릿 저장 (신규 생성 또는 덮어쓰기 수정). */
    void save(String templateName, TemplateNode root);

    /** 템플릿 로드. 없으면 null. */
    TemplateNode load(String templateName);

    /** 저장된 템플릿 이름 목록 (정렬됨). */
    List<String> list();

    /** 템플릿 삭제. 삭제했으면 true. */
    boolean delete(String templateName);

    boolean exists(String templateName);

    /**
     * 템플릿 이름 공통 검증. 모든 구현체가 저장소 접근 전에 호출해서
     * 메모리/Oracle 모드가 같은 입력에 같은 결과를 내도록 한다.
     * ('/', '\\' 는 URL 경로에서 안전하게 왕복되지 않아 차단)
     */
    static void validateName(String templateName) {
        if (templateName == null || templateName.trim().isEmpty()) {
            throw new RepositoryException("템플릿 이름이 비어 있습니다.");
        }
        if (templateName.length() > 100) {
            throw new RepositoryException("템플릿 이름이 너무 깁니다 (최대 100자).");
        }
        if (templateName.indexOf('/') >= 0 || templateName.indexOf('\\') >= 0) {
            throw new RepositoryException(
                    "템플릿 이름에 '/' 또는 '\\' 은 사용할 수 없습니다: " + templateName);
        }
    }
}
