package com.xmltemplate;

import java.util.HashMap;
import java.util.Map;

import com.xmltemplate.db.InMemoryTemplateRepository;
import com.xmltemplate.db.TemplateRepository;
import com.xmltemplate.engine.XmlGenerator;
import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.model.ValueDataType;
import com.xmltemplate.model.ValueType;
import com.xmltemplate.template.TemplateSerializer;

/**
 * 데모 & 로직 검증.
 *
 * 주문(ORDER) 템플릿으로 아래 기능을 모두 확인한다.
 *  - 고정값 / 변수 / 함수(삼항연산자) 값
 *  - 표시 조건 (외부 변수 기준, 노드 경로 기준)
 *  - 반복 횟수 조건: 고정 숫자("3") / 파라미터 기준("{ITEM_NAME}")
 *  - 반복 중 회차 변수 해석 ({ITEM_NAME} -> ITEM_NAME_i), 내장 변수 {INDEX}
 *  - 입력 데이터 타입 NUMBER 검증
 *  - 직렬화 왕복(round-trip), 구버전 repeatCount 포맷 읽기 호환
 *  - InMemoryTemplateRepository CRUD (Oracle 구현과 같은 인터페이스)
 */
public class Main {

    private static int failures = 0;

    public static void main(String[] args) {
        TemplateNode root = buildDemoTemplate();

        /* ---------- 시나리오 1: 국내 주문 (파라미터 기반 반복 3회) ---------- */
        Map<String, String> domestic = new HashMap<String, String>();
        domestic.put("ORDER_NO", "ORD-2026-0001");
        domestic.put("ORDER_TYPE", "D");
        domestic.put("MEMO", "빠른 배송 요청");
        domestic.put("ITEM_NAME_1", "노트북");
        domestic.put("ITEM_PRICE_1", "1500000");
        domestic.put("ITEM_NAME_2", "마우스");
        domestic.put("ITEM_PRICE_2", "30000");
        domestic.put("ITEM_NAME_3", "키보드");
        domestic.put("ITEM_PRICE_3", "80000");

        String xml1 = new XmlGenerator(root, domestic).generate();
        System.out.println("=== 시나리오 1: 국내 주문 (ITEM_NAME_1..3) ===");
        System.out.println(xml1);

        check(xml1.contains("<ORDER-TYPE-NAME>국내</ORDER-TYPE-NAME>"), "함수(삼항연산자) 값 - 참 분기");
        check(xml1.contains("<ORDER-NO>ORD-2026-0001</ORDER-NO>"), "변수 치환");
        check(xml1.contains("<MEMO>빠른 배송 요청</MEMO>"), "표시 조건 참 -> 노드 생성");
        check(count(xml1, "<ITEM>") == 3, "파라미터 기반 반복: ITEM_NAME_1..3 -> 3회");
        check(xml1.contains("<NAME>노트북</NAME>") && xml1.contains("<NAME>키보드</NAME>"),
                "회차 변수 해석: {ITEM_NAME} -> ITEM_NAME_i");
        check(xml1.contains("<PRICE>30000</PRICE>"), "회차 변수 해석: {ITEM_PRICE} -> ITEM_PRICE_i");
        check(xml1.contains("<SEQ>1</SEQ>") && xml1.contains("<SEQ>3</SEQ>"), "내장 변수 {INDEX}");
        check(xml1.contains("<DOMESTIC-ONLY>국내 전용 항목</DOMESTIC-ONLY>"),
                "노드 경로 피연산자 표시 조건");

        /* ---------- 시나리오 2: 해외 주문 (반복 파라미터 없음 -> ITEM 미생성) ---------- */
        Map<String, String> overseas = new HashMap<String, String>();
        overseas.put("ORDER_NO", "ORD-2026-0002");
        overseas.put("ORDER_TYPE", "O");
        overseas.put("MEMO", "");

        String xml2 = new XmlGenerator(root, overseas).generate();
        System.out.println("=== 시나리오 2: 해외 주문 (ITEM 파라미터 없음) ===");
        System.out.println(xml2);

        check(xml2.contains("<ORDER-TYPE-NAME>해외</ORDER-TYPE-NAME>"), "함수(삼항연산자) 값 - 거짓 분기");
        check(!xml2.contains("<MEMO>"), "표시 조건 거짓 -> 노드 미생성");
        check(count(xml2, "<ITEM>") == 0, "파라미터 기반 반복: 파라미터 없음 -> 0회(미생성)");
        check(!xml2.contains("<DOMESTIC-ONLY>"), "노드 경로 조건 거짓 -> 노드 미생성");

        /* ---------- 고정 숫자 반복 + 반복 조건 조합 ---------- */
        TemplateNode fixedRepeat = new TemplateNode("ROOT");
        TemplateNode row = new TemplateNode("ROW");
        row.setValueType(ValueType.VARIABLE);
        row.setValue("{INDEX}");
        row.setRepeatCondition("{USE_REPEAT} == 'Y'");
        row.setRepeatCountExpr("4");
        fixedRepeat.addChild(row);

        Map<String, String> useRepeat = new HashMap<String, String>();
        useRepeat.put("USE_REPEAT", "Y");
        String xml3 = new XmlGenerator(fixedRepeat, useRepeat).generate();
        check(count(xml3, "<ROW>") == 4, "고정 숫자 반복: 조건 참 -> 4회");

        useRepeat.put("USE_REPEAT", "N");
        String xml4 = new XmlGenerator(fixedRepeat, useRepeat).generate();
        check(count(xml4, "<ROW>") == 1, "고정 숫자 반복: 조건 거짓 -> 1회");

        /* ---------- 입력 데이터 타입 NUMBER 검증 ---------- */
        TemplateNode numRoot = new TemplateNode("ROOT");
        TemplateNode amount = new TemplateNode("AMOUNT");
        amount.setValueType(ValueType.VARIABLE);
        amount.setValue("{AMOUNT}");
        amount.setValueDataType(ValueDataType.NUMBER);
        numRoot.addChild(amount);

        Map<String, String> numData = new HashMap<String, String>();
        numData.put("AMOUNT", "12345.67");
        String xml5 = new XmlGenerator(numRoot, numData).generate();
        check(xml5.contains("<AMOUNT>12345.67</AMOUNT>"), "NUMBER 타입: 숫자 값 통과");

        numData.put("AMOUNT", "십만원");
        boolean numberRejected = false;
        try {
            new XmlGenerator(numRoot, numData).generate();
        } catch (XmlGenerator.GenerationException e) {
            numberRejected = true;
            System.out.println("기대된 오류 확인: " + e.getMessage());
        }
        check(numberRejected, "NUMBER 타입: 숫자 아닌 값 -> GenerationException");

        /* ---------- 잘못된 반복 횟수 조건 ---------- */
        TemplateNode badRoot = new TemplateNode("ROOT");
        TemplateNode badChild = new TemplateNode("CHILD");
        badChild.setRepeatCountExpr("abc");
        badRoot.addChild(badChild);
        boolean countRejected = false;
        try {
            new XmlGenerator(badRoot, new HashMap<String, String>()).generate();
        } catch (XmlGenerator.GenerationException e) {
            countRejected = true;
            System.out.println("기대된 오류 확인: " + e.getMessage());
        }
        check(countRejected, "잘못된 반복 횟수 조건 -> GenerationException");

        /* ---------- 직렬화 왕복 + 구버전 포맷 호환 ---------- */
        String templateXml = TemplateSerializer.toXmlString("order-template", root);
        check(templateXml.contains("<repeatCountExpr>{ITEM_NAME}</repeatCountExpr>"),
                "직렬화: repeatCountExpr 기록");
        check(templateXml.contains("dataType=\"NUMBER\""), "직렬화: dataType 기록");

        TemplateNode reloaded = TemplateSerializer.fromXmlString(templateXml);
        check(xml1.equals(new XmlGenerator(reloaded, domestic).generate()),
                "직렬화 왕복 후 동일한 XML 생성");

        String legacyXml = "<template name=\"legacy\"><node name=\"ROOT\">"
                + "<children><node name=\"ROW\">"
                + "<value type=\"FIXED\">x</value>"
                + "<repeatCount>2</repeatCount>"
                + "</node></children></node></template>";
        TemplateNode legacy = TemplateSerializer.fromXmlString(legacyXml);
        String legacyOut = new XmlGenerator(legacy, new HashMap<String, String>()).generate();
        check(count(legacyOut, "<ROW>") == 2, "구버전 repeatCount 포맷 읽기 호환");

        /* ---------- 저장소 CRUD (InMemory - Oracle 과 동일 인터페이스) ---------- */
        TemplateRepository repo = new InMemoryTemplateRepository();
        repo.save("order-template", root);
        check(repo.exists("order-template"), "저장소 저장/존재 확인");
        check(repo.list().contains("order-template"), "저장소 목록");
        check(repo.load("없는템플릿") == null, "없는 템플릿 -> null");

        TemplateNode fromRepo = repo.load("order-template");
        check(xml1.equals(new XmlGenerator(fromRepo, domestic).generate()),
                "저장소 왕복 후 동일한 XML 생성");

        check(repo.delete("order-template"), "저장소 삭제");
        check(!repo.exists("order-template"), "삭제 후 존재하지 않음");

        System.out.println();
        if (failures == 0) {
            System.out.println("모든 검증 통과");
        } else {
            System.out.println(failures + "건 검증 실패");
            System.exit(1);
        }
    }

    /**
     * 데모 템플릿 구조:
     * ORDER
     *  ├─ HEADER
     *  │   ├─ ORDER-NO         : 변수 {ORDER_NO}
     *  │   ├─ ORDER-TYPE-NAME  : 함수 {ORDER_TYPE} == 'D' ? '국내' : '해외'
     *  │   └─ MEMO             : 변수 {MEMO}, 표시 조건 {MEMO} != ''
     *  ├─ ITEMS
     *  │   └─ ITEM             : 반복 횟수 조건 {ITEM_NAME} (파라미터 기반)
     *  │       ├─ SEQ          : 변수 {INDEX}
     *  │       ├─ NAME         : 변수 {ITEM_NAME}  -> 회차별 ITEM_NAME_i
     *  │       └─ PRICE        : 변수 {ITEM_PRICE} -> 회차별 ITEM_PRICE_i (NUMBER)
     *  └─ DOMESTIC-ONLY        : 고정값, 표시 조건 ORDER.HEADER.ORDER-TYPE-NAME == '국내'
     */
    private static TemplateNode buildDemoTemplate() {
        TemplateNode root = new TemplateNode("ORDER");

        TemplateNode header = new TemplateNode("HEADER");
        root.addChild(header);

        TemplateNode orderNo = new TemplateNode("ORDER-NO");
        orderNo.setValueType(ValueType.VARIABLE);
        orderNo.setValue("{ORDER_NO}");
        header.addChild(orderNo);

        TemplateNode typeName = new TemplateNode("ORDER-TYPE-NAME");
        typeName.setValueType(ValueType.FUNCTION);
        typeName.setValue("{ORDER_TYPE} == 'D' ? '국내' : '해외'");
        header.addChild(typeName);

        TemplateNode memo = new TemplateNode("MEMO");
        memo.setValueType(ValueType.VARIABLE);
        memo.setValue("{MEMO}");
        memo.setDisplayCondition("{MEMO} != ''");
        header.addChild(memo);

        TemplateNode items = new TemplateNode("ITEMS");
        root.addChild(items);

        TemplateNode item = new TemplateNode("ITEM");
        item.setRepeatCountExpr("{ITEM_NAME}");
        items.addChild(item);

        TemplateNode seq = new TemplateNode("SEQ");
        seq.setValueType(ValueType.VARIABLE);
        seq.setValue("{INDEX}");
        item.addChild(seq);

        TemplateNode itemName = new TemplateNode("NAME");
        itemName.setValueType(ValueType.VARIABLE);
        itemName.setValue("{ITEM_NAME}");
        item.addChild(itemName);

        TemplateNode itemPrice = new TemplateNode("PRICE");
        itemPrice.setValueType(ValueType.VARIABLE);
        itemPrice.setValue("{ITEM_PRICE}");
        itemPrice.setValueDataType(ValueDataType.NUMBER);
        item.addChild(itemPrice);

        TemplateNode domesticOnly = new TemplateNode("DOMESTIC-ONLY");
        domesticOnly.setValueType(ValueType.FIXED);
        domesticOnly.setValue("국내 전용 항목");
        domesticOnly.setDisplayCondition("ORDER.HEADER.ORDER-TYPE-NAME == '국내'");
        root.addChild(domesticOnly);

        return root;
    }

    private static void check(boolean condition, String description) {
        if (condition) {
            System.out.println("[OK] " + description);
        } else {
            System.out.println("[FAIL] " + description);
            failures++;
        }
    }

    private static int count(String text, String token) {
        int c = 0;
        int idx = 0;
        while ((idx = text.indexOf(token, idx)) >= 0) {
            c++;
            idx += token.length();
        }
        return c;
    }
}
