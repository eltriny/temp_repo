package com.xmltemplate;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.xmltemplate.engine.XmlGenerator;
import com.xmltemplate.model.TemplateNode;
import com.xmltemplate.model.ValueType;
import com.xmltemplate.template.TemplateManager;
import com.xmltemplate.template.TemplateSerializer;

/**
 * 데모 & 로직 검증.
 *
 * 주문(ORDER) 템플릿을 만들어 아래 기능을 모두 확인한다.
 *  - 고정값 / 변수 / 함수(삼항연산자) 값
 *  - 표시 조건 (외부 변수 기준, 노드 경로 기준)
 *  - 반복 조건 + 반복 횟수, 내장 변수 {INDEX}
 *  - 템플릿 직렬화 왕복(round-trip), TemplateManager CRUD
 */
public class Main {

    private static int failures = 0;

    public static void main(String[] args) {
        TemplateNode root = buildDemoTemplate();

        /* ---------- 시나리오 1: 국내 주문 (표시 O, 반복 O) ---------- */
        Map<String, String> domestic = new HashMap<String, String>();
        domestic.put("ORDER_NO", "ORD-2026-0001");
        domestic.put("ORDER_TYPE", "D");
        domestic.put("ITEM_COUNT", "3");
        domestic.put("MEMO", "빠른 배송 요청");

        String xml1 = new XmlGenerator(root, domestic).generate();
        System.out.println("=== 시나리오 1: 국내 주문 ===");
        System.out.println(xml1);

        check(xml1.contains("<ORDER-TYPE-NAME>국내</ORDER-TYPE-NAME>"), "함수(삼항연산자) 값 - 참 분기");
        check(xml1.contains("<ORDER-NO>ORD-2026-0001</ORDER-NO>"), "변수 치환");
        check(xml1.contains("<MEMO>빠른 배송 요청</MEMO>"), "표시 조건 참 -> 노드 생성");
        check(count(xml1, "<ITEM>") == 3, "반복 조건 참 -> repeatCount 만큼 반복");
        check(xml1.contains("<SEQ>1</SEQ>") && xml1.contains("<SEQ>3</SEQ>"), "내장 변수 {INDEX}");
        check(xml1.contains("<DOMESTIC-ONLY>국내 전용 항목</DOMESTIC-ONLY>"),
                "노드 경로 피연산자 표시 조건 (ORDER.HEADER.ORDER-TYPE-NAME == '국내')");

        /* ---------- 시나리오 2: 해외 주문 (표시 X, 반복 X) ---------- */
        Map<String, String> overseas = new HashMap<String, String>();
        overseas.put("ORDER_NO", "ORD-2026-0002");
        overseas.put("ORDER_TYPE", "O");
        overseas.put("ITEM_COUNT", "0");
        overseas.put("MEMO", "");

        String xml2 = new XmlGenerator(root, overseas).generate();
        System.out.println("=== 시나리오 2: 해외 주문 ===");
        System.out.println(xml2);

        check(xml2.contains("<ORDER-TYPE-NAME>해외</ORDER-TYPE-NAME>"), "함수(삼항연산자) 값 - 거짓 분기");
        check(!xml2.contains("<MEMO>"), "표시 조건 거짓 -> 노드 미생성");
        check(count(xml2, "<ITEM>") == 1, "반복 조건 거짓 -> 1회만 생성");
        check(!xml2.contains("<DOMESTIC-ONLY>"), "노드 경로 조건 거짓 -> 노드 미생성");

        /* ---------- 직렬화 왕복 + TemplateManager ---------- */
        File dir = new File(System.getProperty("java.io.tmpdir"), "xml-template-demo");
        TemplateManager manager = new TemplateManager(dir);
        manager.save("order-template", root);
        check(manager.exists("order-template"), "TemplateManager 저장/존재 확인");
        check(manager.list().contains("order-template"), "TemplateManager 목록");

        TemplateNode reloaded = manager.load("order-template");
        String xml1Again = new XmlGenerator(reloaded, domestic).generate();
        check(xml1.equals(xml1Again), "직렬화 왕복 후 동일한 XML 생성");

        check(manager.delete("order-template"), "TemplateManager 삭제");
        check(!manager.exists("order-template"), "삭제 후 존재하지 않음");

        /* ---------- 문자열 직렬화 왕복 ---------- */
        String templateXml = TemplateSerializer.toXmlString("order-template", root);
        TemplateNode fromString = TemplateSerializer.fromXmlString(templateXml);
        check(xml1.equals(new XmlGenerator(fromString, domestic).generate()),
                "문자열 직렬화 왕복 후 동일한 XML 생성");

        /* ---------- 오류 처리 확인 ---------- */
        TemplateNode bad = new TemplateNode("ROOT");
        TemplateNode badChild = new TemplateNode("CHILD");
        badChild.setDisplayCondition("{A} == ");
        bad.addChild(badChild);
        boolean threw = false;
        try {
            new XmlGenerator(bad, new HashMap<String, String>()).generate();
        } catch (XmlGenerator.GenerationException e) {
            threw = true;
            System.out.println("기대된 오류 확인: " + e.getMessage());
        }
        check(threw, "잘못된 조건식 -> GenerationException");

        System.out.println();
        if (failures == 0) {
            System.out.println("모든 검증 통과");
        } else {
            System.out.println(failures + "건 검증 실패");
            System.exit(1);
        }
    }

    /**
     * 데모 템플릿 구조:
     * ORDER
     *  ├─ HEADER
     *  │   ├─ ORDER-NO         : 변수 {ORDER_NO}
     *  │   ├─ ORDER-TYPE-NAME  : 함수 {ORDER_TYPE} == 'D' ? '국내' : '해외'
     *  │   └─ MEMO             : 변수 {MEMO}, 표시 조건 {MEMO} != ''
     *  ├─ ITEMS
     *  │   └─ ITEM             : 반복 조건 {ITEM_COUNT} > 1, 반복 횟수 3
     *  │       ├─ SEQ          : 변수 {INDEX}
     *  │       └─ LABEL        : 고정값 "품목"
     *  └─ DOMESTIC-ONLY        : 고정값, 표시 조건 ORDER.HEADER.ORDER-TYPE-NAME == '국내'
     */
    private static TemplateNode buildDemoTemplate() {
        TemplateNode root = new TemplateNode("ORDER");

        TemplateNode header = new TemplateNode("HEADER");
        root.addChild(header);

        TemplateNode orderNo = new TemplateNode("ORDER-NO");
        orderNo.setValueType(ValueType.VARIABLE);
        orderNo.setValue("{ORDER_NO}");
        header.addChild(orderNo);

        TemplateNode typeName = new TemplateNode("ORDER-TYPE-NAME");
        typeName.setValueType(ValueType.FUNCTION);
        typeName.setValue("{ORDER_TYPE} == 'D' ? '국내' : '해외'");
        header.addChild(typeName);

        TemplateNode memo = new TemplateNode("MEMO");
        memo.setValueType(ValueType.VARIABLE);
        memo.setValue("{MEMO}");
        memo.setDisplayCondition("{MEMO} != ''");
        header.addChild(memo);

        TemplateNode items = new TemplateNode("ITEMS");
        root.addChild(items);

        TemplateNode item = new TemplateNode("ITEM");
        item.setRepeatCondition("{ITEM_COUNT} > 1");
        item.setRepeatCount(3);
        items.addChild(item);

        TemplateNode seq = new TemplateNode("SEQ");
        seq.setValueType(ValueType.VARIABLE);
        seq.setValue("{INDEX}");
        item.addChild(seq);

        TemplateNode label = new TemplateNode("LABEL");
        label.setValueType(ValueType.FIXED);
        label.setValue("품목");
        item.addChild(label);

        TemplateNode domesticOnly = new TemplateNode("DOMESTIC-ONLY");
        domesticOnly.setValueType(ValueType.FIXED);
        domesticOnly.setValue("국내 전용 항목");
        domesticOnly.setDisplayCondition("ORDER.HEADER.ORDER-TYPE-NAME == '국내'");
        root.addChild(domesticOnly);

        return root;
    }

    private static void check(boolean condition, String description) {
        if (condition) {
            System.out.println("[OK] " + description);
        } else {
            System.out.println("[FAIL] " + description);
            failures++;
        }
    }

    private static int count(String text, String token) {
        int c = 0;
        int idx = 0;
        while ((idx = text.indexOf(token, idx)) >= 0) {
            c++;
            idx += token.length();
        }
        return c;
    }
}
