package com.xmltemplate.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 웹 계층 구성.
 *
 * <b>DataSource·저장소 빈 정의는 없다</b> — Spring Boot 자동 구성이
 * {@code spring.datasource.*} 로 HikariCP 풀을, {@code @EnableJpaRepositories}(자동)가
 * 리포지토리 구현을 만든다. 손으로 정의하면 자동 구성과 두 벌이 되어 어느 쪽이 이기는지
 * 알 수 없게 된다.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * React 개발 서버(다른 포트)의 교차 출처 호출 허용 — <b>기존 CORS 정책과 동일</b>.
     *
     * <b>계약 정본에 CORS 절이 없다.</b> {@code docs/API_V4_FLAT.md} 는 본문·응답 형태만
     * 규정하고 전송 헤더는 다루지 않으므로 여기서 §번호를 가리키지 않는다. 이 값들의 정본은
     * <b>회귀 테스트</b>다: {@code TemplateApiContractTest.corsPreflight} 가 헤더 3종의 값을
     * 구 서버 실측치와 대조해 고정한다. 문서를 참조하는 척하면 다음 사람이 없는 절을 찾는다.
     *
     * <b>{@code allowedOrigins} 이지 {@code allowedOriginPatterns} 가 아니다.</b> 후자는
     * 요청의 {@code Origin} 을 그대로 되비추므로 응답 헤더가 {@code http://localhost:5173} 이
     * 된다. 구 서버는 언제나 {@code *} 를 돌려줬다 — 실측으로 확인한 차이라 값을 맞춘다.
     *
     * 허용 헤더도 {@code *} 가 아니라 {@code Content-Type} 만이다(구 서버와 동일).
     * multipart 프리플라이트가 통과하려면 이 헤더가 반드시 포함돼야 한다.
     *
     * {@code allowCredentials} 는 켜지 않는다 — {@code allowedOrigins("*")} 와 함께 쓰면
     * Spring 이 기동 시점에 예외를 던지고, 출처 반사로 바꾸면 응답 값이 {@code *} 를 벗어난다.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("Content-Type");
    }
}
