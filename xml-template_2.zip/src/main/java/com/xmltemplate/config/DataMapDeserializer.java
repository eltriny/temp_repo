package com.xmltemplate.config;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * 외부 데이터 맵({@code data})의 역직렬화 (docs/API_V4_FLAT.md §2.5).
 *
 * <b>값은 문자열 또는 숫자만이다.</b> 숫자는 <b>입력 표기 그대로</b> 문자열이 된다 —
 * {@code "ITEM_PRICE_1": 1500000} 은 {@code "1500000"}, {@code 1.50} 은 {@code "1.50"} 이다.
 * 기본 {@code Map<String,String>} 바인딩은 숫자에서 실패하므로 이 역직렬화기가 없으면
 * <b>기존 샘플 데이터가 그대로 400</b> 이 된다.
 *
 * <h3>왜 {@code readTree} 가 아니라 토큰 스트림인가</h3>
 * {@code readTree(...).asText()} 로 값을 꺼내면 세 가지가 조용히 어긋난다 (실측):
 * <ul>
 *   <li>중첩 객체·배열이 예외 없이 <b>빈 문자열</b>이 된다 — 데이터가 소리 없이 사라진다.</li>
 *   <li>{@code true} 가 {@code "true"} 라는 <b>값</b>으로 들어간다.</li>
 *   <li>{@code 1.50} 이 {@code BigDecimal} 을 거치며 {@code "1.5"} 로 <b>재포맷</b>된다.
 *       소수 자릿수는 SUM 의 결과 자릿수를 좌우하므로(명세 §6.2) 표기 보존이 규칙이다.</li>
 * </ul>
 * 토큰 스트림은 {@link JsonParser#getText()} 로 <b>원문 렉심</b>을 그대로 읽으므로 재포맷이
 * 일어날 여지가 없고, 스칼라 아닌 값은 건너뛰지 않고 그 자리에서 거부할 수 있다.
 *
 * 이 정책은 프론트 {@code serializer.js} 의 {@code parseSampleData} 와 동일하다 —
 * 같은 입력을 두 곳이 다르게 받아들이면 "화면에서는 되는데 서버에서는 안 된다"가 된다.
 */
public class DataMapDeserializer extends JsonDeserializer<Map<String, String>> {

    @Override
    public Map<String, String> deserialize(JsonParser parser, DeserializationContext context)
            throws IOException {
        Map<String, String> data = new LinkedHashMap<String, String>();

        JsonToken root = parser.currentToken();
        if (root == JsonToken.VALUE_NULL) {
            /* "data": null 은 "데이터 없음"으로 읽는다 (§2.1 — 응답에는 null 을 쓰지 않지만
               요청에서 들어오는 것까지 거부할 이유는 없다). */
            return data;
        }
        if (root != JsonToken.START_OBJECT) {
            throw mismatch(parser, "data 는 객체여야 합니다.");
        }

        while (parser.nextToken() != JsonToken.END_OBJECT) {
            String key = parser.currentName();
            JsonToken value = parser.nextToken();
            switch (value) {
                case VALUE_STRING:
                case VALUE_NUMBER_INT:
                case VALUE_NUMBER_FLOAT:
                    /* getText() 는 원문 렉심이다 — 1.50 이 1.5 로 바뀌지 않는다 */
                    data.put(key, parser.getText());
                    break;
                default:
                    /*
                     * 객체/배열/불리언/null 은 <b>건너뛰지 않고</b> 거부한다.
                     * skipChildren() 으로 넘기면 사용자가 보낸 값이 조용히 사라지고,
                     * "왜 이 변수만 비어 있지"를 추적할 단서가 없어진다.
                     */
                    throw mismatch(parser,
                            "'" + key + "' 값은 문자열 또는 숫자만 쓸 수 있습니다.");
            }
        }
        return data;
    }

    /**
     * 400 으로 나갈 오류.
     *
     * 평범한 {@link IOException} 은 Spring 이 "I/O error while reading input message" 로
     * 갈아끼워 <b>메시지가 사라진다</b>. {@link JsonMappingException}(= IOException 하위)
     * 이어야 {@code HttpMessageNotReadableException} 이 원본 문구를 보존해 사용자가
     * 어느 키가 문제인지 알 수 있다.
     */
    private static JsonMappingException mismatch(JsonParser parser, String message) {
        return JsonMappingException.from(parser, message);
    }
}
