package com.xmltemplate.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * 템플릿 마스터 행 ({@code XML_TEMPLATE}).
 *
 * <h3>대리키를 쓰는 이유 (R3)</h3>
 * 이전에는 {@code TEMPLATE_NAME} 이 그대로 PK 였고 자식 테이블이 그 <b>이름</b>을 FK 로 들고
 * 있었다. 그러면 이름이 업무 식별자이면서 동시에 물리 식별자가 되어, 이름을 바꾸는 순간 모든
 * 자식 행을 함께 갱신해야 한다. 대리키({@link #id})를 두면 이름은 <b>유일 제약이 걸린 평범한
 * 속성</b>이 되고 자식은 안정적인 ID 만 참조한다.
 *
 * 이름의 유일성은 {@code UNIQUE} 제약이 계속 보장한다 — 대리키를 도입해도 "같은 이름 두 개"가
 * 허용되면 안 되기 때문이다.
 *
 * <h3>왜 마스터도 시퀀스인가 (재량 결정)</h3>
 * 마스터는 저장 1회에 1행이라 배치와 무관하고, IDENTITY 여도 성능 차이가 없다. 그럼에도
 * 시퀀스로 통일한 이유는 <b>두 테이블이 다른 전략을 쓰면 "왜 여기만 다르지"를 매번 되묻게
 * 되고, persist 시점에 키가 있느냐 없느냐가 테이블마다 달라져 저장 코드를 읽기 어려워지기</b>
 * 때문이다. 지금은 두 엔티티 모두 <b>persist 직후 키가 채워진다</b>는 하나의 규칙으로 읽힌다.
 *
 * <b>{@code @Lob} 을 쓰지 않는 이유</b>: Hibernate 6 에서 {@code @Lob String} 은 CLOB 으로 매핑되어
 * 드라이버의 {@code setCharacterStream}/{@code Clob} 경로를 탄다. 평범한 {@code String} 필드는
 * Hibernate 가 {@code setString} 을 쓰므로 이전 JdbcTemplate 구현과 바이트 수준에서 같다.
 *
 * <b>{@code LocalDateTime} 을 쓰는 이유</b>: {@code java.util.Date}/{@code Timestamp} 는 드라이버가
 * 세션 타임존으로 변환하지만 {@code LocalDateTime} 은 Hibernate 6 이 {@code setObject} 로 넣어
 * <b>벽시계 값 그대로</b> 저장한다.
 */
@Entity
@Table(name = "XML_TEMPLATE")
public class XmlTemplate {

    /**
     * 시퀀스 블록 크기. <b>DB 시퀀스의 {@code INCREMENT BY} 와 반드시 같아야 한다</b> —
     * 어긋나면 Hibernate 가 남의 블록을 나눠 써 <b>조용히 키가 충돌</b>한다 (§schema.sql).
     */
    static final int ALLOCATION_SIZE = 50;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqXmlTemplate")
    @SequenceGenerator(name = "seqXmlTemplate", sequenceName = "SEQ_XML_TEMPLATE",
            allocationSize = ALLOCATION_SIZE)
    @Column(name = "ID", nullable = false)
    private Long id;

    /** 업무 식별자. PK 는 아니지만 <b>UNIQUE</b> 라 여전히 중복될 수 없다. */
    @Column(name = "TEMPLATE_NAME", length = 100, nullable = false, unique = true)
    private String templateName;

    @Column(name = "UPDATED_AT", nullable = false)
    private LocalDateTime updatedAt;

    /** 업로드 원본 XML (LONGTEXT). 참고용 — 소스오브트루스는 노드 트리다. */
    @Column(name = "SOURCE_XML", columnDefinition = "LONGTEXT")
    private String sourceXml;

    /** JPA 요구. */
    protected XmlTemplate() {
    }

    /** 신규 마스터 — {@code id} 는 DB 가 채운다. */
    public XmlTemplate(String templateName, LocalDateTime updatedAt, String sourceXml) {
        this.templateName = templateName;
        this.updatedAt = updatedAt;
        this.sourceXml = sourceXml;
    }

    public Long getId() {
        return id;
    }

    public String getTemplateName() {
        return templateName;
    }

    /**
     * 이름 변경을 허용한다 — 대리키 도입의 실질적 이득이 여기다. 자식 행은 {@code TEMPLATE_ID}
     * 를 참조하므로 이름만 바꾸면 되고 노드를 건드릴 필요가 없다.
     */
    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getSourceXml() {
        return sourceXml;
    }

    public void setSourceXml(String sourceXml) {
        this.sourceXml = sourceXml;
    }
}
