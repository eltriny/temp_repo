package com.xmltemplate.entity;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * {@code INPUT_TYPE} 컬럼 ↔ {@link ValueType} 변환.
 *
 * <b>{@code @Enumerated(EnumType.STRING)} 을 쓰지 않는 이유</b>: 그 매핑은 DB 에 enum 이름과
 * 정확히 일치하지 않는 값이 있으면 {@code IllegalArgumentException} 을 던져 <b>조회 전체가
 * 실패</b>한다. 기존 운영 DB 에는 구 문법 시절의 데이터나 손으로 넣은 행이 남아 있을 수 있고,
 * 그 경우 목록은 뜨는데 개별 조회만 죽어 화면에서 그 템플릿을 지울 수조차 없게 된다.
 *
 * {@link ValueType#fromString} 의 관대함(미지 값 → FIXED)을 그대로 유지한다.
 *
 * <b>{@code autoApply = true} 를 쓰지 않는다</b> — 필드마다 {@code @Convert} 를 명시해야
 * 어느 컬럼이 관대 변환을 타는지 코드에서 보인다.
 */
@Converter
public class ValueTypeConverter implements AttributeConverter<ValueType, String> {

    @Override
    public String convertToDatabaseColumn(ValueType attribute) {
        return (attribute == null ? ValueType.FIXED : attribute).name();
    }

    @Override
    public ValueType convertToEntityAttribute(String dbData) {
        return ValueType.fromString(dbData);
    }
}
