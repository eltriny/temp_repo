package com.xmltemplate.entity;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * {@code INPUT_DATA_TYPE} 컬럼 ↔ {@link ValueDataType} 변환.
 * 관대 복원의 근거는 {@link ValueTypeConverter} 주석과 같다 (미지 값 → STRING).
 */
@Converter
public class ValueDataTypeConverter implements AttributeConverter<ValueDataType, String> {

    @Override
    public String convertToDatabaseColumn(ValueDataType attribute) {
        return (attribute == null ? ValueDataType.STRING : attribute).name();
    }

    @Override
    public ValueDataType convertToEntityAttribute(String dbData) {
        return ValueDataType.fromString(dbData);
    }
}
