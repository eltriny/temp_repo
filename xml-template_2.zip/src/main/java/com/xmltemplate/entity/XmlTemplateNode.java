package com.xmltemplate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * 템플릿 노드 한 행 ({@code XML_TEMPLATE_NODE}).
 *
 * <h3>단일 대리키로 바뀐 이유 (R3)</h3>
 * 이전 PK 는 복합키 {@code (TEMPLATE_NAME, NODE_SN)} 이었고 별도 {@code @IdClass} 클래스가
 * 필요했다. 단일 대리키가 되면서 그 클래스가 사라졌고, 자식은 이름이 아니라
 * {@link #templateId} 를 참조하므로 템플릿 이름 변경이 노드 행에 전파되지 않는다.
 *
 * <h3>{@code NODE_SN} 의 의미가 바뀌었다 — 주의</h3>
 * 이전에는 <b>템플릿마다 1부터</b> DFS 전위 순서로 앱이 부여했다. 지금은 DB 가 채우는
 * <b>전역 증가</b> 값이다. 따라서:
 * <ul>
 *   <li>{@code ORDER BY NODE_SN} 이 DFS 전위라는 <b>계약은 그대로 성립</b>한다 — 저장이 DFS
 *       순서로 삽입하므로 생성 순서가 곧 DFS 순서다.</li>
 *   <li>다만 <b>더 이상 1..n 이 아니다.</b> 저장할 때마다 전건 삭제 후 재삽입하므로 값이
 *       계속 커지고 구간이 비어 있다. "1부터"를 가정한 코드·테스트는 깨진다.</li>
 * </ul>
 *
 * <h3>연관관계를 걸지 않는다</h3>
 * {@code TEMPLATE_ID}/{@code PARENT_SN} 을 {@code @ManyToOne} 으로 매핑하지 않고 평범한
 * {@code Long} 으로 둔다. 엔진이 필요한 것은 평면 목록 하나뿐이고
 * ({@code ORDER BY NODE_SN} 한 번이면 부모가 자식보다 먼저 나온다), 지연 로딩 프록시가
 * 깊이 재귀하는 생성 엔진으로 새는 것을 막아야 하기 때문이다.
 *
 * <h3>왜 IDENTITY 가 아니라 SEQUENCE 인가</h3>
 * IDENTITY 를 쓰면 Hibernate 가 INSERT 를 <b>배치로 묶지 못한다</b> — 생성된 키를 행마다
 * 받아와야 하기 때문이다. 노드 상한이 10,000 이라 저장이 10,000 왕복이 되어,
 * {@code hibernate.jdbc.batch_size=100} 을 살리려던 이전 라운드의 결정과 정면으로 어긋난다.
 *
 * 시퀀스는 <b>persist 시점에 INSERT 없이</b> 블록에서 키를 꺼내 준다. 그래서
 * <ul>
 *   <li>INSERT 는 flush 까지 미뤄져 <b>배치가 살아남고</b>,</li>
 *   <li>자식이 참조할 부모 키가 부모 INSERT 전에 이미 정해져 <b>삽입 직렬화도 사라진다</b>.</li>
 * </ul>
 * 대가는 {@code allocationSize} 만큼의 키 구멍인데, 저장마다 전건 재삽입이라 어차피 값이
 * 띄엄띄엄해지므로 실질 손해가 없다.
 */
@Entity
@Table(name = "XML_TEMPLATE_NODE")
public class XmlTemplateNode {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqXmlTemplateNode")
    @SequenceGenerator(name = "seqXmlTemplateNode", sequenceName = "SEQ_XML_TEMPLATE_NODE",
            allocationSize = XmlTemplate.ALLOCATION_SIZE)
    @Column(name = "NODE_SN", nullable = false)
    private Long nodeSn;

    /** 소속 템플릿의 대리키 ({@code XML_TEMPLATE.ID} FK). */
    @Column(name = "TEMPLATE_ID", nullable = false)
    private Long templateId;

    @Column(name = "NODE_NAME", length = 200, nullable = false)
    private String nodeName;

    /** 부모 노드의 {@code NODE_SN}. 루트는 null. */
    @Column(name = "PARENT_SN")
    private Long parentSn;

    @Convert(converter = ValueTypeConverter.class)
    @Column(name = "INPUT_TYPE", length = 20, nullable = false)
    private ValueType inputType;

    @Column(name = "INPUT_VALUE", columnDefinition = "TEXT")
    private String inputValue;

    @Convert(converter = ValueDataTypeConverter.class)
    @Column(name = "INPUT_DATA_TYPE", length = 20, nullable = false)
    private ValueDataType inputDataType;

    @Column(name = "DISPLAY_COND", columnDefinition = "TEXT")
    private String displayCond;

    /**
     * 폐지된 반복 조건 (문법 v2 §2). 컬럼과 필드를 남겨 두는 이유는 값이 남아 있을 때
     * {@code REPEAT_CONDITION_REMOVED} 로 <b>명확히 거부</b>하기 위해서다 — 필드를 없애면
     * 사용자가 쓴 속성이 소리 없이 사라진다. 새 저장은 항상 빈 값이다.
     */
    @Column(name = "REPEAT_COND", columnDefinition = "TEXT")
    private String repeatCond;

    @Column(name = "REPEAT_COUNT_COND", length = 1000)
    private String repeatCountCond;

    /** JPA 요구. */
    protected XmlTemplateNode() {
    }

    /** 신규 노드 — {@code nodeSn} 은 DB 가 채운다. */
    public XmlTemplateNode(Long templateId, String nodeName, Long parentSn,
            ValueType inputType, String inputValue, ValueDataType inputDataType,
            String displayCond, String repeatCond, String repeatCountCond) {
        this.templateId = templateId;
        this.nodeName = nodeName;
        this.parentSn = parentSn;
        this.inputType = inputType;
        this.inputValue = inputValue;
        this.inputDataType = inputDataType;
        this.displayCond = displayCond;
        this.repeatCond = repeatCond;
        this.repeatCountCond = repeatCountCond;
    }

    public Long getNodeSn() {
        return nodeSn;
    }

    public Long getTemplateId() {
        return templateId;
    }

    public String getNodeName() {
        return nodeName;
    }

    public Long getParentSn() {
        return parentSn;
    }

    public ValueType getInputType() {
        return inputType;
    }

    public String getInputValue() {
        return inputValue;
    }

    public ValueDataType getInputDataType() {
        return inputDataType;
    }

    public String getDisplayCond() {
        return displayCond;
    }

    public String getRepeatCond() {
        return repeatCond;
    }

    public String getRepeatCountCond() {
        return repeatCountCond;
    }
}
