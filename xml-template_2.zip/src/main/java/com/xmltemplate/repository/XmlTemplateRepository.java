package com.xmltemplate.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xmltemplate.entity.XmlTemplate;

/**
 * 템플릿 마스터 행.
 *
 * R3 에서 PK 가 대리키({@code ID})가 되면서 ID 타입이 {@code Long} 이 되었다. 이름으로 찾는
 * 일은 {@link #findByTemplateName} 이 맡는다 — 이름은 이제 <b>UNIQUE 제약이 걸린 속성</b>이지
 * 식별자가 아니다.
 */
public interface XmlTemplateRepository extends JpaRepository<XmlTemplate, Long> {

    /** 이름은 UNIQUE 라 최대 1건이다. */
    Optional<XmlTemplate> findByTemplateName(String templateName);

    boolean existsByTemplateName(String templateName);

    /**
     * 이름 오름차순 전체 목록.
     *
     * <b>정렬은 계약이다.</b> 목록 화면의 순서가 DB 의 물리적 행 순서에 따라 달라지면 화면이
     * 새로고침마다 뒤바뀌고, 목록의 첫 항목을 단언하는 테스트가 실행 순서에 따라 깨진다.
     * 프론트는 재정렬하지 않으므로 서버가 순서를 보장해야 한다.
     */
    List<XmlTemplate> findAllByOrderByTemplateNameAsc();
}
