package com.xmltemplate.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.xmltemplate.entity.XmlTemplateNode;

/**
 * 템플릿 노드 행.
 *
 * R3 에서 PK 가 단일 대리키({@code NODE_SN})가 되면서 ID 타입이 {@code Long} 이 되었다 —
 * 별도 {@code @IdClass} 가 필요 없다.
 */
public interface XmlTemplateNodeRepository extends JpaRepository<XmlTemplateNode, Long> {

    /**
     * <b>정렬을 메서드 이름에 박는다</b> — 정렬이 계약이라는 사실이 코드에 드러나야 한다.
     * 저장이 DFS 전위 순서로 삽입하므로 생성 순서가 곧 DFS 순서이고, 이 정렬이면 부모가
     * 자식보다 먼저 나와 O(n) 단일 패스로 트리를 조립할 수 있다.
     *
     * <b>템플릿 이름이 아니라 ID 로 찾는다</b> (R3) — 이름 변경이 노드 조회에 영향을 주지 않는다.
     */
    List<XmlTemplateNode> findByTemplateIdOrderByNodeSnAsc(Long templateId);

    /**
     * 벌크 DELETE.
     *
     * <b>파생 {@code deleteBy…} 를 쓰지 않는 이유</b>: Spring Data 의 파생 삭제는 "SELECT 로
     * 엔티티를 읽어 하나씩 {@code remove()}" 다. 노드 상한이 10,000 이므로 최악에 10,000번의
     * DELETE 가 나간다. 벌크 DELETE 는 SQL 한 방이다.
     *
     * 대신 벌크 연산은 영속성 컨텍스트를 우회하므로 {@code flushAutomatically}(선행 변경 반영)와
     * {@code clearAutomatically}(스테일 엔티티 제거)를 <b>반드시</b> 함께 준다.
     */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("delete from XmlTemplateNode n where n.templateId = :templateId")
    int deleteAllByTemplateId(@Param("templateId") Long templateId);
}
