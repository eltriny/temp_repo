package com.xmltemplate.repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.TemplateSummaryDto;
import com.xmltemplate.entity.XmlTemplate;
import com.xmltemplate.entity.XmlTemplateNode;
import com.xmltemplate.exception.InvalidRequestException;
import com.xmltemplate.exception.RepositoryException;
import com.xmltemplate.util.template.TemplateEntityMapper;

/**
 * 템플릿 트리 ↔ 행 변환을 캡슐화하는 저장소.
 *
 * <b>트랜잭션을 열지 않는다</b> — 호출자({@code TemplateService})의 트랜잭션 안에서 돈다.
 * 경계가 한 계층에만 있어야 어디서 열리는지가 자명하다.
 *
 * 데이터 접근 예외는 {@link RepositoryException} 으로 감싼다. 감싸지 않으면 폴백 핸들러가
 * 500 {@code INTERNAL_ERROR} 로 처리해 <b>DB 장애와 코드 버그가 구분되지 않는다</b>.
 *
 * <h3>R3: 이름이 아니라 대리키로 다룬다</h3>
 * 모든 조회가 {@code TEMPLATE_NAME} 으로 마스터를 한 번 찾아 {@code ID} 를 얻은 뒤, 노드는
 * 그 ID 로 다룬다. 이름은 UNIQUE 제약이 걸린 <b>속성</b>일 뿐 식별자가 아니다.
 */
@Repository
public class TemplateStore {

    private final XmlTemplateRepository templates;
    private final XmlTemplateNodeRepository nodes;

    /**
     * 노드 삽입 전용.
     *
     * 트랜잭션에 묶인 공유 프록시라 {@code nodes} 리포지토리와 <b>같은 영속성 컨텍스트</b>를
     * 본다 — 여기서 persist 한 엔티티를 리포지토리의 {@code flush()} 가 그대로 내보낸다.
     */
    @PersistenceContext
    private EntityManager entityManager;

    public TemplateStore(XmlTemplateRepository templates, XmlTemplateNodeRepository nodes) {
        this.templates = templates;
        this.nodes = nodes;
    }

    /* ------------------------------------------------------------------ */
    /* 저장                                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 마스터는 upsert, 노드는 <b>전건 삭제 후 재삽입</b>.
     *
     * <h3>왜 병합(merge)이 아닌가</h3>
     * 노드에는 저장 간에 유지되는 안정적 식별자가 없다. {@code NODE_SN} 은 대리키가 된 뒤에도
     * 저장할 때마다 새로 발급되므로 "옛 노드 ↔ 새 노드" 대응이 <b>존재하지 않는다</b>. 억지로
     * 병합하면 새 트리보다 노드가 많던 옛 저장분의 잔여 행이 고아로 남는다.
     *
     * <h3>시퀀스라서 배치가 살아 있다</h3>
     * 노드 키는 시퀀스에서 나온다. {@code persist} 시점에 <b>INSERT 없이</b> 블록에서 키가
     * 발급되므로, 부모 키를 자식에게 넘기면서도 INSERT 자체는 flush 까지 미뤄져
     * {@code batch_size=100} 배치가 유지된다. IDENTITY 였다면 행마다 INSERT 왕복이 생기고
     * 배치가 통째로 무효화된다 — 그래서 시퀀스를 골랐다({@code XmlTemplateNode} 주석 참조).
     */
    public void save(String templateName, TemplateNode root) {
        validateName(templateName);
        if (root == null) {
            throw new InvalidRequestException("저장할 템플릿이 비어 있습니다.");
        }
        try {
            XmlTemplate master = templates.findByTemplateName(templateName)
                    .orElseGet(() -> new XmlTemplate(templateName, null, null));
            master.setUpdatedAt(LocalDateTime.now().withNano(0));
            master = templates.save(master);
            /*
             * 마스터를 먼저 내보낸다. 신규라면 여기서 ID 가 채워지고, 노드 INSERT 는 그 ID 를
             * FK 로 요구한다.
             */
            templates.flush();
            Long templateId = master.getId();

            nodes.deleteAllByTemplateId(templateId);
            /*
             * ★ 삭제를 삽입보다 먼저 내보내는 것을 사람이 보증한다.
             *
             * Hibernate 는 SQL 을 action queue 에 쌓았다가 flush 때 정해진 순서
             * (insert → update → … → delete)로 내보낸다. 위 벌크 DELETE 는 JPQL 이라 즉시
             * 나가지만, 마스터 저장이 만든 대기 상태와의 상호작용이 버전에 따라 미묘하다.
             */
            nodes.flush();

            /*
             * DFS 전위 순서로 persist 한다. 시퀀스라 persist 직후 nodeSn 이 채워지므로
             * 자식에게 넘길 부모 키를 INSERT 없이 알 수 있다 — 이 순서가 곧 NODE_SN 순서이고,
             * 그래서 "ORDER BY NODE_SN = DFS 전위" 계약이 성립한다.
             */
            persistTree(root, templateId, null);
            /*
             * ★ 제약 위반을 이 try 안에서 드러낸다.
             *
             * 시퀀스라서 persist 는 키만 발급하고 <b>INSERT 를 큐에 쌓아 둔다</b>. 이 flush 가
             * 없으면 INSERT 가 커밋 시점까지 미뤄지고, 그때 나는 제약 위반(예: NODE_NAME 길이
             * 초과 → Data too long)은 <b>이 catch 를 이미 지나친 뒤</b>라 폴백 핸들러가 500
             * INTERNAL_ERROR 로 처리한다 — 계약상 REPOSITORY_ERROR 여야 한다. IDENTITY 였다면
             * INSERT 가 persist 때 나가 이 줄이 덜 중요했겠지만, 시퀀스에서는 <b>필수</b>다.
             *
             * <b>리포지토리를 거쳐</b> flush 해야 하는 것도
             * 핵심이다 — entityManager.flush() 는 원시 PersistenceException 을 던져 아래 catch 를
             * 그냥 통과한다. Spring 의 예외 변환(→ DataAccessException)은 @Repository 빈을
             * 빠져나갈 때와 Spring Data 프록시 호출에서만 일어나는데, catch 는 메서드 안이라
             * 전자는 이미 늦다.
             */
            nodes.flush();
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 저장 실패: " + templateName + " - "
                    + e.getMessage(), e);
        }
    }

    /**
     * 트리를 DFS 전위 순서로 persist 한다.
     *
     * 재귀와 키 전달이 여기 있는 이유는 {@code TemplateEntityMapper} 주석 참조 — 부모 키는
     * 영속성 컨텍스트가 발급하므로 순수 변환 함수가 알 수 없는 값이다.
     */
    private void persistTree(TemplateNode node, Long templateId, Long parentSn) {
        XmlTemplateNode row = TemplateEntityMapper.toEntity(node, templateId, parentSn);
        entityManager.persist(row);
        for (TemplateNode child : node.getChildren()) {
            persistTree(child, templateId, row.getNodeSn());
        }
    }

    /* ------------------------------------------------------------------ */
    /* 조회                                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 트리를 조립해 돌려준다. 없으면 null.
     *
     * 마스터 1회 + 노드 평면 목록 1회 조회 후 메모리에서 조립한다 — 자기참조 연관을 걸어
     * 재귀 탐색하면 노드당 1쿼리(최대 10,000 쿼리)가 된다.
     */
    public TemplateNode load(String templateName) {
        validateName(templateName);
        try {
            XmlTemplate master = templates.findByTemplateName(templateName).orElse(null);
            if (master == null) {
                return null;
            }
            List<XmlTemplateNode> rows =
                    nodes.findByTemplateIdOrderByNodeSnAsc(master.getId());
            return TemplateEntityMapper.toDomainTree(rows, templateName);
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 조회 실패: " + templateName + " - "
                    + e.getMessage(), e);
        }
    }

    /** 마지막 저장 시각 (ISO-8601). 없으면 null. */
    public String loadUpdatedAt(String templateName) {
        validateName(templateName);
        try {
            return templates.findByTemplateName(templateName)
                    .map(TemplateStore::iso)
                    .orElse(null);
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 조회 실패: " + templateName + " - "
                    + e.getMessage(), e);
        }
    }

    /** 이름 + 수정 시각 목록 — <b>이름 오름차순</b>(계약). */
    public List<TemplateSummaryDto> listSummaries() {
        try {
            List<TemplateSummaryDto> result = new ArrayList<TemplateSummaryDto>();
            for (XmlTemplate master : templates.findAllByOrderByTemplateNameAsc()) {
                TemplateSummaryDto dto = new TemplateSummaryDto();
                dto.name = master.getTemplateName();
                dto.updatedAt = iso(master);
                result.add(dto);
            }
            return result;
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 목록 조회 실패: " + e.getMessage(), e);
        }
    }

    public boolean exists(String templateName) {
        validateName(templateName);
        try {
            return templates.existsByTemplateName(templateName);
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 존재 확인 실패: " + templateName + " - "
                    + e.getMessage(), e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 삭제                                                                 */
    /* ------------------------------------------------------------------ */

    /** 자식(노드) 먼저, 마스터 마지막 — FK 방향. 마스터가 있었으면 true. */
    public boolean delete(String templateName) {
        validateName(templateName);
        try {
            XmlTemplate master = templates.findByTemplateName(templateName).orElse(null);
            if (master == null) {
                return false;
            }
            nodes.deleteAllByTemplateId(master.getId());
            templates.delete(master);
            return true;
        } catch (DataAccessException e) {
            throw new RepositoryException("템플릿 삭제 실패: " + templateName + " - "
                    + e.getMessage(), e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 공통                                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 템플릿 이름 검증.
     *
     * {@code '/'} 와 {@code '\\'} 는 URL 경로에서 안전하게 왕복되지 않아 차단한다.
     * 이름 규칙 위반은 <b>클라이언트 오류(400)</b>다 — 저장소 장애(500)와 타입으로 구분한다.
     */
    private static void validateName(String templateName) {
        if (templateName == null || templateName.trim().isEmpty()) {
            throw new InvalidRequestException("템플릿 이름이 비어 있습니다.");
        }
        if (templateName.length() > 100) {
            throw new InvalidRequestException("템플릿 이름이 너무 깁니다 (최대 100자).");
        }
        if (templateName.indexOf('/') >= 0 || templateName.indexOf('\\') >= 0) {
            throw new InvalidRequestException(
                    "템플릿 이름에 '/' 또는 '\\' 은 사용할 수 없습니다: " + templateName);
        }
    }

    /** {@code LocalDateTime#toString()} = ISO-8601 (예: {@code 2026-08-07T15:43:59}). */
    private static String iso(XmlTemplate master) {
        LocalDateTime updatedAt = master.getUpdatedAt();
        return (updatedAt == null) ? null : updatedAt.withNano(0).toString();
    }
}
