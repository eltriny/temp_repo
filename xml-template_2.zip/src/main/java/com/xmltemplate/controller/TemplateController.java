package com.xmltemplate.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.xmltemplate.dto.GenerateRequestDto;
import com.xmltemplate.dto.GenerationResultDto;
import com.xmltemplate.dto.ImportResultDto;
import com.xmltemplate.dto.PreviewRequestDto;
import com.xmltemplate.dto.SaveResultDto;
import com.xmltemplate.dto.TemplateDto;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.TemplateSummaryDto;
import com.xmltemplate.dto.WarningDto;
import com.xmltemplate.exception.InvalidRequestException;
import com.xmltemplate.exception.TemplateNotFoundException;
import com.xmltemplate.service.TemplateService;
import com.xmltemplate.util.xml.SecureXml;
import com.xmltemplate.util.template.TemplateMapper;

/**
 * JSON 계약 (docs/API_V4_FLAT.md §4) — 노드는 <b>평면 목록</b>({@code nodes[]})으로 오간다.
 *
 * 이 컨트롤러는 <b>HTTP 와 JSON 표현만</b> 다룬다. 검증 시점·경고 생성 같은
 * 정책은 전부 {@link TemplateService} 에 있다 — 여기에 복사하면 미리보기와
 * 저장분 생성의 의미론이 갈라진다 (§5.1 — 검증·정책이 한 지점을 지나야 하는 이유).
 */
@RestController
@RequestMapping("/api")
public class TemplateController {

    private final TemplateService service;

    public TemplateController(TemplateService service) {
        this.service = service;
    }

    /* ------------------------------------------------------------------ */
    /* 조회                                                                 */
    /* ------------------------------------------------------------------ */

    @GetMapping("/templates")
    public List<TemplateSummaryDto> list() {
        return service.list();
    }

    @GetMapping("/templates/{name}")
    public TemplateDto get(@PathVariable("name") String name) {
        TemplateDto loaded = service.load(name);
        if (loaded == null) {
            throw new TemplateNotFoundException("템플릿이 존재하지 않습니다: " + name);
        }
        return loaded;
    }

    /* ------------------------------------------------------------------ */
    /* 저장 / 삭제                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * 저장. 정적 검증(§5.2 V11)을 통과해야 하며 실패하면 400 + 오류 목록이다
     * (§5.4 — 조건식 오류는 사용자가 한 칸씩 고치는 대상이라 {@code errors[]} 를 채운다.
     *  구조 오류가 첫 위반에서 즉시 실패하는 것과 정책이 다르다).
     *
     * <b>본문이 아예 없는 경우만 여기서 본다.</b> {@code nodes} 유무·구조 검증·tombstone 은
     * 전부 {@link TemplateMapper#toModel(TemplateDto)} 이 한다 — 미리보기와 <b>완전히 같은
     * 지점</b>을 지나야 "미리보기는 되는데 저장은 안 되는" 상태가 생기지 않는다.
     * 같은 조건문을 두 메서드에 복사하면 한쪽만 고쳐지는 날이 온다.
     */
    @PutMapping("/templates/{name}")
    public SaveResultDto save(@PathVariable("name") String name,
            @RequestBody TemplateDto body) {
        if (body == null) {
            throw new InvalidRequestException("요청 본문이 비어 있습니다.");
        }
        /* 경로가 정본이다 — 본문의 name 은 읽지 않는다. */
        TemplateNode root = TemplateMapper.toModel(body);
        return service.save(name, root);
    }

    @DeleteMapping("/templates/{name}")
    public ResponseEntity<Void> delete(@PathVariable("name") String name) {
        if (!service.delete(name)) {
            throw new TemplateNotFoundException("템플릿이 존재하지 않습니다: " + name);
        }
        return ResponseEntity.noContent().build();
    }

    /* ------------------------------------------------------------------ */
    /* 임포트                                                               */
    /* ------------------------------------------------------------------ */

    /**
     * 구조 XML → 템플릿 변환 (저장하지 않음).
     *
     * <b>리터럴 경로가 경로 변수보다 우선</b>하므로 이름이 "import" 인 일반 템플릿의
     * PUT/GET/DELETE 는 그대로 동작한다 (명세 §12.2). 프레임워크 동작에 기댄 것이라
     * 테스트로 고정한다.
     *
     * multipart 파트는 {@code getInputStream()} 을 그대로 파서에 넘긴다 — 바이트를 미리
     * UTF-8 로 디코딩하면 {@code encoding="EUC-KR"} 선언 파일이 파서가 선언을 보기 전에
     * 깨진다 (§4.4).
     *
     * <b>단 파트 {@code Content-Type} 에 charset 이 명시되면 그것이 우선한다</b> (§4.4,
     * RFC 7303). 붙여넣기 경로가 그 경우다 — 원본 바이트가 없는 텍스트를 프론트가 UTF-8 로
     * 인코딩해 보내므로, 본문에 남은 {@code encoding="EUC-KR"} 선언을 따르면 그 자리에서
     * 한글이 깨진다. 두 경로를 파트 메타데이터로 구분한다.
     */
    @PostMapping(value = "/templates/import",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ImportResultDto importMultipart(
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "templateName", required = false) String templateName)
            throws IOException {
        if (file == null || file.isEmpty()) {
            throw new InvalidRequestException("업로드할 XML 파일(file 파트)이 없습니다.");
        }
        return toImportDto(file.getInputStream(), charsetOf(file.getContentType()),
                suggestName(templateName, file.getOriginalFilename()));
    }

    /** 붙여넣기 경로 — 본문이 XML 자체. 이쪽은 요청 Content-Type 의 charset 을 본다. */
    @PostMapping(value = "/templates/import",
            consumes = { MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_XML_VALUE })
    public ImportResultDto importRaw(@RequestBody byte[] body,
            @RequestHeader(value = "Content-Type", required = false) String contentType) {
        if (body == null || body.length == 0) {
            throw new InvalidRequestException("업로드할 XML 이 없습니다.");
        }
        SecureXml.checkBodySize(body.length);
        return toImportDto(new ByteArrayInputStream(body), charsetOf(contentType), "");
    }

    /**
     * 파트/요청의 {@code Content-Type} 에서 charset 파라미터를 뽑는다.
     * 없으면 null — 그 경우 XML 선언을 따른다 (§4.4).
     */
    private static String charsetOf(String contentType) {
        if (contentType == null) {
            return null;
        }
        try {
            java.nio.charset.Charset charset = MediaType.parseMediaType(contentType).getCharset();
            return (charset == null) ? null : charset.name();
        } catch (RuntimeException e) {
            /* 파싱 불가한 Content-Type 은 charset 없음으로 본다 — 선언 기준 해석 */
            return null;
        }
    }

    /**
     * 이름 제안은 전송 계층의 정보(파트 이름·파일명)에서 나오므로 서비스가 아니라 여기서
     * 채운다. 서비스는 트리와 경고만 만든다.
     */
    private ImportResultDto toImportDto(InputStream stream, String encoding,
            String suggestedName) {
        ImportResultDto dto = service.importStructure(stream, encoding);
        dto.template.name = suggestedName;
        return dto;
    }

    /**
     * 제안 이름: {@code templateName} 파트 &gt; {@code filename} 확장자 제거 &gt; {@code ""}
     * (§4.4).
     *
     * <b>합성 파일명을 전제로 한다.</b> 붙여넣기 경로는 프론트가 텍스트를 Blob 으로 감싸
     * {@code pasted.xml} 같은 합성값을 붙이므로, 파일명이 사용자의 의도를 담고 있다는 보장이
     * 없다. 그래서 명시 파트가 있으면 그것을 우선하고, 아무것도 없으면 서버가 이름을
     * 지어내지 않고 빈 문자열을 돌려준다 — 이름은 사용자가 정할 몫이다.
     */
    private static String suggestName(String templateName, String filename) {
        if (templateName != null && !templateName.trim().isEmpty()) {
            return templateName.trim();
        }
        if (filename == null || filename.trim().isEmpty()) {
            return "";
        }
        String base = filename.replace('\\', '/');
        int slash = base.lastIndexOf('/');
        if (slash >= 0) {
            base = base.substring(slash + 1);
        }
        int dot = base.lastIndexOf('.');
        if (dot > 0) {
            base = base.substring(0, dot);
        }
        return base.trim();
    }

    /* ------------------------------------------------------------------ */
    /* 생성 / 미리보기                                                       */
    /* ------------------------------------------------------------------ */

    /** 미리보기. 저장과 <b>같은</b> 매퍼 진입점을 지난다 — 두 경로의 거부 조건이 갈라지지 않는다. */
    @PostMapping("/preview")
    public GenerationResultDto preview(@RequestBody PreviewRequestDto body) {
        if (body == null || body.template == null) {
            throw new InvalidRequestException("요청 본문에 template 이 없습니다.");
        }

        TemplateNode root = TemplateMapper.toModel(body.template);
        return withWarnings(service.preview(root, emptyIfNull(body.data)), body.withWarnings);
    }

    /** 저장분 생성 (외부 시스템용). 프론트는 호출하지 않지만 외부 계약이다. */
    @PostMapping("/generate/{name}")
    public GenerationResultDto generate(@PathVariable("name") String name,
            @RequestBody(required = false) GenerateRequestDto body) {
        Map<String, String> data = (body == null) ? null : body.data;
        return withWarnings(service.generate(name, emptyIfNull(data)), true);
    }

    /**
     * 응답 <b>형태는 항상 같다</b> — {@code withWarnings=false} 면 warnings 가 빈 배열일 뿐이다.
     * 레거시가 형태를 바꾼 이유는 기존 파서를 깨지 않기 위함이었고, 이 API 에는 그 제약이 없다.
     */
    private static GenerationResultDto withWarnings(GenerationResultDto result,
            boolean withWarnings) {
        if (!withWarnings) {
            result.warnings = new ArrayList<WarningDto>();
        }
        return result;
    }

    private static Map<String, String> emptyIfNull(Map<String, String> data) {
        return (data == null) ? new HashMap<String, String>() : data;
    }
}
