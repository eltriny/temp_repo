package com.xmltemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * XML 템플릿 JSON API (docs/API_V4_FLAT.md).
 *
 * 컴포넌트 스캔 루트여야 하므로 8개 하위 패키지 <b>위</b>에 둔다.
 *
 * 이전 진입점에 있던 {@code exclude = DataSourceAutoConfiguration.class} 는 제거했다 —
 * DataSource 를 손으로 만들던 시절의 잔재이며, 남겨 두면 JPA 자동 구성이 DataSource 를
 * 찾지 못해 기동에 실패한다.
 */
@SpringBootApplication
public class XmlTemplateApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlTemplateApplication.class, args);
    }
}
