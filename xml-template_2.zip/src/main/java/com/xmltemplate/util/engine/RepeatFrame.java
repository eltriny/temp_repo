package com.xmltemplate.util.engine;

import com.xmltemplate.dto.TemplateNode;

/**
 * 반복 회차 한 겹 — 어느 노드의 몇 회차인지.
 * 오류 메시지의 인덱스 경로({@code catalog.book[2].price})에도 쓴다.
 */
final class RepeatFrame {

    final TemplateNode node;
    final int index;

    RepeatFrame(TemplateNode node, int index) {
        this.node = node;
        this.index = index;
    }
}
