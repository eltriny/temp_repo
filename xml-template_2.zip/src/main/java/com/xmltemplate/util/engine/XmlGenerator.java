package com.xmltemplate.util.engine;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xmltemplate.util.expression.Expr;
import com.xmltemplate.util.expression.ExpressionEvaluator;
import com.xmltemplate.util.expression.ExpressionResolver;
import com.xmltemplate.util.expression.NodePathExpr;
import com.xmltemplate.util.xml.SecureXml;
import com.xmltemplate.util.template.TemplateValidator;
import com.xmltemplate.util.expression.VarExpr;
import com.xmltemplate.util.expression.VariableText;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.WarningDto;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.exception.ExpressionException;
import com.xmltemplate.exception.GenerationException;

/**
 * 템플릿 + 외부 데이터 -> XML 문자열 생성 엔진 (docs/TEMPLATE_SPEC_V2.md).
 *
 * 생성 규칙:
 *  1. 표시 조건이 있고 false 로 평가되면 해당 노드(하위 포함)를 생성하지 않는다.
 *  2. 반복 횟수는 "반복 횟수 조건(repeatCountExpr)" 으로 정한다 (§9.1).
 *     임의의 식을 평가한 <b>값</b>이 횟수다 — 고정 숫자 | {PARAM} | COUNT(...) | 삼항식.
 *     0 이면 미생성, 비어 있으면 1회. repeatCondition 은 폐지되어(§2) 남아 있으면 오류다.
 *  3. 자식이 있는 노드는 자식 엘리먼트를 갖고, 자식이 없는 노드는 값(텍스트)을 갖는다.
 *  4. 값 유형별 처리:
 *     - FIXED    : 입력 텍스트 그대로 (리터럴 중괄호 이스케이프만 해제, §3.1)
 *     - VARIABLE : {변수명} 을 외부 데이터 값으로 치환 (없으면 빈 문자열 + 경고)
 *     - FUNCTION : 조건식 평가 결과
 *     값의 데이터 타입이 NUMBER 인 노드는 최종 값이 비어 있지 않으면
 *     숫자 형식인지 검증한다.
 *  5. 반복 중 인덱스는 표기로 명시한다 (§5.2) — {@code {NAME_[Nk]}} 가 현재 회차의
 *     {@code NAME_회차} 키를 조회하고, 내장 변수 {@code {INDEX}}/{@code {INDEXk}} 가
 *     회차 값 자체를 준다. 암묵 폴백({X} -> X_회차 자동 탐색)은 없다.
 *
 * 조건식의 피연산자로 노드 경로(예: node1-1.node1-1-1)가 오면
 * 해당 노드의 "값" 을 재귀적으로 계산해서 비교에 사용한다.
 * (순환 참조는 빈 문자열로 처리해서 무한 재귀를 막는다.)
 *
 * <h3>{@link ExpressionResolver} 를 직접 구현하는 이유</h3>
 * 이전에는 생성자에서 익명 클래스로 리졸버를 만들었다. 익명 클래스를 쓰지 않기로 하면서
 * 선택지는 둘이었다 — 위임 클래스를 따로 만들거나, 이 클래스가 직접 구현하거나.
 * 위임 클래스는 생성기의 private 상태(반복 프레임, 경고 목록, 순환 감지 집합)에 전부
 * 접근해야 해서 <b>순환 참조</b>가 생긴다. 직접 구현을 택한 대가로 콜백 4개가
 * {@code public} 이 되었는데, <b>이들은 {@link ExpressionEvaluator} 전용이며 외부에서
 * 직접 호출하면 안 된다</b>.
 */
public class XmlGenerator implements ExpressionResolver {

    /** 반복 회차를 나타내는 내장 변수 이름. */
    public static final String INDEX_VARIABLE = "INDEX";

    /** 경고 코드 (명세 §11). */
    public static final String WARN_MISSING_VARIABLE = "MISSING_VARIABLE";
    public static final String WARN_COUNT_GAP = "COUNT_GAP";
    public static final String WARN_SUM_EMPTY_SKIPPED = "SUM_EMPTY_SKIPPED";

    /** 단일 노드 반복 횟수 상한 (§9.2). COUNT/SUM 의 키 스캔 상한도 같은 값이다. */
    public static final int MAX_REPEAT_PER_NODE = 10000;

    /** 총 생성 엘리먼트 수 상한 (§9.2). */
    public static final int MAX_TOTAL_ELEMENTS = 100000;

    private static final int MAX_SCAN = MAX_REPEAT_PER_NODE;

    private final TemplateNode root;
    private final Map<String, String> data;
    private final ExpressionEvaluator evaluator;

    /** 생성 중 수집된 경고 (명세 §11 - opt-in 응답으로 전달된다). */
    private final List<WarningDto> warnings = new ArrayList<WarningDto>();

    /**
     * 현재 반복 컨텍스트. <b>최외곽이 0번</b>이므로 {@code [Nk]} 의 k-1 이 그대로 인덱스다.
     * (ArrayDeque 의 push=addFirst 는 iterator 가 안→밖으로 돌아 {@code [Nk]} 의
     * 밖→안 순서와 반대라 List 를 쓴다.)
     */
    private final List<RepeatFrame> repeatFrames = new ArrayList<RepeatFrame>();

    /** 총 생성 엘리먼트 수 (명세 §9.2 상한). */
    private int elementCount;

    /** 노드 값 계산 중 순환 참조 감지용. */
    private final Set<TemplateNode> resolving = new HashSet<TemplateNode>();

    /** 표시 여부 판정 중 순환 참조 감지용 (표시 조건이 다시 경로를 참조할 수 있다). */
    private final Set<TemplateNode> displayChecking = new HashSet<TemplateNode>();

    public XmlGenerator(TemplateNode root, Map<String, String> data) {
        this.root = root;
        this.data = (data == null) ? new HashMap<String, String>() : data;
        this.evaluator = new ExpressionEvaluator(this);
    }

    /* ------------------------------------------------------------------ */
    /* ExpressionResolver 콜백 — 평가기 전용, 직접 호출 금지                  */
    /* ------------------------------------------------------------------ */

    @Override
    public String resolveNodePath(String path) {
        return resolvePathValue(path);
    }

    @Override
    public String resolveVariable(String name) {
        return lookupVariable(name);
    }

    @Override
    public String callFunction(String name, Expr argument) {
        return evaluateFunction(name, argument);
    }

    @Override
    public void warn(String code, String message) {
        addWarning(code, message);
    }

    /* ------------------------------------------------------------------ */
    /* 생성                                                                 */
    /* ------------------------------------------------------------------ */

    /** 생성 중 수집된 경고 (생성 후 조회). */
    public List<WarningDto> getWarnings() {
        return warnings;
    }

    /** 생성 엔진의 경고는 노드가 특정되지 않으므로 nodePath 는 항상 "" 다. */
    private void addWarning(String code, String message) {
        warnings.add(new WarningDto(code, "", message));
    }

    /**
     * XML 문자열을 생성한다.
     *
     * @throws GenerationException 노드 이름이 XML 엘리먼트 이름으로 부적합하거나 조건식 오류가 있을 때
     */
    public String generate() {
        try {
            Document doc = SecureXml.newDocument();

            /* 루트는 XML 규칙상 1개만 허용되므로 반복 설정을 무시하고 1개만 생성한다. */
            List<Element> rootElements = buildElements(doc, root, true);
            if (rootElements.isEmpty()) {
                throw new GenerationException(
                        "루트 노드가 표시 조건에 의해 제외되어 XML 을 생성할 수 없습니다.");
            }
            doc.appendChild(rootElements.get(0));
            return serialize(doc);
        } catch (GenerationException e) {
            throw e;
        } catch (ExpressionException e) {
            throw new GenerationException("조건식 오류: " + e.getMessage());
        } catch (Exception e) {
            throw new GenerationException("XML 생성 실패: " + e.getMessage());
        }
    }

    /* ------------------------------------------------------------------ */
    /* 노드 -> 엘리먼트 변환                                                */
    /* ------------------------------------------------------------------ */

    private List<Element> buildElements(Document doc, TemplateNode node, boolean isRoot) {
        List<Element> result = new ArrayList<Element>();

        /* 1. 표시 조건 */
        String displayCond = trim(node.getDisplayCondition());
        if (!displayCond.isEmpty() && !evaluateCondition(node, "표시 조건", displayCond)) {
            return result;
        }

        /* 2. 반복 횟수 결정 */
        String countExpr = trim(node.getRepeatCountExpr());

        /*
         * repeatCondition 은 폐지됐다 (§2). 저장 경로는 TemplateValidator 가
         * 막지만 <b>미리보기는 저장 검증을 거치지 않으므로</b> 여기서도 막아야 한다.
         * 무시하면 사용자가 쓴 속성이 조용히 사라지고(이 프로젝트의 일관된 금지 사항),
         * 저장에서는 거부될 본문의 미리보기를 통과시키게 된다.
         */
        if (!trim(node.getRepeatCondition()).isEmpty()) {
            throw new GenerationException("노드 '" + describePath(node)
                    + "' 에 repeatCondition 이 있습니다. 문법 v2 에서 폐지된 속성입니다 —"
                    + " 게이트가 필요하면 repeatCountExpr 의 삼항식으로 옮기세요:"
                    + " repeatCountExpr=\"{USE} == 'Y' ? COUNT({X}) : 0\"");
        }

        boolean isRepeating = !countExpr.isEmpty();

        int count = resolveRepeatCount(node, countExpr);
        if (isRoot) {
            count = 1;
            isRepeating = false;
        }

        /*
         * 3. count 만큼 엘리먼트 생성.
         * 인덱스 스택은 반복 설정이 있는 노드만 사용한다.
         * 모든 노드가 push 하면 자식 노드의 인덱스(항상 1)가
         * 조상 반복 노드의 회차를 가려서 {INDEX} 가 늘 1이 되기 때문이다.
         */
        for (int i = 1; i <= count; i++) {
            if (isRepeating) {
                repeatFrames.add(new RepeatFrame(node, i));
            }
            try {
                Element el = createElement(doc, node);
                if (node.hasChildren()) {
                    for (TemplateNode child : node.getChildren()) {
                        for (Element childEl : buildElements(doc, child, false)) {
                            el.appendChild(childEl);
                        }
                    }
                } else {
                    String value = resolveNodeValue(node);
                    validateDataType(node, value);
                    if (!value.isEmpty()) {
                        el.appendChild(doc.createTextNode(value));
                    }
                }
                result.add(el);
            } finally {
                if (isRepeating) {
                    repeatFrames.remove(repeatFrames.size() - 1);
                }
            }
        }
        return result;
    }

    /**
     * 오류 메시지용 경로 — 반복 조상에 현재 회차를 붙인다 (§10).
     * 예: {@code catalog.book[2].price}
     */
    private String describePath(TemplateNode node) {
        List<TemplateNode> chain = new ArrayList<TemplateNode>();
        for (TemplateNode current = node; current != null; current = current.getParent()) {
            chain.add(0, current);
        }
        StringBuilder sb = new StringBuilder();
        for (TemplateNode current : chain) {
            if (sb.length() > 0) {
                sb.append('.');
            }
            sb.append(current.getName());
            for (RepeatFrame frame : repeatFrames) {
                if (frame.node == current) {
                    sb.append('[').append(frame.index).append(']');
                    break;
                }
            }
        }
        return sb.toString();
    }

    private Element createElement(Document doc, TemplateNode node) {
        elementCount++;
        if (elementCount > MAX_TOTAL_ELEMENTS) {
            throw new GenerationException("생성 엘리먼트 수가 상한(" + MAX_TOTAL_ELEMENTS
                    + ")을 넘었습니다. (노드: " + describePath(node) + ")");
        }
        String name = trim(node.getName());
        if (name.isEmpty()) {
            throw new GenerationException("이름이 비어 있는 노드가 있습니다. (경로: " + node.getPath() + ")");
        }
        /*
         * ':' 은 XML 네임스페이스 접두사로 해석된다. 네임스페이스 미선언 상태에서는
         * 환경(Java DOM / C# XmlDocument)에 따라 동작이 갈리므로 명시적으로 거부한다.
         */
        if (name.indexOf(':') >= 0) {
            throw new GenerationException(
                    "노드 이름에 ':' 은 사용할 수 없습니다: '" + name + "' (경로: " + node.getPath() + ")");
        }
        try {
            return doc.createElement(name);
        } catch (org.w3c.dom.DOMException e) {
            throw new GenerationException(
                    "'" + name + "' 은(는) XML 엘리먼트 이름으로 사용할 수 없습니다. (경로: " + node.getPath() + ")");
        }
    }

    /**
     * 반복 횟수를 정한다 — 임의의 식을 평가해 그 <b>값</b>을 횟수로 쓴다
     * (고정 숫자 | {PARAM} | 함수·삼항식). 개수는 {@code COUNT({X})} 로 명시한다.
     * 0 이면 미생성, 음수·소수·비숫자는 생성 오류다 (§9.1).
     */
    private int resolveRepeatCount(TemplateNode node, String countExpr) {
        if (countExpr.isEmpty()) {
            return 1;
        }
        Object result;
        try {
            result = evaluator.evaluate(countExpr);
        } catch (ExpressionException e) {
            throw new GenerationException("노드 '" + describePath(node)
                    + "' 의 반복 횟수 식 오류: " + e.getMessage());
        }
        String text = String.valueOf(result).trim();
        int count = parseDigits(text);
        if (count < 0) {
            throw new GenerationException("노드 '" + describePath(node)
                    + "' 의 반복 횟수가 0 이상의 정수가 아닙니다: '" + text + "' (식: " + countExpr + ")");
        }
        if (count > MAX_REPEAT_PER_NODE) {
            throw new GenerationException("노드 '" + describePath(node) + "' 의 반복 횟수 "
                    + count + " 가 상한(" + MAX_REPEAT_PER_NODE + ")을 넘습니다.");
        }
        return count;
    }

    /** 값의 데이터 타입이 NUMBER 인 노드는 비어 있지 않은 최종 값이 숫자여야 한다. */
    private void validateDataType(TemplateNode node, String value) {
        if (node.getValueDataType() == ValueDataType.NUMBER
                && !value.isEmpty() && !isNumeric(value)) {
            throw new GenerationException(
                    "노드 '" + describePath(node) + "' 의 값이 숫자가 아닙니다: '" + value
                            + "' (입력 데이터 타입: NUMBER)");
        }
    }

    private static boolean isNumeric(String s) {
        String t = s.trim();
        if (t.isEmpty()) {
            return false;
        }
        int start = (t.charAt(0) == '+' || t.charAt(0) == '-') ? 1 : 0;
        boolean digit = false;
        boolean dot = false;
        for (int i = start; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c >= '0' && c <= '9') {
                digit = true;
            } else if (c == '.' && !dot) {
                dot = true;
            } else {
                return false;
            }
        }
        return digit;
    }

    private boolean evaluateCondition(TemplateNode node, String kind, String condition) {
        try {
            return evaluator.evaluateCondition(condition);
        } catch (ExpressionException e) {
            throw new GenerationException(
                    "노드 '" + node.getPath() + "' 의 " + kind + " 오류: " + e.getMessage());
        }
    }

    /* ------------------------------------------------------------------ */
    /* 값 계산                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * 노드의 값을 계산한다. 조건식에서 노드 경로 피연산자를 만나도 이 메서드를 사용한다.
     * 순환 참조가 감지되면 빈 문자열을 반환한다.
     */
    private String resolveNodeValue(TemplateNode node) {
        if (!resolving.add(node)) {
            return "";
        }
        try {
            String raw = node.getValue();
            if (raw == null) {
                return "";
            }
            switch (node.getValueType()) {
                case VARIABLE:
                    return substituteVariables(raw);
                case FUNCTION: {
                    String expr = trim(raw);
                    if (expr.isEmpty()) {
                        return "";
                    }
                    Object result = evaluator.evaluate(expr);
                    return String.valueOf(result);
                }
                case FIXED:
                default:
                    /* FIXED 도 리터럴 중괄호 이스케이프는 해제한다 (§3.1 - 유형 기준). */
                    return unescapeFixed(raw);
            }
        } catch (ExpressionException e) {
            throw new GenerationException(
                    "노드 '" + node.getPath() + "' 의 값(함수) 오류: " + e.getMessage());
        } finally {
            resolving.remove(node);
        }
    }

    /**
     * 문자열 안의 {@code {변수명}} 을 외부 데이터 값으로 치환한다 (§3.1).
     * 리터럴 중괄호 이스케이프({@code {{}) 해제와 같은 패스에서 처리된다.
     */
    private String substituteVariables(String text) {
        return VariableText.substitute(text, this::lookupVariable);
    }

    /** FIXED 값의 리터럴 중괄호 이스케이프 해제 (§3.1). */
    private String unescapeFixed(String raw) {
        return VariableText.unescapeBraces(raw);
    }

    /* ------------------------------------------------------------------ */
    /* 함수 (명세 §6)                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * COUNT / SUM / EXISTS. 인자는 평가되지 않은 AST 로 들어온다(특수형식).
     *
     * 인덱스 표기 {@code [Nk]} 치환은 다중 depth 반복 의미론(4단계)에 속한다.
     * 지금 조용히 무시하면 {@code COUNT({X_[N1]})} 이 존재하지 않는 접두사
     * "X_[N1]" 을 세어 늘 0 을 돌려주므로, 명확한 오류로 거부한다.
     */
    private String evaluateFunction(String name, Expr argument) {
        if ("EXISTS".equals(name) && argument instanceof NodePathExpr) {
            String path = ((NodePathExpr) argument).getPath();
            TemplateNode node = findNode(path);
            return String.valueOf(node != null && isNodeDisplayed(node));
        }
        if (!(argument instanceof VarExpr)) {
            throw new GenerationException(name + " 의 인자는 {변수} 형식이어야 합니다: " + argument);
        }
        VarExpr variable = (VarExpr) argument;
        /* 명세 §6.1-1: 인자의 [Nk] 를 현재 회차로 치환한 뒤 접두사로 쓴다. */
        String prefix = substituteIndexRefs(variable.getName());

        if ("EXISTS".equals(name)) {
            return String.valueOf(data.containsKey(prefix));
        }
        if ("COUNT".equals(name)) {
            return String.valueOf(countConsecutive(prefix));
        }
        if ("SUM".equals(name)) {
            return sumConsecutive(prefix);
        }
        throw new GenerationException("지원하지 않는 함수입니다: " + name);
    }

    /**
     * 접두사 P 에 대해 {@code P_1, P_2, ...} 가 <b>1부터 연속으로</b> 존재하는 개수 (§6.1).
     * 키가 있으면 값이 비어 있어도 센다.
     *
     * 불연속 지점 뒤에 키가 더 있으면 경고를 남긴다 — 대표 필드를 잘못 골라
     * 데이터가 잘리는 상황이 조용히 넘어가지 않게 하기 위함이다.
     */
    private int countConsecutive(String prefix) {
        int n = 0;
        while (data.containsKey(prefix + "_" + (n + 1))) {
            n++;
            if (n > MAX_SCAN) {
                throw new GenerationException("COUNT(" + prefix + ") 스캔이 상한 "
                        + MAX_SCAN + " 을 초과했습니다.");
            }
        }
        warnOnGap(prefix, n);
        return n;
    }

    /**
     * 연속 구간 뒤에 키가 더 있으면 (데이터 유실) 경고.
     *
     * 데이터 키 전체를 훑어 접두사가 맞는 것만 본다. 고정 폭 탐침으로 하면
     * 간격이 그보다 넓은 경우(X_1, X_50)를 놓친다.
     */
    private void warnOnGap(String prefix, int consecutive) {
        String head = prefix + "_";
        for (String key : data.keySet()) {
            if (!key.startsWith(head)) {
                continue;
            }
            String suffix = key.substring(head.length());
            int index = parseIndexSuffix(suffix);
            if (index > consecutive) {
                addWarning(WARN_COUNT_GAP, "'" + prefix + "_" + (consecutive + 1)
                        + "' 이(가) 없어 " + consecutive + "건까지만 셌지만 '" + key
                        + "' 이(가) 존재합니다 (데이터가 잘렸을 수 있습니다).");
                return;
            }
        }
    }

    /** 접미사가 순수 숫자면 그 값, 아니면 -1 (다른 필드의 키는 무시). */
    private static int parseIndexSuffix(String suffix) {
        if (suffix.isEmpty() || suffix.length() > 9) {
            return -1;
        }
        for (int i = 0; i < suffix.length(); i++) {
            if (!Character.isDigit(suffix.charAt(i))) {
                return -1;
            }
        }
        return Integer.parseInt(suffix);
    }

    /**
     * COUNT 와 같은 수집 규칙으로 모은 값을 합산한다 (§6.2).
     *
     * BigDecimal 로 누적한다 — 이진 부동소수점이면 0.1 + 0.2 가 0.30000000000000004 가 된다.
     * BigDecimal.add 는 피연산자의 최대 소수 자릿수를 유지하므로 1.50 + 2.5 = 4.00 이 된다.
     * 빈 값은 건너뛴다 (dataType=NUMBER 가 빈 값을 허용하는 정책과 일관) — 다만 경고를 남긴다.
     * 따라서 <b>SUM 의 유효 원소 수는 COUNT 와 다를 수 있다</b> (평균 계산 시 주의).
     */
    private String sumConsecutive(String prefix) {
        int count = countConsecutive(prefix);
        BigDecimal total = BigDecimal.ZERO;
        int skipped = 0;
        for (int i = 1; i <= count; i++) {
            String key = prefix + "_" + i;
            String raw = data.get(key);
            String value = (raw == null) ? "" : raw.trim();
            if (value.isEmpty()) {
                skipped++;
                continue;
            }
            try {
                total = total.add(new BigDecimal(value));
            } catch (NumberFormatException e) {
                throw new GenerationException("SUM(" + prefix + ") 에 숫자가 아닌 값이 있습니다: '"
                        + raw + "' (키: " + key + ")");
            }
        }
        if (skipped > 0) {
            addWarning(WARN_SUM_EMPTY_SKIPPED, "SUM(" + prefix + ") 에서 빈 값 "
                    + skipped + "건을 건너뛰었습니다 (유효 원소 수가 COUNT 와 다릅니다).");
        }
        return total.toPlainString();
    }

    /* ------------------------------------------------------------------ */
    /* 노드 경로 참조 (명세 §8)                                              */
    /* ------------------------------------------------------------------ */

    /**
     * 노드 경로 피연산자의 값.
     *
     * <b>참조 노드나 그 조상이 표시 조건으로 제외되었으면 NULL(빈 문자열)</b>이다(§8).
     * 이 규칙이 정본 예시 1 의 publish_date 를 성립시킨다 — price 가 표시 제외되면
     * publish_date 의 {@code catalog.book.price != NULL} 이 거짓이 되어야 하는데,
     * 값만 다시 계산하면 삼항의 거짓 분기 값('저')이 나와 조건이 참이 되어 버린다.
     */
    private String resolvePathValue(String path) {
        TemplateNode node = findNode(path);
        if (node == null) {
            return "";
        }
        if (!isNodeDisplayed(node)) {
            return "";
        }
        return resolveNodeValue(node);
    }

    /**
     * 현재 반복 인스턴스 기준으로 이 노드가 출력되는지 (조상 표시 조건 포함).
     *
     * 표시 조건 평가가 다시 경로 참조를 부를 수 있으므로 순환 감지가 필요하다.
     * 순환이면 "표시되지 않음"으로 보고 무한 재귀를 끊는다.
     */
    private boolean isNodeDisplayed(TemplateNode node) {
        List<TemplateNode> chain = new ArrayList<TemplateNode>();
        for (TemplateNode current = node; current != null; current = current.getParent()) {
            chain.add(current);
        }
        for (int i = chain.size() - 1; i >= 0; i--) {
            TemplateNode current = chain.get(i);
            String condition = trim(current.getDisplayCondition());
            if (condition.isEmpty()) {
                continue;
            }
            if (!displayChecking.add(current)) {
                return false;
            }
            try {
                if (!evaluator.evaluateCondition(condition)) {
                    return false;
                }
            } catch (ExpressionException e) {
                throw new GenerationException("노드 '" + current.getPath()
                        + "' 의 표시 조건 오류: " + e.getMessage());
            } finally {
                displayChecking.remove(current);
            }
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* 변수 해석 (명세 §5.2)                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * {@code [Nk]} 를 회차로 치환한 뒤 <b>그 키만</b> 조회한다.
     * 암묵 폴백({X} -> X_회차 자동 탐색)은 없다(§5.2-3) — 인덱스는 표기로 명시한다.
     */
    private String lookupVariable(String name) {
        String resolved = substituteIndexRefs(name);
        String builtin = builtinIndexValue(resolved);
        if (builtin != null) {
            return builtin;
        }
        String value = data.get(resolved);
        if (value != null) {
            return value;
        }
        addWarning(WARN_MISSING_VARIABLE,
                "외부 데이터에 '" + resolved + "' 이(가) 없어 빈 값으로 처리했습니다."
                        + (resolved.equals(name) ? "" : " (원본 표기: " + name + ")"));
        return "";
    }

    /**
     * 내장 인덱스 변수 {@code {INDEX}} / {@code {INDEXk}}. 해당 없으면 null.
     * 내장 이름은 동명의 외부 데이터 키보다 우선한다 (§4).
     */
    private String builtinIndexValue(String name) {
        if (!name.startsWith(INDEX_VARIABLE)) {
            return null;
        }
        String suffix = name.substring(INDEX_VARIABLE.length());
        if (suffix.isEmpty()) {
            /* §5.2-4: {INDEX} 는 반복 조상이 정확히 1개일 때만. */
            if (repeatFrames.isEmpty()) {
                return "";
            }
            if (repeatFrames.size() > 1) {
                throw new GenerationException("{INDEX} 는 반복 조상이 정확히 1개일 때만 쓸 수 있습니다"
                        + " (현재 " + repeatFrames.size() + "개). {INDEX1} 처럼 레벨을 명시하세요.");
            }
            return String.valueOf(repeatFrames.get(0).index);
        }
        int level = parseDigits(suffix);
        if (level < 1) {
            return null;
        }
        if (level > repeatFrames.size()) {
            throw new GenerationException("{" + name + "} 이 반복 스코프 깊이("
                    + repeatFrames.size() + ")를 넘습니다.");
        }
        return String.valueOf(repeatFrames.get(level - 1).index);
    }

    /**
     * 변수명 안의 {@code _[Nk]} 를 현재 회차로 치환한다 (명세 §5.2-1).
     *
     * <b>경계는 파서({@code ExpressionEvaluator.buildVariable})와 동일한 {@code _[N} 3글자</b>다.
     * 예전에는 여기만 {@code [N} 2글자를 봐서 {@code {A[N1]}} 이 파서에겐 평범한 이름인데
     * 치환기에겐 인덱스로 보여 조용히 {@code A1} 을 조회했다. 규칙이 갈리면
     * "검증은 통과하고 생성에서 실패"하는 §11 위반이 생긴다.
     * 이제 대괄호가 남아 있는 변수명은 저장 시 거부되고(TemplateValidator), 혹시 새어
     * 들어와도 여기서는 <b>리터럴</b>로 취급되어 조회 실패(경고)로 드러난다.
     *
     * {@code [N]} 축약형은 레벨 1 이다 (체인 길이 1 제약은 저장 시 검증한다).
     */
    private String substituteIndexRefs(String name) {
        if (name.indexOf("_[N") < 0) {
            return name;
        }
        StringBuilder sb = new StringBuilder(name.length());
        int i = 0;
        while (i < name.length()) {
            if (startsWithIndexRef(name, i)) {
                int close = name.indexOf(']', i + 3);
                if (close >= 0) {
                    String levelText = name.substring(i + 3, close);
                    int level = levelText.isEmpty() ? 1 : parseDigits(levelText);
                    if (level >= 1) {
                        if (level > repeatFrames.size()) {
                            throw new GenerationException("{" + name + "} 의 [N"
                                    + levelText + "] 이 반복 스코프 깊이("
                                    + repeatFrames.size() + ")를 넘습니다.");
                        }
                        sb.append('_').append(repeatFrames.get(level - 1).index);
                        i = close + 1;
                        continue;
                    }
                }
            }
            sb.append(name.charAt(i));
            i++;
        }
        return sb.toString();
    }

    /** 위치 i 에서 {@code _[N} 이 시작하는지 (파서와 같은 판정). */
    private static boolean startsWithIndexRef(String name, int i) {
        return i + 2 < name.length()
                && name.charAt(i) == '_' && name.charAt(i + 1) == '[' && name.charAt(i + 2) == 'N';
    }

    /** 순수 숫자면 그 값, 아니면 -1. */
    private static int parseDigits(String text) {
        if (text.isEmpty() || text.length() > 9) {
            return -1;
        }
        for (int i = 0; i < text.length(); i++) {
            if (!Character.isDigit(text.charAt(i))) {
                return -1;
            }
        }
        return Integer.parseInt(text);
    }

    /* ------------------------------------------------------------------ */
    /* 노드 경로 탐색                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * 전체 경로(예: "node1-1.node1-1-1")로 노드를 찾는다.
     * 루트 이름을 포함한 경로("ROOT.node1-1...")와
     * 루트 바로 아래부터 시작하는 경로("node1-1...") 둘 다 허용한다.
     */
    private TemplateNode findNode(String path) {
        if (path == null || path.trim().isEmpty()) {
            return null;
        }
        String[] segments = path.trim().split("\\.");

        TemplateNode found = matchFrom(root, segments, 0);
        if (found != null) {
            return found;
        }
        for (TemplateNode child : root.getChildren()) {
            found = matchFrom(child, segments, 0);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    private TemplateNode matchFrom(TemplateNode node, String[] segments, int index) {
        if (!node.getName().equals(segments[index])) {
            return null;
        }
        if (index == segments.length - 1) {
            return node;
        }
        for (TemplateNode child : node.getChildren()) {
            TemplateNode found = matchFrom(child, segments, index + 1);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* 직렬화                                                               */
    /* ------------------------------------------------------------------ */

    /** 명세 §10 출력 규칙 — XML 선언 없이 들여쓰기 직렬화. */
    private static String serialize(Document doc) throws Exception {
        Transformer transformer = SecureXml.newIndentingTransformer();
        transformer.setOutputProperty(
                javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "yes");

        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        return writer.toString();
    }

    private static String trim(String s) {
        return (s == null) ? "" : s.trim();
    }
}
