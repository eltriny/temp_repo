package com.xmltemplate.util.template;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.XmlTemplateNode;
import com.xmltemplate.exception.RepositoryException;

/**
 * 영속 엔티티 ↔ 도메인 트리 변환의 <b>유일한 장소</b>.
 *
 * {@link TemplateMapper}(전송 DTO ↔ 도메인)와 대칭이다. 두 변환을 한 클래스에 섞지 않는 이유는
 * 방향이 다르기 때문이다 — 이쪽은 <b>행 목록 ↔ 트리</b>, 저쪽은 <b>중첩 JSON ↔ 트리</b> 다.
 *
 * <h3>왜 저장소에서 꺼냈나 (R3)</h3>
 * 이전에는 {@code TemplateStore} 안의 private 메서드였다. 그러면 변환 규칙(특히 null → "" 정규화와
 * 부모 참조 조립)을 <b>저장소를 띄우지 않고는 단위 테스트할 수 없다</b>. 트리 조립은 이 시스템에서
 * 조용히 틀리기 가장 쉬운 로직이라(부모 순서·고아 참조·루트 중복) 독립적으로 검증 가능해야 한다.
 *
 * <h3>패키지 경계</h3>
 * {@code util} 은 Spring/Jackson/JPA 를 import 할 수 없다({@code PackageBoundaryTest}). 이 클래스는
 * <b>엔티티 클래스만</b> 참조하고 JPA API 는 건드리지 않으므로 경계를 지킨다 — 엔티티는
 * {@code entity} 패키지의 평범한 타입이고, 의존 방향도 기존({@code dto → entity})과 같다.
 *
 * <h3>왜 "트리 → 행 목록" 이 없는가</h3>
 * 트리 전체를 행 목록으로 바꾸는 순수 함수를 두지 <b>않았다</b>. 자식의 {@code PARENT_SN} 은
 * 부모의 <b>생성된 키</b>인데, 그 키는 영속성 컨텍스트가 발급한다 — 순수 함수가 알 수 없는 값이다.
 * 그래서 이 클래스는 <b>노드 하나</b>를 만드는 {@link #toEntity} 만 제공하고, DFS 재귀와 키
 * 전달은 {@code TemplateStore}(persist 를 쥔 쪽)가 맡는다. 억지로 여기서 트리를 다루려면
 * 변환기가 {@code EntityManager} 를 알아야 하고, 그 순간 위의 패키지 경계가 무너진다.
 *
 * <h3>정렬 전제</h3>
 * {@link #toDomainTree} 는 입력 행이 <b>DFS 전위 순서</b>(= {@code ORDER BY NODE_SN})로 정렬돼
 * 있다고 가정한다. 그래야 부모가 자식보다 먼저 나와 O(n) 단일 패스로 끝난다. 정렬이 어긋나면
 * "존재하지 않는 부모 참조" 오류로 <b>드러난다</b> — 조용히 잘못 조립되지 않는다.
 */
public final class TemplateEntityMapper {

    private TemplateEntityMapper() {
    }

    /* ------------------------------------------------------------------ */
    /* 엔티티 -> 도메인                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * 행 하나 → 도메인 노드 (자식 연결 없음).
     *
     * <b>반드시 setter 를 거친다.</b> 생성자만으로 필드를 채우면 {@code null → ""} 정규화가
     * 통째로 빠져 "응답에 null 을 넣지 않는다"는 계약이 깨지고, {@code non_null} 정책 때문에
     * 그 필드가 응답에서 <b>아예 사라진다</b>.
     */
    public static TemplateNode toDomain(XmlTemplateNode row) {
        TemplateNode node = new TemplateNode(text(row.getNodeName()));
        node.setValueType(row.getInputType());
        node.setValue(text(row.getInputValue()));
        node.setValueDataType(row.getInputDataType());
        node.setDisplayCondition(text(row.getDisplayCond()));
        node.setRepeatCondition(text(row.getRepeatCond()));
        node.setRepeatCountExpr(text(row.getRepeatCountCond()));
        return node;
    }

    /**
     * 정렬된 노드 행 목록을 트리로 조립한다. 행이 없으면 null.
     *
     * @param rows  {@code ORDER BY NODE_SN} 으로 정렬된 한 템플릿의 전체 노드
     * @param label 오류 메시지에 쓸 템플릿 식별 문구 (이름 등)
     * @throws RepositoryException 루트가 없거나 2개 이상이거나 부모 참조가 깨졌을 때
     */
    public static TemplateNode toDomainTree(List<XmlTemplateNode> rows, String label) {
        if (rows == null || rows.isEmpty()) {
            return null;
        }
        Map<Long, TemplateNode> bySn = new HashMap<Long, TemplateNode>();
        TemplateNode root = null;

        for (XmlTemplateNode row : rows) {
            TemplateNode node = toDomain(row);
            bySn.put(row.getNodeSn(), node);

            if (row.getParentSn() == null) {
                if (root != null) {
                    throw new RepositoryException(
                            "템플릿 '" + label + "' 에 루트 노드가 2개 이상 있습니다.");
                }
                root = node;
            } else {
                TemplateNode parent = bySn.get(row.getParentSn());
                if (parent == null) {
                    throw new RepositoryException("템플릿 '" + label + "' 의 노드 "
                            + row.getNodeSn() + " 이(가) 존재하지 않는 부모 " + row.getParentSn()
                            + " 을(를) 참조합니다.");
                }
                parent.addChild(node);
            }
        }
        if (root == null) {
            throw new RepositoryException(
                    "템플릿 '" + label + "' 에 루트 노드가 없습니다 (모든 노드가 부모를 참조).");
        }
        return root;
    }

    /* ------------------------------------------------------------------ */
    /* 도메인 -> 엔티티                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * 도메인 노드 하나 → 새 행. 자식은 다루지 않는다 (위 "왜 트리 → 행 목록이 없는가" 참조).
     *
     * @param templateId 소속 템플릿의 대리키
     * @param parentSn   부모의 {@code NODE_SN}. 루트면 null
     */
    public static XmlTemplateNode toEntity(TemplateNode node, Long templateId, Long parentSn) {
        return new XmlTemplateNode(templateId, node.getName(), parentSn,
                node.getValueType(), node.getValue(), node.getValueDataType(),
                node.getDisplayCondition(), node.getRepeatCondition(), node.getRepeatCountExpr());
    }

    private static String text(String s) {
        return (s == null) ? "" : s;
    }
}
