package com.xmltemplate.util.template;

import com.xmltemplate.entity.ValueType;

/** 값 유형 추론의 결과 한 건 — {@link StructureTemplateParser} 내부 전달용. */
final class ValueInference {

    final ValueType type;
    final String value;

    ValueInference(ValueType type, String value) {
        this.type = type;
        this.value = value;
    }
}
