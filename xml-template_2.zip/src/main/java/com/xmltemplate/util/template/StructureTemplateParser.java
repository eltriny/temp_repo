package com.xmltemplate.util.template;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.xmltemplate.util.expression.Expr;
import com.xmltemplate.util.expression.ExpressionEvaluator;
import com.xmltemplate.util.xml.SecureXml;
import com.xmltemplate.util.expression.TernaryExpr;
import com.xmltemplate.util.expression.VarExpr;
import com.xmltemplate.util.expression.VariableText;
import com.xmltemplate.dto.StructureImportResult;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.ValidationErrorDto;
import com.xmltemplate.dto.WarningDto;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.exception.ExpressionException;
import com.xmltemplate.exception.ImportException;

/**
 * 구조 XML(생성하려는 XML 그 자체) -> 템플릿 트리 변환 (명세 §3).
 *
 * <b>업로드한 XML 의 구조가 곧 템플릿</b>이다. 제어 정보는 예약 속성
 * (displayCondition / repeatCountExpr / valueType / dataType)으로 표기한다.
 * <b>그 밖의 일반 속성은 R2 에서 폐지되어 버려진다</b> — 다만 무엇을 버렸는지
 * {@code GENERAL_ATTR_IGNORED} 경고로 알린다.
 *
 * 변환만 하고 저장하지 않는다 — 사용자가 추론 결과를 확인·교정한 뒤 기존
 * {@code PUT /api/templates/{name}} 으로 저장하는 흐름이다(명세 §12.2).
 *
 * <b>설계 원칙: 조용한 소실 금지.</b> 표현할 수 없는 입력은 오류로 거부하고,
 * 자동으로 결정한 것은 전부 경고로 알린다. 사용자가 "올린 대로 저장됐다"고
 * 오해하는 상황을 만들지 않는 것이 이 파서의 가장 중요한 계약이다.
 */
public final class StructureTemplateParser {

    /* 예약 속성 이름 (명세 §2) */
    public static final String ATTR_DISPLAY_CONDITION = "displayCondition";
    public static final String ATTR_REPEAT_COUNT_EXPR = "repeatCountExpr";
    public static final String ATTR_VALUE_TYPE = "valueType";
    public static final String ATTR_DATA_TYPE = "dataType";
    /** v2 에서 폐지 — 남아 있으면 오류. */
    public static final String ATTR_REPEAT_CONDITION = "repeatCondition";

    private static final Set<String> RESERVED_ATTRIBUTES = Collections.unmodifiableSet(
            new HashSet<String>(Arrays.asList(
                    ATTR_DISPLAY_CONDITION, ATTR_REPEAT_COUNT_EXPR,
                    ATTR_VALUE_TYPE, ATTR_DATA_TYPE, ATTR_REPEAT_CONDITION)));

    /* 경고 코드 */
    public static final String WARN_TYPE_INFERRED = "TYPE_INFERRED";
    public static final String WARN_TYPE_DEMOTED = "TYPE_DEMOTED";
    public static final String WARN_RESERVED_ATTR_CONSUMED = "RESERVED_ATTR_CONSUMED";
    /** 일반 XML 속성은 R2 에서 폐지 — 버리되 버렸다는 사실을 알린다. */
    public static final String WARN_GENERAL_ATTR_IGNORED = "GENERAL_ATTR_IGNORED";
    public static final String WARN_COMMENT_IGNORED = "COMMENT_IGNORED";
    public static final String WARN_PI_IGNORED = "PI_IGNORED";

    private StructureTemplateParser() {
    }

    /* ------------------------------------------------------------------ */
    /* 진입점                                                               */
    /* ------------------------------------------------------------------ */

    /**
     * 바이트 스트림에서 구조 XML 을 템플릿 트리로 변환한다.
     *
     * <b>바이트를 미리 문자열로 디코딩하지 않는 것이 요점이다.</b> 미리 UTF-8 로 디코딩해
     * 넘기면 {@code <?xml version="1.0" encoding="EUC-KR"?>} 로 선언된 파일이 파서가 선언을
     * 보기도 전에 깨진다. 스트림을 그대로 넘기면 XML 파서가 선언을 읽고 스스로 디코딩한다.
     *
     * {@code encoding} 이 있으면 <b>문서 내부 선언보다 우선</b>한다 (RFC 7303, 계약 §4.4) —
     * 전송 계층이 charset 을 명시한 경우(붙여넣기 경로)가 여기 해당한다. null 이면 선언을
     * 따른다(파일 업로드 경로).
     *
     * @throws ImportException 표현 불가 구조, 예약 속성 위반, 상한 초과
     * @throws com.xmltemplate.exception.XmlSecurityException XXE / 문법 오류 / 본문 상한 초과
     */
    public static StructureImportResult parse(java.io.InputStream structureXml, String encoding) {
        if (structureXml == null) {
            throw new ImportException("업로드할 XML 이 비어 있습니다.");
        }
        return parseDocument(SecureXml.parse(structureXml, encoding));
    }

    private static StructureImportResult parseDocument(Document doc) {
        Element rootEl = doc.getDocumentElement();
        if (rootEl == null) {
            throw new ImportException("XML 에 루트 엘리먼트가 없습니다.");
        }

        List<WarningDto> warnings = new ArrayList<WarningDto>();
        List<TemplateNode> inferredFunctions = new ArrayList<TemplateNode>();
        TemplateNode root = convert(rootEl, null, 1, new int[] { 0 }, warnings, inferredFunctions);

        /*
         * 명세 §9.1: 루트는 항상 정확히 1회 생성된다. 루트에 표시 조건이나 반복을
         * 걸면 "문서가 성립하지 않는 상태"가 되므로 런타임이 아니라 여기서 막는다.
         */
        if (!root.getDisplayCondition().isEmpty()) {
            throw new ImportException("루트 노드 '" + root.getName()
                    + "' 에는 displayCondition 을 지정할 수 없습니다. (루트는 항상 1회 생성)");
        }
        if (!root.getRepeatCountExpr().isEmpty()) {
            throw new ImportException("루트 노드 '" + root.getName()
                    + "' 에는 repeatCountExpr 을 지정할 수 없습니다. (루트는 항상 1회 생성)");
        }
        demoteInvalidInferredFunctions(root, inferredFunctions, warnings);
        return new StructureImportResult(root, warnings, collectVariables(root),
                doc.getXmlEncoding());
    }

    /**
     * 정적 검증에 걸린 <b>추론</b> FUNCTION 값을 FIXED 로 강등한다 (명세 §3.1).
     *
     * {@code 초급 ? 중급 : 고급} 처럼 평범한 텍스트가 우연히 삼항으로 파싱되는 경우,
     * 그 안의 "노드 경로"(실은 그냥 단어)가 존재하지 않는다고 저장을 막으면 안 된다.
     * 반대로 {@code valueType} 을 <b>명시</b>한 경우에는 사용자의 의도가 분명하므로
     * 강등하지 않고 검증 오류로 남긴다.
     */
    private static void demoteInvalidInferredFunctions(TemplateNode root,
            List<TemplateNode> inferredFunctions, List<WarningDto> warnings) {
        if (inferredFunctions.isEmpty()) {
            return;
        }
        for (TemplateNode node : inferredFunctions) {
            List<ValidationErrorDto> errors = TemplateValidator.validate(root);
            String reason = firstErrorForValue(errors, node);
            if (reason == null) {
                continue;
            }
            node.setValueType(ValueType.FIXED);
            /* 저장값은 항상 원문 — 이스케이프 해제는 생성 시점의 몫이다 (§3.1). */
            warnings.add(new WarningDto(WARN_TYPE_DEMOTED, node.getPath(),
                    "삼항식으로 추론했지만 검증에 실패해 고정값(FIXED)으로 처리했습니다: " + reason));
        }
    }

    private static String firstErrorForValue(List<ValidationErrorDto> errors, TemplateNode node) {
        for (ValidationErrorDto error : errors) {
            if ("값".equals(error.where) && node.getPath().equals(error.nodePath)) {
                return error.message;
            }
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* 참조 변수 수집 (명세 §12.2)                                           */
    /* ------------------------------------------------------------------ */

    /**
     * 템플릿이 참조하는 외부 데이터 변수 이름을 등장 순으로 모은다 (중복 제거).
     *
     * <b>왜 필요한가</b>: 단축 평가 때문에 논리 연산 오른쪽의 오타 변수는 데이터에
     * 따라 아예 평가되지 않아 경고조차 나오지 않을 수 있다(명세 §4 는 경고 수집을
     * 위해 단축 평가를 우회하는 구현을 금지한다). 그래서 "평가해 보고 알려주는" 대신
     * <b>정적으로 뽑은 변수 목록</b>을 주어 사용자가 자기 데이터 키와 대조하게 한다.
     *
     * 수집 순서: DFS 전위, 노드마다 displayCondition -> repeatCountExpr -> 값.
     * 이름은 중괄호 안 <b>원문 그대로</b>(인덱스 표기 포함)를 쓴다. 사용자가 템플릿에
     * 쓴 표기와 그대로 대조할 수 있어야 하기 때문이다.
     * 노드 경로는 외부 데이터가 아니므로 제외한다. COUNT/SUM 의 인자는 포함한다.
     */
    public static List<String> collectVariables(TemplateNode root) {
        Set<String> collected = new LinkedHashSet<String>();
        collectVariables(root, collected);
        return new ArrayList<String>(collected);
    }

    private static void collectVariables(TemplateNode node, Set<String> out) {
        collectFromExpression(node.getDisplayCondition(), out);
        collectFromExpression(node.getRepeatCountExpr(), out);
        collectFromValue(node.getValueType(), node.getValue(), out);
        for (TemplateNode child : node.getChildren()) {
            collectVariables(child, out);
        }
    }

    private static void collectFromValue(ValueType type, String value, Set<String> out) {
        if (value == null || value.isEmpty()) {
            return;
        }
        switch (type) {
            case VARIABLE:
                /* 텍스트와 변수가 섞인 형태라 식으로 파싱되지 않는다. 스캐너로 뽑는다. */
                collectFromVariableText(value, out);
                break;
            case FUNCTION:
                collectFromExpression(value, out);
                break;
            case FIXED:
            default:
                break;
        }
    }

    private static void collectFromExpression(String expression, Set<String> out) {
        if (expression == null || expression.trim().isEmpty()) {
            return;
        }
        try {
            for (Expr node : ExpressionEvaluator.parse(expression).flatten()) {
                if (node instanceof VarExpr) {
                    out.add(((VarExpr) node).getName());
                }
            }
        } catch (ExpressionException e) {
            /*
             * 여기 오는 식은 이미 저장 단계에서 거부되었거나 FIXED 로 강등된 것들이다.
             * 변수 목록 수집이 실패해서 임포트 전체를 막을 이유는 없다.
             */
        }
    }

    /**
     * VARIABLE 값에서 변수 이름을 뽑는다.
     *
     * 정규식이 아니라 치환과 <b>같은 스캐너</b>를 쓴다. 갈라져 있으면 치환에서는
     * 리터럴로 본 {@code {{LIT}}} 가 변수 목록에는 올라와, 사용자가 있지도 않은
     * 데이터 키를 찾게 된다.
     */
    private static void collectFromVariableText(String text, Set<String> out) {
        VariableText.collectNames(text, out);
    }

    /* ------------------------------------------------------------------ */
    /* 엘리먼트 -> 노드                                                      */
    /* ------------------------------------------------------------------ */

    private static TemplateNode convert(Element el, String parentPath, int depth,
            int[] nodeCount, List<WarningDto> warnings, List<TemplateNode> inferredFunctions) {
        if (depth > SecureXml.MAX_TREE_DEPTH) {
            throw new ImportException("XML 트리 깊이가 상한을 초과했습니다 (최대 "
                    + SecureXml.MAX_TREE_DEPTH + ").");
        }
        nodeCount[0]++;
        if (nodeCount[0] > SecureXml.MAX_TEMPLATE_NODES) {
            throw new ImportException("노드 수가 상한을 초과했습니다 (최대 "
                    + SecureXml.MAX_TEMPLATE_NODES + ").");
        }

        String tagName = el.getTagName();
        String path = (parentPath == null) ? tagName : parentPath + "." + tagName;

        /*
         * 네임스페이스는 v2 지원 대상이 아니다(명세 §1, §3.2). 접두사를 조용히
         * 노드 이름에 섞어 넣으면 생성 시점에 DOM 구현별로 동작이 갈리므로 거부한다.
         */
        if (tagName.indexOf(':') >= 0) {
            throw new ImportException("네임스페이스를 사용하는 엘리먼트는 지원하지 않습니다: '"
                    + tagName + "' (경로: " + path + ")");
        }

        TemplateNode node = new TemplateNode(tagName);
        readAttributes(el, node, path, warnings);

        List<Element> childElements = new ArrayList<Element>();
        StringBuilder text = new StringBuilder();
        scanChildren(el, path, childElements, text, warnings);

        String trimmedText = text.toString().trim();

        if (!childElements.isEmpty()) {
            /* 명세 §3.2: 자식과 텍스트가 동시에 있으면 이 모델로 표현할 수 없다. */
            if (!trimmedText.isEmpty()) {
                throw new ImportException("텍스트와 자식 엘리먼트가 함께 있는 노드는 지원하지 않습니다"
                        + " (혼합 콘텐츠): '" + trimmedText + "' (경로: " + path + ")");
            }
            for (Element child : childElements) {
                node.addChild(convert(child, path, depth + 1, nodeCount, warnings,
                        inferredFunctions));
            }
            /* 자식이 있는 노드의 값은 쓰이지 않지만 명시 valueType 의 유효성은 확인한다. */
            applyValueType(node, el, trimmedText, path, warnings, inferredFunctions);
        } else {
            applyValueType(node, el, trimmedText, path, warnings, inferredFunctions);
        }
        return node;
    }

    /**
     * 자식 노드를 훑어 엘리먼트/텍스트를 모으고, 표현할 수 없는 종류는 경고로 남긴다.
     * 주석과 처리 명령은 버려지지만 <b>버렸다는 사실</b>은 반드시 알린다(§3.2).
     */
    private static void scanChildren(Element el, String path, List<Element> childElements,
            StringBuilder text, List<WarningDto> warnings) {
        NodeList children = el.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            switch (child.getNodeType()) {
                case Node.ELEMENT_NODE:
                    childElements.add((Element) child);
                    break;
                case Node.TEXT_NODE:
                case Node.CDATA_SECTION_NODE:
                    /* CDATA 는 텍스트와 동일하게 취급한다 (§3.2) */
                    text.append(((CharacterData) child).getData());
                    break;
                case Node.COMMENT_NODE:
                    warnings.add(new WarningDto(WARN_COMMENT_IGNORED, path,
                            "주석은 템플릿에 보존되지 않고 무시됩니다."));
                    break;
                case Node.PROCESSING_INSTRUCTION_NODE:
                    warnings.add(new WarningDto(WARN_PI_IGNORED, path,
                            "처리 명령(PI)은 템플릿에 보존되지 않고 무시됩니다."));
                    break;
                default:
                    break;
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* 속성 (명세 §2, §3.3)                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 속성을 읽어 예약 속성은 제어 정보로, 나머지는 일반 속성으로 나눈다.
     *
     * <b>순서에 대하여</b>: DOM 의 {@code NamedNodeMap} 은 순서가 없는 컬렉션이라
     * (W3C DOM 명세) 원본 XML 의 속성 작성 순서는 파싱 시점에 이미 소실된다.
     * 실제로 Xerces 는 이름순으로 돌려준다. XML 명세상 속성 순서에는 의미가 없으므로
     * 복원을 시도하는 대신 <b>이름순으로 명시 정렬</b>해서 파서 구현이 바뀌어도
     * 결과가 흔들리지 않게 한다 (골든 테스트 안정성).
     */
    private static void readAttributes(Element el, TemplateNode node, String path,
            List<WarningDto> warnings) {
        NamedNodeMap attrs = el.getAttributes();
        List<String> names = new ArrayList<String>();
        for (int i = 0; i < attrs.getLength(); i++) {
            names.add(attrs.item(i).getNodeName());
        }
        Collections.sort(names);

        for (String name : names) {
            String value = attrs.getNamedItem(name).getNodeValue();

            if (name.indexOf(':') >= 0) {
                throw new ImportException("네임스페이스를 사용하는 속성은 지원하지 않습니다: '"
                        + name + "' (경로: " + path + ")");
            }

            if (!RESERVED_ATTRIBUTES.contains(name)) {
                /*
                 * 일반 XML 속성은 R2 에서 폐지됐다. <b>거부가 아니라 경고 후 버림</b>이다 —
                 * 사용자가 올린 원본 XML 에 속성이 있는 것은 자연스러운 일이라 거부하면
                 * 기존 파일을 아예 가져올 수 없게 된다. 다만 조용히 버리면 "올린 대로
                 * 저장됐다"고 오해하므로 무엇을 버렸는지 값까지 알린다.
                 */
                warnings.add(new WarningDto(WARN_GENERAL_ATTR_IGNORED, path,
                        "일반 속성 '" + name + "=\"" + value + "\"' 는 더 이상 지원되지 않아"
                                + " 무시했습니다. 생성 XML 에 출력되지 않습니다 —"
                                + " 필요하면 자식 노드로 옮기세요."));
                continue;
            }

            /*
             * 예약 이름은 값이 우연히 유효해도 제어 정보로 흡수된다. 사용자가
             * "일반 속성으로 출력되겠지"라고 오해하지 않도록 값 유효 여부와
             * 무관하게 경고를 남긴다(명세 §2).
             */
            warnings.add(new WarningDto(WARN_RESERVED_ATTR_CONSUMED, path,
                    "예약 속성 '" + name + "' 은 제어 정보로 해석되며 생성 XML 에 출력되지 않습니다."));

            if (ATTR_REPEAT_CONDITION.equals(name)) {
                throw new ImportException("repeatCondition 은 문법 v2 에서 폐지되었습니다"
                        + " (경로: " + path + "). 게이트가 필요하면 repeatCountExpr 의 삼항식으로"
                        + " 표현하세요: repeatCountExpr=\"{USE} == 'Y' ? COUNT({X}) : 0\"");
            }
            if (ATTR_DISPLAY_CONDITION.equals(name)) {
                node.setDisplayCondition(requireParsable(value, name, path));
            } else if (ATTR_REPEAT_COUNT_EXPR.equals(name)) {
                node.setRepeatCountExpr(requireParsable(value, name, path));
            } else if (ATTR_DATA_TYPE.equals(name)) {
                node.setValueDataType(strictDataType(value, path));
            }
            /* valueType 은 값 텍스트가 필요하므로 applyValueType() 에서 처리한다. */
        }
    }

    /** 조건식 속성은 저장 전에 문법이 맞는지 확인한다 (명세 §11 - 저장 시 오류). */
    private static String requireParsable(String expression, String attributeName, String path) {
        String trimmed = (expression == null) ? "" : expression.trim();
        if (trimmed.isEmpty()) {
            return "";
        }
        try {
            ExpressionEvaluator.parse(trimmed);
        } catch (ExpressionException e) {
            throw new ImportException("속성 " + attributeName + " 의 식이 잘못되었습니다 (경로: "
                    + path + "): " + e.getMessage()
                    + " — 조건식의 '<' 는 &lt; 로, '&' 는 &amp; 로 이스케이프해야 합니다.");
        }
        return trimmed;
    }

    /** 명세 §2: 예약 속성의 값이 제어 문법으로 유효하지 않으면 조용히 넘기지 않고 거부한다. */
    private static ValueDataType strictDataType(String value, String path) {
        String trimmed = (value == null) ? "" : value.trim();
        for (ValueDataType type : ValueDataType.values()) {
            if (type.name().equalsIgnoreCase(trimmed)) {
                return type;
            }
        }
        throw new ImportException("dataType 값이 잘못되었습니다: '" + value
                + "' (경로: " + path + ", 사용 가능: STRING, NUMBER)");
    }

    private static ValueType strictValueType(String value, String path) {
        String trimmed = (value == null) ? "" : value.trim();
        for (ValueType type : ValueType.values()) {
            if (type.name().equalsIgnoreCase(trimmed)) {
                return type;
            }
        }
        throw new ImportException("valueType 값이 잘못되었습니다: '" + value
                + "' (경로: " + path + ", 사용 가능: FIXED, VARIABLE, FUNCTION)");
    }

    /* ------------------------------------------------------------------ */
    /* 값 유형 추론 (명세 §3.1)                                              */
    /* ------------------------------------------------------------------ */

    private static void applyValueType(TemplateNode node, Element el, String text,
            String path, List<WarningDto> warnings, List<TemplateNode> inferredFunctions) {
        if (el.hasAttribute(ATTR_VALUE_TYPE)) {
            /* 1. 명시 valueType 은 추론하지 않는다 — 오인 추론의 탈출구다. */
            ValueType explicit = strictValueType(el.getAttribute(ATTR_VALUE_TYPE), path);
            if (explicit == ValueType.FUNCTION) {
                /* 명시한 경우에만 검증 실패가 저장 오류다 (§3.1). */
                requireParsable(text, ATTR_VALUE_TYPE + "=\"FUNCTION\" 노드 값", path);
            }
            node.setValueType(explicit);
            node.setValue(text);
            return;
        }

        ValueInference inference = infer(text, path, warnings);
        node.setValueType(inference.type);
        node.setValue(inference.value);
        if (inference.type == ValueType.FUNCTION) {
            inferredFunctions.add(node);
        }
    }

    /**
     * 명세 §3.1 의 결정적 추론 순서:
     * <ol>
     *   <li>최상위가 삼항으로 파싱되면 FUNCTION</li>
     *   <li>(이스케이프되지 않은) {@code {} } 를 포함하면 VARIABLE</li>
     *   <li>그 외 FIXED</li>
     * </ol>
     *
     * 삼항처럼 보이지만 파싱에 실패하는 텍스트({@code A ? B : C : D} 등)는 오류가
     * 아니라 FIXED 로 강등하고 경고한다. 평범한 문장이 저장 거부되는 것보다
     * 사용자에게 알리고 통과시키는 편이 낫다는 명세 판단을 따른다.
     */
    private static ValueInference infer(String text, String path, List<WarningDto> warnings) {
        if (text.isEmpty()) {
            return new ValueInference(ValueType.FIXED, "");
        }

        if (looksLikeTernary(text)) {
            try {
                Expr ast = ExpressionEvaluator.parse(text);
                if (ast instanceof TernaryExpr) {
                    warnings.add(new WarningDto(WARN_TYPE_INFERRED, path,
                            "삼항식으로 판정해 값 유형을 FUNCTION 으로 추론했습니다."));
                    return new ValueInference(ValueType.FUNCTION, text);
                }
            } catch (ExpressionException e) {
                warnings.add(new WarningDto(WARN_TYPE_DEMOTED, path,
                        "삼항식처럼 보이지만 식으로 해석할 수 없어 고정값(FIXED)으로 처리했습니다: "
                                + e.getMessage()));
                return new ValueInference(ValueType.FIXED, text);
            }
        }

        if (hasUnescapedBrace(text)) {
            warnings.add(new WarningDto(WARN_TYPE_INFERRED, path,
                    "{ } 를 포함해 값 유형을 VARIABLE 로 추론했습니다."));
            return new ValueInference(ValueType.VARIABLE, text);
        }
        return new ValueInference(ValueType.FIXED, text);
    }

    /**
     * 이스케이프({@code ''})와 중괄호 밖에 최상위 {@code ?} 와 {@code :} 가 모두
     * 있는지 본다. 전부 파싱해 보기 전에 값싸게 거르는 용도라 정밀할 필요는 없지만,
     * {@code 'a?b'} 나 {@code {A?B}} 처럼 리터럴 안의 기호에 낚이면 안 된다.
     */
    private static boolean looksLikeTernary(String text) {
        boolean inString = false;
        int braceDepth = 0;
        boolean question = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\'') {
                inString = !inString;
                continue;
            }
            if (inString) {
                continue;
            }
            if (c == '{') {
                if (i + 1 < text.length() && text.charAt(i + 1) == '{') {
                    i++;
                    continue;
                }
                braceDepth++;
            } else if (c == '}') {
                if (i + 1 < text.length() && text.charAt(i + 1) == '}') {
                    i++;
                    continue;
                }
                if (braceDepth > 0) {
                    braceDepth--;
                }
            } else if (braceDepth == 0) {
                if (c == '?') {
                    question = true;
                } else if (c == ':' && question) {
                    return true;
                }
            }
        }
        return false;
    }

    /** 이스케이프되지 않은 여는 중괄호가 있는지. {@code {{} 는 리터럴이라 세지 않는다. */
    private static boolean hasUnescapedBrace(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{' || c == '}') {
                if (i + 1 < text.length() && text.charAt(i + 1) == c) {
                    i++;
                    continue;
                }
                return true;
            }
        }
        return false;
    }
}
