package com.xmltemplate.util.template;

import java.util.ArrayList;
import java.util.List;

import com.xmltemplate.dto.NodeDto;
import com.xmltemplate.dto.TemplateDto;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.exception.GeneralAttributeRemovedException;
import com.xmltemplate.exception.InvalidRequestException;
import com.xmltemplate.exception.MappingException;
import com.xmltemplate.exception.NodeListStructureException;
import com.xmltemplate.util.xml.SecureXml;

/**
 * 전송 DTO ↔ 도메인 트리 변환의 <b>유일한 장소</b> (docs/API_V4_FLAT.md §5.1).
 *
 * 컨트롤러마다 변환을 조금씩 하면 "이 경로에서만 attributes 가 빠진다" 같은 차이가 생긴다.
 * 이 프로젝트가 프론트 2종에서 겪은 이원화 실패 모드와 같은 형태다.
 *
 * <h3>R4 — 와이어는 평면, 도메인은 트리</h3>
 * {@code nodes[]} 는 DFS 전위로 평면화된 목록이고 도메인({@link TemplateNode})은 그대로
 * 재귀 트리다. 생성 엔진·검증기·저장소가 전부 재귀 트리 위에서 도는데 평면화를 안쪽까지
 * 밀면 엔진을 재작성해야 하고 얻는 것이 없다 — <b>변경 표면을 DTO 계층에 가둔다</b>.
 *
 * <h3>구조 검증이 왜 여기 있는가</h3>
 * 저장({@code PUT})과 미리보기({@code POST /api/preview})가 <b>함께 지나는 유일한 지점</b>이기
 * 때문이다. 검증기({@link TemplateValidator}, 저장 전용)에 두면 미리보기가 그냥 통과해
 * "미리보기는 되는데 저장은 안 되는" 상태가 된다 — {@code GeneralAttributeRemovedException}
 * 주석에 이미 기록된 실패 모드다. 컨트롤러에 두면 두 메서드에 복사되어 갈라진다.
 *
 * <h3>{@link TemplateEntityMapper} 와의 관계</h3>
 * R4 이후 두 조립기는 <b>골격이 같다</b>(평면 목록 → 트리, 단일 패스). 그래도 합치지 않는다.
 * 입력의 신뢰도(DB vs 클라이언트), SN 의 성질(전역 희소 vs 정확히 1..n), 자료구조
 * (HashMap vs 배열), 실패의 의미(500 데이터 손상 vs 400 요청 오류), 검증 강도가 모두 다르다.
 * 합치면 그 5가지를 파라미터로 뚫어야 하고, 그 순간 <b>500 이어야 할 실패가 400 으로 나가는</b>
 * 회귀가 가능해진다. <b>한쪽을 고치면 다른 쪽도 확인하라.</b>
 *
 * enum 값은 <b>조용히 기본값으로 떨어뜨리지 않는다</b> — "조용한 폴백 금지" 원칙에 맞춰
 * 알 수 없는 값이면 예외를 던져 400 이 되게 한다.
 * ({@code ValueType.fromString} 은 <b>저장본 복원용</b>이라 관대한데, API 입력에는
 *  그 관대함이 오히려 오타를 감춘다 — 두 경로의 엄격도가 다른 것이 의도다.)
 */
public final class TemplateMapper {

    private TemplateMapper() {
    }

    /* ------------------------------------------------------------------ */
    /* 도메인 -> DTO (평면화)                                                */
    /* ------------------------------------------------------------------ */

    /**
     * 도메인 트리를 DFS 전위 평면 목록으로 만든다.
     *
     * 산출물은 불변식 (I1)({@code sn == 인덱스 + 1}) 과 (I2)({@code parentSn < sn}) 를
     * <b>구성적으로</b> 만족한다 — 자신을 담은 뒤 자식을 방문하기 때문이다. 그래서
     * 서버가 만든 목록은 검증할 필요가 없다(임포트 경로가 구조 검증을 건너뛰는 근거).
     * 그 성질은 주석이 아니라 테스트로 고정한다({@code TemplateMapperTest} T-B4).
     */
    public static List<NodeDto> toNodeList(TemplateNode root) {
        List<NodeDto> out = new ArrayList<NodeDto>();
        appendPreorder(root, null, out);
        return out;
    }

    /**
     * 재귀 깊이는 {@code MAX_TREE_DEPTH=50} 으로 제한되어 있어 스택 위험이 없다
     * (구 재귀 {@code toDto} 와 같은 전제).
     */
    private static void appendPreorder(TemplateNode node, Integer parentSn, List<NodeDto> out) {
        NodeDto dto = new NodeDto();
        /* ★ add 이전에 계산한다 — 1-based 이므로 "현재 크기 + 1" 이 곧 자기 위치다 */
        dto.sn = out.size() + 1;
        /* 루트는 null 로 남는다 -> non_null 정책이 응답에서 키 자체를 생략한다 */
        dto.parentSn = parentSn;
        dto.name = nullToEmpty(node.getName());
        dto.valueType = node.getValueType().name();
        dto.value = nullToEmpty(node.getValue());
        dto.valueDataType = node.getValueDataType().name();
        dto.displayCondition = nullToEmpty(node.getDisplayCondition());
        dto.repeatCondition = nullToEmpty(node.getRepeatCondition());
        dto.repeatCountExpr = nullToEmpty(node.getRepeatCountExpr());

        /*
         * attributes / children 은 폐지된 tombstone 이라 <b>채우지 않는다</b>. null 로 남으므로
         * non_null 정책이 응답에서 키 자체를 생략한다 — 빈 배열로 내보내면 폐지된 개념이
         * 계속 살아 있는 것처럼 보인다. 요청 쪽 tombstone 검사는 아래 toModel 에 있다.
         */
        out.add(dto);
        for (TemplateNode child : node.getChildren()) {
            appendPreorder(child, dto.sn, out);
        }
    }

    /**
     * 템플릿 전문 DTO.
     *
     * @throws IllegalStateException {@code root} 가 null 일 때. <b>조용한 빈 응답을 만들지
     *         않는다</b> — {@code nodes} 를 null 로 두면 non_null 정책이 키를 지워 프론트가
     *         "노드 목록이 없습니다"로 실패하고, 빈 배열로 두면 요청 방향의 V1("비어 있지
     *         않을 것")과 어긋나 왕복이 깨진다. 어느 쪽도 정답이 아니므로 <b>호출부가
     *         null 을 넘기지 않는 것이 계약</b>이고, 어겼다는 사실을 여기서 드러낸다.
     *         (도달 경로는 현재 없다 — {@code TemplateService.load} 가 먼저 걸러 404 를 낸다.)
     */
    public static TemplateDto toDto(String name, TemplateNode root, String updatedAt) {
        if (root == null) {
            throw new IllegalStateException("템플릿 DTO 를 만들 수 없습니다: root 가 null 입니다"
                    + " (name='" + nullToEmpty(name) + "'). 호출부가 null 을 먼저 걸러야 합니다.");
        }
        TemplateDto dto = new TemplateDto();
        dto.name = nullToEmpty(name);
        dto.updatedAt = updatedAt;
        dto.nodes = toNodeList(root);
        return dto;
    }

    /* ------------------------------------------------------------------ */
    /* DTO -> 도메인 (조립 + 구조 검증)                                       */
    /* ------------------------------------------------------------------ */

    /**
     * 요청 본문 전체 → 도메인 트리. <b>컨트롤러는 이 진입점만 쓴다</b> (저장·미리보기 공통).
     *
     * {@code nodes} 유무 판단을 컨트롤러가 아니라 여기서 하는 것이 요점이다 — 두 메서드에
     * 같은 조건문을 복사하면 한쪽만 고쳐지는 날이 온다.
     */
    public static TemplateNode toModel(TemplateDto template) {
        if (template == null) {
            throw new InvalidRequestException("요청 본문이 비어 있습니다.");
        }
        /* V8 — 구 계약 tombstone. nodes 검사보다 먼저 봐야 "nodes 가 없다"는 엉뚱한 안내를 피한다 */
        if (template.root != null) {
            throw new NodeListStructureException(NodeListStructureException.LEGACY_TREE_PAYLOAD,
                    "구 계약(중첩 트리) 본문입니다. root 대신 nodes 평면 목록을 보내세요.");
        }
        return toModel(template.nodes);
    }

    /**
     * 평면 목록 → 도메인 트리. <b>O(n) 단일 패스</b>이며 검증을 겸한다.
     *
     * <h3>왜 배열인가 (HashMap 이 아니라)</h3>
     * {@code sn} 이 1..n 으로 <b>강제</b>되므로 배열 인덱싱이 성립한다 — 해시 비용과 박싱이
     * 사라진다. {@link TemplateEntityMapper#toDomainTree} 가 {@code HashMap} 을 쓰는 이유
     * (전역 {@code NODE_SN} 은 1..n 이 아니고 구간이 비어 있다)와 정확히 대비되며,
     * 이 차이가 두 조립기를 통합하지 않는 근거 중 하나다.
     *
     * <h3>순환 탐지 코드가 없는 이유</h3>
     * <b>V5({@code parentSn < sn})가 그것을 대신한다.</b> 순환은 반드시 "뒤를 참조하는 간선"을
     * 포함하는데 V5 가 그 간선을 금지하므로 <b>순환은 표현 자체가 불가능</b>하다. 별도
     * 탐지 알고리즘을 두면 <b>절대 실행되지 않는 죽은 분기</b>가 된다. 근거 없이 빠져 있으면
     * 다음 사람이 "빠뜨렸다"고 판단해 다시 넣으므로 여기 적어 둔다. 그 사실 자체도
     * 테스트로 고정돼 있다({@code TemplateMapperTest} T-B9).
     *
     * <h3>경로(path)는 오류가 날 때만 만든다</h3>
     * tombstone·enum 오류 메시지에는 전체 경로({@code ORDER.HEADER.MEMO})가 필요하다.
     * 구 재귀 구현은 정상 경로에서도 문자열을 계속 이어붙였다. 평면에서는 {@code parent[]} 를
     * 역추적해 <b>오류 시에만</b> O(depth) 로 조립하면 된다 — 정상 경로 비용 0.
     */
    public static TemplateNode toModel(List<NodeDto> nodes) {
        /* V1 */
        if (nodes == null || nodes.isEmpty()) {
            throw new InvalidRequestException("요청 본문에 nodes 목록이 없습니다.");
        }
        /*
         * V2 — 조립 <b>전에</b> O(1) 로 막는다. 10,000 개를 다 조립한 뒤 거부하면 상한의
         * 목적(자원 보호)이 반쯤 무너진다. 재귀 트리에서는 다 만들어 봐야 셀 수 있었는데,
         * 평면 목록은 길이를 즉시 안다 — 평면화가 준 개선점이다.
         * (TemplateService.checkTreeLimits 의 이중 방어는 그대로 남는다.)
         */
        if (nodes.size() > SecureXml.MAX_TEMPLATE_NODES) {
            throw new InvalidRequestException("템플릿 노드 수가 상한을 초과했습니다 (최대 "
                    + SecureXml.MAX_TEMPLATE_NODES + ").");
        }

        int n = nodes.size();
        TemplateNode[] bySn = new TemplateNode[n + 1];   // 1-based
        int[] parent = new int[n + 1];                   // 오류 시 경로 역추적용 (루트는 0)
        String[] names = new String[n + 1];              // 〃
        int[] depth = new int[n + 1];
        TemplateNode root = null;
        int rootSn = 0;

        for (int i = 0; i < n; i++) {
            NodeDto dto = nodes.get(i);
            int sn = i + 1;
            if (dto == null) {
                throw new MappingException("노드가 비어 있습니다 (sn=" + sn + ").");
            }
            /* V3 (I1) */
            if (dto.sn == null || dto.sn.intValue() != sn) {
                throw new NodeListStructureException(NodeListStructureException.NODE_SN_SEQUENCE,
                        "노드 목록의 sn 은 1부터 순서대로여야 합니다: " + sn + "번째 노드의 sn="
                                + (dto.sn == null ? "없음" : dto.sn) + " (기대값 " + sn + ").");
            }

            /*
             * 부모를 <b>먼저</b> 확정한다. 아래 buildNode 의 오류 메시지(경로 병기)가
             * parent[]/names[] 를 읽기 때문이다 — 순서를 바꾸면 자기 자신의 조상 경로를
             * 알 수 없는 상태에서 메시지를 만들게 된다.
             */
            if (dto.parentSn == null) {
                /* V4 — 루트는 정확히 1개 */
                if (root != null) {
                    throw new NodeListStructureException(NodeListStructureException.MULTIPLE_ROOTS,
                            "루트 노드가 2개 이상입니다 (sn=" + rootSn + ", sn=" + sn + ")."
                                    + " parentSn 이 없는 노드는 하나여야 합니다.");
                }
                parent[sn] = 0;
                depth[sn] = 1;
            } else {
                int p = dto.parentSn.intValue();
                /*
                 * V6 을 V5 보다 <b>먼저</b> 본다. 순서를 뒤집으면 parentSn=999 같은 명백한
                 * 고아가 "부모가 뒤에 있다"(PARENT_AFTER_CHILD)로 보고되어, 사용자가 목록
                 * 순서를 의심하며 엉뚱한 곳을 뒤진다. 범위 밖이면 순서 문제가 아니다.
                 */
                if (p < 1 || p > n) {
                    throw new NodeListStructureException(NodeListStructureException.ORPHAN_NODE,
                            "노드 '" + nullToEmpty(dto.name) + "' (sn=" + sn
                                    + ") 가 존재하지 않는 부모 parentSn=" + p
                                    + " 를 참조합니다 (노드 수 " + n + ").");
                }
                /* V5 (I2) — 자기참조(p == sn)도 여기서 걸린다 */
                if (p >= sn) {
                    throw new NodeListStructureException(
                            NodeListStructureException.PARENT_AFTER_CHILD,
                            "노드 '" + nullToEmpty(dto.name) + "' (sn=" + sn + ") 의 parentSn="
                                    + p + (p == sn ? " 이 자기 자신입니다." : " 이 자신보다 뒤에 있습니다.")
                                    + " 목록은 DFS 전위(부모가 먼저) 순서여야 합니다.");
                }
                /*
                 * 이 지점에서 bySn[p] 는 <b>반드시</b> 비어 있지 않다 — (I1) 이 sn 을 위치에
                 * 못박았고 1 ≤ p < sn 이므로 p 번째 노드는 이미 만들어졌다. null 검사를
                 * 넣으면 절대 참이 되지 않는 죽은 분기가 되므로 두지 않는다(순환 탐지와 같은 이유).
                 */
                parent[sn] = p;
                depth[sn] = depth[p] + 1;
                /* V7 — 조립하면서 계산하므로 트리를 다 만든 뒤 재귀로 재는 패스가 필요 없다 */
                if (depth[sn] > SecureXml.MAX_TREE_DEPTH) {
                    throw new InvalidRequestException("템플릿 트리 깊이가 상한을 초과했습니다 (최대 "
                            + SecureXml.MAX_TREE_DEPTH + ").");
                }
            }

            names[sn] = nullToEmpty(dto.name);
            TemplateNode node = buildNode(dto, sn, parent, names);
            bySn[sn] = node;

            if (parent[sn] == 0) {
                root = node;
                rootSn = sn;
            } else {
                bySn[parent[sn]].addChild(node);
            }
        }
        /* V4 — 모든 노드가 parentSn 을 가진 경우 */
        if (root == null) {
            throw new NodeListStructureException(NodeListStructureException.NO_ROOT_NODE,
                    "루트 노드가 없습니다 — 모든 노드가 parentSn 을 가지고 있습니다.");
        }
        return root;
    }

    /**
     * 노드 하나의 필드 검증·변환. 구조(배치)가 아니라 <b>값</b>의 오류라 여기서 나오는 예외는
     * {@link MappingException} / {@link GeneralAttributeRemovedException} 이다.
     *
     * 오류 메시지에 전체 경로를 싣는다. {@code sn} 만으로는 사용자가 화면의 어느 노드인지
     * 특정할 수 없고, 이름만으로는 동명 노드가 여럿일 때 어느 것을 고쳐야 할지 모른다.
     */
    private static TemplateNode buildNode(NodeDto dto, int sn, int[] parent, String[] names) {
        String name = nullToEmpty(dto.name);
        String path = pathOf(sn, parent, names);

        /*
         * ── 검사 순서는 계약 §5.1 의 명시 순서를 따른다: tombstone(V8, V9) → 값(V10, V-NAME).
         *
         * 순서가 의미를 갖는 이유: 구 클라이언트가 <b>이름 없는 노드에 children 을 실어</b>
         * 보내는 조합이 실제로 가능하다(평면화를 반쯤 고친 직렬화기). 그때 나가야 할 안내는
         * "노드 이름이 비어 있습니다"가 아니라 <b>"root/children 대신 nodes 평면 목록을
         * 보내세요"</b>다 — 전자를 보면 개발자가 이름 필드를 채우려 들고, 진짜 원인(구 계약
         * 본문)은 그대로 남는다. 두 오류 모두 400 이지만 <b>고쳐야 할 대상이 다르다.</b>
         * 이 순서는 단위 테스트로 고정돼 있다(TemplateMapperTest T-B12 순서 케이스).
         */

        /*
         * V8 — 노드 단위 구 계약 tombstone. TemplateDto.root 만 막으면 "평면 목록을 만들면서
         * children 을 그대로 남긴" 반쯤 고친 클라이언트가 검사를 통과해, 자식이 통째로 사라진
         * 트리가 조용히 저장된다. 빈 배열은 통과 (attributes 와 같은 규칙).
         */
        if (dto.children != null && !dto.children.isEmpty()) {
            throw new NodeListStructureException(NodeListStructureException.LEGACY_TREE_PAYLOAD,
                    "구 계약(중첩 트리) 본문입니다. root/children 대신 nodes 평면 목록을 보내세요."
                            + " (노드 '" + path + "' 에 children " + dto.children.size() + "개)");
        }
        /*
         * V9 — 폐지된 일반 속성이 실려 오면 거부한다 (R2). 도메인 트리에는 속성 개념이 남아
         * 있지 않으므로 이 아래로 내려가면 정보 자체가 사라진다.
         * 빈 배열은 통과시킨다 — 전환기 클라이언트가 계속 보내는데 그것까지 거부하면
         * 화면이 상시 400 이 된다.
         */
        if (dto.attributes != null && !dto.attributes.isEmpty()) {
            throw new GeneralAttributeRemovedException("일반 XML 속성은 더 이상 지원하지 않습니다"
                    + " (노드 '" + path + "' 에 " + dto.attributes.size() + "개)."
                    + " 속성으로 표현하던 값은 자식 노드로 옮기세요.");
        }

        /*
         * V10 — enum. 값을 <b>먼저 확정한 뒤</b> 노드를 만든다. 예전처럼 setter 안에서 던지면
         * 검사 순서가 "노드 생성"이라는 부수 효과에 묶여, 순서를 바꾸려 할 때마다 객체 수명을
         * 함께 옮겨야 한다.
         */
        ValueType valueType = requireValueType(dto.valueType, path);
        ValueDataType valueDataType = requireDataType(dto.valueDataType, path);

        /*
         * V-NAME — 빈 이름 거부 (R4 신설).
         *
         * 이전에는 이 검사가 <b>어디에도 없었다</b>. TemplateValidator 에는 이름 규칙이 없고
         * XmlGenerator.createElement 가 생성 시점에야 거부했다 — 즉 <b>저장은 되는데 생성이
         * 안 되는</b> 템플릿을 만들 수 있었다. D4 가 막으려는 "미리보기는 되는데 저장은 안 되는"
         * 상태의 거울상이다. 평면 목록에서는 이름 없는 노드를 배열에 끼워 넣기가 중첩 트리보다
         * 쉬워 노출 확률이 오르므로 이번 라운드에 매퍼로 끌어올린다.
         */
        if (name.trim().isEmpty()) {
            throw new MappingException("노드 이름이 비어 있습니다 (sn=" + sn + ", 부모 경로 '"
                    + parentPathOf(sn, parent, names) + "')."
                    + " 모든 노드에는 XML 엘리먼트 이름이 있어야 합니다.");
        }

        TemplateNode node = new TemplateNode(name);
        node.setValueType(valueType);
        node.setValueDataType(valueDataType);
        node.setValue(nullToEmpty(dto.value));
        node.setDisplayCondition(nullToEmpty(dto.displayCondition));
        node.setRepeatCondition(nullToEmpty(dto.repeatCondition));
        node.setRepeatCountExpr(nullToEmpty(dto.repeatCountExpr));
        return node;
    }

    /**
     * {@code parent[]} 를 역추적해 루트부터의 전체 경로를 만든다 — <b>오류 경로에서만</b> 호출된다.
     *
     * 정상 경로에서 부르지 않는 것이 요점이다. 도메인 트리를 다 만든 뒤에는
     * {@link TemplateNode#getPath()} 로 얻을 수 있지만, 변환 도중 거부하는 검사는 그때까지
     * 갈 수 없다.
     */
    private static String pathOf(int sn, int[] parent, String[] names) {
        StringBuilder path = new StringBuilder();
        appendPath(sn, parent, names, path);
        return path.toString();
    }

    /** 부모까지의 경로. 루트면 {@code "(루트)"} — 빈 문자열이면 메시지가 읽히지 않는다. */
    private static String parentPathOf(int sn, int[] parent, String[] names) {
        if (parent[sn] == 0) {
            return "(루트)";
        }
        return pathOf(parent[sn], parent, names);
    }

    private static void appendPath(int sn, int[] parent, String[] names, StringBuilder out) {
        if (parent[sn] != 0) {
            appendPath(parent[sn], parent, names, out);
            out.append('.');
        }
        out.append(names[sn] == null ? "" : names[sn]);
    }

    /**
     * enum 은 조용한 기본값 대입을 하지 않는다.
     * {@code valueType: "FUCNTION"} 오타가 FIXED 로 떨어지면 사용자는 왜 값이 안 나오는지
     * 알 수 없다 — 400 으로 즉시 알린다.
     */
    private static ValueType requireValueType(String raw, String where) {
        if (raw == null || raw.trim().isEmpty()) {
            return ValueType.FIXED;
        }
        for (ValueType type : ValueType.values()) {
            if (type.name().equals(raw.trim())) {
                return type;
            }
        }
        throw new MappingException("valueType 값이 잘못되었습니다: '" + raw + "'"
                + (where == null ? "" : " (노드: " + where + ")")
                + " — 사용 가능: FIXED, VARIABLE, FUNCTION");
    }

    private static ValueDataType requireDataType(String raw, String where) {
        if (raw == null || raw.trim().isEmpty()) {
            return ValueDataType.STRING;
        }
        for (ValueDataType type : ValueDataType.values()) {
            if (type.name().equals(raw.trim())) {
                return type;
            }
        }
        throw new MappingException("valueDataType 값이 잘못되었습니다: '" + raw + "'"
                + (where == null ? "" : " (노드: " + where + ")")
                + " — 사용 가능: STRING, NUMBER");
    }

    private static String nullToEmpty(String s) {
        return (s == null) ? "" : s;
    }
}
