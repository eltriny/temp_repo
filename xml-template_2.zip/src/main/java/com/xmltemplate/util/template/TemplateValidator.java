package com.xmltemplate.util.template;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.xmltemplate.util.expression.BinaryExpr;
import com.xmltemplate.util.expression.Expr;
import com.xmltemplate.util.expression.ExpressionEvaluator;
import com.xmltemplate.util.expression.NodePathExpr;
import com.xmltemplate.util.expression.NullLiteralExpr;
import com.xmltemplate.util.expression.VarExpr;
import com.xmltemplate.util.engine.XmlGenerator;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.ValidationErrorDto;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.exception.ExpressionException;
import com.xmltemplate.exception.ValidationException;

/**
 * 정적 검증기 (명세 §8, §11).
 *
 * 저장/업로드 시점에 돌려서, 생성 시점에야 드러날 문제를 미리 잡는다.
 *
 * 검사 항목:
 *  <ul>
 *    <li>표현식 문법 (식 내 위치 포함)</li>
 *    <li>존재하지 않는 노드 경로 — 정본 예시 2 의 {@code Paramters} 오타가 여기서 잡힌다</li>
 *    <li>전방 참조 (DFS 전위 순서상 자기보다 뒤에 오는 노드)</li>
 *    <li>자기 참조</li>
 *    <li>동명 형제로 경로가 유일하게 결정되지 않는 참조</li>
 *    <li>반복 스코프 체인 prefix 위반 (반복 인스턴스를 결정할 수 없는 참조)</li>
 *    <li>리터럴 {@code NULL} 의 순서 비교</li>
 *    <li>{@code [Nk]} 인덱스 표기의 깊이 규칙</li>
 *  </ul>
 *
 * 오류를 하나 만나고 멈추지 않고 <b>전부 모아서</b> 돌려준다. 사용자가 한 번에
 * 고칠 수 있어야 하기 때문이다(명세 §11 - "400 + 오류 목록").
 */
public final class TemplateValidator {

    public static final String ERR_SYNTAX = "EXPRESSION_SYNTAX";
    public static final String ERR_UNKNOWN_PATH = "UNKNOWN_NODE_PATH";
    public static final String ERR_FORWARD_REFERENCE = "FORWARD_REFERENCE";
    public static final String ERR_SELF_REFERENCE = "SELF_REFERENCE";
    public static final String ERR_AMBIGUOUS_PATH = "AMBIGUOUS_NODE_PATH";
    public static final String ERR_SCOPE_CHAIN = "REPEAT_SCOPE_MISMATCH";
    public static final String ERR_NULL_ORDER = "NULL_ORDER_COMPARISON";
    public static final String ERR_INDEX_DEPTH = "INDEX_DEPTH";
    /** 변수명에 대괄호가 남아 있을 때 (§3.1 - 중괄호 내부 리터럴 [N...] 불가). */
    public static final String ERR_VARIABLE_NAME = "INVALID_VARIABLE_NAME";
    /** 중첩 반복 깊이 상한 초과 (§9.2). */
    public static final String ERR_REPEAT_DEPTH = "REPEAT_DEPTH_EXCEEDED";
    /** 루트에 표시 조건/반복을 지정 (§9.1). */
    public static final String ERR_ROOT_REPEAT = "ROOT_REPEAT_OR_DISPLAY";
    /** v2 에서 폐지된 repeatCondition 이 남아 있을 때 (§2). */
    public static final String ERR_REPEAT_CONDITION = "REPEAT_CONDITION_REMOVED";

    /** 중첩 반복 깊이 상한 (§9.2 - 저장 시 거부). */
    public static final int MAX_REPEAT_NESTING = 5;

    /** VARIABLE 값 안의 {이름} 추출 (XmlGenerator 와 같은 패턴). */
    private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\{([^{}]+)\\}");

    private static final String BUILTIN_INDEX = "INDEX";

    private TemplateValidator() {
    }

    /* ------------------------------------------------------------------ */
    /* 진입점                                                               */
    /* ------------------------------------------------------------------ */

    /** 오류 목록을 돌려준다 (비어 있으면 통과). */
    public static List<ValidationErrorDto> validate(TemplateNode root) {
        List<ValidationErrorDto> errors = new ArrayList<ValidationErrorDto>();
        if (root == null) {
            return errors;
        }
        List<TemplateNode> order = new ArrayList<TemplateNode>();
        flatten(root, order);

        /* §9.1: 루트는 항상 정확히 1회 생성된다 — 문서가 성립하지 않는 상태를 저장 시 차단. */
        if (!root.getDisplayCondition().trim().isEmpty()) {
            errors.add(new ValidationErrorDto(root.getPath(), "displayCondition", ERR_ROOT_REPEAT,
                    "루트 노드에는 displayCondition 을 지정할 수 없습니다 (루트는 항상 1회 생성)."));
        }
        if (isRepeating(root)) {
            errors.add(new ValidationErrorDto(root.getPath(), "repeatCountExpr", ERR_ROOT_REPEAT,
                    "루트 노드에는 repeatCountExpr 을 지정할 수 없습니다 (루트는 항상 1회 생성)."));
        }
        validateNode(root, root, order, errors);
        return errors;
    }

    /** 오류가 있으면 예외를 던진다. */
    public static void requireValid(TemplateNode root) {
        List<ValidationErrorDto> errors = validate(root);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
    }

    /**
     * 이름이 예약 리터럴 {@code NULL} 인 노드의 경로를 찾는다 (거부가 아니라 <b>경고</b>용).
     *
     * 루트 상대 단일 세그먼트 {@code NULL} 참조가 리터럴에 가려진다.
     * 다만 전체 경로({@code ROOT.NULL})로는 여전히 참조되므로 거부할 일은 아니다.
     *
     * {@code COUNT}/{@code SUM}/{@code EXISTS} 는 뒤에 {@code (} 가 올 때만 함수로
     * 해석되므로 노드 이름으로 써도 가려지지 않는다 — NULL 만 대상이다.
     */
    public static List<String> findNullNamedNodes(TemplateNode root) {
        List<String> paths = new ArrayList<String>();
        if (root != null) {
            collectNullNamed(root, paths);
        }
        return paths;
    }

    private static void collectNullNamed(TemplateNode node, List<String> paths) {
        if (ExpressionEvaluator.NULL_LITERAL.equals(node.getName())) {
            paths.add(node.getPath());
        }
        for (TemplateNode child : node.getChildren()) {
            collectNullNamed(child, paths);
        }
    }

    private static void flatten(TemplateNode node, List<TemplateNode> out) {
        out.add(node);
        for (TemplateNode child : node.getChildren()) {
            flatten(child, out);
        }
    }

    private static void validateNode(TemplateNode node, TemplateNode root,
            List<TemplateNode> order, List<ValidationErrorDto> errors) {
        /*
         * 반복 노드 자신의 조건/횟수식은 자기 회차가 확정되기 전에 평가되므로
         * 조상 레벨만 쓸 수 있다 (§5.1). 값과 속성값은 회차 확정 후라 자기 레벨까지 쓴다.
         */
        int ancestorDepth = repeatDepth(node, false);
        int selfDepth = repeatDepth(node, true);

        /*
         * §2/§11: repeatCondition 은 폐지됐다. 저장 시점에 거부해야 한다.
         *
         * 임포트 파서(StructureTemplateParser)만 막고 있으면 구멍이 남는다 —
         * JSON 저장(PUT) 경로는 임포트를 거치지 않기 때문이다. 조용히 버리면
         * 사용자가 쓴 속성이 소리 없이 사라진다.
         */
        if (!node.getRepeatCondition().trim().isEmpty()) {
            errors.add(new ValidationErrorDto(node.getPath(), "repeatCondition",
                    ERR_REPEAT_CONDITION,
                    "repeatCondition 은 문법 v2 에서 폐지되었습니다. 게이트가 필요하면"
                            + " repeatCountExpr 의 삼항식으로 옮기세요:"
                            + " repeatCountExpr=\"{USE} == 'Y' ? COUNT({X}) : 0\""));
        }

        /* §9.2: 중첩 반복 깊이 상한은 저장 시 거부한다 (생성까지 가면 폭발한다). */
        if (isRepeating(node) && selfDepth > MAX_REPEAT_NESTING) {
            errors.add(new ValidationErrorDto(node.getPath(), "repeatCountExpr", ERR_REPEAT_DEPTH,
                    "중첩 반복 깊이 " + selfDepth + " 가 상한(" + MAX_REPEAT_NESTING + ")을 넘습니다."));
        }

        check(node, "displayCondition", node.getDisplayCondition(), ancestorDepth,
                root, order, errors);
        check(node, "repeatCountExpr", node.getRepeatCountExpr(), ancestorDepth,
                root, order, errors);
        if (node.getValueType() == ValueType.FUNCTION) {
            check(node, "값", node.getValue(), selfDepth, root, order, errors);
        } else if (node.getValueType() == ValueType.VARIABLE) {
            checkVariableText(node, "값", node.getValue(), selfDepth, errors);
        }
        for (TemplateNode child : node.getChildren()) {
            validateNode(child, root, order, errors);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 식 하나 검사                                                          */
    /* ------------------------------------------------------------------ */

    private static void check(TemplateNode node, String where, String expression,
            int availableDepth, TemplateNode root, List<TemplateNode> order,
            List<ValidationErrorDto> errors) {
        String trimmed = (expression == null) ? "" : expression.trim();
        if (trimmed.isEmpty()) {
            return;
        }
        Expr ast;
        try {
            ast = ExpressionEvaluator.parse(trimmed);
        } catch (ExpressionException e) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_SYNTAX, e.getMessage()));
            return;
        }
        for (Expr part : ast.flatten()) {
            if (part instanceof BinaryExpr) {
                checkNullOrdering(node, where, (BinaryExpr) part, errors);
            } else if (part instanceof VarExpr) {
                checkIndexRefs(node, where, (VarExpr) part, availableDepth, errors);
                checkBuiltinIndex(node, where, (VarExpr) part, availableDepth, errors);
            } else if (part instanceof NodePathExpr) {
                checkNodePath(node, where, (NodePathExpr) part, root, order, errors);
            }
        }
    }

    /**
     * VARIABLE 유형 값/속성값 안의 {@code {이름}} 을 하나씩 검사한다.
     *
     * VARIABLE 값은 텍스트와 변수가 섞인 형태라(예: {@code 총 {CNT} 건}) 통째로는
     * 식으로 파싱되지 않는다. 그래서 중괄호 단위로 떼어 변수 문법만 확인한다.
     * 이 경로를 빠뜨리면 {@code {K_[N]}} 같은 인덱스 표기가 검증을 그냥 통과한다.
     */
    private static void checkVariableText(TemplateNode node, String where, String text,
            int availableDepth, List<ValidationErrorDto> errors) {
        if (text == null || text.isEmpty()) {
            return;
        }
        Matcher matcher = VARIABLE_PATTERN.matcher(text);
        while (matcher.find()) {
            String name = matcher.group(1).trim();
            if (name.isEmpty()) {
                continue;
            }
            Expr parsed;
            try {
                parsed = ExpressionEvaluator.parse("{" + name + "}");
            } catch (ExpressionException e) {
                errors.add(new ValidationErrorDto(node.getPath(), where, ERR_SYNTAX,
                        e.getMessage()));
                continue;
            }
            if (parsed instanceof VarExpr) {
                checkIndexRefs(node, where, (VarExpr) parsed, availableDepth, errors);
                checkBuiltinIndex(node, where, (VarExpr) parsed, availableDepth, errors);
            }
        }
    }

    /**
     * 내장 인덱스 변수 제약 (§5.2-4).
     *
     * {@code {INDEX}} 는 {@code [N]} 축약형과 같은 이유로 반복 조상이 정확히 1개일
     * 때만 허용한다 — 다중 반복에서 "현재 회차"가 어느 레벨인지 읽는 사람마다 다르게
     * 읽히기 때문이다. 레벨을 밝히려면 {@code {INDEX1}} / {@code {INDEX2}} 를 쓴다.
     */
    private static void checkBuiltinIndex(TemplateNode node, String where, VarExpr variable,
            int availableDepth, List<ValidationErrorDto> errors) {
        String name = variable.getName();
        if (!name.startsWith(BUILTIN_INDEX)) {
            return;
        }
        String suffix = name.substring(BUILTIN_INDEX.length());
        if (suffix.isEmpty()) {
            if (availableDepth != 1) {
                errors.add(new ValidationErrorDto(node.getPath(), where, ERR_INDEX_DEPTH,
                        availableDepth == 0
                                ? "{INDEX} 는 반복 안에서만 쓸 수 있습니다."
                                : "{INDEX} 는 반복 조상이 정확히 1개일 때만 쓸 수 있습니다 (현재 "
                                        + availableDepth + "개). {INDEX1} 처럼 레벨을 명시하세요."));
            }
            return;
        }
        int level = 0;
        for (int i = 0; i < suffix.length(); i++) {
            if (!Character.isDigit(suffix.charAt(i))) {
                return; /* INDEXFOO 같은 이름은 그냥 외부 데이터 키다 */
            }
        }
        level = Integer.parseInt(suffix);
        if (level < 1 || level > availableDepth) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_INDEX_DEPTH,
                    "{" + name + "} 이 반복 스코프 깊이(" + availableDepth + ")를 넘습니다."));
        }
    }

    /** 명세 §7: 리터럴 NULL 은 ==/!= 하고만 결합할 수 있다. */
    private static void checkNullOrdering(TemplateNode node, String where, BinaryExpr binary,
            List<ValidationErrorDto> errors) {
        if (!ExpressionEvaluator.isOrderingOp(binary.getOp())) {
            return;
        }
        if (binary.getLeft() instanceof NullLiteralExpr
                || binary.getRight() instanceof NullLiteralExpr) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_NULL_ORDER,
                    "리터럴 NULL 은 순서 비교 '" + binary.getOp()
                            + "' 에 쓸 수 없습니다. == 또는 != 만 가능합니다. (위치 "
                            + binary.getPosition() + ")"));
        }
    }

    /** 명세 §5.1: [N] 은 체인 길이 1일 때만, [Nk] 는 1 <= k <= 체인 길이. */
    private static void checkIndexRefs(TemplateNode node, String where, VarExpr variable,
            int availableDepth, List<ValidationErrorDto> errors) {
        /*
         * 명세 §3.1: 중괄호 안에 리터럴 [N...] 표기는 쓸 수 없다.
         *
         * 파서는 인덱스 참조를 '_[N' 3글자로 인식하므로 {A[N1]} 같은 이름은 인덱스가
         * 아니라 기준 이름의 일부로 남는다. 그대로 두면 "검증은 통과하고 생성에서
         * 실패"하거나(§11 위반) 치환기 규칙과 갈려 조용히 다른 키를 조회한다.
         * 기준 이름에 대괄호가 남아 있으면 여기서 거부해 규칙을 한 곳으로 모은다.
         */
        String baseName = variable.getBaseName();
        if (baseName.indexOf('[') >= 0 || baseName.indexOf(']') >= 0) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_VARIABLE_NAME,
                    "변수명에 대괄호를 쓸 수 없습니다: {" + variable.getName()
                            + "} — 인덱스 표기는 이름 뒤 '_[N1]' 형태여야 합니다."));
            return;
        }
        if (!variable.hasIndexRefs()) {
            return;
        }
        if (availableDepth == 0) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_INDEX_DEPTH,
                    "반복 안이 아닌 곳에서 인덱스 표기를 쓸 수 없습니다: {" + variable.getName() + "}"));
            return;
        }
        for (Integer level : variable.getIndexRefs()) {
            int k = level.intValue();
            if (k == VarExpr.SHORTHAND_LEVEL) {
                if (availableDepth != 1) {
                    errors.add(new ValidationErrorDto(node.getPath(), where, ERR_INDEX_DEPTH,
                            "[N] 축약형은 반복 조상이 정확히 1개일 때만 쓸 수 있습니다 (현재 "
                                    + availableDepth + "개). [N1] 처럼 레벨을 명시하세요: {"
                                    + variable.getName() + "}"));
                }
            } else if (k > availableDepth) {
                errors.add(new ValidationErrorDto(node.getPath(), where, ERR_INDEX_DEPTH,
                        "[N" + k + "] 이 반복 스코프 깊이(" + availableDepth + ")를 넘습니다: {"
                                + variable.getName() + "}"));
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* 노드 경로 검사 (명세 §8)                                              */
    /* ------------------------------------------------------------------ */

    private static void checkNodePath(TemplateNode node, String where, NodePathExpr reference,
            TemplateNode root, List<TemplateNode> order, List<ValidationErrorDto> errors) {
        String path = reference.getPath();
        List<TemplateNode> matches = resolveAll(root, path);

        if (matches.isEmpty()) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_UNKNOWN_PATH,
                    "존재하지 않는 노드 경로입니다: '" + path + "' (위치 "
                            + reference.getPosition() + ")"));
            return;
        }
        if (matches.size() > 1) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_AMBIGUOUS_PATH,
                    "동명 형제가 있어 경로가 유일하게 결정되지 않습니다: '" + path + "' ("
                            + matches.size() + "개 일치)"));
            return;
        }

        TemplateNode target = matches.get(0);
        if (target == node) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_SELF_REFERENCE,
                    "자기 자신을 참조합니다: '" + path + "'"));
            return;
        }
        if (order.indexOf(target) > order.indexOf(node)) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_FORWARD_REFERENCE,
                    "아직 생성되지 않은 뒤쪽 노드를 참조합니다: '" + path
                            + "' (참조는 DFS 전위 순서상 앞쪽 노드만 가능)"));
            return;
        }
        /*
         * 반복 스코프 체인 prefix 규칙 (§8).
         * 참조 노드의 반복 체인이 현재 노드 체인의 앞부분과 같아야 한다.
         * 다르면 "어느 반복 인스턴스의 값인지" 결정할 수 없다.
         * 예: Filter[1] 하위에서 다른 Filter 하위 노드를 참조하는 경우.
         */
        List<TemplateNode> targetChain = repeatChain(target);
        List<TemplateNode> sourceChain = repeatChain(node);
        if (!isPrefix(targetChain, sourceChain)) {
            errors.add(new ValidationErrorDto(node.getPath(), where, ERR_SCOPE_CHAIN,
                    "참조 노드의 반복 스코프가 현재 노드의 앞부분과 일치하지 않아"
                            + " 반복 인스턴스를 결정할 수 없습니다: '" + path + "'"));
        }
    }

    /**
     * 경로에 일치하는 노드를 모두 찾는다.
     * 루트 이름을 포함한 경로와 루트 아래부터 시작하는 경로를 모두 허용한다
     * (XmlGenerator.findNode 와 같은 규칙).
     */
    private static List<TemplateNode> resolveAll(TemplateNode root, String path) {
        List<TemplateNode> found = new ArrayList<TemplateNode>();
        if (path == null || path.trim().isEmpty()) {
            return found;
        }
        String[] segments = path.trim().split("\\.");
        matchFrom(root, segments, 0, found);
        for (TemplateNode child : root.getChildren()) {
            matchFrom(child, segments, 0, found);
        }
        return found;
    }

    private static void matchFrom(TemplateNode node, String[] segments, int index,
            List<TemplateNode> found) {
        if (!node.getName().equals(segments[index])) {
            return;
        }
        if (index == segments.length - 1) {
            found.add(node);
            return;
        }
        for (TemplateNode child : node.getChildren()) {
            matchFrom(child, segments, index + 1, found);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 반복 스코프 체인                                                      */
    /* ------------------------------------------------------------------ */

    /** 루트 -> 현재 노드 경로상의 반복 노드 목록 (자신 포함, 최외곽이 먼저). */
    public static List<TemplateNode> repeatChain(TemplateNode node) {
        List<TemplateNode> chain = new ArrayList<TemplateNode>();
        for (TemplateNode current = node; current != null; current = current.getParent()) {
            if (isRepeating(current)) {
                chain.add(0, current);
            }
        }
        return chain;
    }

    public static int repeatDepth(TemplateNode node, boolean includeSelf) {
        int depth = repeatChain(node).size();
        if (!includeSelf && isRepeating(node)) {
            depth--;
        }
        return depth;
    }

    public static boolean isRepeating(TemplateNode node) {
        return !node.getRepeatCountExpr().trim().isEmpty();
    }

    private static boolean isPrefix(List<TemplateNode> candidate, List<TemplateNode> full) {
        if (candidate.size() > full.size()) {
            return false;
        }
        for (int i = 0; i < candidate.size(); i++) {
            if (candidate.get(i) != full.get(i)) {
                return false;
            }
        }
        return true;
    }
}
