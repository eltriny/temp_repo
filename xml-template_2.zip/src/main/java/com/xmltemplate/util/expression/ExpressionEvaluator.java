package com.xmltemplate.util.expression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.xmltemplate.exception.ExpressionException;

/**
 * 템플릿 조건식 평가기.
 *
 * <b>파싱(parse)과 평가(eval)가 분리되어 있다.</b>
 * {@link #parse(String)} 는 리졸버 없이 {@link Expr} AST 를 만들고,
 * {@link #evaluate(Expr)} 가 그 AST 를 값으로 계산한다. 분리 이유는
 * {@link Expr} 클래스 주석 참조 (단축 평가 / 지연 인자 / 정적 검증).
 *
 * 지원 문법은 {@link ExpressionParser} 주석 참조.
 * <pre>
 *   STRING   : 작은따옴표 문자열. 예) 'VALUE'  (따옴표 이스케이프는 지원하지 않음)
 *   NUMBER   : 정수/실수. 예) 3, 1.5, -2
 *   VARIABLE : 외부 데이터 변수. 예) {PARAM}
 *   NODEPATH : 노드 전체 경로. 예) node1-1.node1-1-1
 * </pre>
 *
 * 피연산자(노드 경로, 변수, 함수)의 실제 값은 {@link ExpressionResolver} 를 통해 얻는다.
 * 비교 시 양쪽 모두 숫자로 해석되면 숫자 비교, 아니면 문자열 비교를 한다.
 *
 * 함수는 문법상 여기서 인식되지만 의미(COUNT/SUM/EXISTS 계산)는 리졸버 구현이 제공한다.
 * 구현하지 않으면 평가 시점에 명확한 오류가 난다.
 */
public class ExpressionEvaluator {

    /** 예약 리터럴 이름 (대문자만 — 명세 §4). */
    public static final String NULL_LITERAL = "NULL";

    /** 문법이 인식하는 함수 이름 (대문자만 — 명세 §4 예약어 규칙). */
    public static final Set<String> FUNCTION_NAMES =
            new HashSet<String>(Arrays.asList("COUNT", "SUM", "EXISTS"));

    /** 노드 경로 인자를 허용하는 함수 (나머지는 {변수} 만 허용 — 명세 §6). */
    static final Set<String> PATH_ARG_FUNCTIONS =
            new HashSet<String>(Arrays.asList("EXISTS"));

    /** 경고 코드 (명세 §11). */
    public static final String WARN_NULL_ORDER_COMPARISON = "NULL_ORDER_COMPARISON";

    private final ExpressionResolver resolver;

    /**
     * 식 문자열 -> AST 캐시.
     *
     * 반복 노드의 표시 조건은 회차마다 다시 평가되는데, 캐시가 없으면 회차마다
     * 같은 문자열을 다시 토크나이즈/파싱한다. 평가기는 생성 1회당 하나만 만들어지므로
     * 캐시 크기는 템플릿의 서로 다른 식 개수로 자연히 제한된다.
     */
    private final Map<String, Expr> astCache = new HashMap<String, Expr>();

    public ExpressionEvaluator(ExpressionResolver resolver) {
        this.resolver = resolver;
    }

    /* ------------------------------------------------------------------ */
    /* 공개 API                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * 식을 파싱해 AST 를 만든다. 리졸버가 필요 없으므로 정적 메서드이며,
     * 저장 시점의 문법 검증에도 그대로 쓸 수 있다.
     *
     * @throws ExpressionException 문법 오류 (메시지에 식 안의 위치 포함)
     */
    public static Expr parse(String expression) {
        List<ExpressionToken> tokens = tokenize(expression);
        ExpressionParser parser = new ExpressionParser(tokens);
        Expr ast = parser.parseExpression();
        parser.expectEnd();
        return ast;
    }

    /**
     * 식을 평가한다. 결과는 Boolean(조건식) 또는 String(값 식)이다.
     */
    public Object evaluate(String expression) {
        return evaluate(cachedAst(expression));
    }

    /**
     * 조건식을 평가해서 참/거짓을 반환한다.
     * Boolean 이 아닌 결과는 문자열 "true"(대소문자 무시)일 때만 참으로 본다.
     */
    public boolean evaluateCondition(String expression) {
        return isTruthy(evaluate(expression));
    }

    /** 이미 파싱된 AST 를 평가한다. */
    public Object evaluate(Expr ast) {
        return evalNode(ast);
    }

    /** 이미 파싱된 AST 를 조건으로 평가한다. */
    public boolean evaluateCondition(Expr ast) {
        return isTruthy(evalNode(ast));
    }

    public static boolean isTruthy(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        return "true".equalsIgnoreCase(String.valueOf(value).trim());
    }

    private Expr cachedAst(String expression) {
        Expr cached = astCache.get(expression);
        if (cached == null) {
            cached = parse(expression);
            astCache.put(expression, cached);
        }
        return cached;
    }

    /* ------------------------------------------------------------------ */
    /* 평가 (eval)                                                          */
    /* ------------------------------------------------------------------ */

    private Object evalNode(Expr node) {
        if (node instanceof LiteralExpr) {
            return ((LiteralExpr) node).getText();
        }
        if (node instanceof NullLiteralExpr) {
            /* NULL 의 값은 빈 문자열이다 (§7 - 부재와 빈 값을 구분하지 않는다). */
            return "";
        }
        if (node instanceof VarExpr) {
            return nullToEmpty(resolver.resolveVariable(((VarExpr) node).getName()));
        }
        if (node instanceof NodePathExpr) {
            return nullToEmpty(resolver.resolveNodePath(((NodePathExpr) node).getPath()));
        }
        if (node instanceof CallExpr) {
            CallExpr call = (CallExpr) node;
            /* 인자를 평가하지 않고 AST 그대로 넘긴다 (특수형식). */
            return nullToEmpty(resolver.callFunction(call.getName(), call.getArgument()));
        }
        if (node instanceof TernaryExpr) {
            TernaryExpr ternary = (TernaryExpr) node;
            /* 선택된 분기만 평가한다. */
            return isTruthy(evalNode(ternary.getCondition()))
                    ? evalNode(ternary.getWhenTrue())
                    : evalNode(ternary.getWhenFalse());
        }
        if (node instanceof BinaryExpr) {
            return evalBinary((BinaryExpr) node);
        }
        throw new ExpressionException("알 수 없는 식 노드입니다: " + node);
    }

    private Object evalBinary(BinaryExpr node) {
        String op = node.getOp();
        /* 자바의 &&/|| 가 오른쪽 evalNode 호출 자체를 건너뛴다 (단축 평가). */
        if (op.equals("&&")) {
            return Boolean.valueOf(isTruthy(evalNode(node.getLeft()))
                    && isTruthy(evalNode(node.getRight())));
        }
        if (op.equals("||")) {
            return Boolean.valueOf(isTruthy(evalNode(node.getLeft()))
                    || isTruthy(evalNode(node.getRight())));
        }
        Object left = evalNode(node.getLeft());
        Object right = evalNode(node.getRight());
        if (isOrderingOp(op)) {
            return compareOrdered(left, right, op);
        }
        return Boolean.valueOf(compare(left, right, op));
    }

    /**
     * 순서 비교(&gt; &lt; &gt;= &lt;=) 규칙 (명세 §4).
     *
     * 한쪽만 숫자인데 조용히 문자열 비교로 넘어가면 {@code "9" > "1000000"} 이
     * 참이 되는 함정이 생기므로 명확한 오류로 거부한다.
     * 다만 선택 입력 한 건이 비었다고 전체 생성을 실패시키지는 않는다.
     */
    private Boolean compareOrdered(Object left, Object right, String op) {
        String ls = String.valueOf(left);
        String rs = String.valueOf(right);

        if (ls.isEmpty() || rs.isEmpty()) {
            resolver.warn(WARN_NULL_ORDER_COMPARISON,
                    "순서 비교 '" + op + "' 의 피연산자가 NULL(부재 또는 빈 값)이라 거짓으로 평가했습니다: '"
                            + ls + "' " + op + " '" + rs + "'");
            return Boolean.FALSE;
        }
        Double ln = tryParseNumber(ls);
        Double rn = tryParseNumber(rs);
        if ((ln == null) != (rn == null)) {
            throw new ExpressionException("순서 비교 '" + op
                    + "' 의 한쪽만 숫자입니다: '" + ls + "' " + op + " '" + rs
                    + "' (문자열 비교로 조용히 넘어가지 않습니다)");
        }
        return Boolean.valueOf(compare(left, right, op));
    }

    /* ------------------------------------------------------------------ */
    /* 어휘 분석 (Lexer)                                                    */
    /* ------------------------------------------------------------------ */

    private static List<ExpressionToken> tokenize(String expr) {
        if (expr == null) {
            throw new ExpressionException("식이 비어 있습니다.");
        }
        List<ExpressionToken> tokens = new ArrayList<ExpressionToken>();
        int i = 0;
        int len = expr.length();

        while (i < len) {
            char c = expr.charAt(i);

            if (isSpace(c)) {
                i++;
                continue;
            }

            /* 문자열 리터럴 'xxx' */
            if (c == '\'') {
                int end = expr.indexOf('\'', i + 1);
                if (end < 0) {
                    throw new ExpressionException(
                            "문자열이 닫히지 않았습니다: " + expr.substring(i) + " (위치 " + i + ")");
                }
                tokens.add(new ExpressionToken(ExpressionTokenType.STRING,
                        expr.substring(i + 1, end), i));
                i = end + 1;
                continue;
            }

            /* 외부 데이터 변수 {NAME} / {NAME_[N1]_[N2]} */
            if (c == '{') {
                /*
                 * 명세 §3.1 일관성 규칙: 식에는 {{ 이스케이프가 없다.
                 * 유형 추론의 "{{ 는 변수가 아님" 판정과 토크나이저 판정이 어긋나면
                 * 추론은 FUNCTION 인데 식은 해석 불가인 상태가 생기므로 여기서 막는다.
                 * 식 안의 리터럴 중괄호는 따옴표 문자열로 쓴다: '{X}'
                 */
                if (i + 1 < len && expr.charAt(i + 1) == '{') {
                    throw new ExpressionException(
                            "식에서는 '{{' 이스케이프를 쓸 수 없습니다. 리터럴 중괄호는"
                                    + " '{X}' 처럼 따옴표 문자열로 쓰세요. (위치 " + i + ")");
                }
                int end = expr.indexOf('}', i + 1);
                if (end < 0) {
                    throw new ExpressionException(
                            "변수가 닫히지 않았습니다: " + expr.substring(i) + " (위치 " + i + ")");
                }
                String name = expr.substring(i + 1, end).trim();
                if (name.isEmpty()) {
                    throw new ExpressionException("변수 이름이 비어 있습니다. (위치 " + i + ")");
                }
                tokens.add(new ExpressionToken(ExpressionTokenType.VARIABLE, name, i));
                i = end + 1;
                continue;
            }

            /* 2문자 연산자 */
            if (i + 1 < len) {
                String two = expr.substring(i, i + 2);
                if (two.equals("==") || two.equals("!=") || two.equals(">=")
                        || two.equals("<=") || two.equals("&&") || two.equals("||")) {
                    tokens.add(new ExpressionToken(ExpressionTokenType.OP, two, i));
                    i += 2;
                    continue;
                }
            }

            /* 1문자 연산자 */
            if (c == '>' || c == '<' || c == '?' || c == ':' || c == '(' || c == ')') {
                tokens.add(new ExpressionToken(ExpressionTokenType.OP, String.valueOf(c), i));
                i++;
                continue;
            }

            /* 음수: 피연산자 위치에서 '-' 뒤에 숫자가 오는 경우 */
            if (c == '-' && i + 1 < len && Character.isDigit(expr.charAt(i + 1))
                    && expectsOperand(tokens)) {
                int start = i;
                i++;
                i = consumeNumber(expr, i);
                tokens.add(new ExpressionToken(ExpressionTokenType.NUMBER,
                        expr.substring(start, i), start));
                continue;
            }

            /* 숫자 */
            if (Character.isDigit(c)) {
                int start = i;
                i = consumeNumber(expr, i);
                /* 숫자 뒤에 노드 이름 문자가 이어지면 노드 경로로 본다. 예) 1abc (드문 경우) */
                if (i < len && isPathChar(expr.charAt(i))) {
                    i = consumePath(expr, i);
                    tokens.add(new ExpressionToken(ExpressionTokenType.NODEPATH,
                            expr.substring(start, i), start));
                } else {
                    tokens.add(new ExpressionToken(ExpressionTokenType.NUMBER,
                            expr.substring(start, i), start));
                }
                continue;
            }

            /* 노드 경로 (이름에 영문/숫자/한글/'-'/'_'/'.' 허용) */
            if (isPathStartChar(c)) {
                int start = i;
                i = consumePath(expr, i);
                tokens.add(new ExpressionToken(ExpressionTokenType.NODEPATH,
                        expr.substring(start, i), start));
                continue;
            }

            throw new ExpressionException("해석할 수 없는 문자입니다: '" + c + "' (위치 " + i + ")");
        }

        tokens.add(new ExpressionToken(ExpressionTokenType.END, "", len));
        return tokens;
    }

    /**
     * 식에서 무시하는 공백. 명시적 집합으로 제한한다.
     * (Character.isWhitespace 는 U+00A0 등 판정이 구현·언어별로 갈리는 문자를 포함한다.)
     */
    private static boolean isSpace(char c) {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n';
    }

    /** 직전 토큰 기준으로 다음에 피연산자가 와야 하는 위치인지 판단 (음수 판별용). */
    private static boolean expectsOperand(List<ExpressionToken> tokens) {
        if (tokens.isEmpty()) {
            return true;
        }
        ExpressionToken last = tokens.get(tokens.size() - 1);
        return last.type == ExpressionTokenType.OP && !last.text.equals(")");
    }

    private static int consumeNumber(String expr, int i) {
        int len = expr.length();
        while (i < len && Character.isDigit(expr.charAt(i))) {
            i++;
        }
        if (i < len && expr.charAt(i) == '.' && i + 1 < len && Character.isDigit(expr.charAt(i + 1))) {
            i++;
            while (i < len && Character.isDigit(expr.charAt(i))) {
                i++;
            }
        }
        return i;
    }

    private static boolean isPathStartChar(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isPathChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '-' || c == '.';
    }

    private static int consumePath(String expr, int i) {
        int len = expr.length();
        while (i < len && isPathChar(expr.charAt(i))) {
            i++;
        }
        /* 경로 끝의 '.' 은 경로에 포함하지 않는다. */
        while (i > 0 && expr.charAt(i - 1) == '.') {
            i--;
        }
        return i;
    }

    /* ------------------------------------------------------------------ */
    /* 변수 분해 — 명세 §4 렉서 전략                                         */
    /* ------------------------------------------------------------------ */

    /**
     * 중괄호 안의 내용을 {@code VAR_NAME ( '_' indexRef )*} 로 분해한다.
     *
     * <b>모호성과 해소 규칙</b>: {@code VAR_NAME} 도 {@code _} 를 허용하고 인덱스
     * 참조의 구분자도 {@code _} 라서, {@code PARAM_FILTER_ITEM_[N1]} 에서 이름이
     * 어디서 끝나는지가 문법만으로는 결정되지 않는다. 명세 §4 에 따라
     * <b>{@code _[N} 시퀀스를 최장일치로 우선 스캔</b>해서 그 지점부터를 인덱스
     * 참조 구간으로 확정한다.
     *
     * {@code _[N} 이 없으면 전체가 이름이다. {@link VarExpr#getName()} 은
     * 중괄호 안 원문을 그대로 유지한다.
     */
    static VarExpr buildVariable(int position, String raw) {
        int refStart = indexOfIndexRefStart(raw);
        if (refStart < 0) {
            return new VarExpr(position, raw, raw, Collections.<Integer>emptyList());
        }

        String baseName = raw.substring(0, refStart);
        /*
         * 인덱스 표기만 있고 기준 이름이 없으면(예: {_[N1]}) 조회할 키를 만들 수 없다.
         * 다중 depth 반복이 키를 "기준이름_인덱스..." 로 조합하므로, 빈 기준 이름을
         * 통과시키면 나중에 "_1" 같은 엉뚱한 키를 찾게 된다. 여기서 막는다.
         */
        if (baseName.isEmpty()) {
            throw new ExpressionException("변수 '" + raw
                    + "' 에 인덱스 표기 앞의 이름이 없습니다. (위치 " + position + ")");
        }
        List<Integer> refs = new ArrayList<Integer>();

        int i = refStart;
        while (i < raw.length()) {
            /* 여기 도달했다면 '_[N' 으로 시작하는 것이 이미 확인된 상태다. */
            if (!startsWithIndexRef(raw, i)) {
                throw new ExpressionException("변수 '" + raw
                        + "' 의 인덱스 표기 뒤에 해석할 수 없는 내용이 있습니다: '"
                        + raw.substring(i) + "' (위치 " + position + ")");
            }
            int close = raw.indexOf(']', i);
            if (close < 0) {
                throw new ExpressionException("변수 '" + raw
                        + "' 의 인덱스 참조가 닫히지 않았습니다. (위치 " + position + ")");
            }
            /* '_[N' 3글자 다음부터 ']' 앞까지가 레벨 숫자 (없으면 축약형 [N]) */
            String levelText = raw.substring(i + 3, close);
            refs.add(Integer.valueOf(parseIndexLevel(levelText, raw, position)));
            i = close + 1;
        }
        return new VarExpr(position, raw, baseName, refs);
    }

    /** {@code [Nk]} 의 k 를 해석한다. 비어 있으면 축약형 {@code [N]}. */
    private static int parseIndexLevel(String levelText, String raw, int position) {
        if (levelText.isEmpty()) {
            return VarExpr.SHORTHAND_LEVEL;
        }
        for (int i = 0; i < levelText.length(); i++) {
            if (!Character.isDigit(levelText.charAt(i))) {
                throw new ExpressionException("변수 '" + raw + "' 의 인덱스 표기가 잘못되었습니다: '[N"
                        + levelText + "]' ([N] 또는 [N1], [N2] ... 형식, 위치 " + position + ")");
            }
        }
        int level;
        try {
            level = Integer.parseInt(levelText);
        } catch (NumberFormatException e) {
            throw new ExpressionException("변수 '" + raw + "' 의 인덱스 레벨이 너무 큽니다: '[N"
                    + levelText + "]' (위치 " + position + ")");
        }
        /* 명세 §5.1: 레벨은 1부터. [N0] 은 오류. */
        if (level < 1) {
            throw new ExpressionException("변수 '" + raw
                    + "' 의 인덱스 레벨은 1 이상이어야 합니다: '[N" + levelText
                    + "]' (위치 " + position + ")");
        }
        return level;
    }

    /** 최장일치로 첫 {@code _[N} 위치를 찾는다. 없으면 -1. */
    private static int indexOfIndexRefStart(String raw) {
        for (int i = 0; i + 2 < raw.length(); i++) {
            if (startsWithIndexRef(raw, i)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean startsWithIndexRef(String raw, int i) {
        return i + 2 < raw.length()
                && raw.charAt(i) == '_' && raw.charAt(i + 1) == '[' && raw.charAt(i + 2) == 'N';
    }

    /** 순서 비교 연산자 (동등 비교 ==/!= 제외). */
    public static boolean isOrderingOp(String op) {
        return op.equals(">") || op.equals("<") || op.equals(">=") || op.equals("<=");
    }

    static boolean isComparisonOp(String op) {
        return op.equals("==") || op.equals("!=") || op.equals(">")
                || op.equals("<") || op.equals(">=") || op.equals("<=");
    }

    private static String nullToEmpty(String s) {
        return (s == null) ? "" : s;
    }

    /**
     * 두 값을 비교한다. 양쪽 모두 숫자면 숫자 비교, 아니면 문자열 비교.
     */
    private static boolean compare(Object left, Object right, String op) {
        String ls = String.valueOf(left);
        String rs = String.valueOf(right);
        Double ln = tryParseNumber(ls);
        Double rn = tryParseNumber(rs);

        int cmp;
        if (ln != null && rn != null) {
            cmp = ln.compareTo(rn);
        } else {
            cmp = ls.compareTo(rs);
        }

        if (op.equals("==")) {
            return cmp == 0;
        }
        if (op.equals("!=")) {
            return cmp != 0;
        }
        if (op.equals(">")) {
            return cmp > 0;
        }
        if (op.equals("<")) {
            return cmp < 0;
        }
        if (op.equals(">=")) {
            return cmp >= 0;
        }
        return cmp <= 0; /* <= */
    }

    private static Double tryParseNumber(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        if (t.isEmpty()) {
            return null;
        }
        /*
         * Double.valueOf 는 "10d", "1.5f", "0x1p3" 같은 자바 전용 표기도 허용하는데,
         * 명세 §4 의 NUMBER 는 십진 표기만이다. 자바 전용 표기는 숫자로 보지 않는다.
         */
        char last = t.charAt(t.length() - 1);
        if (last == 'd' || last == 'D' || last == 'f' || last == 'F') {
            return null;
        }
        String body = (t.charAt(0) == '+' || t.charAt(0) == '-') ? t.substring(1) : t;
        if (body.startsWith("0x") || body.startsWith("0X")) {
            return null;
        }
        try {
            return Double.valueOf(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
