package com.xmltemplate.util.expression;

/**
 * 변수 이름 → 값.
 *
 * 단일 메서드라 호출부는 람다나 메서드 참조로 넘긴다
 * (예: {@code VariableText.substitute(text, this::lookupVariable)}).
 */
public interface VariableLookup {
    String valueOf(String name);
}
