package com.xmltemplate.util.expression;

import java.util.Collections;
import java.util.List;

/**
 * 함수 호출 {@code COUNT({X})} / {@code SUM({X})} / {@code EXISTS(...)}.
 *
 * <b>인자는 평가되지 않은 AST 그대로 보관된다.</b> COUNT/SUM 은 인자를 "값"이
 * 아니라 "이름"으로 받는 특수형식이기 때문이다. 인자를 먼저 평가하는 일반적인
 * 함수 호출 구조로 구현하면 빈 문자열이 넘어가 예외 없이 항상 0을 반환한다.
 */
public final class CallExpr extends Expr {

    private final String name;
    private final Expr argument;

    public CallExpr(int position, String name, Expr argument) {
        super(position);
        this.name = name;
        this.argument = argument;
    }

    public String getName() {
        return name;
    }

    /** 평가되지 않은 인자 AST ({@link VarExpr} 또는 {@link NodePathExpr}). */
    public Expr getArgument() {
        return argument;
    }

    /**
     * 인자는 {@link #children()} 에 포함시킨다 — 정적 검증기는 인자 안의
     * 인덱스 참조나 노드 경로도 검사해야 하기 때문이다. 평가기는 children()
     * 을 쓰지 않고 {@link #getArgument()} 를 직접 넘기므로 지연 평가는 유지된다.
     */
    @Override
    public List<Expr> children() {
        return Collections.singletonList(argument);
    }

    @Override
    public String toString() {
        return name + "(" + argument + ")";
    }
}
