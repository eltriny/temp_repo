package com.xmltemplate.util.expression;

/** 리터럴. 문자열 {@code 'abc'} 또는 숫자 {@code 3}, {@code -1.5}. */
public final class LiteralExpr extends Expr {

    private final String text;
    private final boolean string;

    public LiteralExpr(int position, String text, boolean string) {
        super(position);
        this.text = text;
        this.string = string;
    }

    public String getText() {
        return text;
    }

    @Override
    public String toString() {
        return string ? "'" + text + "'" : text;
    }
}
