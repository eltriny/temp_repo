package com.xmltemplate.util.expression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 표현식 AST (추상 구문 트리)의 공통 베이스.
 *
 * {@link ExpressionEvaluator} 의 parse 단계가 만들고 eval 단계가 소비한다.
 * 파싱과 평가를 분리한 이유는 세 가지다.
 *
 *  1. <b>단축 평가</b> — 파싱과 평가가 붙어 있으면 {@code a || b} 의 b 도, 삼항의
 *     선택되지 않은 분기도 무조건 평가된다. AST 가 있어야 명세 §4 의
 *     "&amp;&amp;/|| 단축 평가 보장, 삼항은 선택된 분기만 평가"를 지킬 수 있다.
 *  2. <b>지연 인자</b> — {@code COUNT({X})} 는 특수형식이라 인자를 값으로 평가하면
 *     안 된다(빈 문자열이 넘어가 항상 0이 된다). {@link CallExpr} 은 인자를 평가하지 않은
 *     AST 그대로 들고 있는다.
 *  3. <b>정적 검증</b> — 저장 시점에 미지 노드 경로/전방 참조/인덱스 깊이를 검사하려면
 *     평가 없이 트리를 순회할 수 있어야 한다. {@link #children()} 이 그 통로다.
 *
 * 모든 노드는 원본 식 문자열 안에서의 시작 위치를 들고 있어 오류 메시지에
 * 위치를 표시할 수 있다.
 *
 * <b>하위 클래스는 전부 별도 파일이다</b> — 이름이 지나치게 일반적이 되지 않도록
 * {@code Expr} 접미사를 붙였다({@link LiteralExpr} 등). 생성자가 {@code protected} 인 것도
 * 하위 클래스가 다른 파일이 되었기 때문이다.
 */
public abstract class Expr {

    private final int position;

    protected Expr(int position) {
        this.position = position;
    }

    /** 원본 식 문자열에서 이 노드가 시작하는 위치 (0-base). */
    public int getPosition() {
        return position;
    }

    /** 하위 식 목록. 정적 검증기가 트리를 순회할 때 쓴다. 잎 노드는 빈 목록. */
    public List<Expr> children() {
        return Collections.emptyList();
    }

    /** 트리 전체를 전위 순서로 평탄화한다 (정적 검증 편의용). */
    public final List<Expr> flatten() {
        List<Expr> all = new ArrayList<Expr>();
        collect(this, all);
        return all;
    }

    private static void collect(Expr node, List<Expr> out) {
        out.add(node);
        for (Expr child : node.children()) {
            collect(child, out);
        }
    }
}
