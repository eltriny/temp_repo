package com.xmltemplate.util.expression;

/**
 * 예약 리터럴 {@code NULL} (명세 §7).
 *
 * <b>값으로는 빈 문자열</b>이다. §7 이 NULL 을 "키/경로 부재 <b>또는</b> 빈 문자열"로
 * 정의하고 {@code {X} == NULL} 을 {@code {X} == ''} 와 동치로 규정하므로, 별도
 * 센티널을 두면 오히려 {@code NULL == ''} 를 참으로 만들기 위한 특례가 필요해진다.
 *
 * 그래도 <b>AST 에서는 문자열 리터럴과 구분</b>한다. "리터럴 NULL 을 순서 비교에
 * 쓰면 정적 오류"(§7)라는 규칙은 토큰 종류를 알아야 검사할 수 있기 때문이다.
 */
public final class NullLiteralExpr extends Expr {

    public NullLiteralExpr(int position) {
        super(position);
    }

    @Override
    public String toString() {
        return "NULL";
    }
}
