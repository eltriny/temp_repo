package com.xmltemplate.util.expression;

import java.util.Arrays;
import java.util.List;

/** 삼항 연산 {@code 조건 ? 참값 : 거짓값}. 선택된 분기만 평가된다. */
public final class TernaryExpr extends Expr {

    private final Expr condition;
    private final Expr whenTrue;
    private final Expr whenFalse;

    public TernaryExpr(int position, Expr condition, Expr whenTrue, Expr whenFalse) {
        super(position);
        this.condition = condition;
        this.whenTrue = whenTrue;
        this.whenFalse = whenFalse;
    }

    public Expr getCondition() {
        return condition;
    }

    public Expr getWhenTrue() {
        return whenTrue;
    }

    public Expr getWhenFalse() {
        return whenFalse;
    }

    @Override
    public List<Expr> children() {
        return Arrays.asList(condition, whenTrue, whenFalse);
    }

    @Override
    public String toString() {
        return "(" + condition + " ? " + whenTrue + " : " + whenFalse + ")";
    }
}
