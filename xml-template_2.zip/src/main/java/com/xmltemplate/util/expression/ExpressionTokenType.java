package com.xmltemplate.util.expression;

/** 식 토큰의 종류. */
enum ExpressionTokenType {
    STRING,
    NUMBER,
    VARIABLE,
    NODEPATH,
    OP,
    END
}
