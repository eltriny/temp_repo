package com.xmltemplate.util.expression;

/** 노드 전체 경로 {@code catalog.book.price}. */
public final class NodePathExpr extends Expr {

    private final String path;

    public NodePathExpr(int position, String path) {
        super(position);
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    @Override
    public String toString() {
        return path;
    }
}
