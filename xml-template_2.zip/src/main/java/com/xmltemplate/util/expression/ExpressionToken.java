package com.xmltemplate.util.expression;

/**
 * 식 토큰 하나. 어휘 분석기({@link ExpressionEvaluator})가 만들고
 * {@link ExpressionParser} 가 소비하는 패키지 내부 타입이다.
 */
final class ExpressionToken {

    final ExpressionTokenType type;
    final String text;
    /** 원본 식 문자열에서의 시작 위치 (0-base). 오류 메시지용. */
    final int position;

    ExpressionToken(ExpressionTokenType type, String text, int position) {
        this.type = type;
        this.text = text;
        this.position = position;
    }
}
