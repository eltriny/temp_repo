package com.xmltemplate.util.expression;

import java.util.Collection;

/**
 * 텍스트 안의 {@code {변수}} 와 리터럴 중괄호 이스케이프 규칙 (명세 §3.1).
 *
 * 노드 값·속성값의 치환(생성기)과 참조 변수 수집(임포터)이 <b>같은 판정</b>을 쓰도록
 * 한 곳에 모았다. 갈라져 있으면 "치환은 리터럴로 봤는데 변수 목록에는 올라오는"
 * 식의 불일치가 생긴다.
 *
 * 스캐너는 여는 중괄호부터 <b>첫 닫는 괄호까지</b>를 이름으로 본다. 리터럴
 * 중괄호는 §3.1 에 따라 {@code {{}/{@code }}} 로 이스케이프해야 한다.
 */
public final class VariableText {

    private VariableText() {
    }

    /**
     * {@code {변수}} 를 치환하면서 리터럴 중괄호 이스케이프를 <b>같은 패스에서</b> 해제한다.
     *
     * <b>왜 한 패스여야 하는가</b>: 해제와 치환을 나누면 어느 쪽을 먼저 해도 깨진다.
     * <ul>
     *   <li>먼저 해제하면 {@code 총 {{X}} {CNT} 건} 이 {@code 총 {X} {CNT} 건} 이 되어
     *       {@code {X}} 까지 변수로 치환된다 (리터럴이어야 할 것이 값이 됨).</li>
     *   <li>먼저 치환하고 전체를 해제하면, 치환된 <b>값</b> 안의 중괄호까지 해제된다.</li>
     * </ul>
     */
    public static String substitute(String text, VariableLookup lookup) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder(text.length());
        int i = 0;
        int len = text.length();
        while (i < len) {
            char c = text.charAt(i);

            if (isEscapedBrace(text, i)) {
                sb.append(c);
                i += 2;
                continue;
            }
            if (c == '{') {
                int end = text.indexOf('}', i + 1);
                if (end < 0) {
                    /* 닫히지 않은 중괄호는 리터럴로 둔다. */
                    sb.append(c);
                    i++;
                    continue;
                }
                String name = text.substring(i + 1, end).trim();
                if (name.isEmpty()) {
                    sb.append(text, i, end + 1);
                } else {
                    /* 치환된 값은 이스케이프 해제 대상이 아니다 — 그대로 붙인다. */
                    sb.append(nullToEmpty(lookup.valueOf(name)));
                }
                i = end + 1;
                continue;
            }
            sb.append(c);
            i++;
        }
        return sb.toString();
    }

    /**
     * 텍스트가 참조하는 변수 이름을 등장 순으로 모은다.
     *
     * {@link #substitute} 와 <b>같은 판정</b>을 써야 한다 — 치환에서 리터럴로 본
     * {@code {{LIT}}} 가 변수 목록에는 올라오면 사용자가 있지도 않은 키를 찾게 된다.
     */
    public static void collectNames(String text, Collection<String> out) {
        if (text == null || text.isEmpty()) {
            return;
        }
        int i = 0;
        int len = text.length();
        while (i < len) {
            if (isEscapedBrace(text, i)) {
                i += 2;
                continue;
            }
            if (text.charAt(i) == '{') {
                int end = text.indexOf('}', i + 1);
                if (end < 0) {
                    i++;
                    continue;
                }
                String name = text.substring(i + 1, end).trim();
                if (!name.isEmpty()) {
                    out.add(name);
                }
                i = end + 1;
                continue;
            }
            i++;
        }
    }

    /**
     * 리터럴 중괄호 이스케이프만 해제한다 ({@code {{} -> {@code {}).
     * 변수 치환이 없는 FIXED 값에 쓴다.
     */
    public static String unescapeBraces(String text) {
        if (text == null || (text.indexOf('{') < 0 && text.indexOf('}') < 0)) {
            return text;
        }
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            sb.append(text.charAt(i));
            if (isEscapedBrace(text, i)) {
                i++;
            }
        }
        return sb.toString();
    }

    /** 위치 i 에서 {@code {{} 또는 {@code }}} 가 시작하는지. */
    private static boolean isEscapedBrace(String text, int i) {
        char c = text.charAt(i);
        return (c == '{' || c == '}')
                && i + 1 < text.length() && text.charAt(i + 1) == c;
    }

    private static String nullToEmpty(String s) {
        return (s == null) ? "" : s;
    }
}
