package com.xmltemplate.util.expression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 외부 데이터 변수 {@code {NAME}} / {@code {NAME_[N1]_[N2]}}.
 *
 * 명세 §4 의 {@code variable := '{' VAR_NAME ( '_' indexRef )* '}'} 를 분해해
 * 보관한다. {@link #getName()} 은 <b>중괄호 안 원문 그대로</b>를 돌려주고,
 * 인덱스를 해석하는 쪽(다중 depth 반복)은 {@link #getBaseName()} 과
 * {@link #getIndexRefs()} 를 쓴다.
 */
public final class VarExpr extends Expr {

    /** {@code [N]} 축약형이 쓰인 레벨 값. 반복 조상이 정확히 1개일 때만 허용된다(§5.1). */
    public static final int SHORTHAND_LEVEL = 0;

    private final String name;
    private final String baseName;
    private final List<Integer> indexRefs;

    public VarExpr(int position, String name, String baseName, List<Integer> indexRefs) {
        super(position);
        this.name = name;
        this.baseName = baseName;
        this.indexRefs = Collections.unmodifiableList(new ArrayList<Integer>(indexRefs));
    }

    /** 중괄호 안 원문 (인덱스 표기 포함). */
    public String getName() {
        return name;
    }

    /** 인덱스 표기를 제외한 이름. 예) {@code PARAM_FILTER_ITEM_[N1]_[N2]} -> {@code PARAM_FILTER_ITEM} */
    public String getBaseName() {
        return baseName;
    }

    /**
     * 인덱스 참조 레벨 목록 (왼쪽부터 = 바깥 반복부터).
     * {@code [Nk]} 는 k, {@code [N]} 축약형은 {@link #SHORTHAND_LEVEL}(0).
     * 인덱스 표기가 없으면 빈 목록.
     */
    public List<Integer> getIndexRefs() {
        return indexRefs;
    }

    /** 인덱스 표기가 하나라도 있으면 true. */
    public boolean hasIndexRefs() {
        return !indexRefs.isEmpty();
    }

    @Override
    public String toString() {
        return "{" + name + "}";
    }
}
