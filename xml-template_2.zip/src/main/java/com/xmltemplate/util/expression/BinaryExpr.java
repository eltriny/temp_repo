package com.xmltemplate.util.expression;

import java.util.Arrays;
import java.util.List;

/** 이항 연산: 비교({@code == != > < >= <=}) 또는 논리({@code && ||}). */
public final class BinaryExpr extends Expr {

    private final String op;
    private final Expr left;
    private final Expr right;

    public BinaryExpr(int position, String op, Expr left, Expr right) {
        super(position);
        this.op = op;
        this.left = left;
        this.right = right;
    }

    public String getOp() {
        return op;
    }

    public Expr getLeft() {
        return left;
    }

    public Expr getRight() {
        return right;
    }

    @Override
    public List<Expr> children() {
        return Arrays.asList(left, right);
    }

    @Override
    public String toString() {
        return "(" + left + " " + op + " " + right + ")";
    }
}
