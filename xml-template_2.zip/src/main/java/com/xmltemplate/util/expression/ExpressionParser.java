package com.xmltemplate.util.expression;

import java.util.List;

import com.xmltemplate.exception.ExpressionException;

/**
 * 구문 분석기 — <b>AST 를 만들 뿐 값을 계산하지 않는다</b>.
 *
 * 문법 (우선순위 낮은 것부터):
 * <pre>
 *   expr       := ternary
 *   ternary    := or ( '?' ternary ':' ternary )?
 *   or         := and ( '||' and )*
 *   and        := comparison ( '&amp;&amp;' comparison )*
 *   comparison := operand ( ('=='|'!='|'&gt;='|'&lt;='|'&gt;'|'&lt;') operand )?
 *   operand    := '(' expr ')' | STRING | NUMBER | VARIABLE | FUNCALL | NODEPATH
 *   FUNCALL    := ('COUNT'|'SUM') '(' VARIABLE ')' | 'EXISTS' '(' (VARIABLE|NODEPATH) ')'
 * </pre>
 */
final class ExpressionParser {

    private final List<ExpressionToken> tokens;
    private int pos = 0;

    ExpressionParser(List<ExpressionToken> tokens) {
        this.tokens = tokens;
    }

    Expr parseExpression() {
        return parseTernary();
    }

    /** ternary := or ( '?' ternary ':' ternary )? */
    private Expr parseTernary() {
        Expr condition = parseOr();
        ExpressionToken questionMark = peek();
        if (matchOp("?")) {
            Expr whenTrue = parseTernary();
            expectOp(":");
            Expr whenFalse = parseTernary();
            return new TernaryExpr(questionMark.position, condition, whenTrue, whenFalse);
        }
        return condition;
    }

    /** or := and ( '||' and )*  — 좌결합 */
    private Expr parseOr() {
        Expr left = parseAnd();
        while (true) {
            ExpressionToken op = peek();
            if (!matchOp("||")) {
                return left;
            }
            left = new BinaryExpr(op.position, "||", left, parseAnd());
        }
    }

    /** and := comparison ( '&&' comparison )*  — 좌결합 */
    private Expr parseAnd() {
        Expr left = parseComparison();
        while (true) {
            ExpressionToken op = peek();
            if (!matchOp("&&")) {
                return left;
            }
            left = new BinaryExpr(op.position, "&&", left, parseComparison());
        }
    }

    /** comparison := operand ( op operand )? */
    private Expr parseComparison() {
        Expr left = parseOperand();
        ExpressionToken t = peek();
        if (t.type == ExpressionTokenType.OP && ExpressionEvaluator.isComparisonOp(t.text)) {
            pos++;
            return new BinaryExpr(t.position, t.text, left, parseOperand());
        }
        return left;
    }

    private Expr parseOperand() {
        ExpressionToken t = peek();
        switch (t.type) {
            case STRING:
                pos++;
                return new LiteralExpr(t.position, t.text, true);
            case NUMBER:
                pos++;
                return new LiteralExpr(t.position, t.text, false);
            case VARIABLE:
                pos++;
                return ExpressionEvaluator.buildVariable(t.position, t.text);
            case NODEPATH:
                pos++;
                /* 이름 바로 뒤에 '(' 가 오면 함수 호출이다. */
                if (peek().type == ExpressionTokenType.OP && peek().text.equals("(")) {
                    return parseCall(t);
                }
                /* 예약어는 대문자만 (명세 §4). 'null' 은 평범한 노드 이름이다. */
                if (ExpressionEvaluator.NULL_LITERAL.equals(t.text)) {
                    return new NullLiteralExpr(t.position);
                }
                return new NodePathExpr(t.position, t.text);
            case OP:
                if (t.text.equals("(")) {
                    pos++;
                    Expr inner = parseExpression();
                    expectOp(")");
                    return inner;
                }
                break;
            default:
                break;
        }
        throw new ExpressionException("피연산자가 필요한 위치에 '" + t.text
                + "' 이(가) 있습니다. (위치 " + t.position + ")");
    }

    /**
     * 함수 호출을 파싱한다. 이름 토큰은 이미 소비된 상태로 들어온다.
     *
     * 인자는 <b>평가하지 않고</b> 피연산자 하나만 받아 그대로 AST 에 보관한다.
     * COUNT/SUM 은 {변수} 만 허용한다 (명세 §6.1 - 중괄호 없는 COUNT(X) 는 오류).
     */
    private Expr parseCall(ExpressionToken nameToken) {
        String name = nameToken.text;
        if (!ExpressionEvaluator.FUNCTION_NAMES.contains(name)) {
            throw new ExpressionException("알 수 없는 함수입니다: '" + name
                    + "' (사용 가능: " + ExpressionEvaluator.FUNCTION_NAMES
                    + ", 위치 " + nameToken.position + ")");
        }
        expectOp("(");
        Expr argument = parseOperand();
        expectOp(")");

        boolean pathAllowed = ExpressionEvaluator.PATH_ARG_FUNCTIONS.contains(name);
        boolean valid = (argument instanceof VarExpr)
                || (pathAllowed && argument instanceof NodePathExpr);
        if (!valid) {
            throw new ExpressionException(name + " 의 인자는 "
                    + (pathAllowed ? "{변수} 또는 노드 경로" : "{변수}")
                    + " 형식이어야 합니다: " + argument
                    + " (위치 " + argument.getPosition() + ")");
        }
        return new CallExpr(nameToken.position, name, argument);
    }

    private boolean matchOp(String op) {
        ExpressionToken t = peek();
        if (t.type == ExpressionTokenType.OP && t.text.equals(op)) {
            pos++;
            return true;
        }
        return false;
    }

    private void expectOp(String op) {
        ExpressionToken t = peek();
        if (!matchOp(op)) {
            throw new ExpressionException("'" + op + "' 이(가) 필요합니다. (현재: '"
                    + t.text + "', 위치 " + t.position + ")");
        }
    }

    void expectEnd() {
        ExpressionToken t = peek();
        if (t.type != ExpressionTokenType.END) {
            throw new ExpressionException("식 끝에 해석할 수 없는 내용이 있습니다: '"
                    + t.text + "' (위치 " + t.position + ")");
        }
    }

    private ExpressionToken peek() {
        return tokens.get(pos);
    }
}
