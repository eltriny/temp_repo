package com.xmltemplate.util.expression;

import com.xmltemplate.exception.ExpressionException;

/** 노드 경로/외부 변수/함수의 값을 제공하는 인터페이스. XML 생성기가 구현한다. */
public interface ExpressionResolver {

    String resolveNodePath(String path);

    String resolveVariable(String name);

    /**
     * 함수 호출. 인자는 <b>평가되지 않은 AST 그대로</b> 전달된다
     * (COUNT/SUM 은 인자를 값이 아니라 이름으로 받는 특수형식이기 때문).
     *
     * 기본 구현은 오류다. 함수를 지원하는 생성기가 재정의한다.
     */
    default String callFunction(String name, Expr argument) {
        throw new ExpressionException("지원하지 않는 함수입니다: " + name);
    }

    /**
     * 생성 중 경고를 보고한다 (명세 §11).
     *
     * 평가된 피연산자에서만 호출된다. 경고를 모으려고 단축 평가를 우회하는 사전
     * 순회는 명세 §4 가 금지한다 — 평가되지 않은 가지의 경고는 원래 없는 것이다.
     */
    default void warn(String code, String message) {
        /* 기본은 무시. 경고를 수집하는 생성기가 재정의한다. */
    }
}
