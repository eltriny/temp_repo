package com.xmltemplate.util.xml;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * 파서 오류를 예외로만 전달하는 핸들러.
 *
 * 기본 핸들러는 치명적 오류를 stderr 에 "[Fatal Error] ..." 로 먼저 출력한 뒤
 * 던진다. 어차피 예외로 400 을 만들어 응답하므로, 악의적 요청 한 건마다
 * 서버 로그가 오염되는 것을 막는다.
 *
 * 메서드가 3개라 람다로 쓸 수 없어 별도 클래스로 둔다.
 */
public final class ThrowingXmlErrorHandler implements ErrorHandler {

    @Override
    public void warning(SAXParseException e) throws SAXException {
        /* 경고는 무시한다 (파싱은 계속 진행) */
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        throw e;
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        throw e;
    }
}
