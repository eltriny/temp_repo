package com.xmltemplate.util.xml;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.xmltemplate.exception.XmlSecurityException;

/**
 * XML 파싱/직렬화 공용 진입점.
 *
 * 이 프로젝트의 <b>모든</b> XML 파싱은 이 클래스를 거친다. 파싱 지점마다
 * 팩토리를 따로 만들면 한 곳만 빠뜨려도 방어가 무너지기 때문이다.
 *
 * 방어 내용 (XXE - XML External Entity):
 *  - DOCTYPE 선언 자체를 금지한다 (엔티티 확장 공격의 진입점 차단).
 *  - 외부 일반/파라미터 엔티티, 외부 DTD 로드를 모두 끈다.
 *  - FEATURE_SECURE_PROCESSING 으로 구현체 기본 방어를 켠다.
 *  - 그래도 엔티티 해석이 시도되면 예외를 던지는
 *    EntityResolver 로 막는다 (다층 방어).
 *
 * 상한 (docs/TEMPLATE_SPEC_V2.md §9.2):
 *  - 요청/업로드 본문 10MB, 템플릿 트리 깊이 50, 템플릿 노드 수 10,000
 *
 * namespaceAware 는 명시적으로 false 로 둔다. 기존 코드가 getTagName() 결과를
 * 직접 비교하고, 노드 이름의 ':' 는 명세상 거부 대상이라 네임스페이스 인식이 필요 없다.
 */
public final class SecureXml {

    /** 요청/업로드 본문 최대 바이트 (§9.2). */
    public static final int MAX_BODY_BYTES = 10 * 1024 * 1024;

    /** 템플릿 트리 최대 깊이 (§9.2). */
    public static final int MAX_TREE_DEPTH = 50;

    /** 템플릿 한 개의 최대 노드 수 (§9.2 의 생성 상한에 대응하는 저장 측 방어선). */
    public static final int MAX_TEMPLATE_NODES = 10000;

    private static final String DISALLOW_DOCTYPE =
            "http://apache.org/xml/features/disallow-doctype-decl";
    private static final String EXTERNAL_GENERAL_ENTITIES =
            "http://xml.org/sax/features/external-general-entities";
    private static final String EXTERNAL_PARAMETER_ENTITIES =
            "http://xml.org/sax/features/external-parameter-entities";
    private static final String LOAD_EXTERNAL_DTD =
            "http://apache.org/xml/features/nonvalidating/load-external-dtd";

    /**
     * 어떤 엔티티 해석 요청도 거부하는 최후 방어선.
     * 단일 메서드 인터페이스라 람다로 둔다 — 별도 클래스 파일이 생기지 않는다.
     */
    private static final EntityResolver DENY_ENTITIES = (publicId, systemId) -> {
        throw new SAXException("외부 엔티티 참조는 허용되지 않습니다: " + systemId);
    };

    private static final ErrorHandler THROWING_ERROR_HANDLER = new ThrowingXmlErrorHandler();

    private SecureXml() {
    }

    /* ------------------------------------------------------------------ */
    /* 파싱                                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 보안 설정이 적용된 DocumentBuilder 를 만든다.
     *
     * disallow-doctype-decl 과 SECURE_PROCESSING 은 <b>필수</b>다. 지원하지 않는
     * 파서 구현이면 조용히 넘어가지 않고 예외를 던진다 (fail-closed).
     * 나머지 항목은 doctype 이 이미 금지된 상태의 중복 방어라 best-effort 로 둔다.
     */
    public static DocumentBuilder newSecureBuilder() {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dbf.setFeature(DISALLOW_DOCTYPE, true);
        } catch (ParserConfigurationException e) {
            throw new XmlSecurityException(
                    "XML 파서에 보안 설정을 적용할 수 없습니다: " + e.getMessage(), e);
        }
        setFeatureQuietly(dbf, EXTERNAL_GENERAL_ENTITIES, false);
        setFeatureQuietly(dbf, EXTERNAL_PARAMETER_ENTITIES, false);
        setFeatureQuietly(dbf, LOAD_EXTERNAL_DTD, false);
        setAttributeQuietly(dbf, XMLConstants.ACCESS_EXTERNAL_DTD, "");
        setAttributeQuietly(dbf, XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");

        dbf.setXIncludeAware(false);
        dbf.setExpandEntityReferences(false);
        dbf.setNamespaceAware(false);
        dbf.setValidating(false);

        try {
            DocumentBuilder builder = dbf.newDocumentBuilder();
            builder.setEntityResolver(DENY_ENTITIES);
            builder.setErrorHandler(THROWING_ERROR_HANDLER);
            return builder;
        } catch (ParserConfigurationException e) {
            throw new XmlSecurityException("XML 파서를 만들 수 없습니다: " + e.getMessage(), e);
        }
    }

    /** UTF-8 문자열을 파싱한다. 본문 크기 상한을 함께 검사한다. */
    public static Document parse(String xml) {
        if (xml == null) {
            throw new XmlSecurityException("XML 내용이 비어 있습니다.");
        }
        byte[] bytes = xml.getBytes(StandardCharsets.UTF_8);
        checkBodySize(bytes.length);
        return parse(new ByteArrayInputStream(bytes));
    }

    /**
     * 스트림을 파싱한다.
     *
     * @throws XmlSecurityException 문법 오류, DOCTYPE 포함, 외부 엔티티 참조 시
     */
    public static Document parse(InputStream in) {
        return parse(in, null);
    }

    /**
     * 스트림을 <b>지정한 인코딩으로</b> 파싱한다. {@code encoding} 이 null/빈 값이면
     * {@link #parse(InputStream)} 과 같다(XML 선언을 따른다).
     *
     * <b>왜 필요한가</b> (RFC 7303, 계약 §4.4): 전송 계층이 charset 을 명시했다면 그것이
     * 문서 내부 선언보다 우선한다. multipart 붙여넣기 경로가 정확히 이 경우다 — 원본
     * 바이트가 없는 텍스트를 프론트가 UTF-8 로 인코딩해 {@code application/xml;charset=UTF-8}
     * 로 보내므로, 본문에 {@code encoding="EUC-KR"} 선언이 남아 있어도 UTF-8 로 읽어야 한다.
     * 선언을 따르면 그 자리에서 한글이 깨진다.
     *
     * 반대로 파일 업로드 경로는 charset 파라미터가 없으므로 선언을 따라야 한다. 두 경우를
     * 호출자가 구분해 넘긴다.
     *
     * @throws XmlSecurityException 문법 오류, DOCTYPE 포함, 외부 엔티티 참조,
     *                              알 수 없는 인코딩 이름
     */
    public static Document parse(InputStream in, String encoding) {
        try {
            InputSource source = new InputSource(in);
            if (encoding != null && !encoding.trim().isEmpty()) {
                source.setEncoding(encoding.trim());
            }
            return newSecureBuilder().parse(source);
        } catch (XmlSecurityException e) {
            throw e;
        } catch (SAXException e) {
            throw new XmlSecurityException("XML 해석 실패: " + e.getMessage(), e);
        } catch (IOException e) {
            /* 알 수 없는 charset 이름은 UnsupportedEncodingException(IOException) 으로 온다 */
            throw new XmlSecurityException("XML 읽기 실패: " + e.getMessage(), e);
        }
    }

    /** 본문 바이트 수 상한 검사 (§9.2 - 10MB). */
    public static void checkBodySize(long bytes) {
        if (bytes > MAX_BODY_BYTES) {
            throw new XmlSecurityException("요청 본문이 너무 큽니다: " + bytes
                    + " 바이트 (최대 " + MAX_BODY_BYTES + " 바이트)");
        }
    }

    /* ------------------------------------------------------------------ */
    /* 생성 / 직렬화                                                        */
    /* ------------------------------------------------------------------ */

    /** 빈 Document 를 만든다 (XML 생성 엔진용 - 파싱하지 않지만 팩토리는 동일 설정). */
    public static Document newDocument() {
        return newSecureBuilder().newDocument();
    }

    /** UTF-8 / 들여쓰기 2칸 Transformer. */
    public static Transformer newIndentingTransformer() {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            } catch (Exception ignored) {
                /* 구현체가 지원하지 않으면 넘어간다 - 외부 스타일시트를 쓰지 않으므로 위험 없음 */
            }
            try {
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (IllegalArgumentException ignored) {
                /* 위와 같음 */
            }

            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            return transformer;
        } catch (Exception e) {
            throw new XmlSecurityException("XML 직렬화기를 만들 수 없습니다: " + e.getMessage(), e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* 유틸                                                                 */
    /* ------------------------------------------------------------------ */

    private static void setFeatureQuietly(DocumentBuilderFactory dbf, String feature, boolean value) {
        try {
            dbf.setFeature(feature, value);
        } catch (ParserConfigurationException ignored) {
            /* doctype 금지가 이미 걸려 있으므로 이 항목은 중복 방어다. */
        }
    }

    private static void setAttributeQuietly(DocumentBuilderFactory dbf, String name, String value) {
        try {
            dbf.setAttribute(name, value);
        } catch (IllegalArgumentException ignored) {
            /* JAXP 1.5 미만 구현체는 이 속성을 모른다. */
        }
    }
}
