package com.xmltemplate.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.xmltemplate.dto.GenerationResultDto;
import com.xmltemplate.dto.ImportResultDto;
import com.xmltemplate.dto.SaveResultDto;
import com.xmltemplate.dto.StructureImportResult;
import com.xmltemplate.dto.TemplateDto;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.dto.TemplateSummaryDto;
import com.xmltemplate.dto.WarningDto;
import com.xmltemplate.exception.InvalidRequestException;
import com.xmltemplate.exception.TemplateNotFoundException;
import com.xmltemplate.repository.TemplateStore;
import com.xmltemplate.util.xml.SecureXml;
import com.xmltemplate.util.template.StructureTemplateParser;
import com.xmltemplate.util.template.TemplateMapper;
import com.xmltemplate.util.template.TemplateValidator;
import com.xmltemplate.util.engine.XmlGenerator;

/**
 * 템플릿 도메인 정책 — 전송 형식과 무관한 규칙을 한 곳에 모은 계층.
 *
 * <b>왜 필요한가</b>: "언제 검증하는가", "무엇을 경고하는가"는 HTTP 나 JSON 의 문제가 아니라
 * 도메인 규칙이다. 이 로직이 컨트롤러마다 복사되면 <b>경로별 의미론이 갈라진다</b>.
 * 이 프로젝트는 같은 실패 모드를 프론트엔드 2종 시절에 이미 겪었다.
 *
 * <h3>트랜잭션 경계는 이 계층에만 있다</h3>
 * 클래스 기본이 {@code readOnly = true} 이고 쓰기 메서드만 덮어쓴다. 컨트롤러와
 * {@link TemplateStore} 에는 {@code @Transactional} 을 붙이지 않는다 — 경계가 한 계층에만
 * 있어야 어디서 열리는지가 자명하다.
 *
 * <b>DB 를 쓰지 않는 두 메서드는 {@code NOT_SUPPORTED} 로 뺀다.</b> 클래스 레벨 애노테이션
 * 때문에 그냥 두면 최대 10MB XML 파싱과 트리 검증 내내 커넥션을 잡고 있게 되어 대용량
 * 임포트가 커넥션 풀을 고갈시킨다.
 */
@Service
@Transactional(readOnly = true)
public class TemplateService {

    /** 저장 경고 코드 — 노드 이름이 예약 리터럴 NULL 과 같을 때 (§7). */
    public static final String WARN_NULL_NAMED_NODE = "NULL_NAMED_NODE";
    /** 임포트 시 어떤 인코딩으로 해석했는지 (계약 §4.4). 문서 단위라 nodePath 는 "". */
    public static final String WARN_ENCODING_USED = "ENCODING_USED";

    private final TemplateStore store;

    public TemplateService(TemplateStore store) {
        this.store = store;
    }

    /* ------------------------------------------------------------------ */
    /* 조회                                                                 */
    /* ------------------------------------------------------------------ */

    /** 템플릿 조회. 없으면 null. */
    public TemplateDto load(String name) {
        TemplateNode root = store.load(name);
        if (root == null) {
            return null;
        }
        return TemplateMapper.toDto(name, root, store.loadUpdatedAt(name));
    }

    /** 목록 (이름 + 수정 시각) — 이름 오름차순. */
    public List<TemplateSummaryDto> list() {
        return store.listSummaries();
    }

    /* ------------------------------------------------------------------ */
    /* 저장 / 삭제                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * 템플릿을 저장한다. 정적 검증(§8)을 통과해야 한다.
     *
     * 세 테이블 중 하나만 반영되면 트리가 깨지므로 한 트랜잭션으로 묶는다 — 중간에 실패하면
     * "노드는 지워졌는데 새로 안 들어간" 빈 템플릿이 남는다.
     */
    @Transactional
    public SaveResultDto save(String name, TemplateNode root) {
        if (root == null) {
            throw new InvalidRequestException("저장할 템플릿이 비어 있습니다.");
        }
        checkTreeLimits(root);
        boolean created = !store.exists(name);

        TemplateValidator.requireValid(root);

        store.save(name, root);

        SaveResultDto dto = new SaveResultDto();
        dto.name = name;
        dto.created = created;
        dto.warnings = nullNamedNodeWarnings(root);
        return dto;
    }

    /** 부분 삭제 시 고아 행이 남아 다음 저장의 PK 와 충돌하므로 한 트랜잭션으로 묶는다. */
    @Transactional
    public boolean delete(String name) {
        return store.delete(name);
    }

    /**
     * 트리 상한 검사 (§9.2) — <b>들어오는 트리 전부에 적용</b>한다.
     *
     * <b>왜 여기인가</b>: 상한 검사가 원래 XML 직렬화·임포트 경로에만 있었다. 그래서 그 경로를
     * 지나지 않는 입력(JSON 본문)은 검사 없이 통과했고, 노드를 행으로 저장하는 MariaDB 에서는
     * <b>읽을 때도 걸리지 않아 상한이 통째로 무효</b>였다(M4 실측). 메모리 저장소는 XML 을
     * 경유해 읽기에서 터졌는데, 그때는 <b>목록 조회까지 같이 죽어</b> 화면에서 그 템플릿을
     * 지울 수도 없었다.
     *
     * 검사를 형식(XML/JSON)이 아니라 <b>정책 계층</b>에 두면 전송 형식이나 저장소 구현과
     * 무관하게 걸린다. 새 진입점이 생겨도 자동으로 보호된다는 것이 요점이다.
     *
     * 임포트 경로는 파서에서 먼저 걸리므로 여기까지 오지 않는다(이중 방어).
     */
    private static void checkTreeLimits(TemplateNode root) {
        checkTreeLimits(root, 1, new int[] { 0 });
    }

    private static void checkTreeLimits(TemplateNode node, int depth, int[] nodeCount) {
        if (depth > SecureXml.MAX_TREE_DEPTH) {
            throw new InvalidRequestException("템플릿 트리 깊이가 상한을 초과했습니다 (최대 "
                    + SecureXml.MAX_TREE_DEPTH + ").");
        }
        nodeCount[0]++;
        if (nodeCount[0] > SecureXml.MAX_TEMPLATE_NODES) {
            throw new InvalidRequestException("템플릿 노드 수가 상한을 초과했습니다 (최대 "
                    + SecureXml.MAX_TEMPLATE_NODES + ").");
        }
        for (TemplateNode child : node.getChildren()) {
            checkTreeLimits(child, depth + 1, nodeCount);
        }
    }

    /**
     * 거부가 아니라 경고 — 예약 리터럴과 같은 이름의 노드.
     * 전체 경로로는 참조되므로 막을 일은 아니지만, 조용히 넘기면 사용자가 원인을 못 찾는다.
     */
    private static List<WarningDto> nullNamedNodeWarnings(TemplateNode root) {
        List<WarningDto> warnings = new ArrayList<WarningDto>();
        for (String path : TemplateValidator.findNullNamedNodes(root)) {
            warnings.add(new WarningDto(WARN_NULL_NAMED_NODE, path,
                    "노드 '" + path + "' 의 이름이 예약 리터럴 NULL 과 같습니다."
                            + " 짧은 경로 'NULL' 로는 참조할 수 없으니 전체 경로 '" + path
                            + "' 를 쓰세요."));
        }
        return warnings;
    }

    /* ------------------------------------------------------------------ */
    /* 임포트 (§3)                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * 구조 XML 을 템플릿 트리로 변환한다. <b>저장하지 않는다</b> —
     * 사용자가 추론 결과와 경고를 확인·교정한 뒤 저장하는 흐름이다.
     *
     * 정적 검증을 여기서 돌린다. 생성 시점에야 드러날 문제를 이 단계에서 목록으로
     * 돌려주기 위함이다 (§11).
     *
     * multipart 파트의 {@code Content-Type} 에 charset 이 명시돼 있으면 그 값을 넘긴다 —
     * 외부 메타데이터가 문서 내부 선언보다 우선한다(RFC 7303). 없으면 null 을 넘겨
     * 원본 바이트를 선언 기준으로 해석하게 한다.
     *
     * <b>응답의 {@code template.name} 은 비어 있다</b> — 이름 제안은 전송 계층의 정보
     * (파트 이름·파일명)에서 나오므로 컨트롤러가 채운다.
     */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public ImportResultDto importStructure(InputStream structureXml, String encoding) {
        StructureImportResult parsed = StructureTemplateParser.parse(structureXml, encoding);
        TemplateValidator.requireValid(parsed.getRoot());

        List<WarningDto> warnings = new ArrayList<WarningDto>();
        WarningDto encodingWarning = encodingUsedWarning(encoding, parsed.getDeclaredEncoding());
        if (encodingWarning != null) {
            /* 문서 단위 정보라 노드별 경고보다 앞에 둔다 */
            warnings.add(encodingWarning);
        }
        warnings.addAll(parsed.getWarnings());

        ImportResultDto dto = new ImportResultDto();
        dto.template = TemplateMapper.toDto("", parsed.getRoot(), null);
        dto.warnings = warnings;
        dto.variables = new ArrayList<String>(parsed.getVariables());
        return dto;
    }

    /**
     * 어떤 인코딩으로 읽었는지 알린다 (계약 §4.4).
     *
     * <b>왜 필요한가</b>: "EUC-KR 선언 + 실제로는 UTF-8 바이트 + charset 없음" 조합은 파서가
     * 선언대로 EUC-KR 로 읽어 <b>깨진 문자열로 200 을 통과</b>한다. 서버는 이 불일치를 감지할
     * 수 없다 — 어느 쪽이 진실인지 판단할 근거가 없기 때문이다. 그래서 "감지했다"가 아니라
     * <b>"무엇으로 해석했다"</b>를 알려 사용자가 결과를 보고 판단하게 한다.
     *
     * <b>charset 이 명시된 요청에는 경고하지 않는다.</b> 클라이언트가 인코딩을 선언한 것이라
     * 알려줄 새 정보가 없고, 붙여넣기마다 쌓이면 정작 봐야 할 경고가 묻힌다.
     *
     * @param requestedEncoding 전송 계층이 지정한 charset (없으면 null)
     * @param declaredEncoding  XML 선언의 인코딩 (선언이 없으면 null)
     * @return 경고, 또는 알릴 것이 없으면 null
     */
    private static WarningDto encodingUsedWarning(String requestedEncoding,
            String declaredEncoding) {
        if (requestedEncoding != null && !requestedEncoding.trim().isEmpty()) {
            return null;
        }
        String message = (declaredEncoding != null && !declaredEncoding.trim().isEmpty())
                ? "파트 charset 이 없어 XML 선언의 '" + declaredEncoding + "' 로 해석했습니다."
                        + " 실제 파일이 다른 인코딩이면 문자가 깨진 채 저장될 수 있으니"
                        + " 결과를 확인하세요."
                : "파트 charset 과 XML 선언이 모두 없어 기본값 'UTF-8' 로 해석했습니다."
                        + " 실제 파일이 다른 인코딩이면 문자가 깨진 채 저장될 수 있으니"
                        + " 결과를 확인하세요.";
        return new WarningDto(WARN_ENCODING_USED, "", message);
    }

    /* ------------------------------------------------------------------ */
    /* 생성 (§9)                                                            */
    /* ------------------------------------------------------------------ */

    /** 저장된 템플릿으로 생성한다. 로드 후 생성은 순수 계산이라 readOnly 로 충분하다. */
    public GenerationResultDto generate(String name, Map<String, String> data) {
        TemplateNode root = store.load(name);
        if (root == null) {
            throw new TemplateNotFoundException("템플릿이 존재하지 않습니다: " + name);
        }
        return runGenerator(root, data);
    }

    /** 저장하지 않은 템플릿으로 생성한다 (미리보기). 저장소를 조회하지 않는다. */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public GenerationResultDto preview(TemplateNode root, Map<String, String> data) {
        if (root == null) {
            throw new InvalidRequestException("미리보기할 템플릿이 없습니다.");
        }
        checkTreeLimits(root);
        return runGenerator(root, data);
    }

    private GenerationResultDto runGenerator(TemplateNode root, Map<String, String> data) {
        XmlGenerator generator = new XmlGenerator(root, data);

        GenerationResultDto dto = new GenerationResultDto();
        dto.xml = generator.generate();
        dto.warnings = new ArrayList<WarningDto>(generator.getWarnings());
        return dto;
    }
}
