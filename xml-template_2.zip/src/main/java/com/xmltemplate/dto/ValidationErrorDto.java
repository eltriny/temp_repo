package com.xmltemplate.dto;

/**
 * 검증 오류 한 건.
 *
 * 이전의 {@code TemplateValidator.ValidationError} 를 흡수했다. 프론트는 이 4필드를
 * {@code [code] nodePath (where): message} 로 조립해 사용자에게 보여주므로 <b>필드 이름이
 * 계약</b>이고, {@code where} 는 엔진 문구 그대로여야 한다 (컬럼명으로 번역 금지).
 */
public class ValidationErrorDto {

    public String nodePath;
    /** 노드 안에서의 위치 (displayCondition / repeatCountExpr / 값 / 속성 이름). */
    public String where;
    public String code;
    public String message;

    /** Jackson 용. */
    public ValidationErrorDto() {
    }

    public ValidationErrorDto(String nodePath, String where, String code, String message) {
        this.nodePath = nodePath;
        this.where = where;
        this.code = code;
        this.message = message;
    }

    /**
     * 검증 예외의 요약 메시지가 이 형식에 의존한다 (한 건당 한 줄).
     * Jackson 은 {@code getX}/{@code isX} 만 프로퍼티로 보므로 직렬화에는 영향이 없다.
     */
    @Override
    public String toString() {
        return "[" + code + "] " + nodePath + " (" + where + "): " + message;
    }
}
