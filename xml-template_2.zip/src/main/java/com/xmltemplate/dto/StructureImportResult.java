package com.xmltemplate.dto;

import java.util.Collections;
import java.util.List;

/**
 * 구조 XML 파싱 결과 — 파서와 서비스 사이의 내부 전달 타입.
 *
 * <b>{@link ImportResultDto} 로 흡수할 수 없다.</b> {@code declaredEncoding} 이 와이어에
 * 나가지 않기 때문이다 — 서비스가 이 값을 보고 "무엇으로 해석했다" 경고를 만들 뿐이다.
 * 응답 DTO 에 넣으면 계약에 없는 필드가 나가고, 빼면 경고를 만들 수 없다.
 */
public class StructureImportResult {

    private final TemplateNode root;
    private final List<WarningDto> warnings;
    private final List<String> variables;
    private final String declaredEncoding;

    public StructureImportResult(TemplateNode root, List<WarningDto> warnings,
            List<String> variables, String declaredEncoding) {
        this.root = root;
        this.warnings = Collections.unmodifiableList(warnings);
        this.variables = Collections.unmodifiableList(variables);
        this.declaredEncoding = declaredEncoding;
    }

    public TemplateNode getRoot() {
        return root;
    }

    public List<WarningDto> getWarnings() {
        return warnings;
    }

    /** 템플릿이 참조하는 외부 데이터 변수 이름 (중복 제거, 등장 순). */
    public List<String> getVariables() {
        return variables;
    }

    /**
     * XML <b>선언에 적힌</b> 인코딩. 선언이 없으면 null (그 경우 XML 규격상 UTF-8 이다).
     *
     * <b>DOM 의 {@code getInputEncoding()} 을 쓰지 않는 이유</b>: 이 파서에서는 EUC-KR 로
     * 읽은 문서에도 "UTF-8" 을 돌려준다(실측 확인). "실제로 무엇으로 읽었는지"를 그 값으로
     * 알릴 수는 없다. 선언값만 사실로 취급하고, 해석 규칙은 호출자가 표현한다.
     */
    public String getDeclaredEncoding() {
        return declaredEncoding;
    }
}
