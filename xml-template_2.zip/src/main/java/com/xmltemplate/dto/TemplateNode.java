package com.xmltemplate.dto;

import java.util.ArrayList;
import java.util.List;

import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;

/**
 * XML 템플릿의 한 노드 — <b>내부 도메인 트리</b>이지 와이어 계약이 아니다.
 *
 * JPA 엔티티(행)와 이 트리는 서로 다른 자료구조라 하나로 합칠 수 없다. 엔티티는
 * {@code (TEMPLATE_NAME, NODE_SN, PARENT_SN)} 의 평면 행이고, 엔진이 깊이 재귀하는 것은
 * 이 트리다. 엔티티 패키지에 두면 "@Entity 를 안 붙였네"라며 누군가 붙일 위험이 있어
 * {@code dto} 에 두되 <b>접미사로 구분</b>한다 — {@code *Dto} 만 전송 계약이다.
 *
 * <b>이 타입은 컨트롤러 시그니처에 절대 등장하지 않는다.</b> 등장하면 {@link #parent}
 * 역참조 때문에 Jackson 이 무한 재귀에 빠진다.
 *
 * 노드마다 아래 정보를 가진다.
 *  - name             : 생성될 XML 엘리먼트 이름 (DB: NODE_NAME)
 *  - valueType/value  : 노드 값 - 고정값/변수/함수 (DB: INPUT_TYPE / INPUT_VALUE)
 *  - valueDataType    : 값의 데이터 타입 - STRING/NUMBER (DB: INPUT_DATA_TYPE)
 *  - displayCondition : 표시 조건식 (DB: DISPLAY_COND). 비어 있으면 항상 표시,
 *                       조건식이 false 면 노드(하위 포함)를 생성하지 않는다.
 *  - repeatCondition  : 폐지된 반복 조건식 (DB: REPEAT_COND, 명세 §2).
 *                       값이 남아 있으면 저장·생성이 명확한 오류로 거부한다 —
 *                       필드를 없애고 조용히 버리면 사용자가 쓴 속성이 소리 없이
 *                       사라지므로, 거부 안내를 위해 모델에는 남겨 둔다.
 *  - repeatCountExpr  : 반복 횟수 식 (DB: REPEAT_COUNT_COND, 명세 §9.1).
 *                       평가 결과 값이 반복 횟수다 — 고정 숫자 | {PARAM} |
 *                       COUNT({X}) | 삼항식. 0 이면 미생성.
 *
 * 자식이 있는 노드는 값 대신 자식 엘리먼트를 갖는다 (value 는 무시).
 *
 * <b>일반 XML 속성은 더 이상 다루지 않는다</b> (R2 에서 기능 제거). 임포트는 속성을
 * 버리면서 {@code GENERAL_ATTR_IGNORED} 로 알리고, 저장·미리보기는 속성이 실려 오면
 * {@code GENERAL_ATTR_REMOVED} 로 거부한다 — 조용히 버리지 않는 것이 규칙이다.
 */
public class TemplateNode {

    private String name;
    private ValueType valueType = ValueType.FIXED;
    private ValueDataType valueDataType = ValueDataType.STRING;
    private String value = "";
    private String displayCondition = "";
    private String repeatCondition = "";
    private String repeatCountExpr = "";

    private TemplateNode parent;
    private final List<TemplateNode> children = new ArrayList<TemplateNode>();

    public TemplateNode(String name) {
        this.name = name;
    }

    /* ------------------------------------------------------------------ */
    /* 트리 조작                                                           */
    /* ------------------------------------------------------------------ */

    public void addChild(TemplateNode child) {
        child.parent = this;
        children.add(child);
    }

    public List<TemplateNode> getChildren() {
        return children;
    }

    public TemplateNode getParent() {
        return parent;
    }

    public boolean hasChildren() {
        return !children.isEmpty();
    }

    /** 루트로부터의 전체 경로 (예: "ROOT.node1-1.node1-1-1") */
    public String getPath() {
        if (parent == null) {
            return name;
        }
        return parent.getPath() + "." + name;
    }

    /* ------------------------------------------------------------------ */
    /* 속성 접근자                                                          */
    /* ------------------------------------------------------------------ */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ValueType getValueType() {
        return valueType;
    }

    public void setValueType(ValueType valueType) {
        this.valueType = (valueType == null) ? ValueType.FIXED : valueType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = (value == null) ? "" : value;
    }

    public String getDisplayCondition() {
        return displayCondition;
    }

    public void setDisplayCondition(String displayCondition) {
        this.displayCondition = (displayCondition == null) ? "" : displayCondition;
    }

    public String getRepeatCondition() {
        return repeatCondition;
    }

    public void setRepeatCondition(String repeatCondition) {
        this.repeatCondition = (repeatCondition == null) ? "" : repeatCondition;
    }

    public String getRepeatCountExpr() {
        return repeatCountExpr;
    }

    public void setRepeatCountExpr(String repeatCountExpr) {
        this.repeatCountExpr = (repeatCountExpr == null) ? "" : repeatCountExpr.trim();
    }

    public ValueDataType getValueDataType() {
        return valueDataType;
    }

    public void setValueDataType(ValueDataType valueDataType) {
        this.valueDataType = (valueDataType == null) ? ValueDataType.STRING : valueDataType;
    }

    @Override
    public String toString() {
        return "TemplateNode[" + getPath() + "]";
    }
}
