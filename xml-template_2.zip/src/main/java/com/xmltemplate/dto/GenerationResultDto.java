package com.xmltemplate.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 생성 결과.
 *
 * {@code xml} 을 문자열로 두는 이유: 생성된 XML 을 DOM 으로 다시 파싱해 담으면 공백 노드
 * 제거 같은 보정이 필요하고 재직렬화 과정에서 원문과 바이트가 달라질 여지가 있다.
 * 문자열 필드는 <b>엔진 출력 그대로</b>를 담아 바이트 동일성을 구조적으로 보장한다.
 * 프론트는 이 값을 재파싱·재포맷하지 않고 {@code <pre>} 에 그대로 출력한다.
 */
public class GenerationResultDto {
    public String xml;
    public List<WarningDto> warnings = new ArrayList<WarningDto>();
}
