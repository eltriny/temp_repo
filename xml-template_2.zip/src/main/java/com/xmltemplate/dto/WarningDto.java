package com.xmltemplate.dto;

/**
 * 경고 한 건.
 *
 * <b>이전에 있던 경고 타입 3종(서비스 / 임포트 파서 / 생성 엔진)을 하나로 합친 것이다.</b>
 * 세 타입의 필드가 {@code code}/{@code nodePath}/{@code message} 로 동일했고, 서비스가 하던
 * 일이 바로 이 세 타입 간 필드 복사였다. 합치면서 클래스 2개와 변환 루프 2벌이 사라졌다.
 *
 * {@code nodePath} 는 노드가 특정되지 않으면 {@code ""} 다 (null 아님) — 프론트가 그대로
 * 렌더링하므로 null 이면 화면에 "undefined" 가 뜬다. 생성 엔진의 경고는 노드가 특정되지
 * 않으므로 항상 {@code ""} 이며, 이는 이전 동작과 같다.
 */
public class WarningDto {

    public String code;
    public String nodePath = "";
    public String message;

    /** Jackson 용. */
    public WarningDto() {
    }

    public WarningDto(String code, String nodePath, String message) {
        this.code = code;
        this.nodePath = (nodePath == null) ? "" : nodePath;
        this.message = message;
    }
}
