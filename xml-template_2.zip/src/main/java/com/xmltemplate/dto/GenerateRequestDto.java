package com.xmltemplate.dto;

import java.util.Map;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import com.xmltemplate.config.DataMapDeserializer;

/** 저장분 생성 요청 (외부 시스템용). */
public class GenerateRequestDto {

    @JsonDeserialize(using = DataMapDeserializer.class)
    public Map<String, String> data;
}
