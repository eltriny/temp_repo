package com.xmltemplate.dto;

import java.util.List;

/**
 * 노드 하나의 전송 표현 — <b>평면</b> (docs/API_V4_FLAT.md §3.1).
 *
 * <h3>왜 평면인가</h3>
 * DB({@code XML_TEMPLATE_NODE})는 원래부터 평면 행이고 와이어만 중첩이었다. R4 에서 그
 * 비대칭을 없앴다. 트리 구조는 {@link #sn}/{@link #parentSn} 두 숫자로만 표현한다.
 *
 * <h3>{@code sn} 은 DB 의 {@code NODE_SN} 이 아니다</h3>
 * <b>이 요청/응답 안에서만 유효한 위치 번호</b>다 (1..n, 반드시 배열 인덱스 + 1).
 * 저장은 전건 삭제 후 재삽입이라 DB 의 전역 {@code NODE_SN} 은 저장할 때마다 새로 발급된다 —
 * 그 값을 와이어에 실으면 "이 번호를 유지해 달라"는, <b>서버가 지킬 수 없는 기대</b>를
 * 클라이언트가 갖게 된다. 그래서 응답에서도 항상 1..n 으로 재부여한다.
 * 클라이언트는 이 값을 상태로 보관해서는 안 된다.
 *
 * 자바 타입을 {@code Integer} 로 둔 것도 같은 이유다 — 노드 상한이 10,000 이라 범위는
 * 충분하고, <b>타입 자체가 "이건 DB 의 {@code Long NODE_SN} 이 아니다"를 말해 준다.</b>
 * JSON 표현은 어차피 같다.
 *
 * <h3>폐지된 필드를 계약에서 빼지 않는 이유</h3>
 * {@code repeatCondition}(문법 v2 에서 폐지), {@code attributes}(R2 에서 폐지),
 * {@code children}(R4 에서 폐지)은 셋 다 더 이상 기능하지 않지만 <b>필드는 남겨 둔다</b>.
 * 전역 설정이 {@code fail-on-unknown-properties=false} 라서 필드를 없애면 사용자가 보낸 값이
 * <b>아무 말 없이 사라지기</b> 때문이다. 받아서 명확한 오류로 거부해야 사용자가
 * "왜 내가 쓴 속성이 결과에 없지"를 추적할 수 있다.
 *
 * 규약: 문자열 필드는 비어 있어도 {@code ""} 로 싣고 응답에 null 을 넣지 않는다.
 * tombstone 배열 필드({@code attributes}, {@code children})만 예외로 <b>null 기본값</b>이며,
 * 그래서 응답에서 키 자체가 사라진다.
 */
public class NodeDto {

    /**
     * 이 페이로드 안의 위치 번호 — <b>반드시 배열 인덱스 + 1</b> (1..n).
     *
     * 요청에서 필수다. 관대하게(유일·오름차순이면 통과) 두지 않는 것은 의도다 —
     * 그러면 "sn 은 의미 있는 값"이라는 오해가 자라고, 조립기가 위치와 번호 중
     * 어느 쪽을 믿어야 하는지 두 번째 진실이 생긴다.
     */
    public Integer sn;

    /**
     * 부모의 {@link #sn}. <b>루트는 필드 자체를 싣지 않는다</b> (null → {@code non_null} 이 생략).
     *
     * {@code 0} 같은 매직 넘버를 쓰지 않는 것은 DB 의 {@code PARENT_SN}(루트 null)과 어휘를
     * 맞추기 위해서다. 계약상 항상 {@code 1 ≤ parentSn < sn} 이며, 이 부등식 하나가
     * <b>순환 참조를 구조적으로 표현 불가능하게 만든다</b> — 순환은 반드시 뒤를 참조하는
     * 간선을 포함하기 때문이다 (docs/API_V4_FLAT.md §3.3).
     */
    public Integer parentSn;

    public String name = "";
    public String valueType = "FIXED";
    public String value = "";
    public String valueDataType = "STRING";
    public String displayCondition = "";
    public String repeatCondition = "";
    public String repeatCountExpr = "";

    /**
     * 폐지된 일반 XML 속성 (R2) — <b>요청 전용 tombstone</b>.
     *
     * <ul>
     *   <li><b>요청</b>: 비어 있지 않으면 저장·미리보기가 400 {@code GENERAL_ATTR_REMOVED} 로
     *       거부한다. 빈 배열({@code []})과 <b>필드 누락(null)</b>은 정상 통과 — 프론트는
     *       이미 이 필드를 보내지 않고, 전환기의 구 클라이언트는 {@code []} 를 보낸다.</li>
     *   <li><b>응답</b>: <b>null 로 남겨 키 자체가 실리지 않는다.</b> 전역
     *       {@code default-property-inclusion=non_null} 이 생략해 준다. 빈 배열로 내보내면
     *       폐지된 개념이 응답에 계속 살아 있는 것처럼 보이고, 프론트가 "속성이 0개인 노드"와
     *       "속성 개념이 없는 노드"를 구분할 수 없다.</li>
     * </ul>
     *
     * <b>기본값을 빈 배열로 두면 안 된다</b> — 그러면 매퍼가 손대지 않아도 모든 응답에
     * {@code "attributes": []} 가 실린다. {@link #children} 도 R4 부터 같은 규약이다.
     *
     * 원소 타입을 두지 않는 것도 의도다. 더 이상 모델링하지 않는 데이터라 구조를 알 필요가
     * 없고 "비어 있는가"만 보면 된다.
     */
    public List<Object> attributes;

    /**
     * 폐지된 중첩 자식 목록 (R4) — <b>요청 전용 tombstone</b>. {@link #attributes} 와 같은 규약이다.
     *
     * <b>왜 {@link TemplateDto#root} 만 막으면 안 되는가</b>: 프론트 직렬화를 반쯤 고친 상태
     * (평면 목록을 만들면서 각 노드에 {@code children} 을 그대로 남긴 상태)에서는
     * {@code root} 가 없으므로 그 검사를 통과한다. 그러면 <b>자식이 통째로 사라진 트리가
     * 조용히 저장된다</b> — 정확히 이 프로젝트가 반복해서 막아 온 "조용한 소실"이다.
     *
     * 빈 배열({@code []})은 통과시킨다 — 전환기 클라이언트가 보낼 수 있고, 잃을 정보가 없다.
     * <b>초기화하지 않는다({@code = null})</b>: 초기화하면 매퍼가 손대지 않아도 모든 응답 노드에
     * {@code "children": []} 가 실려, 폐지한 개념이 계약에 살아 있는 것처럼 보인다.
     *
     * 원소 타입이 {@code Object} 인 것도 의도다 — 구 계약의 중첩 트리를 <b>해석할 필요가 없고</b>
     * "비어 있는가"만 보면 된다. {@code List<NodeDto>} 로 두면 구 본문을 통째로 역직렬화하는
     * 비용을 치르면서 결국 버리게 된다.
     */
    public List<Object> children;
}
