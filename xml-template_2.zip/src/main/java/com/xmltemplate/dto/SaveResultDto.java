package com.xmltemplate.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 저장 결과.
 *
 * <b>PUT 은 반드시 200 + 이 본문이어야 한다.</b> 204 나 빈 본문을 돌려주면 프론트가
 * {@code result.created} 에서 TypeError 를 내고 "저장 실패" 로 표시한다 — 저장은 성공했는데
 * 실패로 보이는 상태가 된다.
 */
public class SaveResultDto {
    public String name;
    public boolean created;
    public List<WarningDto> warnings = new ArrayList<WarningDto>();
}
