package com.xmltemplate.dto;

import java.util.List;

/**
 * 템플릿 전문 (docs/API_V4_FLAT.md §3.4). {@code updatedAt} 은 응답 전용이며 값이 없으면
 * <b>필드 자체가 생략</b>된다 (전역 {@code default-property-inclusion=non_null}).
 *
 * <b>{@code sourceXml} 필드는 없다</b>. 업로드 원본은 최대 10MB 이고 프론트는 XML 을 다루지
 * 않는다는 것이 전제라, 요청으로도 응답으로도 오가지 않는다. 필요해지면
 * {@code GET /api/templates/{name}/source} 를 따로 판다.
 */
public class TemplateDto {
    public String name = "";
    public String updatedAt;

    /**
     * 평면 노드 목록 — <b>DFS 전위(pre-order)</b> 정렬. 요청 필수, 응답 항상.
     *
     * 배열 순서가 곧 계약이다. 별도 정렬 키({@code orderNo})를 두지 않는 것은 의도다 —
     * 배열 순서와 정렬 키가 어긋났을 때 어느 쪽이 이기는지 정해야 하고, 그 규칙은
     * 반드시 조용한 승자가 된다. DB 가 {@code ORDER BY NODE_SN} 하나로 순서를 표현하는 것과
     * 같은 이유다.
     */
    public List<NodeDto> nodes;

    /**
     * 구 계약의 중첩 트리 루트 (R4 에서 폐지) — <b>요청 전용 tombstone</b>.
     *
     * 전역 {@code fail-on-unknown-properties=false} 때문에 필드를 그냥 없애면 구 클라이언트가
     * 보낸 트리가 <b>아무 말 없이 사라진다</b>. 받아서 400 {@code LEGACY_TREE_PAYLOAD} 로
     * 거부해야 "저장했는데 노드가 하나도 없다"가 되지 않는다.
     *
     * 타입이 {@code Object} 인 것은 의도다 — 구 본문의 내용을 해석할 필요가 없고
     * "실려 왔는가"만 보면 된다. 응답에는 null 로 남아 키 자체가 실리지 않는다.
     */
    public Object root;
}
