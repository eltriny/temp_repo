package com.xmltemplate.dto;

import java.util.Map;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import com.xmltemplate.config.DataMapDeserializer;

/**
 * 미리보기 요청.
 *
 * <b>{@code template.name} 으로 저장소를 조회하면 안 된다.</b> 미리보기는 저장되지 않은
 * 템플릿을 대상으로 하며, 이름은 라벨일 뿐이다. 빈 문자열이나 '새 템플릿' 같은 값도 온다.
 */
public class PreviewRequestDto {

    public TemplateDto template;

    /** 숫자 리터럴 값을 표기 그대로 수용한다 (계약 §2.4 숫자 관용 · §2.5 data 맵). */
    @JsonDeserialize(using = DataMapDeserializer.class)
    public Map<String, String> data;

    /** 값과 무관하게 응답 <b>형태</b>는 같다 — false 면 warnings 가 빈 배열일 뿐이다. */
    public boolean withWarnings;
}
