package com.xmltemplate.dto;

/** 목록 한 줄. 프론트는 {@code name} 을 React key 로 쓰므로 중복되면 안 된다. */
public class TemplateSummaryDto {
    public String name;
    public String updatedAt;
}
