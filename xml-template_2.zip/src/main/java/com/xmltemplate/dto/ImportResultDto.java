package com.xmltemplate.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 임포트 결과 — 변환된 트리, 경고, 참조 변수.
 *
 * {@code variables} 는 프론트가 React key 로 쓰므로 <b>중복 없는 문자열 배열</b>이어야 한다.
 * {@code template.root} 는 필수다 — 없으면 프론트가 "템플릿 응답에 root 노드가 없습니다" 로
 * 실패한다.
 */
public class ImportResultDto {
    public TemplateDto template;
    public List<WarningDto> warnings = new ArrayList<WarningDto>();
    public List<String> variables = new ArrayList<String>();
}
