package com.xmltemplate.exception;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.xmltemplate.dto.ValidationErrorDto;

/**
 * 정적 검증 오류가 하나라도 있을 때 — 400 {@code VALIDATION_FAILED}.
 *
 * <b>오류 목록을 통째로 들고 다닌다.</b> 하나 만나고 멈추면 사용자가 저장 → 오류 → 수정을
 * 오류 개수만큼 반복하게 된다. 전역 핸들러가 이 목록을 응답의 {@code errors[]} 에 싣고,
 * 프론트는 그 배열을 화면 목록의 <b>유일한 원천</b>으로 쓴다.
 */
public class ValidationException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    private final List<ValidationErrorDto> errors;

    public ValidationException(List<ValidationErrorDto> errors) {
        super("VALIDATION_FAILED", HttpStatus.BAD_REQUEST, summarize(errors));
        this.errors = Collections.unmodifiableList(new ArrayList<ValidationErrorDto>(errors));
    }

    public List<ValidationErrorDto> getErrors() {
        return errors;
    }

    private static String summarize(List<ValidationErrorDto> errors) {
        StringBuilder sb = new StringBuilder("템플릿 검증 오류 ")
                .append(errors.size()).append("건:");
        for (ValidationErrorDto error : errors) {
            sb.append("\n - ").append(error);
        }
        return sb.toString();
    }
}
