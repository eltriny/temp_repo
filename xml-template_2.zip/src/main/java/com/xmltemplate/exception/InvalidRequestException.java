package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 요청 자체가 잘못됐을 때 (본문 누락, 템플릿 이름 규칙 위반 등) — 400 {@code BAD_REQUEST}.
 *
 * <b>이름 규칙 위반이 여기로 온다.</b> 이전 구현은 저장소 예외 메시지에 "템플릿 이름"이
 * 들어 있는지로 400 과 500 을 갈랐다 — 문구를 다듬는 순간 400 이 500 으로 바뀌는 구조였다.
 * 원인 쪽에서 타입을 나눠 문자열 검사를 없앤다.
 */
public class InvalidRequestException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public InvalidRequestException(String message) {
        super("BAD_REQUEST", HttpStatus.BAD_REQUEST, message);
    }
}
