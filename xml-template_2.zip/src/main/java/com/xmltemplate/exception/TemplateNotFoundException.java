package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/** 템플릿이 없을 때 — 404 {@code TEMPLATE_NOT_FOUND}. */
public class TemplateNotFoundException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public TemplateNotFoundException(String message) {
        super("TEMPLATE_NOT_FOUND", HttpStatus.NOT_FOUND, message);
    }
}
