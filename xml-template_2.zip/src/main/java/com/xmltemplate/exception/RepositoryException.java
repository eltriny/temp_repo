package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 저장소 접근 실패 — 500 {@code REPOSITORY_ERROR}.
 *
 * <b>여기 오는 것은 DB 장애뿐이다.</b> 템플릿 이름 규칙 위반은
 * {@link InvalidRequestException}(400)으로 분리했다 — 클라이언트가 재시도해도 소용없는 것을
 * 500 으로 내면 재시도 루프가 생긴다.
 *
 * 데이터 접근 예외를 이 타입으로 감싸는 이유는 폴백 500 과 구분하기 위함이다.
 * 감싸지 않으면 동작은 같지만 <b>DB 장애와 코드 버그가 응답에서 구분되지 않는다</b>.
 */
public class RepositoryException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public RepositoryException(String message) {
        super("REPOSITORY_ERROR", HttpStatus.INTERNAL_SERVER_ERROR, message);
    }

    public RepositoryException(String message, Throwable cause) {
        super("REPOSITORY_ERROR", HttpStatus.INTERNAL_SERVER_ERROR, message, cause);
    }
}
