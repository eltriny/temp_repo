package com.xmltemplate.exception;

import java.net.URI;
import java.util.ArrayList;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import com.xmltemplate.dto.ValidationErrorDto;
import com.xmltemplate.util.xml.SecureXml;

/**
 * 도메인 예외 → {@link ProblemDetail}(RFC 7807) + {@code code}/{@code errors[]} 확장
 * (docs/API_V4_FLAT.md §2.6).
 *
 * <b>사람이 읽는 한 줄은 {@code detail} 이다.</b> 프론트가 {@code detail} 을 읽고
 * 없을 때만 {@code title} 로 폴백하도록 만들어져 있어, 여기서 다른 필드명을 쓰면 화면에
 * "HTTP 400" 만 뜨고 원인이 사라진다.
 *
 * <b>문구는 새로 쓰지 않고 예외 메시지를 그대로 싣는다</b> — 문구의 정본은 도메인 예외이고,
 * 여기서 바꿔 쓰면 같은 오류가 경로마다 다른 문장으로 보인다.
 *
 * <h3>핸들러가 4개뿐인 이유</h3>
 * HTTP 상태와 {@code code} 를 {@link XmlTemplateException} 이 들고 다니므로 예외 종류마다
 * 분기할 필요가 없다. 이전 구현은 예외 타입 8종을 하나씩 나열했고, 새 예외를 추가하면서
 * 등록을 빠뜨리면 그 예외가 <b>500 "서버 오류"로 보이는</b> 회귀가 있었다.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** 검증 오류는 목록 전체를 싣는다 — 사용자가 한 번에 고칠 수 있어야 한다 (§11). */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> onValidation(ValidationException e, HttpServletRequest request) {
        ProblemDetail problem = body(request, e.getStatus(), e.getCode(),
                summaryLine(e.getMessage()));
        problem.setProperty("errors", e.getErrors());
        return ResponseEntity.status(e.getStatus()).body((Object) problem);
    }

    /** 상태·code 를 예외가 들고 오므로 모든 도메인 예외가 이 한 곳을 지난다. */
    @ExceptionHandler(XmlTemplateException.class)
    public ResponseEntity<Object> onDomain(XmlTemplateException e, HttpServletRequest request) {
        return respond(request, e.getStatus(), e.getCode(), e.getMessage());
    }

    /**
     * 본문을 읽을 수 없을 때 (JSON 문법 오류, {@code data} 값 타입 위반 등).
     *
     * {@code DataMapDeserializer} 가 던지는 {@code JsonMappingException} 이 여기로 감싸여
     * 오며, 원본 문구가 보존되어야 사용자가 어느 키가 문제인지 알 수 있다.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> onUnreadable(HttpMessageNotReadableException e,
            HttpServletRequest request) {
        return respond(request, HttpStatus.BAD_REQUEST, "BAD_REQUEST", e.getMessage());
    }

    /**
     * 업로드 상한 초과는 <b>컨트롤러 진입 전</b>에 터지므로 도메인 예외가 될 기회가 없다.
     * 여기서 잡지 않으면 HTML 오류 페이지가 나가 화면에 원문 HTML 이 표시된다.
     */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Object> onUploadSize(MaxUploadSizeExceededException e,
            HttpServletRequest request) {
        return respond(request, HttpStatus.BAD_REQUEST, "XML_SECURITY",
                "요청 본문이 너무 큽니다 (최대 " + SecureXml.MAX_BODY_BYTES + " 바이트).");
    }

    /**
     * 마지막 폴백.
     *
     * <b>프레임워크가 이미 상태를 정한 예외를 500 으로 덮지 않는다.</b> Spring 6 에서
     * {@code NoResourceFoundException}(404), {@code HttpRequestMethodNotSupportedException}(405),
     * {@code HttpMediaTypeNotSupportedException}(415) 등은 {@link ErrorResponse} 를 구현해
     * 자기 상태 코드를 들고 다닌다. 포괄 핸들러가 그것을 무시하면 <b>경로 오타가 "서버 오류"로
     * 보인다</b> — 구 서버는 매핑 없는 경로에 404 를 냈으므로 회귀이기도 하다(실측 확인).
     *
     * 진짜 예상 밖의 예외만 500 이고, 그때도 예외 클래스명을 본문에 싣지 않는다.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> onOther(Exception e, HttpServletRequest request) {
        if (e instanceof ErrorResponse framework) {
            HttpStatus status = HttpStatus.valueOf(framework.getStatusCode().value());
            String detail = (framework.getBody() == null) ? null : framework.getBody().getDetail();
            return respond(request, status, codeFor(status),
                    (detail == null || detail.isEmpty()) ? status.getReasonPhrase() : detail);
        }
        return respond(request, HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR",
                "서버 오류가 발생했습니다.");
    }

    /**
     * {@code detail} 은 <b>사람이 읽는 한 줄</b>이다 (§2.6).
     *
     * 검증 예외 메시지는 요약 줄 + 노드별 상세가 줄바꿈으로 이어진 형태인데, 그 상세는
     * {@code errors[]} 와 <b>내용이 완전히 겹친다</b>. 통째로 실으면 프론트가 같은 내용을 두 번
     * 렌더링하거나 중복 제거 로직을 따로 들고 있어야 한다. 그래서 첫 줄만 남기고 상세는
     * {@code errors[]} 에만 둔다 — 끝의 콜론도 뗀다("…오류 1건:" → "…오류 1건").
     */
    private static String summaryLine(String message) {
        if (message == null) {
            return "";
        }
        int newline = message.indexOf('\n');
        String first = (newline < 0) ? message : message.substring(0, newline);
        first = first.trim();
        return first.endsWith(":") ? first.substring(0, first.length() - 1) : first;
    }

    /** 프레임워크 예외의 상태 코드를 계약상의 {@code code} 로 옮긴다. */
    private static String codeFor(HttpStatus status) {
        switch (status) {
            case NOT_FOUND:
                return "NOT_FOUND";
            case METHOD_NOT_ALLOWED:
                return "METHOD_NOT_ALLOWED";
            case UNSUPPORTED_MEDIA_TYPE:
                return "UNSUPPORTED_MEDIA_TYPE";
            default:
                return status.is4xxClientError() ? "BAD_REQUEST" : "INTERNAL_ERROR";
        }
    }

    /** 모든 오류는 {@link ProblemDetail} 로 나간다 — 평문 오류 계약은 레거시와 함께 제거되었다. */
    private static ResponseEntity<Object> respond(HttpServletRequest request, HttpStatus status,
            String code, String message) {
        return ResponseEntity.status(status).body((Object) body(request, status, code, message));
    }

    /**
     * {@code title} 은 설정하지 않는다 — {@code ProblemDetail} 이 상태 코드의 표준 문구
     * ("Bad Request" 등)를 채운다. 여기서 한국어로 덮으면 계약 예시와 달라진다.
     * {@code errors} 는 검증 오류에서만 채우므로, 없을 때도 프론트가 분기하지 않도록
     * 빈 배열을 기본값으로 둔다 (§2.6 "검증 오류가 아니면 errors 는 []").
     */
    private static ProblemDetail body(HttpServletRequest request, HttpStatus status,
            String code, String message) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, message);
        problem.setProperty("code", code);
        problem.setProperty("errors", new ArrayList<ValidationErrorDto>());
        if (request != null && request.getRequestURI() != null) {
            try {
                problem.setInstance(URI.create(request.getRequestURI()));
            } catch (IllegalArgumentException ignored) {
                /* 경로에 URI 로 못 쓰는 문자가 있어도 오류 응답 자체는 나가야 한다 */
            }
        }
        return problem;
    }
}
