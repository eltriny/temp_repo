package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 평면 노드 목록의 <b>구조</b>가 계약을 어겼을 때 — 400 (docs/API_V4_FLAT.md §5.2).
 *
 * <h3>왜 code 를 생성자 인자로 받는가</h3>
 * 구조 위반이 6종인데 예외 클래스를 6개 만들면 계층만 늘고 얻는 것이 없다.
 * {@link GlobalExceptionHandler} 는 {@link XmlTemplateException} 한 곳으로 처리하므로
 * {@code code} 만 다르면 충분하다. 상수를 여기 모아 두면 <b>테스트가 문자열 리터럴을
 * 복사하지 않는다</b> — 코드명을 바꾸면 컴파일이 깨져서 알려 준다.
 *
 * <h3>왜 {@code errors[]} 를 채우지 않는가</h3>
 * 구조 위반은 사용자가 화면에서 고칠 수 있는 문제가 아니라 <b>클라이언트 직렬화 버그</b>다.
 * 목록화의 이득이 없고 {@code sn} 두 개면 진단이 끝나므로 <b>첫 위반에서 즉시 실패</b>한다.
 * 조건식 오류({@link ValidationException})가 "한 번에 고칠 수 있도록 목록 전체"인 것과
 * 정책이 다른 것은 의도다 — 그쪽은 사용자가 한 칸씩 고치는 대상이다.
 * (별도 작업은 필요 없다. {@code GlobalExceptionHandler.body()} 가 항상 {@code errors: []} 를
 *  넣고 {@code onValidation} 만 덮어쓴다.)
 *
 * <h3>이 예외가 <b>아닌</b> 것</h3>
 * 필드 <b>값</b>의 오류(enum 오타, 빈 이름)는 {@link MappingException} 이다. 구조(목록의
 * 배치)와 값을 code 로 구분해 두면 프론트가 "전송 형식 오류(프로그램 결함)"와
 * "입력 값 오류"를 다른 문구로 안내할 수 있다.
 */
public class NodeListStructureException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    /** 구 계약(중첩 트리) 본문이 실려 왔다 — {@code TemplateDto.root} 또는 {@code NodeDto.children}. */
    public static final String LEGACY_TREE_PAYLOAD = "LEGACY_TREE_PAYLOAD";
    /** {@code nodes[i].sn != i + 1} — 불변식 (I1) 위반. */
    public static final String NODE_SN_SEQUENCE = "NODE_SN_SEQUENCE";
    /** {@code parentSn} 이 없는 노드가 2개 이상. */
    public static final String MULTIPLE_ROOTS = "MULTIPLE_ROOTS";
    /** 모든 노드가 {@code parentSn} 을 가져 루트가 없다. */
    public static final String NO_ROOT_NODE = "NO_ROOT_NODE";
    /** {@code parentSn >= sn} — 불변식 (I2) 위반. 자기참조도 여기로 온다. */
    public static final String PARENT_AFTER_CHILD = "PARENT_AFTER_CHILD";
    /** {@code parentSn} 이 목록의 범위 {@code [1, n]} 밖이다. */
    public static final String ORPHAN_NODE = "ORPHAN_NODE";

    public NodeListStructureException(String code, String message) {
        super(code, HttpStatus.BAD_REQUEST, message);
    }
}
