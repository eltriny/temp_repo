package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 폐지된 일반 XML 속성이 요청에 실려 왔을 때 — 400 {@code GENERAL_ATTR_REMOVED}.
 *
 * 저장(PUT)과 미리보기(POST /api/preview) 양쪽에서 나온다. 두 경로가 공유하는
 * {@code TemplateMapper.toModel} 에서 던지므로 한쪽만 막히는 일이 없다 — 미리보기는 저장
 * 검증을 거치지 않으므로 검증기에만 두면 구멍이 남는다({@code repeatCondition} 폐지 때
 * 겪은 실패 모드다).
 *
 * 임포트 경로는 <b>거부하지 않고</b> {@code GENERAL_ATTR_IGNORED} 경고와 함께 속성을
 * 버린다 — 사용자가 올린 원본 XML 에 속성이 있는 것은 자연스러운 일이고, 거부하면 기존
 * 파일을 아예 가져올 수 없게 된다.
 */
public class GeneralAttributeRemovedException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public GeneralAttributeRemovedException(String message) {
        super("GENERAL_ATTR_REMOVED", HttpStatus.BAD_REQUEST, message);
    }
}
