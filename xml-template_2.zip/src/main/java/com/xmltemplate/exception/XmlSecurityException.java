package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * XML 입력이 안전 규칙이나 상한을 위반했을 때 — 400 {@code XML_SECURITY}.
 * XXE·상한 위반은 위험한 입력이므로 클라이언트 오류다.
 */
public class XmlSecurityException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public XmlSecurityException(String message) {
        super("XML_SECURITY", HttpStatus.BAD_REQUEST, message);
    }

    public XmlSecurityException(String message, Throwable cause) {
        super("XML_SECURITY", HttpStatus.BAD_REQUEST, message, cause);
    }
}
