package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/** XML 생성 중 오류 — 400 {@code GENERATION_FAILED}. */
public class GenerationException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public GenerationException(String message) {
        super("GENERATION_FAILED", HttpStatus.BAD_REQUEST, message);
    }
}
