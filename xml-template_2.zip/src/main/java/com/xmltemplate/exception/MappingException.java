package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/** 알 수 없는 enum 값 등 요청 형식 오류 — 400 {@code BAD_REQUEST}. */
public class MappingException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public MappingException(String message) {
        super("BAD_REQUEST", HttpStatus.BAD_REQUEST, message);
    }
}
