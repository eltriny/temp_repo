package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/** 업로드 XML 이 표현 불가하거나 규칙을 위반했을 때 — 400 {@code IMPORT_FAILED}. */
public class ImportException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public ImportException(String message) {
        super("IMPORT_FAILED", HttpStatus.BAD_REQUEST, message);
    }
}
