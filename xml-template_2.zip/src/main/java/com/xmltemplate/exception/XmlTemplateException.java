package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 이 애플리케이션의 도메인 예외 공통 베이스.
 *
 * <b>HTTP 상태와 계약상의 {@code code} 를 예외 정의에 붙여 둔다.</b> 그러면 전역 핸들러가
 * 예외 종류마다 분기할 필요가 없고, 새 예외를 추가해도 500 폴백으로 조용히 새지 않는다.
 * 이전 구현은 핸들러가 예외 타입 8종을 하나씩 나열했고, 하나라도 빠뜨리면 그 예외가
 * "서버 오류"로 보이는 회귀가 있었다.
 *
 * {@link HttpStatus}(spring-web)를 예외가 참조하는 것은 "모든 계층에서 Spring 을 쓴다"는
 * 이 라운드의 규칙에 부합한다.
 */
public abstract class XmlTemplateException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String code;
    private final HttpStatus status;

    protected XmlTemplateException(String code, HttpStatus status, String message) {
        super(message);
        this.code = code;
        this.status = status;
    }

    protected XmlTemplateException(String code, HttpStatus status, String message,
            Throwable cause) {
        super(message, cause);
        this.code = code;
        this.status = status;
    }

    /** ProblemDetail 의 최상위 확장 필드 {@code code}. */
    public String getCode() {
        return code;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
