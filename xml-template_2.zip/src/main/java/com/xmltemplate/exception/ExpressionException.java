package com.xmltemplate.exception;

import org.springframework.http.HttpStatus;

/**
 * 식이 잘못되었을 때 — 400 {@code GENERATION_FAILED}.
 *
 * 생성 엔진은 이 예외를 잡아 {@link GenerationException} 으로 문맥(노드 경로)을 붙여 다시
 * 던지므로, 이 코드가 그대로 응답에 나가는 것은 검증기·파서가 직접 던진 경우다.
 */
public class ExpressionException extends XmlTemplateException {

    private static final long serialVersionUID = 1L;

    public ExpressionException(String message) {
        super("GENERATION_FAILED", HttpStatus.BAD_REQUEST, message);
    }
}
