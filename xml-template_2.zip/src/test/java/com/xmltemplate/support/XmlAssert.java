package com.xmltemplate.support;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.xmltemplate.util.xml.SecureXml;

/**
 * XML 정규화 비교/단언 유틸 (명세 §10) — <b>골든 케이스의 오라클</b>.
 *
 * <b>왜 테스트 소스에 있나</b>: 운영 코드는 이 비교기를 쓰지 않는다. 기대 XML 과 실제
 * 생성 결과를 대조하는 테스트 전용 자산이라 {@code src/test} 가 제자리다.
 * 패키지를 {@code com.xmltemplate.test} 가 아니라 {@code com.xmltemplate.support} 로
 * 둔 것은 의도적이다 — 옛 위치({@code src/main} 의 같은 이름 패키지)와 FQCN 이 겹치면
 * 더티 빌드의 {@code target/classes} 잔재와 클래스가 충돌한다.
 *
 * <b>이 비교기가 틀리면 모든 골든이 조용히 통과한다.</b> 그래서
 * {@code com.xmltemplate.support.XmlAssertTest} 가 "같다"뿐 아니라 <b>"다르다"</b>를
 * 판정하는 부정 케이스까지 고정한다 — 그게 이 자산의 유일한 보증이다.
 *
 * 생성 결과를 문자열로 비교하면 의미와 무관한 차이 때문에 테스트가 깨진다.
 * 들여쓰기 폭, {@code <a/>} 와 {@code <a></a>}, 속성을 쓴 순서 같은 것들이다.
 * 그래서 기대값 비교는 DOM 을 정규화해서 한다.
 *
 * 정규화 규칙 (명세 §10 개정본):
 *  - <b>구조적 공백만 무시</b>: 자식 엘리먼트 사이의 들여쓰기/개행은 무시한다.
 *  - <b>리프 텍스트와 속성값은 원문 비교</b>: trim 도 공백 접기도 하지 않는다.
 *    §7 의 NULL 의미론이 "빈 문자열"과 "공백만 있는 값"을 구분하므로(trim 하지 않음),
 *    비교기가 그 둘을 같다고 판정하면 NULL 규칙을 검증할 수단이 사라진다.
 *    같은 이유로 텍스트와 속성값의 처리를 비대칭으로 두지 않는다.
 *  - <b>빈 요소 동일 취급</b>: {@code <a/>} 와 {@code <a></a>} 는 같다
 *    (둘 다 자식 없음 + 텍스트 ""). 반면 {@code <a> </a>} 는 이 둘과 <b>다르다</b>.
 *  - <b>혼합 콘텐츠는 차이로 보고</b>: 자식 엘리먼트가 있는 노드의 공백 아닌 텍스트는
 *    무시하지 않는다. 무시하면 표현할 수 없는 입력이 조용히 같다고 판정된다.
 *  - <b>속성 순서 무시</b>: 이름-값 집합으로 비교한다 (XML 명세상 순서는 무의미).
 *  - 주석과 처리 명령(PI)은 비교 대상이 아니다.
 *  - XML 선언 유무는 DOM 비교에 영향을 주지 않는다.
 *
 * 엘리먼트의 <b>순서</b>는 의미가 있으므로 정규화하지 않는다 (반복 생성 순서가
 * 곧 결과다).
 */
public final class XmlAssert {

    private XmlAssert() {
    }

    /** 정규화 비교가 어긋났을 때. 골든 케이스 테스트가 잡아서 보고한다. */
    public static class ComparisonException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public ComparisonException(String message) {
            super(message);
        }
    }

    /** 두 XML 이 정규화 기준으로 같으면 true. */
    public static boolean equal(String expected, String actual) {
        return diff(expected, actual) == null;
    }

    /**
     * 두 XML 이 정규화 기준으로 같지 않으면 예외를 던진다.
     *
     * {@code src/test/resources/cases/} 골든 케이스처럼 "실패하면
     * 멈춰야 하는" 호출부를 위한 형태다. 판정 결과를 값으로 받고 싶으면
     * {@link #equal(String, String)} 이나 {@link #diff(String, String)} 을 쓴다.
     */
    public static void assertEqual(String expected, String actual, String description) {
        String difference = diff(expected, actual);
        if (difference != null) {
            throw new ComparisonException(
                    (description == null ? "XML 이 기대와 다릅니다" : description) + " - " + difference);
        }
    }

    /**
     * 두 XML 을 비교해서 첫 번째 차이를 사람이 읽을 수 있게 돌려준다.
     * 같으면 null.
     *
     * 어긋난 위치를 경로로 알려줘야 실패한 테스트를 바로 고칠 수 있다.
     */
    public static String diff(String expected, String actual) {
        Document expectedDoc;
        Document actualDoc;
        try {
            expectedDoc = SecureXml.parse(expected);
        } catch (RuntimeException e) {
            return "기대 XML 파싱 실패: " + e.getMessage();
        }
        try {
            actualDoc = SecureXml.parse(actual);
        } catch (RuntimeException e) {
            return "실제 XML 파싱 실패: " + e.getMessage();
        }
        return compareElements(expectedDoc.getDocumentElement(),
                actualDoc.getDocumentElement(), "");
    }

    private static String compareElements(Element expected, Element actual, String parentPath) {
        if (expected == null || actual == null) {
            return "루트 엘리먼트가 없습니다.";
        }
        String path = parentPath + "/" + expected.getTagName();

        if (!expected.getTagName().equals(actual.getTagName())) {
            return path + ": 엘리먼트 이름이 다릅니다 (기대 '" + expected.getTagName()
                    + "', 실제 '" + actual.getTagName() + "')";
        }

        String attrDiff = compareAttributes(expected, actual, path);
        if (attrDiff != null) {
            return attrDiff;
        }

        List<Element> expectedChildren = childElements(expected);
        List<Element> actualChildren = childElements(actual);

        /*
         * 리프끼리는 원문 그대로 비교한다. trim 이나 공백 접기를 하면
         * "" 와 " " 가 같아져 §7 의 NULL 의미론을 검증할 수 없게 된다.
         */
        if (expectedChildren.isEmpty() && actualChildren.isEmpty()) {
            String expectedText = rawText(expected);
            String actualText = rawText(actual);
            if (!expectedText.equals(actualText)) {
                return path + ": 값이 다릅니다 (기대 " + quote(expectedText)
                        + ", 실제 " + quote(actualText) + ")";
            }
            return null;
        }

        /*
         * 자식이 있는 쪽의 텍스트는 대부분 들여쓰기(구조적 공백)라 무시하지만,
         * 공백이 아닌 텍스트가 섞여 있으면(혼합 콘텐츠) 무시하지 않고 차이로 본다.
         * 조용히 넘기면 표현할 수 없는 입력이 "같음"으로 판정된다.
         */
        String expectedMixed = mixedContentText(expected);
        String actualMixed = mixedContentText(actual);
        if (!expectedMixed.equals(actualMixed)) {
            return path + ": 자식 엘리먼트와 함께 있는 텍스트(혼합 콘텐츠)가 다릅니다 (기대 "
                    + quote(expectedMixed) + ", 실제 " + quote(actualMixed) + ")";
        }

        if (expectedChildren.size() != actualChildren.size()) {
            return path + ": 자식 엘리먼트 수가 다릅니다 (기대 " + expectedChildren.size()
                    + "개 " + tagNames(expectedChildren) + ", 실제 " + actualChildren.size()
                    + "개 " + tagNames(actualChildren) + ")";
        }

        for (int i = 0; i < expectedChildren.size(); i++) {
            String childDiff = compareElements(expectedChildren.get(i), actualChildren.get(i),
                    path + "[" + (i + 1) + "]");
            if (childDiff != null) {
                return childDiff;
            }
        }
        return null;
    }

    /** 속성은 이름-값 집합으로 비교한다 (쓴 순서는 의미가 없다). */
    private static String compareAttributes(Element expected, Element actual, String path) {
        Map<String, String> expectedAttrs = attributes(expected);
        Map<String, String> actualAttrs = attributes(actual);

        for (Map.Entry<String, String> entry : expectedAttrs.entrySet()) {
            String actualValue = actualAttrs.get(entry.getKey());
            if (actualValue == null) {
                return path + ": 속성 '" + entry.getKey() + "' 이(가) 없습니다.";
            }
            if (!entry.getValue().equals(actualValue)) {
                return path + ": 속성 '" + entry.getKey() + "' 값이 다릅니다 (기대 '"
                        + entry.getValue() + "', 실제 '" + actualValue + "')";
            }
        }
        for (String name : actualAttrs.keySet()) {
            if (!expectedAttrs.containsKey(name)) {
                return path + ": 기대에 없는 속성이 있습니다: '" + name + "'";
            }
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* 정규화                                                               */
    /* ------------------------------------------------------------------ */

    private static Map<String, String> attributes(Element el) {
        Map<String, String> result = new TreeMap<String, String>();
        NamedNodeMap attrs = el.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) {
            Node attr = attrs.item(i);
            result.put(attr.getNodeName(), attr.getNodeValue());
        }
        return result;
    }

    private static List<Element> childElements(Element el) {
        List<Element> result = new ArrayList<Element>();
        NodeList children = el.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                result.add((Element) child);
            }
        }
        return result;
    }

    /** 텍스트/CDATA 를 이어붙인 원문 (정규화 없음). CDATA 는 텍스트와 동일 취급. */
    private static String rawText(Element el) {
        StringBuilder sb = new StringBuilder();
        NodeList children = el.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.TEXT_NODE
                    || child.getNodeType() == Node.CDATA_SECTION_NODE) {
                sb.append(child.getNodeValue());
            }
        }
        return sb.toString();
    }

    /**
     * 자식 엘리먼트가 있는 노드에서 <b>구조적 공백을 뺀</b> 텍스트.
     *
     * 공백만으로 이루어진 텍스트 노드(들여쓰기·개행)는 버리고, 내용이 있는
     * 텍스트 노드만 남겨 앞뒤 공백을 떼고 이어붙인다. 들여쓰기 폭 차이는
     * 무시하면서 "텍스트가 있었다/없었다"는 놓치지 않기 위한 절충이다.
     */
    private static String mixedContentText(Element el) {
        StringBuilder sb = new StringBuilder();
        NodeList children = el.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() != Node.TEXT_NODE
                    && child.getNodeType() != Node.CDATA_SECTION_NODE) {
                continue;
            }
            String value = child.getNodeValue();
            if (value.trim().isEmpty()) {
                continue;
            }
            sb.append(value.trim());
        }
        return sb.toString();
    }

    /** 공백 차이를 눈으로 구분할 수 있도록 따옴표로 감싼다. */
    private static String quote(String text) {
        return "'" + text + "'";
    }

    private static String tagNames(List<Element> elements) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < elements.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(elements.get(i).getTagName());
        }
        return sb.append(']').toString();
    }
}
