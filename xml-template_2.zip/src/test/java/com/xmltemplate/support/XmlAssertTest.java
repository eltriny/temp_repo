package com.xmltemplate.support;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * 골든 오라클의 자기 검증 (명세 §10) — 구 {@code SelfTest.checkXmlAssert} 17건의 이관본.
 *
 * <b>왜 부정 케이스가 절반인가</b>: {@link XmlAssert} 는 모든 골든 케이스가 "기대와 같다"를
 * 판정하는 데 쓰는 유일한 도구다. 비교기가 <b>무엇이든 같다고 답하면</b> 골든 13건과
 * 미리보기 대조가 전부 조용히 통과한다 — 회귀 방어선이 있다고 착각하게 되는 최악의 실패다.
 * 그래서 "같다"보다 <b>"다르다"를 제대로 판정하는지</b>가 이 클래스의 본체다.
 *
 * Spring 컨텍스트를 쓰지 않는다 — 비교기는 순수 함수다.
 */
class XmlAssertTest {

    /* ================================================================== */
    /* 같다고 판정해야 하는 것 — 의미와 무관한 차이                            */
    /* ================================================================== */

    @Nested
    @DisplayName("정규화: 의미가 없는 차이는 무시한다")
    class Normalization {

        @Test
        @DisplayName("<b/> 와 <b></b> 는 같다")
        void emptyElementFormsAreEqual() {
            assertTrue(XmlAssert.equal("<a><b/></a>", "<a><b></b></a>"));
        }

        @Test
        @DisplayName("들여쓰기 공백 무시")
        void indentationIgnored() {
            assertTrue(XmlAssert.equal("<a>\n  <b>x</b>\n</a>", "<a><b>x</b></a>"));
        }

        @Test
        @DisplayName("속성 순서 무시")
        void attributeOrderIgnored() {
            assertTrue(XmlAssert.equal("<a p=\"1\" q=\"2\"/>", "<a q=\"2\" p=\"1\"/>"));
        }

        @Test
        @DisplayName("XML 선언 유무 무시")
        void xmlDeclarationIgnored() {
            assertTrue(XmlAssert.equal("<?xml version=\"1.0\"?><a>x</a>", "<a>x</a>"));
        }

        @Test
        @DisplayName("자식 사이의 구조적 공백만 무시된다")
        void onlyStructuralWhitespaceIgnored() {
            assertTrue(XmlAssert.equal("<a>\n  <b>x</b>\n</a>", "<a>\n\t<b>x</b>\n</a>"));
        }
    }

    /* ================================================================== */
    /* 다르다고 판정해야 하는 것 — 여기가 오라클의 본체                        */
    /* ================================================================== */

    @Nested
    @DisplayName("차이 검출: 조용히 같다고 하지 않는다")
    class DifferenceDetection {

        /** 반복 생성 순서가 곧 결과다 — 순서를 정규화하면 반복 검증이 무의미해진다. */
        @Test
        @DisplayName("엘리먼트 순서는 의미가 있다 (다르게 판정)")
        void elementOrderMatters() {
            assertFalse(XmlAssert.equal("<a><b/><c/></a>", "<a><c/><b/></a>"));
        }

        @Test
        @DisplayName("값 차이 검출")
        void textValueDifference() {
            assertFalse(XmlAssert.equal("<a>x</a>", "<a>y</a>"));
        }

        @Test
        @DisplayName("속성 값 차이 검출")
        void attributeValueDifference() {
            assertFalse(XmlAssert.equal("<a p=\"1\"/>", "<a p=\"2\"/>"));
        }

        @Test
        @DisplayName("자식 수 차이 검출")
        void childCountDifference() {
            assertFalse(XmlAssert.equal("<a><b/></a>", "<a><b/><b/></a>"));
        }

        /**
         * §7 의 NULL 의미론이 "빈 문자열"과 "공백만 있는 값"을 구분한다(trim 하지 않음).
         * 비교기가 그 둘을 같다고 보면 NULL 규칙을 검증할 수단 자체가 사라진다.
         */
        @Test
        @DisplayName("공백만 있는 값과 빈 값은 다르다 (NULL 의미론 검증 가능)")
        void blankIsNotEmpty() {
            assertFalse(XmlAssert.equal("<a> </a>", "<a/>"));
        }

        @Test
        @DisplayName("리프 텍스트는 원문 비교 (trim/공백 접기 안 함)")
        void leafTextComparedRaw() {
            assertFalse(XmlAssert.equal("<a>x</a>", "<a> x </a>"));
        }

        /** 텍스트와 속성값의 처리를 비대칭으로 두지 않는다. */
        @Test
        @DisplayName("속성값도 원문 비교 (텍스트와 대칭)")
        void attributeValueComparedRaw() {
            assertFalse(XmlAssert.equal("<a p=\" \"/>", "<a p=\"\"/>"));
        }

        /** 혼합 콘텐츠는 이 엔진이 표현할 수 없는 입력이다 — 무시하면 조용히 "같음"이 된다. */
        @Test
        @DisplayName("혼합 콘텐츠 텍스트를 차이로 보고한다")
        void mixedContentDetected() {
            assertFalse(XmlAssert.equal("<a>텍스트<b/></a>", "<a><b/></a>"));
        }
    }

    /* ================================================================== */
    /* 진단 메시지 — 실패했을 때 고칠 수 있어야 한다                           */
    /* ================================================================== */

    @Nested
    @DisplayName("차이 메시지")
    class DiffMessage {

        @Test
        @DisplayName("혼합 콘텐츠 차이 메시지에 사유가 드러난다")
        void mixedContentReasonInMessage() {
            String diff = XmlAssert.diff("<a>텍스트<b/></a>", "<a><b/></a>");
            assertNotNull(diff, "혼합 콘텐츠 차이가 보고되지 않았다");
            assertTrue(diff.contains("혼합 콘텐츠"), "사유가 없다: " + diff);
        }

        @Test
        @DisplayName("차이 메시지에 어긋난 경로가 포함된다")
        void pathInMessage() {
            String diff = XmlAssert.diff("<a><b>x</b></a>", "<a><b>y</b></a>");
            assertNotNull(diff, "값 차이가 보고되지 않았다");
            assertTrue(diff.contains("/a") && diff.contains("b"), "경로가 없다: " + diff);
        }
    }

    /* ================================================================== */
    /* assertEqual — 골든 케이스가 쓰는 단언 형태                             */
    /* ================================================================== */

    @Test
    @DisplayName("assertEqual: 같으면 예외 없음")
    void assertEqualPassesWhenSame() {
        assertDoesNotThrow(
                () -> XmlAssert.assertEqual("<a><b/></a>", "<a><b></b></a>", "동일 케이스"));
    }

    @Test
    @DisplayName("assertEqual: 다르면 설명과 차이를 담아 예외")
    void assertEqualThrowsWithDescription() {
        XmlAssert.ComparisonException thrown = assertThrows(XmlAssert.ComparisonException.class,
                () -> XmlAssert.assertEqual("<a>x</a>", "<a>y</a>", "값 불일치 케이스"));
        assertTrue(thrown.getMessage().contains("값 불일치 케이스"),
                "설명이 메시지에 없다: " + thrown.getMessage());
    }
}
