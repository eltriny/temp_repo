package com.xmltemplate.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.xmltemplate.api.ApiTestSupport;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;

/**
 * {@link TemplateStore} 왕복 계약 — <b>JPA 재작성이 새로 만든 위험을 정확히 겨눈다</b>.
 *
 * <b>왜 이 테스트가 필요한가</b>: 이전 저장소({@code JdbcTemplateRepository})는 자동 테스트로
 * 검증된 적이 한 번도 없었다. API 테스트는 매번 저장소를 비우고 새로 저장하므로
 * <b>덮어쓰기 경로를 거의 타지 않고</b>, 골든 케이스 13건은 임포트 → 미리보기만 보므로
 * 저장소를 아예 지나지 않는다. 저장소가 DFS 순서를 잃거나 속성 순서를 바꾸거나 고아 행을
 * 남겨도 기존 278건은 전부 초록이다.
 *
 * <b>왜 {@link TransactionTemplate} 로 감싸는가</b>: {@code TemplateStore} 는 스스로
 * 트랜잭션을 열지 않는다(경계는 {@code TemplateService} 한 곳). 트랜잭션 없이 부르면
 * "벌크 DELETE → flush → 배치 INSERT" 가 서로 다른 트랜잭션으로 흩어져 <b>실제 운영 경로와
 * 다른 것을 검증</b>하게 된다. 여기서 재현하려는 함정이 바로 그 순서이므로 한 트랜잭션으로
 * 묶어 서비스와 같은 조건을 만든다.
 */
class TemplateStoreIntegrationTest extends ApiTestSupport {

    @Autowired
    private TemplateStore store;

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private PlatformTransactionManager txManager;

    /* ================================================================== */
    /* ① 저장 → 로드 트리 동일성 (자식 순서 · 속성 순서)                       */
    /* ================================================================== */

    /**
     * 형제 순서와 <b>노드의 제어 정보 전부</b>가 왕복을 견뎌야 한다.
     *
     * {@code Map} 으로 조립하거나 {@code ORDER BY} 를 빠뜨리면 순서가 DB 의 반환 순서에
     * 맡겨진다. 그래도 "저장했다 열면 내용은 다 있다"라서 얕은 검사는 통과하고,
     * 브라우저에서 "노드 순서가 뒤바뀌었다"로 처음 발견된다.
     *
     * <b>R2 로 검증 범위가 옮겨졌다</b>: 일반 속성이 폐지되며 "속성 순서 보존"이 사라진
     * 자리를, 컬럼별 제어 정보(값 유형·데이터 타입·표시 조건·반복 횟수식)의 왕복이 대신한다.
     * 이 필드들은 임포트 경로 테스트가 <b>메모리상의 트리</b>로만 확인하므로, DB 컬럼을
     * 실제로 왕복하는지는 여기서만 드러난다.
     */
    @Test
    @DisplayName("저장 → 로드 시 자식 순서와 노드 제어 정보가 그대로다")
    void saveThenLoadPreservesChildOrderAndNodeFields() {
        TemplateNode root = node("order", "R");

        TemplateNode first = node("first", "1");
        TemplateNode second = node("second", "2");
        TemplateNode third = node("third", "3");
        root.addChild(first);
        root.addChild(second);
        root.addChild(third);
        second.addChild(node("nested", "n"));

        /* 제어 정보를 한 노드에 몰아 담는다 — 컬럼 하나만 빠져도 드러나도록 */
        second.setValueType(ValueType.VARIABLE);
        second.setValue("{PRICE_[N]}");
        second.setValueDataType(ValueDataType.NUMBER);
        second.setDisplayCondition("{PRICE_[N]} != NULL");
        second.setRepeatCountExpr("COUNT({PRICE})");

        inTransaction(() -> store.save("order-shape", root));

        TemplateNode loaded = inTransactionGet(() -> store.load("order-shape"));
        assertNotNull(loaded, "저장한 템플릿이 로드되지 않았다");

        assertEquals(List.of("first", "second", "third"), childNames(loaded),
                "형제 순서가 바뀌었다");
        assertEquals(List.of("nested"), childNames(loaded.getChildren().get(1)),
                "손자 노드가 다른 부모에 붙었다");

        TemplateNode reloadedSecond = loaded.getChildren().get(1);
        assertEquals(ValueType.VARIABLE, reloadedSecond.getValueType(), "INPUT_TYPE 왕복");
        assertEquals("{PRICE_[N]}", reloadedSecond.getValue(), "INPUT_VALUE 왕복");
        assertEquals(ValueDataType.NUMBER, reloadedSecond.getValueDataType(),
                "INPUT_DATA_TYPE 왕복");
        assertEquals("{PRICE_[N]} != NULL", reloadedSecond.getDisplayCondition(),
                "DISPLAY_COND 왕복");
        assertEquals("COUNT({PRICE})", reloadedSecond.getRepeatCountExpr(),
                "REPEAT_COUNT_COND 왕복");

        /* null → "" 정규화 (계약: 응답에 null 금지) */
        assertEquals("", loaded.getDisplayCondition(), "빈 조건식이 null 로 돌아왔다");
        assertEquals("", loaded.getRepeatCountExpr(), "빈 반복식이 null 로 돌아왔다");
    }

    /* ================================================================== */
    /* ② 재저장으로 노드 수가 줄어드는 경우 — 고아 행 0                        */
    /* ================================================================== */

    /**
     * <b>이 재작성에서 가장 위험한 경로</b>다.
     *
     * 저장은 노드를 <b>전건 삭제 후 재삽입</b>하고 {@code NODE_SN} 은 그때마다 새로 발급되므로
     * "옛 SN ↔ 새 SN" 대응이 존재하지 않는다. 옛 저장분의 잔여 행이 남으면 다음 조회에서
     * "존재하지 않는 부모 참조"로 터진다.
     *
     * 최초 저장은 항상 성공하므로 <b>두 번째 저장</b>이 아니면 드러나지 않는다.
     */
    @Test
    @DisplayName("노드가 줄어드는 재저장 후 고아 노드 행이 0이다")
    void resaveWithFewerNodesLeavesNoOrphans() {
        TemplateNode big = node("root", "");
        for (int i = 1; i <= 4; i++) {
            big.addChild(node("child" + i, "v" + i));
        }
        inTransaction(() -> store.save("shrink", big));
        assertEquals(5, nodeCount("shrink"), "최초 저장의 노드 수");
        long maxSnBefore = 0;
        for (Map<String, Object> row : nodeRows("shrink")) {
            maxSnBefore = Math.max(maxSnBefore, asLong(row.get("NODE_SN")));
        }

        TemplateNode small = node("root", "");
        small.addChild(node("child1", "v1"));
        inTransaction(() -> store.save("shrink", small));

        assertEquals(2, nodeCount("shrink"), "옛 노드 행이 남았다 (고아)");

        /*
         * R3: NODE_SN 은 더 이상 템플릿마다 1..n 이 아니라 <b>전역 시퀀스가 채우는 증가 값</b>
         * 이다. 따라서 "MAX(NODE_SN) == 2" 같은 절대값 단언은 성립하지 않는다.
         *
         * 대신 같은 성질을 더 강하게 볼 수 있다 — 저장은 전건 삭제 후 재삽입이므로 재저장 뒤
         * 남은 행은 <b>전부 새로 발급된 키</b>여야 한다. 옛 SN 이 하나라도 살아 있으면
         * 삭제가 덜 됐다는 뜻이고, 그 행은 지금 트리에 속하지 않는 고아다.
         */
        for (Map<String, Object> row : nodeRows("shrink")) {
            assertTrue(asLong(row.get("NODE_SN")) > maxSnBefore,
                    "옛 저장분의 NODE_SN 이 남아 있다 (고아 행): " + row);
        }

        TemplateNode reloaded = inTransactionGet(() -> store.load("shrink"));
        assertNotNull(reloaded);
        assertEquals(1, reloaded.getChildren().size(), "재로드한 트리의 자식 수");
        assertEquals("child1", reloaded.getChildren().get(0).getName());
    }

    /* ================================================================== */
    /* ③ 재저장 시 SOURCE_XML 보존                                          */
    /* ================================================================== */

    /**
     * 마스터 행을 지우지 않는 것이 새 설계의 개선점이다.
     *
     * 이전 구현은 마스터도 delete + insert 라 {@code SOURCE_XML} 이 지워졌고, 삭제 전에 읽어
     * 두었다가 되돌려 넣는 보정 코드가 있었다. 그 보정이 사라졌으므로 <b>보존이 실제로
     * 되는지</b>를 여기서 고정한다 — 애플리케이션에는 {@code SOURCE_XML} 을 쓰는 경로가 없어
     * 기존 데이터로만 존재하고, 조용히 지워져도 어떤 화면에도 나타나지 않는다.
     */
    @Test
    @DisplayName("재저장해도 SOURCE_XML 이 보존된다")
    void resaveKeepsSourceXml() {
        inTransaction(() -> store.save("keep-source", node("root", "v")));
        jdbc.update("UPDATE XML_TEMPLATE SET SOURCE_XML = ? WHERE TEMPLATE_NAME = ?",
                "<a><b>원본</b></a>", "keep-source");

        TemplateNode changed = node("root", "v2");
        changed.addChild(node("added", "x"));
        inTransaction(() -> store.save("keep-source", changed));

        String sourceXml = jdbc.queryForObject(
                "SELECT SOURCE_XML FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?",
                String.class, "keep-source");
        assertEquals("<a><b>원본</b></a>", sourceXml, "재저장이 SOURCE_XML 을 지웠다");
    }

    /* ================================================================== */
    /* ④ delete 후 3테이블 잔여 행 0                                         */
    /* ================================================================== */

    /**
     * 부분 삭제로 남은 행은 다음 저장의 PK 와 충돌한다 — 두 테이블 모두 확인한다.
     *
     * (R2 에서 {@code XML_TEMPLATE_NODE_ATTR} 이 스키마에서 빠져 검사 대상이 셋에서 둘로
     * 줄었다. 그 테이블은 기존 DB 에 남아 있어도 앱이 전혀 접근하지 않는다.)
     */
    @Test
    @DisplayName("delete 후 두 테이블에 잔여 행이 없다")
    void deleteRemovesRowsFromBothTables() {
        TemplateNode root = node("root", "");
        root.addChild(node("child", "v"));
        inTransaction(() -> store.save("to-delete", root));
        assertEquals(2, nodeCount("to-delete"));

        Boolean deleted = inTransactionGet(() -> Boolean.valueOf(store.delete("to-delete")));
        assertTrue(deleted.booleanValue(), "delete 가 false 를 돌려줬다");

        assertEquals(0, masterCount("to-delete"), "XML_TEMPLATE 잔여 행");
        assertEquals(0, nodeCount("to-delete"), "XML_TEMPLATE_NODE 잔여 행");
    }

    /* ================================================================== */
    /* ⑤ NODE_SN 이 DFS 전위 순서                                            */
    /* ================================================================== */

    /**
     * {@code ORDER BY NODE_SN} 한 번으로 부모가 자식보다 먼저 나온다는 것이 로드 알고리즘의
     * 전제다. 전위가 아니면 조립이 "존재하지 않는 부모 참조"로 실패하거나, 더 나쁘게는
     * 형제 순서만 조용히 뒤바뀐다.
     *
     * 트리:  A ─ B ─ D
     *          └ C ─ E      →  ORDER BY NODE_SN 은 A, B, D, C, E
     *
     * <b>R3: 절대값을 단언하지 않는다.</b> {@code NODE_SN} 은 전역 시퀀스가 채우므로 더 이상
     * 템플릿마다 1..n 이 아니고, 저장할 때마다 값이 커지며 구간이 비어 있다. 계약으로 남은
     * 것은 <b>순서</b>뿐이다 — 그래서 이름의 나열 순서와 부모 참조가 실제 키로 이어지는지를
     * 본다. 절대값 단언을 남겨 두면 시퀀스가 어디까지 소모됐는지에 따라 결과가 달라지는
     * <b>실행 순서 의존 테스트</b>가 된다.
     */
    @Test
    @DisplayName("NODE_SN 순서가 DFS 전위다 (전역 시퀀스라 절대값이 아니라 순서가 계약)")
    void nodeSnOrderFollowsDepthFirstPreorder() {
        TemplateNode a = node("A", "");
        TemplateNode b = node("B", "");
        TemplateNode c = node("C", "");
        a.addChild(b);
        a.addChild(c);
        b.addChild(node("D", ""));
        c.addChild(node("E", ""));

        inTransaction(() -> store.save("dfs", a));

        List<Map<String, Object>> rows = nodeRows("dfs");

        List<String> names = new ArrayList<String>();
        Map<String, Long> snByName = new HashMap<String, Long>();
        long previousSn = Long.MIN_VALUE;
        for (Map<String, Object> row : rows) {
            String nodeName = (String) row.get("NODE_NAME");
            long sn = asLong(row.get("NODE_SN"));
            names.add(nodeName);
            snByName.put(nodeName, Long.valueOf(sn));
            assertTrue(sn > previousSn, "NODE_SN 이 단조 증가하지 않는다: " + row);
            previousSn = sn;
        }
        assertEquals(List.of("A", "B", "D", "C", "E"), names, "NODE_SN 순서가 DFS 전위가 아니다");

        /* 부모 참조가 실제 부모의 키를 가리키는지 — 이름 순서만 맞고 링크가 어긋날 수 있다 */
        Map<String, Object> byName = new HashMap<String, Object>();
        for (Map<String, Object> row : rows) {
            byName.put((String) row.get("NODE_NAME"), row.get("PARENT_SN"));
        }
        assertNull(byName.get("A"), "루트의 PARENT_SN 은 null 이어야 한다");
        assertEquals(snByName.get("A"), Long.valueOf(asLong(byName.get("B"))), "B 의 부모는 A");
        assertEquals(snByName.get("A"), Long.valueOf(asLong(byName.get("C"))), "C 의 부모는 A");
        assertEquals(snByName.get("B"), Long.valueOf(asLong(byName.get("D"))), "D 의 부모는 B");
        assertEquals(snByName.get("C"), Long.valueOf(asLong(byName.get("E"))), "E 의 부모는 C");
    }

    /**
     * <b>NODE_SN 이 1부터 시작한다는 가정이 깨졌음을 명시적으로 고정한다.</b>
     *
     * 저장할 때마다 노드를 전건 삭제 후 재삽입하므로 시퀀스 값은 계속 커지고 구간이 비어
     * 있다. 같은 이름으로 두 번 저장하면 두 번째 저장분의 키는 첫 번째보다 <b>전부 크다</b>.
     * "1부터"를 가정한 코드가 새로 들어오면 여기서 걸린다.
     */
    @Test
    @DisplayName("NODE_SN 은 템플릿마다 1부터가 아니라 전역으로 증가한다")
    void nodeSnIsGloballyMonotonicNotPerTemplate() {
        inTransaction(() -> store.save("seq-a", node("A", "")));
        long firstSn = asLong(nodeRows("seq-a").get(0).get("NODE_SN"));

        inTransaction(() -> store.save("seq-b", node("B", "")));
        long secondSn = asLong(nodeRows("seq-b").get(0).get("NODE_SN"));

        assertTrue(secondSn > firstSn,
                "다른 템플릿의 노드가 같은 시퀀스를 쓰지 않는다: " + firstSn + " → " + secondSn);

        /* 재저장하면 같은 템플릿 안에서도 키가 새로 발급된다 */
        inTransaction(() -> store.save("seq-a", node("A", "")));
        assertTrue(asLong(nodeRows("seq-a").get(0).get("NODE_SN")) > secondSn,
                "재저장이 옛 NODE_SN 을 재사용했다");
    }

    /**
     * <b>API 로 같은 이름을 두 번 저장</b>했을 때, 키는 전역으로 나아가되 템플릿 안의 DFS
     * 순서는 그대로여야 한다.
     *
     * 위의 저장소 직접 호출 테스트들과 달리 <b>실제 사용자 경로</b>(PUT)를 지난다. 덮어쓰기는
     * 이 시스템에서 가장 자주 일어나면서 가장 늦게 발견되는 실패 지점이다 — 최초 저장은 항상
     * 성공하므로 얕은 테스트를 통과하고, 브라우저에서 "수정 저장하니 순서가 뒤집혔다"로
     * 처음 드러난다.
     *
     * 두 성질을 한 번에 본다: ① 두 번째 저장분의 키가 전부 첫 번째보다 크다(전건 삭제 후
     * 재삽입이 실제로 일어났다) ② 그럼에도 {@code ORDER BY NODE_SN} 이 여전히 DFS 전위다.
     */
    @Test
    @DisplayName("같은 이름 2회 PUT: NODE_SN 은 전역 증가하되 템플릿 내 DFS 순서는 유지된다")
    void resaveThroughApiAdvancesKeysButKeepsDepthFirstOrder() throws Exception {
        /* A > (B > D), C — DFS 전위 그대로 평면화한 목록 (R4) */
        String tree = "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"A\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"B\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"D\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":4,\"parentSn\":1,\"name\":\"C\",\"valueType\":\"FIXED\",\"value\":\"\"}]}";

        mvc.perform(put("/api/templates/twice").contentType(MediaType.APPLICATION_JSON)
                .content(tree)).andExpect(status().isOk());

        List<String> firstOrder = new ArrayList<String>();
        long maxSnAfterFirst = Long.MIN_VALUE;
        for (Map<String, Object> row : nodeRows("twice")) {
            firstOrder.add((String) row.get("NODE_NAME"));
            maxSnAfterFirst = Math.max(maxSnAfterFirst, asLong(row.get("NODE_SN")));
        }
        assertEquals(List.of("A", "B", "D", "C"), firstOrder, "최초 저장이 DFS 전위가 아니다");

        mvc.perform(put("/api/templates/twice").contentType(MediaType.APPLICATION_JSON)
                .content(tree)).andExpect(status().isOk());

        List<String> secondOrder = new ArrayList<String>();
        for (Map<String, Object> row : nodeRows("twice")) {
            secondOrder.add((String) row.get("NODE_NAME"));
            assertTrue(asLong(row.get("NODE_SN")) > maxSnAfterFirst,
                    "재저장이 옛 NODE_SN 을 재사용했거나 옛 행이 남았다: " + row);
        }
        assertEquals(List.of("A", "B", "D", "C"), secondOrder,
                "재저장 후 DFS 전위 순서가 깨졌다");
        assertEquals(4, nodeCount("twice"), "재저장 후 노드 수가 두 배가 됐다 (삭제 누락)");

        /* 되읽은 트리도 같은 모양이어야 한다 — 행 순서만 맞고 조립이 어긋날 수 있다 */
        TemplateNode reloaded = inTransactionGet(() -> store.load("twice"));
        assertNotNull(reloaded);
        assertEquals(List.of("B", "C"), childNames(reloaded));
        assertEquals(List.of("D"), childNames(reloaded.getChildren().get(0)));
    }

    /* ---------------- helpers ---------------- */

    private static TemplateNode node(String name, String value) {
        TemplateNode node = new TemplateNode(name);
        node.setValueType(ValueType.FIXED);
        node.setValue(value);
        return node;
    }

    private static List<String> childNames(TemplateNode parent) {
        List<String> names = new ArrayList<String>();
        for (TemplateNode child : parent.getChildren()) {
            names.add(child.getName());
        }
        return names;
    }

    private void inTransaction(Runnable action) {
        new TransactionTemplate(txManager).executeWithoutResult(status -> action.run());
    }

    private <T> T inTransactionGet(java.util.function.Supplier<T> action) {
        return new TransactionTemplate(txManager).execute(status -> action.get());
    }

    private int masterCount(String name) {
        return count("SELECT COUNT(*) FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?", name);
    }

    /**
     * R3: 노드 행은 이름이 아니라 <b>대리키 {@code TEMPLATE_ID}</b> 로 마스터에 매달린다.
     * 이름은 마스터의 UNIQUE 속성일 뿐이므로 조인해야 한다.
     */
    private int nodeCount(String name) {
        return count("SELECT COUNT(*) FROM XML_TEMPLATE_NODE n"
                + " JOIN XML_TEMPLATE t ON n.TEMPLATE_ID = t.ID"
                + " WHERE t.TEMPLATE_NAME = ?", name);
    }

    private int count(String sql, String name) {
        Integer value = jdbc.queryForObject(sql, Integer.class, name);
        return (value == null) ? 0 : value.intValue();
    }

    /** 한 템플릿의 노드 행을 {@code NODE_SN} 순으로. */
    private List<Map<String, Object>> nodeRows(String name) {
        return jdbc.queryForList("SELECT n.NODE_SN, n.NODE_NAME, n.PARENT_SN"
                + " FROM XML_TEMPLATE_NODE n JOIN XML_TEMPLATE t ON n.TEMPLATE_ID = t.ID"
                + " WHERE t.TEMPLATE_NAME = ? ORDER BY n.NODE_SN", name);
    }

    private static long asLong(Object value) {
        return ((Number) value).longValue();
    }
}
