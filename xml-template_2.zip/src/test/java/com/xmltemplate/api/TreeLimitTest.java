package com.xmltemplate.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.transaction.support.TransactionTemplate;

import com.xmltemplate.repository.TemplateStore;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.util.xml.SecureXml;

/**
 * 트리 상한 (§9.2) — <b>M4 에서 DA 가 찾은 결함의 회귀</b>.
 *
 * <b>무엇이 문제였나</b>: 상한 검사가 XML 직렬화·임포트 경로에만 있어서 JSON 본문은 검사를
 * 받지 않았다. 증상은 저장소마다 달랐다.
 *
 * <ul>
 *   <li><b>MariaDB(운영)</b>: 노드를 행으로 저장·복원하므로 XML 파싱을 아예 타지 않는다 →
 *       쓰기도 읽기도 통과. <b>상한이 통째로 무효</b>였다.</li>
 *   <li><b>메모리</b>: XML 을 경유해 읽기에서 터졌다 → 저장은 되는데 읽을 수 없는 "좀비"가
 *       생기고, 목록 조회까지 같이 죽어 <b>화면에서 그 템플릿을 지울 수도 없었다</b>.</li>
 * </ul>
 *
 * 그래서 검사를 형식(XML/JSON)이 아니라 <b>정책 계층({@code TemplateService})</b>으로 옮겼다.
 * 저장소 구현이나 전송 형식과 무관하게 걸린다.
 */
class TreeLimitTest extends ApiTestSupport {

    @Autowired
    private TemplateStore repository;

    /**
     * 저장소를 직접 부르려면 트랜잭션이 필요하다.
     *
     * {@code TemplateStore} 는 스스로 트랜잭션을 열지 않는다 — 경계는 {@code TemplateService}
     * 한 곳에만 둔다는 설계다. 그래서 벌크 DELETE({@code @Modifying})가 주변 트랜잭션 없이는
     * 실행을 거부한다. 이전 JDBC 저장소는 스스로 커밋했기에 맨몸 호출이 가능했다.
     *
     * 테스트 메서드에 {@code @Transactional} 을 붙이는 방법은 <b>쓰지 않는다</b> — 서비스의
     * 트랜잭션이 테스트 트랜잭션에 참여해 커밋이 사라지고, 이 클래스가 검증하려는 "저장이
     * 실제로 이루어졌는가"가 통째로 무의미해진다.
     */
    @Autowired
    private TransactionTemplate tx;

    /** 깊이 {@code depth} 인 선형 트리. */
    private static TemplateNode deepTree(int depth) {
        TemplateNode root = new TemplateNode("L1");
        root.setValueType(ValueType.FIXED);
        TemplateNode current = root;
        for (int i = 2; i <= depth; i++) {
            TemplateNode child = new TemplateNode("L" + i);
            child.setValueType(ValueType.FIXED);
            current.addChild(child);
            current = child;
        }
        return root;
    }

    /**
     * 깊이 {@code depth} 인 <b>사슬형</b> 평면 목록 (R4).
     *
     * 중첩 JSON 시절에는 여는 괄호와 닫는 괄호를 두 번의 루프로 맞춰야 했고, 그 짝이
     * 어긋나면 상한이 아니라 <b>JSON 문법 오류</b>로 400 이 나면서도 테스트는 통과했다 —
     * 무엇을 검사하는지가 흐려지는 구조였다. 평면 목록은 {@code parentSn = sn - 1} 한 줄이
     * 곧 "한 칸 더 깊다"를 뜻해 그 함정이 사라진다.
     */
    private static String deepJson(int depth) {
        StringBuilder nodes = new StringBuilder("{\"nodes\":[");
        for (int i = 1; i <= depth; i++) {
            if (i > 1) {
                nodes.append(',');
            }
            nodes.append("{\"sn\":").append(i);
            if (i > 1) {
                nodes.append(",\"parentSn\":").append(i - 1);
            }
            nodes.append(",\"name\":\"L").append(i).append("\",\"valueType\":\"FIXED\"}");
        }
        return nodes.append("]}").toString();
    }

    /** 루트 + 자식 {@code childCount} 개인 평면 목록 — 총 노드 수는 {@code childCount + 1}. */
    private static String wideJson(int childCount) {
        StringBuilder nodes = new StringBuilder(
                "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"}");
        for (int i = 0; i < childCount; i++) {
            nodes.append(",{\"sn\":").append(i + 2)
                    .append(",\"parentSn\":1,\"name\":\"C").append(i)
                    .append("\",\"valueType\":\"FIXED\"}");
        }
        return nodes.append("]}").toString();
    }

    /* ================================================================== */

    @Test
    @DisplayName("JSON 저장 — 깊이 상한 초과는 400 (저장되지 않는다)")
    void deepTreeRejectedOnSave() throws Exception {
        mvc.perform(put("/api/templates/deep").contentType(MediaType.APPLICATION_JSON)
                        .content(deepJson(SecureXml.MAX_TREE_DEPTH + 1)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail")
                        .value(org.hamcrest.Matchers.containsString("깊이가 상한을 초과")));

        /* 저장 자체가 없었어야 한다 — 좀비가 남으면 여기서 드러난다 */
        mvc.perform(get("/api/templates/deep")).andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("JSON 저장 — 상한 이내 깊이는 통과한다 (경계값)")
    void depthAtLimitAccepted() throws Exception {
        mvc.perform(put("/api/templates/atLimit").contentType(MediaType.APPLICATION_JSON)
                        .content(deepJson(SecureXml.MAX_TREE_DEPTH)))
                .andExpect(status().isOk());
        mvc.perform(get("/api/templates/atLimit")).andExpect(status().isOk());
    }

    @Test
    @DisplayName("JSON 저장 — 노드 수 상한 초과는 400")
    void wideTreeRejectedOnSave() throws Exception {
        mvc.perform(put("/api/templates/wide").contentType(MediaType.APPLICATION_JSON)
                        .content(wideJson(SecureXml.MAX_TEMPLATE_NODES)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail")
                        .value(org.hamcrest.Matchers.containsString("노드 수가 상한을 초과")));
        mvc.perform(get("/api/templates/wide")).andExpect(status().isNotFound());
    }

    /** 미리보기는 저장을 하지 않지만 같은 재귀를 탄다 — 여기도 막아야 한다. */
    @Test
    @DisplayName("미리보기 — 깊이 상한 초과는 400")
    void deepTreeRejectedOnPreview() throws Exception {
        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"template\":" + deepJson(SecureXml.MAX_TREE_DEPTH + 1) + "}"))
                .andExpect(status().isBadRequest());
    }

    /**
     * <b>좀비가 있어도 목록은 살아 있어야 한다</b> (DA 요청 사항).
     *
     * 저장 시점 검사만으로는 부족하다 — 과거 데이터나 직접 DB 조작으로 상한을 넘긴 항목이
     * 이미 있을 수 있고, 그때 목록이 죽으면 <b>화면에서 그 항목을 골라 지울 수조차 없다</b>.
     * 그래서 서비스를 우회해 저장소에 직접 심고 목록을 확인한다.
     */
    @Test
    @DisplayName("상한 초과 항목이 저장소에 있어도 목록 조회는 200")
    void listSurvivesOversizedEntry() throws Exception {
        mvc.perform(put("/api/templates/normal").contentType(MediaType.APPLICATION_JSON)
                .content("{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                        + "\"valueType\":\"FIXED\",\"value\":\"v\"}]}"))
                .andExpect(status().isOk());

        /* 서비스 검사를 우회해 좀비를 심는다 (다른 경로로 들어온 상황을 재현) */
        tx.executeWithoutResult(status ->
                repository.save("zombie", deepTree(SecureXml.MAX_TREE_DEPTH + 1)));

        mvc.perform(get("/api/templates")).andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.name == 'normal')]").exists())
                .andExpect(jsonPath("$[?(@.name == 'zombie')]").exists());

        /* 개별 조회는 실패해도 된다 — 목록이 살아 있어 지울 수 있다는 것이 요점이다 */
        mvc.perform(delete("/api/templates/zombie")).andExpect(status().isNoContent());
        mvc.perform(get("/api/templates")).andExpect(status().isOk());
    }
}
