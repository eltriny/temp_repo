package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 실서버 기동으로만 검증되는 것 — <b>MockMvc 가 지나치는 층</b>.
 *
 * <b>왜 예외적으로 {@code ApiTestSupport} 를 상속하지 않는가</b>: MockMvc 는 서블릿 컨테이너를
 * 띄우지 않는다. 그래서 <b>커넥터와 multipart 파서 층의 규칙이 통째로 우회</b>된다 —
 * 업로드 크기 상한도, 경로의 인코딩 처리도 MockMvc 에서는 검사되지 않는다. 실제로 10MB
 * 상한은 지금까지 "프로퍼티 값이 상수와 같은가"만 확인됐고 <b>실업로드로는 한 번도 검증된 적이
 * 없었다</b>. 그 공백을 메우는 것이 이 클래스의 목적이다.
 *
 * 대신 실서버 기동은 비싸므로(컨텍스트 한 벌 추가) <b>여기 하나로만</b> 몰아 둔다.
 * 이 층을 지나면 판정은 다른 테스트들이 이미 덮은 코드와 같으므로 건수를 늘리지 않는다.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class RealServerApiTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate rest;

    private final ObjectMapper json = new ObjectMapper();

    private String url(String path) {
        return "http://localhost:" + port + path;
    }

    /* ================================================================== */
    /* 1. 업로드 상한 — 실제로 큰 바이트를 보낸다                              */
    /* ================================================================== */

    /**
     * {@code SecureXml.MAX_BODY_BYTES}(10MB) 를 넘는 파일은 400 이다.
     *
     * MockMvc 는 {@code MockMultipartFile} 을 바로 컨트롤러에 넘기므로 이 상한을 지나간다.
     * 실기동에서는 multipart 파서가 먼저 잘라내고 {@code MaxUploadSizeExceededException} 이
     * 나며, 핸들러가 그것을 {@code XML_SECURITY} 로 매핑한다 — <b>거부 사유가 사용자에게
     * "보안/상한"으로 전달되는지</b>까지가 계약이다.
     *
     * <b>이 테스트가 실제로 찾아낸 것</b>: 400 을 만드는 것과 <b>전달하는 것</b>은 다르다.
     * Tomcat 의 {@code max-swallow-size}(기본 2MB)가 남은 본문보다 작으면 연결이 끊겨
     * 클라이언트가 응답을 읽지 못한다 — 화면에는 "파일이 너무 큽니다" 대신 네트워크 오류가
     * 뜬다. {@code application.properties} 의 {@code server.tomcat.max-swallow-size} 가
     * 그 대책이고, <b>이 테스트가 그 설정의 회귀 방어선</b>이다 (프로퍼티를 되돌리면 여기서
     * 다시 broken pipe 로 실패한다).
     */
    @Test
    @DisplayName("10MB 초과 업로드는 400 XML_SECURITY (실업로드)")
    void oversizedUploadRejected() throws Exception {
        byte[] oversized = new byte[com.xmltemplate.util.xml.SecureXml.MAX_BODY_BYTES + 1024];
        Arrays.fill(oversized, (byte) 'x');

        ResponseEntity<byte[]> response = rest.postForEntity(url("/api/templates/import"),
                multipart("big.xml", "application/xml;charset=UTF-8", oversized), byte[].class);

        assertEquals(400, response.getStatusCode().value(),
                "상한 초과 업로드가 400 이 아니다: " + response.getStatusCode());
        assertEquals("XML_SECURITY", field(response, "code"));
    }

    /* ================================================================== */
    /* 2. 경로의 인코딩된 구분자                                              */
    /* ================================================================== */

    /**
     * 인코딩된 슬래시({@code %2F})가 든 이름은 4xx 다.
     *
     * <b>본문 형태는 단언하지 않는다.</b> Tomcat 은 이것을 <b>커넥터 단</b>에서 거부하므로
     * 애플리케이션 핸들러에 도달하지 않고, 따라서 ProblemDetail 본문이 아닐 수 있다.
     * 여기서 확인할 것은 "저장소 이름 규칙을 우회해 들어오지 못한다"는 사실 하나다.
     * (MockMvc 판정은 {@code TemplateApiContractTest#invalidNamesRejected} 가 덮는다 —
     *  그쪽은 애플리케이션 계층의 거부를, 이쪽은 컨테이너 계층의 거부를 본다.)
     */
    @Test
    @DisplayName("인코딩된 %2F 가 든 템플릿 이름은 4xx (커넥터 단 거부)")
    void encodedSlashInNameRejected() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(
                "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\","
                        + "\"value\":\"v\"}]}", headers);

        ResponseEntity<byte[]> response = rest.exchange(
                URI.create(url("/api/templates/a%2Fb")), HttpMethod.PUT, request, byte[].class);

        assertTrue(response.getStatusCode().is4xxClientError(),
                "인코딩된 슬래시가 통과했다: " + response.getStatusCode());
    }

    /* ================================================================== */
    /* 3. 응답 인코딩 — 한글이 왕복을 견디는가                                 */
    /* ================================================================== */

    /**
     * EUC-KR 로 선언된 파일을 올리면 한글이 <b>응답까지</b> 온전해야 한다.
     *
     * MockMvc 는 응답을 바이트로 내보내지 않으므로 "요청 디코딩은 맞는데 응답 인코딩에서
     * 깨진다"는 조합을 잡지 못한다. 실기동에서 바이트로 받아 UTF-8 로 읽어야 전 구간이
     * 검증된다 — 파트 charset 없음 → XML 선언(EUC-KR) 준수 → 내부 UTF-16 → 응답 UTF-8.
     */
    @Test
    @DisplayName("EUC-KR 선언 파일 임포트 응답의 한글이 온전하다 (실기동 바이트 왕복)")
    void eucKrDeclarationSurvivesRoundTrip() throws Exception {
        byte[] eucKr = "<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>"
                .getBytes(Charset.forName("EUC-KR"));

        ResponseEntity<byte[]> response = rest.postForEntity(url("/api/templates/import"),
                /* charset 을 붙이지 않는다 — 그래야 XML 선언을 따르는 경로를 탄다 (§4.1) */
                multipart("euckr.xml", "application/xml", eucKr), byte[].class);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("한글값", json.readTree(new String(response.getBody(), StandardCharsets.UTF_8))
                /* 평면 목록: nodes[0]=a, nodes[1]=b — 자식은 parentSn 링크로 이어진다 */
                .path("template").path("nodes").path(1).path("value").asText());
    }

    /* ---------------- helpers ---------------- */

    private static HttpEntity<MultiValueMap<String, Object>> multipart(String filename,
            String contentType, byte[] content) {
        HttpHeaders partHeaders = new HttpHeaders();
        partHeaders.setContentType(MediaType.parseMediaType(contentType));
        partHeaders.setContentDispositionFormData("file", filename);

        Resource part = new NamedByteArrayResource(content, filename);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<String, Object>();
        body.add("file", new HttpEntity<Resource>(part, partHeaders));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        return new HttpEntity<MultiValueMap<String, Object>>(body, headers);
    }

    private String field(ResponseEntity<byte[]> response, String name) throws Exception {
        byte[] body = response.getBody();
        assertTrue(body != null && body.length > 0, "응답 본문이 비어 있다");
        return json.readTree(new String(body, StandardCharsets.UTF_8)).path(name).asText();
    }
}
