package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.JsonNode;

import com.xmltemplate.exception.NodeListStructureException;

/**
 * 평면 노드 목록 계약의 <b>종단 검증</b> (R4, docs/API_V4_FLAT.md §3·§5).
 *
 * <h3>{@code TemplateMapperTest} 와의 분업</h3>
 * 매퍼 단위 테스트는 규칙 하나하나를 최소 입력으로 고정한다. 여기서는 그 규칙이 <b>HTTP 표면
 * 까지 같은 모양으로 나오는지</b>를 본다 — 상태 코드, {@code code}, {@code errors[]} 형태,
 * 그리고 저장 ↔ 조회 왕복.
 *
 * <h3>왜 왕복(T-A3)이 핵심인가</h3>
 * DFS 전위라는 순서 계약은 코드 어디에도 "정렬" 단계가 없다 — 평면화 함수의 방문 순서가 곧
 * 계약이다. 그런 계약은 단위 테스트로는 "이 함수가 이렇게 돈다"까지만 증명되고, 저장소를
 * 지나며 순서가 바뀌는 회귀는 잡히지 않는다. <b>요청 목록과 응답 목록이 sn 까지 완전히 같다</b>
 * 를 종단으로 걸어 두는 것이 그 안전망이다.
 */
class FlatNodeContractApiTest extends ApiTestSupport {

    /**
     * 3단 중첩 + 형제 순서를 가진 요청 본문.
     *
     * <b>T-A3 의 전제</b>: 왕복 동일성을 단언하려면 픽스처가 <b>전 필드를 명시</b>해야 한다.
     * 서버는 생략된 필드를 정규화해 채우므로({@code valueType→FIXED}, {@code value→""},
     * {@code valueDataType→STRING}, 조건식→{@code ""}), 일부만 적으면 응답에 없던 키가 생겨
     * "요청과 응답이 다르다"가 <b>계약 위반이 아닌 이유</b>로 실패한다.
     */
    private static final String FULL_TEMPLATE = """
            {"name":"무시됨","nodes":[
             {"sn":1,"name":"ORDER","valueType":"FIXED","value":"",
              "valueDataType":"STRING","displayCondition":"","repeatCondition":"",
              "repeatCountExpr":""},
             {"sn":2,"parentSn":1,"name":"HEADER","valueType":"FIXED","value":"",
              "valueDataType":"STRING","displayCondition":"","repeatCondition":"",
              "repeatCountExpr":""},
             {"sn":3,"parentSn":2,"name":"ORDER-NO","valueType":"VARIABLE","value":"{ORDER_NO}",
              "valueDataType":"STRING","displayCondition":"","repeatCondition":"",
              "repeatCountExpr":""},
             {"sn":4,"parentSn":2,"name":"MEMO","valueType":"VARIABLE","value":"{MEMO}",
              "valueDataType":"STRING","displayCondition":"{MEMO} != NULL",
              "repeatCondition":"","repeatCountExpr":""},
             {"sn":5,"parentSn":1,"name":"ITEMS","valueType":"FIXED","value":"",
              "valueDataType":"STRING","displayCondition":"","repeatCondition":"",
              "repeatCountExpr":""},
             {"sn":6,"parentSn":5,"name":"ITEM","valueType":"FIXED","value":"",
              "valueDataType":"STRING","displayCondition":"","repeatCondition":"",
              "repeatCountExpr":"COUNT({ITEM_NAME})"},
             {"sn":7,"parentSn":6,"name":"PRICE","valueType":"VARIABLE",
              "value":"{ITEM_PRICE_[N]}","valueDataType":"NUMBER","displayCondition":"",
              "repeatCondition":"","repeatCountExpr":""}]}
            """;

    /* ================================================================== */
    /* T-A1 · T-A2 — 임포트 응답 형태                                        */
    /* ================================================================== */

    @Test
    @DisplayName("T-A1: 임포트 응답에 template.nodes 가 있고 template.root 키는 없다")
    void importResponseIsFlat() throws Exception {
        mvc.perform(importRequest("<catalog><book><title>{T}</title></book></catalog>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes").isArray())
                .andExpect(jsonPath("$.template.root").doesNotExist())
                .andExpect(jsonPath("$.template.nodes[0].name").value("catalog"));
    }

    @Test
    @DisplayName("T-A2: 임포트 응답의 sn 은 1..n, parentSn<sn, 첫 노드가 루트")
    void importResponseSatisfiesInvariants() throws Exception {
        JsonNode nodes = importXml(
                "<Request><Header><ApiKey>{K}</ApiKey></Header>"
                        + "<Parameters><UserId>{U}</UserId></Parameters></Request>")
                .path("template").path("nodes");

        assertInvariants(nodes);
        assertEquals("Request", nodes.path(0).path("name").asText());
        assertFalse(nodes.path(0).has("parentSn"), "첫 노드에 parentSn 키가 있다");
    }

    /* ================================================================== */
    /* T-A3 — 저장 → 조회 왕복                                               */
    /* ================================================================== */

    /**
     * 요청 {@code nodes} 와 응답 {@code nodes} 가 <b>sn 을 포함해 완전히 같다</b>.
     *
     * 이 한 건이 "DTO → 도메인 트리 → 엔티티 행 → 도메인 트리 → DTO" 네 번의 변환을 통째로
     * 덮는다. 어느 한 단계에서 형제 순서가 뒤집히거나 필드가 정규화되면 여기서 드러난다.
     */
    @Test
    @DisplayName("T-A3: 저장한 nodes 와 조회한 nodes 가 sn 까지 완전히 동일하다")
    void saveThenLoadRoundTripsExactly() throws Exception {
        mvc.perform(put("/api/templates/flat-round").contentType(MediaType.APPLICATION_JSON)
                .content(FULL_TEMPLATE)).andExpect(status().isOk());

        JsonNode requested = json.readTree(FULL_TEMPLATE).path("nodes");
        JsonNode loaded = json.readTree(mvc.perform(get("/api/templates/flat-round"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString()).path("nodes");

        assertEquals(requested, loaded, "요청 목록과 응답 목록이 다르다");
    }

    /**
     * T-A4 — 응답의 {@code sn} 은 <b>항상 1..n 으로 재부여</b>된다.
     *
     * DB 의 {@code NODE_SN} 은 전역 시퀀스라 저장을 반복하면 계속 커진다. 그 값이 그대로
     * 새어 나오면 프론트는 "이 번호를 유지해 달라"는, <b>서버가 지킬 수 없는 기대</b>를 갖게
     * 된다(저장은 전건 재삽입이다). 두 템플릿을 연속 저장해 전역 SN 을 밀어 올린 뒤에도
     * 두 번째 템플릿의 sn 이 1부터 시작하는지 본다.
     */
    @Test
    @DisplayName("T-A4: DB 전역 NODE_SN 이 커져도 응답 sn 은 항상 1..n")
    void responseSnIsAlwaysReassigned() throws Exception {
        mvc.perform(put("/api/templates/flat-first").contentType(MediaType.APPLICATION_JSON)
                .content(FULL_TEMPLATE)).andExpect(status().isOk());
        mvc.perform(put("/api/templates/flat-second").contentType(MediaType.APPLICATION_JSON)
                .content(FULL_TEMPLATE)).andExpect(status().isOk());

        for (String name : new String[] { "flat-first", "flat-second" }) {
            JsonNode nodes = json.readTree(mvc.perform(get("/api/templates/" + name))
                    .andExpect(status().isOk())
                    .andReturn().getResponse().getContentAsString()).path("nodes");

            assertInvariants(nodes);
            assertEquals(1, nodes.path(0).path("sn").asInt(), name + " 의 첫 sn 이 1이 아니다");
            assertEquals(7, nodes.path(6).path("sn").asInt(), name + " 의 마지막 sn 이 n 이 아니다");
        }
    }

    /* ================================================================== */
    /* T-A5 · T-A6 · T-A7 — 구조 오류                                        */
    /* ================================================================== */

    /**
     * 구조 오류 6종이 <b>정확한 code</b> 로 나오고 {@code errors[]} 는 비어 있다.
     *
     * 구조 위반은 사용자가 화면에서 고칠 수 있는 문제가 아니라 클라이언트 직렬화 버그라
     * 목록화의 이득이 없다 — 첫 위반에서 즉시 실패한다. 조건식 오류(VALIDATION_FAILED)가
     * 목록 전체를 싣는 것과 정책이 다른 것은 의도다.
     */
    @ParameterizedTest(name = "{0} -> {1}")
    @MethodSource("structuralErrorCases")
    @DisplayName("T-A5: 구조 오류 6종은 400 + 정확한 code + errors[] 는 빈 배열")
    void structuralErrorsAreTyped(String rule, String expectedCode, String templateJson)
            throws Exception {
        mvc.perform(put("/api/templates/flat-bad").contentType(MediaType.APPLICATION_JSON)
                        .content(templateJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value(expectedCode))
                .andExpect(jsonPath("$.detail").isNotEmpty())
                .andExpect(jsonPath("$.errors").isArray())
                .andExpect(jsonPath("$.errors").isEmpty());

        /* 거부된 저장은 흔적을 남기지 않는다 */
        mvc.perform(get("/api/templates/flat-bad")).andExpect(status().isNotFound());
    }

    static Stream<Arguments> structuralErrorCases() {
        return Stream.of(
                Arguments.of("sn 이 위치와 다름", NodeListStructureException.NODE_SN_SEQUENCE,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":5,\"parentSn\":1,"
                                + "\"name\":\"A\"}]}"),
                Arguments.of("루트 2개", NodeListStructureException.MULTIPLE_ROOTS,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"name\":\"R2\"}]}"),
                Arguments.of("부모가 뒤에 있음", NodeListStructureException.PARENT_AFTER_CHILD,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"parentSn\":3,"
                                + "\"name\":\"A\"},{\"sn\":3,\"parentSn\":1,\"name\":\"B\"}]}"),
                Arguments.of("자기참조", NodeListStructureException.PARENT_AFTER_CHILD,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"parentSn\":2,"
                                + "\"name\":\"A\"}]}"),
                Arguments.of("범위 밖 부모", NodeListStructureException.ORPHAN_NODE,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"parentSn\":999,"
                                + "\"name\":\"A\"}]}"),
                Arguments.of("구 계약 root", NodeListStructureException.LEGACY_TREE_PAYLOAD,
                        "{\"root\":{\"name\":\"R\",\"valueType\":\"FIXED\"}}"),
                Arguments.of("구 계약 children", NodeListStructureException.LEGACY_TREE_PAYLOAD,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"children\":"
                                + "[{\"name\":\"A\"}]}]}"));
    }

    /**
     * T-A6 — 구 본문({@code root})은 저장·미리보기 <b>양쪽</b>에서 400 이다.
     *
     * 전역 {@code fail-on-unknown-properties=false} 때문에 필드를 그냥 없앴다면 구 클라이언트가
     * 보낸 트리가 <b>아무 말 없이 사라지고</b> "노드가 하나도 없는 템플릿"이 저장됐을 것이다.
     * {@code LegacyRemovedTest} 와 같은 성격의 고정이다.
     */
    @Test
    @DisplayName("T-A6: 구 계약 본문(root)은 저장·미리보기 모두 LEGACY_TREE_PAYLOAD")
    void legacyTreePayloadRejectedOnBothPaths() throws Exception {
        String legacy = "{\"root\":{\"name\":\"R\",\"valueType\":\"FIXED\",\"value\":\"v\","
                + "\"children\":[{\"name\":\"A\",\"valueType\":\"FIXED\",\"value\":\"x\"}]}}";

        mvc.perform(put("/api/templates/legacy-body").contentType(MediaType.APPLICATION_JSON)
                        .content(legacy))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code")
                        .value(NodeListStructureException.LEGACY_TREE_PAYLOAD));
        preview(legacy, "{}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code")
                        .value(NodeListStructureException.LEGACY_TREE_PAYLOAD));

        /* 조용한 소실이 아니라는 증거 — 저장 자체가 없었어야 한다 */
        mvc.perform(get("/api/templates/legacy-body")).andExpect(status().isNotFound());
    }

    /**
     * T-A7 — 같은 잘못된 목록이 저장과 미리보기에서 <b>같은 code</b> 로 실패한다.
     *
     * D4("검증은 두 경로가 함께 지나는 매퍼 한 곳에서")의 종단 검증이다. 검증이 저장 쪽에만
     * 있으면 사용자는 화면에서 미리보기로 확인하고 저장을 눌렀다가 거부당한다 —
     * {@code repeatCondition} 폐지 때 실제로 겪은 실패 모드다.
     */
    @ParameterizedTest(name = "{0}")
    @MethodSource("sharedRejectionCases")
    @DisplayName("T-A7: 저장과 미리보기가 같은 code 로 거부한다 (D4 종단 검증)")
    void saveAndPreviewRejectIdentically(String rule, String expectedCode, String templateJson)
            throws Exception {
        String saveCode = codeOf(mvc.perform(put("/api/templates/flat-both")
                .contentType(MediaType.APPLICATION_JSON).content(templateJson))
                .andExpect(status().isBadRequest()));
        String previewCode = codeOf(preview(templateJson, "{}", true)
                .andExpect(status().isBadRequest()));

        assertEquals(expectedCode, saveCode, "저장 경로의 code");
        assertEquals(expectedCode, previewCode,
                "미리보기 경로의 code 가 저장과 다르다 — 경로별 의미론이 갈라졌다");
    }

    static Stream<Arguments> sharedRejectionCases() {
        return Stream.of(
                Arguments.of("고아 노드", NodeListStructureException.ORPHAN_NODE,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"parentSn\":99,"
                                + "\"name\":\"A\"}]}"),
                Arguments.of("sn 순서 위반", NodeListStructureException.NODE_SN_SEQUENCE,
                        "{\"nodes\":[{\"sn\":2,\"name\":\"R\"}]}"),
                Arguments.of("구 계약 children", NodeListStructureException.LEGACY_TREE_PAYLOAD,
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"children\":[{\"name\":\"A\"}]}]}"),
                Arguments.of("폐지된 attributes", "GENERAL_ATTR_REMOVED",
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"attributes\":[{\"n\":\"id\"}]}]}"),
                Arguments.of("빈 노드 이름 (V-NAME)", "BAD_REQUEST",
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\"},{\"sn\":2,\"parentSn\":1,"
                                + "\"name\":\"  \"}]}"),
                Arguments.of("enum 오타", "BAD_REQUEST",
                        "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FUCNTION\"}]}"),
                Arguments.of("nodes 누락", "BAD_REQUEST", "{\"name\":\"x\"}"));
    }

    /* ================================================================== */
    /* 응답 전체 스캔 — 폐지된 개념은 어디에도 없다 (DA #16)                    */
    /* ================================================================== */

    /**
     * 세 응답 경로의 <b>본문 전체</b>에 {@code "children"} / {@code "attributes"} 문자열이
     * 한 번도 나오지 않는다.
     *
     * <b>왜 jsonPath 로는 부족한가</b>: {@code $.nodes[0].children} 같은 경로 단언은 <b>내가
     * 지목한 자리</b>만 본다. 노드가 많으면 그중 하나에서만 키가 새도 그 단언들은 전부 통과한다.
     * 폐지된 개념은 응답 어디에도 없어야 하므로 위치를 지목하지 않는 검사가 필요하다.
     *
     * <b>이 스캔이 특히 중요한 이유</b>: {@code NodeDto.children} 은 R4 이전까지
     * {@code = new ArrayList<>()} 로 <b>초기화되어 있었다</b>. 타입만 tombstone 으로 바꾸고
     * 초기화를 남기면 {@code non_null} 이 키를 생략하지 못해 <b>모든 응답 노드에
     * {@code "children": []} 가 실린다</b> — 컴파일도 되고 기존 테스트도 통과하는 회귀다.
     *
     * 대조군을 함께 단언한다. 위 세 단언은 <b>응답이 비어 있어도</b> 통과하기 때문이다.
     */
    @Test
    @DisplayName("GET / import / preview 응답에 \"children\"·\"attributes\" 가 0건이다 (대조군 포함)")
    void noResponseBodyMentionsLegacyKeys() throws Exception {
        String structureXml = "<order id=\"1\"><items><item seq=\"1\">"
                + "<price cur=\"KRW\">{P}</price></item></items></order>";

        String importBody = mvc.perform(importRequest(structureXml))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertFalse(importBody.contains("\"children\""),
                "임포트 응답에 children 키가 있다: " + importBody);
        assertFalse(importBody.contains("\"attributes\""),
                "임포트 응답에 attributes 키가 있다: " + importBody);

        String templateJson = json.readTree(importBody).get("template").toString();
        mvc.perform(put("/api/templates/flat-scan").contentType(MediaType.APPLICATION_JSON)
                .content(templateJson)).andExpect(status().isOk());

        String getBody = mvc.perform(get("/api/templates/flat-scan"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertFalse(getBody.contains("\"children\""), "조회 응답에 children 키가 있다: " + getBody);
        assertFalse(getBody.contains("\"attributes\""),
                "조회 응답에 attributes 키가 있다: " + getBody);

        String previewBody = preview(templateJson, "{\"P\":\"100\"}", true)
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        /*
         * 다른 두 스캔과 <b>같은 형태</b>로 따옴표를 포함해 본다. 따옴표 없이 보면 생성 XML 에
         * {@code <children>} 같은 엘리먼트 이름이 들어오는 순간 오탐한다 — 지금 미리보기 응답이
         * {@code {xml, warnings}} 뿐이라 문제가 없을 뿐이고, 그 전제는 케이스가 늘면 깨진다.
         */
        assertFalse(previewBody.contains("\"children\""),
                "미리보기 응답에 children 키가 있다: " + previewBody);
        assertFalse(previewBody.contains("\"attributes\""),
                "미리보기 응답에 attributes 키가 있다: " + previewBody);

        /*
         * 대조군 — 스캔이 살아 있다는 증거.
         *  (1) nodes 가 실제로 실려 있고, (2) 3단 중첩(order > items > item > price)이
         *      parentSn 사슬로 표현돼 있으며, (3) 저장분이 되읽혔다.
         * 셋 중 하나라도 없으면 위 단언들은 "응답이 비어서" 통과한 것이다.
         */
        JsonNode nodes = json.readTree(getBody).path("nodes");
        assertEquals(4, nodes.size(), "저장한 4단 트리가 되읽히지 않았다: " + getBody);
        assertInvariants(nodes);
        assertEquals("price", nodes.path(3).path("name").asText());
        assertEquals(3, nodes.path(3).path("parentSn").asInt(), "3단 중첩이 보존되지 않았다");
        assertTrue(json.readTree(importBody).path("warnings").toString()
                        .contains("GENERAL_ATTR_IGNORED"),
                "버린 속성의 경고가 없다 — 스캔 대상 응답이 비었을 수 있다");
    }

    /* ---------------- helpers ---------------- */

    /** 응답 목록이 (I1)(I2)를 만족하고 루트가 정확히 1개인지. */
    private static void assertInvariants(JsonNode nodes) {
        assertTrue(nodes.isArray() && nodes.size() > 0, "nodes 가 비어 있다: " + nodes);
        int roots = 0;
        for (int i = 0; i < nodes.size(); i++) {
            JsonNode node = nodes.get(i);
            assertEquals(i + 1, node.path("sn").asInt(), i + "번째 노드의 sn (I1)");
            if (!node.has("parentSn")) {
                roots++;
            } else {
                int parentSn = node.path("parentSn").asInt();
                assertTrue(parentSn >= 1 && parentSn < node.path("sn").asInt(),
                        "sn=" + node.path("sn") + " 의 parentSn=" + parentSn + " 이 (I2) 를 어긴다");
            }
        }
        assertEquals(1, roots, "루트(parentSn 키 없음)는 정확히 1개여야 한다: " + nodes);
    }

    private String codeOf(ResultActions actions) throws Exception {
        return json.readTree(actions.andReturn().getResponse().getContentAsString())
                .path("code").asText();
    }
}
