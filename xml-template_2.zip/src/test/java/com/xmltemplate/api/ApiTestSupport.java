package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * DB 를 쓰는 테스트의 공통 기반.
 *
 * <b>왜 매번 테이블을 비우는가</b>: {@code @SpringBootTest} 컨텍스트는 <b>테스트 클래스 간에
 * 공유</b>되고, 이제 저장소는 컨텍스트가 아니라 <b>실 MariaDB</b> 에 붙어 있다. 정리하지
 * 않으면 목록 조회 검증이 다른 클래스가 남긴 템플릿을 보게 되고, 실행 순서에 따라 결과가
 * 달라진다.
 *
 * <b>왜 {@code @Transactional} 롤백이 아닌가</b>: 테스트 메서드에 {@code @Transactional} 을
 * 걸면 서비스의 트랜잭션이 그 안에 <b>참여</b>해 버려 실제 커밋이 일어나지 않는다. 그러면
 * "벌크 DELETE → flush → INSERT" 순서 함정이 <b>테스트에서 절대 드러나지 않는다</b> — 이번
 * 재작성에서 가장 위험한 지점이 검증 사각지대가 되는 셈이다. 명시적 정리를 택한다.
 *
 * <b>왜 {@code TRUNCATE} 가 아닌가</b>: {@code XML_TEMPLATE} 은 {@code XML_TEMPLATE_NODE} 의
 * FK 에 참조당하는 부모다. MariaDB 는 참조당하는 테이블의 {@code TRUNCATE} 를 거부한다.
 * {@code SET FOREIGN_KEY_CHECKS=0} 우회는 세션 변수가 커넥션 풀을 통해 다음 테스트로 새어
 * 나갈 수 있다. 순서는 자식 → 부모(FK 방향).
 *
 * <b>파생 클래스는 애노테이션을 덧붙이지 않는다.</b> {@code @TestPropertySource} 나
 * {@code @MockBean} 을 하나라도 추가하면 컨텍스트 캐시 키가 달라져 <b>스프링이 통째로 한 벌
 * 더 뜬다</b> — 클래스마다 부팅 비용이 붙는다. {@code @ActiveProfiles("test")} 도 여기에만
 * 둔다. 실서버 기동이 필요한 검증은 {@code RealServerApiTest} 하나로 몰아 둔다.
 *
 * <b>병렬 실행 금지</b>: 모든 테스트가 같은 DB 를 공유하므로 surefire 의 기본 순차 실행을
 * 유지한다({@code junit.jupiter.execution.parallel.enabled} 를 켜지 않는다).
 *
 * API 밖의 테스트(저장소·매핑·트랜잭션)도 상속하므로 {@code public} 이다 — 같은 애노테이션을
 * 물려받아 <b>컨텍스트를 한 벌만</b> 띄우고, 아래 안전핀을 함께 쓰기 위해서다.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public abstract class ApiTestSupport {

    /**
     * 안전핀이 요구하는 DB 이름.
     *
     * <b>이 검사가 없으면 벌어지는 일</b>: 개발 DB {@code xml_template} 에는 실데이터가 있고
     * DB 백업이 없다. 설정이 어긋나 테스트가 그쪽에 붙으면 첫 {@code @BeforeEach} 가 데이터를
     * 지우고, 테스트는 "목록이 비어 있음"을 정상으로 보므로 <b>{@code mvn verify} 는 초록으로
     * 통과한다</b>. 사고를 알아차릴 시점에는 이미 복구 수단이 없다.
     *
     * 프로퍼티 문자열이 아니라 <b>실제 커넥션의 메타데이터 URL</b> 을 확인한다 — 프로퍼티는
     * 맞는데 다른 {@code DataSource} 빈이 이겨 다른 DB 에 붙는 경우까지 잡아야 한다.
     */
    private static final String REQUIRED_DATABASE = "xml_template_test";

    @Autowired
    protected MockMvc mvc;

    /** 요청 본문 조립·응답 파싱용. 서버 쪽 매퍼와는 무관한 테스트 도구다. */
    protected final ObjectMapper json = new ObjectMapper();

    /** spring-boot-starter-data-jpa 가 spring-jdbc 를 전이 포함한다. */
    @Autowired
    private JdbcTemplate jdbc;

    /**
     * {@code XML_TEMPLATE_NODE_ATTR} 은 정리하지 않는다 — R2 에서 일반 속성 기능이 제거되며
     * 엔티티·리포지토리·스키마에서 모두 빠졌다. 신규 환경에는 테이블 자체가 없으므로
     * {@code DELETE} 를 남겨 두면 <b>모든 테스트가 "테이블 없음"으로 죽는다</b>.
     */
    @BeforeEach
    void resetDatabase() {
        requireTestDatabase();
        jdbc.execute("DELETE FROM XML_TEMPLATE_NODE");
        jdbc.execute("DELETE FROM XML_TEMPLATE");
    }

    /** 정리 직전 안전핀. 테스트 DB 가 아니면 <b>한 행도 지우지 않고</b> 즉시 실패한다. */
    private void requireTestDatabase() {
        DataSource dataSource = jdbc.getDataSource();
        if (dataSource == null) {
            fail("JdbcTemplate 에 DataSource 가 없다 — 테스트 DB 확인 불가");
            return;
        }
        String url;
        try (Connection connection = dataSource.getConnection()) {
            url = connection.getMetaData().getURL();
        } catch (SQLException e) {
            throw new IllegalStateException("테스트 DB 커넥션을 열지 못했습니다. "
                    + "MariaDB(127.0.0.1:13306)와 " + REQUIRED_DATABASE + " DB 가 필요합니다.", e);
        }
        if (!REQUIRED_DATABASE.equals(databaseNameOf(url))) {
            fail("테스트가 테스트 DB 에 붙어 있지 않다 — 정리를 중단한다. 실제 접속 URL: " + url
                    + " (요구 DB: " + REQUIRED_DATABASE + ", 판독된 DB: " + databaseNameOf(url) + "). "
                    + "src/test/resources/application-test.properties 와 @ActiveProfiles(\"test\") 확인.");
        }
    }

    /**
     * JDBC URL 에서 <b>DB 이름만</b> 뽑는다 — {@code …/xml_template_test?user=…} → {@code xml_template_test}.
     *
     * <b>부분 문자열 비교로는 안 되는 이유</b>: 커넥션 메타데이터의 URL 에는 자격 증명이
     * 함께 붙는다({@code ?user=xml_template&password=***}). {@code url.contains(…)} 로 보면
     * 계정명이나 다른 DB 이름에 {@code xml_template_test} 가 섞이는 순간 <b>개발 DB 에 붙은
     * 채로 검사가 통과</b>한다. 지우는 쪽 검사는 관대하면 안 되므로 경로 세그먼트를 잘라
     * <b>정확히 일치</b>하는지 본다.
     */
    private static String databaseNameOf(String url) {
        if (url == null) {
            return null;
        }
        int query = url.indexOf('?');
        String path = (query < 0) ? url : url.substring(0, query);
        int slash = path.lastIndexOf('/');
        return (slash < 0) ? null : path.substring(slash + 1);
    }

    /* ------------------------------------------------------------------ */
    /* 미리보기 — 구 SelfTest 가 XmlGenerator 를 직접 부르던 자리             */
    /* ------------------------------------------------------------------ */

    /**
     * {@code POST /api/preview} 호출.
     *
     * @param templateJson {@code TemplateDto} JSON (최소 {@code {"nodes":[{"sn":1,…}]}})
     * @param dataJson     외부 데이터 객체 JSON. null 이면 빈 객체.
     */
    protected ResultActions preview(String templateJson, String dataJson, boolean withWarnings)
            throws Exception {
        String body = "{\"template\":" + templateJson
                + ",\"data\":" + (dataJson == null ? "{}" : dataJson)
                + ",\"withWarnings\":" + withWarnings + "}";
        return mvc.perform(post("/api/preview")
                .contentType(MediaType.APPLICATION_JSON).content(body));
    }

    /** 미리보기 성공을 기대하고 생성된 XML 만 꺼낸다. */
    protected String previewXml(String templateJson, String dataJson) throws Exception {
        return previewBody(templateJson, dataJson).get("xml").asText();
    }

    /** 미리보기 성공을 기대하고 응답 본문 전체를 돌려준다. */
    protected JsonNode previewBody(String templateJson, String dataJson) throws Exception {
        String response = preview(templateJson, dataJson, true)
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(response);
    }

    /** 미리보기 생성 경고 코드 집합. 개수가 아니라 <b>집합</b>으로 본다 (회차 수에 딸린 값 제외). */
    protected Set<String> previewWarningCodes(String templateJson, String dataJson)
            throws Exception {
        return codesOf(previewBody(templateJson, dataJson).get("warnings"));
    }

    /* ------------------------------------------------------------------ */
    /* 임포트                                                               */
    /* ------------------------------------------------------------------ */

    /**
     * 붙여넣기 경로와 같은 형태의 multipart 임포트 요청.
     *
     * <b>파트 charset 을 명시한다</b> — 그러지 않으면 서버가 "무엇으로 읽었는지" 알리는
     * {@code ENCODING_USED} 경고를 매번 붙이고(계약 §4.4), 경고 집합을 단언하는 테스트가
     * 이 잡음을 계속 걸러야 한다. 프론트도 charset 을 명시하므로 이쪽이 실제 경로다.
     * 인코딩 정책 자체는 {@code TemplateApiContractTest} 가 따로 덮는다.
     */
    protected RequestBuilder importRequest(String structureXml) {
        return multipart("/api/templates/import")
                .file(new MockMultipartFile("file", "case.xml", "application/xml;charset=UTF-8",
                        structureXml.getBytes(StandardCharsets.UTF_8)));
    }

    /** 임포트 성공을 기대하고 응답 본문({@code template}/{@code warnings}/{@code variables}). */
    protected JsonNode importXml(String structureXml) throws Exception {
        String body = mvc.perform(importRequest(structureXml))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(body);
    }

    /* ------------------------------------------------------------------ */
    /* 본문 조립 도우미                                                      */
    /* ------------------------------------------------------------------ */

    /**
     * 값 노드 하나짜리 최소 템플릿 — <b>평면 계약</b>(R4).
     *
     * 구 {@code SelfTest.evalExpr} 이 쓰던 형태 그대로다 — 식 하나를 실제 생성 경로에
     * 태워 결과 문자열만 관찰하기 위한 최소 껍데기이며, 결과 노드 이름은 {@code V} 다.
     *
     * 루트에는 {@code parentSn} 키를 <b>싣지 않는다</b> (계약: 루트만 생략, {@code 0} 같은
     * 매직 넘버 금지). 이 헬퍼 하나가 API 테스트 대부분의 본문을 만들므로 계약이 바뀌면
     * 여기부터 고친다.
     */
    protected String singleNode(String valueType, String value) {
        return "{\"nodes\":[{\"sn\":1,\"name\":\"V\",\"valueType\":\"" + valueType
                + "\",\"value\":" + quote(value) + "}]}";
    }

    /** 자바 문자열을 JSON 문자열 리터럴로 (식에 든 따옴표·역슬래시를 안전하게 싣는다). */
    protected String quote(String raw) {
        try {
            return json.writeValueAsString(raw);
        } catch (IOException e) {
            throw new IllegalStateException("JSON 문자열 변환 실패: " + raw, e);
        }
    }

    /** {@code warnings} / {@code errors} 배열에서 {@code code} 집합을 뽑는다. */
    protected static Set<String> codesOf(JsonNode array) {
        Set<String> codes = new LinkedHashSet<String>();
        if (array != null) {
            for (JsonNode item : array) {
                codes.add(item.path("code").asText());
            }
        }
        return codes;
    }

    /** 테스트 리소스를 UTF-8 문자열로 읽는다. */
    protected static String resource(String classpathPath) {
        try (InputStream in = ApiTestSupport.class.getClassLoader()
                .getResourceAsStream(classpathPath)) {
            if (in == null) {
                throw new IllegalStateException("테스트 리소스를 찾지 못했습니다: " + classpathPath);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("테스트 리소스 읽기 실패: " + classpathPath, e);
        }
    }
}
