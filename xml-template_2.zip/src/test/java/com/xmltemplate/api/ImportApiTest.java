package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import com.fasterxml.jackson.databind.JsonNode;

import com.xmltemplate.support.XmlAssert;

/**
 * 구조 XML 임포트 (§3) — 구 {@code SelfTest.checkStructureImport} 이관본.
 *
 * <b>임포트가 하는 일</b>: 사용자가 가진 <b>결과물 예시 XML</b> 을 템플릿 트리로 되돌린다.
 * 값 유형(고정/변수/함수)은 <b>추론</b>하고, {@code repeatCountExpr} 같은 예약 속성은
 * 제어 정보로 <b>흡수</b>하며, 표현할 수 없는 입력(혼합 콘텐츠·네임스페이스)은 <b>거부</b>한다.
 *
 * 셋 다 조용히 하면 안 된다는 것이 §3 의 요지다 — 추론은 경고로 알리고, 흡수한 속성도
 * 경고로 알리며, 표현 불가는 빈 값으로 떨구지 않고 오류를 낸다. 그래서 이 클래스는
 * "무엇이 되는가"만큼 <b>"무엇을 알리는가"와 "무엇을 거부하는가"</b>를 함께 고정한다.
 *
 * 기본 왕복(파일명 기반 제안 이름·인코딩·XXE)은 {@code TemplateApiContractTest} 가 덮는다.
 */
class ImportApiTest extends ApiTestSupport {

    /** 명세 §14 정본 예시 1 (원문 그대로 — {@code &gt;} 이스케이프 포함). */
    private static final String SPEC_EXAMPLE_1 =
            "<catalog>\n"
            + "    <book repeatCountExpr=\"COUNT({BOOK_NAME})\">\n"
            + "        <author>{BOOK_AUTHOR_[N]}</author>\n"
            + "        <title>{BOOK_NAME_[N]}</title>\n"
            + "        <genre>Computer</genre>\n"
            + "        <price displayCondition=\"{BOOK_PRICE_[N]} != NULL\">"
            + "{BOOK_PRICE_[N]} &gt; 1000000 ? '고' : '저'</price>\n"
            + "        <publish_date displayCondition=\"catalog.book.price != NULL\">"
            + "{BOOK_PUBLISH_DATE_[N]}</publish_date>\n"
            + "        <description>{BOOK_DESCRIPTION_[N]}</description>\n"
            + "    </book>\n"
            + "</catalog>";

    /** 명세 §15 정본 예시 2 (원문 그대로 — 4 depth, 중첩 반복). */
    private static final String SPEC_EXAMPLE_2 =
            "<Request>\n"
            + "    <Header>\n"
            + "        <ApiKey>{API_KEY}</ApiKey>\n"
            + "        <Timestamp>{TIMESTAMP}</Timestamp>\n"
            + "    </Header>\n"
            + "    <Parameters>\n"
            + "        <UserId>{PARAM_USERID}</UserId>\n"
            + "        <Action>{PARAM_ACTION}</Action>\n"
            + "        <PageSize displayCondition=\"Request.Parameters.UserId != NULL\">"
            + "{PARAM_PAGE_SIZE}</PageSize>\n"
            + "        <Filters>\n"
            + "            <Filter repeatCountExpr=\"COUNT({PARAM_FILTER_CATEGORY})\">\n"
            + "                <Category>{PARAM_FILTER_CATEGORY_[N1]}</Category>\n"
            + "                <MinPrice>{PARAM_FILTER_PRICE_[N1]}</MinPrice>\n"
            + "                <Items displayCondition=\"COUNT({PARAM_FILTER_ITEM_[N1]}) &gt; 0\">\n"
            + "                    <Item repeatCountExpr=\"COUNT({PARAM_FILTER_ITEM_[N1]})\">"
            + "{PARAM_FILTER_ITEM_[N1]_[N2]}</Item>\n"
            + "                </Items>\n"
            + "            </Filter>\n"
            + "        </Filters>\n"
            + "    </Parameters>\n"
            + "</Request>";

    /* ================================================================== */
    /* §14 예시 1 — 구조·추론·보존                                           */
    /* ================================================================== */

    @Nested
    @DisplayName("§14 예시 1 임포트")
    class SpecExample1 {

        @Test
        @DisplayName("트리 구조: 루트 catalog + 자식 1개, book 에 자식 6개")
        void treeShape() throws Exception {
            mvc.perform(importRequest(SPEC_EXAMPLE_1))
                    .andExpect(status().isOk())
                    /* 평면 목록: catalog(sn=1) → book(sn=2) → 자식 6개(sn=3..8) */
                    .andExpect(jsonPath("$.template.nodes.length()").value(8))
                    .andExpect(jsonPath("$.template.nodes[0].name").value("catalog"))
                    .andExpect(jsonPath("$.template.nodes[0].parentSn").doesNotExist())
                    .andExpect(jsonPath("$.template.nodes[1].name").value("book"))
                    .andExpect(jsonPath("$.template.nodes[1].parentSn").value(1))
                    /* book 의 자식 6개가 연속으로 이어진다 — DFS 전위의 관찰 가능한 형태 */
                    .andExpect(jsonPath("$.template.nodes[2].parentSn").value(2))
                    .andExpect(jsonPath("$.template.nodes[7].parentSn").value(2));
        }

        /** 예약 속성은 <b>제어 정보로 흡수</b>된다 — 일반 속성으로 남으면 출력 XML 에 새어 나간다. */
        @Test
        @DisplayName("repeatCountExpr 을 제어 정보로 흡수하고 일반 속성으로 남기지 않는다")
        void reservedAttributeAbsorbed() throws Exception {
            mvc.perform(importRequest(SPEC_EXAMPLE_1))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.template.nodes[1].repeatCountExpr")
                            .value("COUNT({BOOK_NAME})"))
                    /* R2/R4: 폐지된 개념은 빈 배열이 아니라 키 자체가 없다 */
                    .andExpect(jsonPath("$.template.nodes[1].attributes").doesNotExist())
                    .andExpect(jsonPath("$.template.nodes[1].children").doesNotExist());
        }

        @ParameterizedTest(name = "{0} -> {1}")
        @CsvSource({
            "author, VARIABLE",   // {BOOK_AUTHOR_[N]}
            "genre,  FIXED",      // Computer
            "price,  FUNCTION",   // 삼항식
        })
        @DisplayName("값 유형 추론 (명시 > 삼항 > 중괄호 > 고정)")
        void valueTypeInference(String childName, String expectedType) throws Exception {
            assertEquals(expectedType,
                    childOf(importXml(SPEC_EXAMPLE_1), "book", childName)
                            .path("valueType").asText());
        }

        @Test
        @DisplayName("&gt; 이스케이프가 '>' 로 해제되어 저장된다")
        void entityUnescapedIntoValue() throws Exception {
            assertEquals("{BOOK_PRICE_[N]} > 1000000 ? '고' : '저'",
                    childOf(importXml(SPEC_EXAMPLE_1), "book", "price").path("value").asText());
        }

        @Test
        @DisplayName("displayCondition 보존 (변수 기준 / 노드 경로 기준)")
        void displayConditionsPreserved() throws Exception {
            JsonNode imported = importXml(SPEC_EXAMPLE_1);
            assertEquals("{BOOK_PRICE_[N]} != NULL",
                    childOf(imported, "book", "price").path("displayCondition").asText());
            assertEquals("catalog.book.price != NULL",
                    childOf(imported, "book", "publish_date").path("displayCondition").asText());
        }

        /** 추론과 흡수는 <b>조용히</b> 일어나면 안 된다. */
        @Test
        @DisplayName("경고 코드: TYPE_INFERRED / RESERVED_ATTR_CONSUMED 발생")
        void inferenceAndAbsorptionAreReported() throws Exception {
            assertTrue(codesOf(importXml(SPEC_EXAMPLE_1).get("warnings"))
                            .containsAll(Arrays.asList("TYPE_INFERRED", "RESERVED_ATTR_CONSUMED")),
                    "추론·흡수 경고가 없다");
        }
    }

    /* ================================================================== */
    /* §15 예시 2 — 다중 depth 중첩 반복                                     */
    /* ================================================================== */

    @Nested
    @DisplayName("§15 예시 2 임포트 (4 depth 중첩 반복)")
    class SpecExample2 {

        @Test
        @DisplayName("바깥/안쪽 반복 repeatCountExpr 과 인덱스 참조 조건이 보존된다")
        void nestedRepeatPreserved() throws Exception {
            JsonNode nodes = nodesOf(importXml(SPEC_EXAMPLE_2));
            JsonNode filter = node(nodes, "Parameters", "Filters", "Filter");
            JsonNode items = child(nodes, filter, "Items");
            JsonNode item = child(nodes, items, "Item");

            assertEquals("COUNT({PARAM_FILTER_CATEGORY})", filter.path("repeatCountExpr").asText());
            assertEquals("COUNT({PARAM_FILTER_ITEM_[N1]}) > 0",
                    items.path("displayCondition").asText());
            assertEquals("COUNT({PARAM_FILTER_ITEM_[N1]})", item.path("repeatCountExpr").asText());
        }

        @Test
        @DisplayName("다중 인덱스 변수값 보존 + 절대 노드 경로 조건 보존")
        void multiIndexAndAbsolutePathPreserved() throws Exception {
            JsonNode nodes = nodesOf(importXml(SPEC_EXAMPLE_2));
            JsonNode parameters = node(nodes, "Parameters");
            JsonNode item = node(nodes, "Parameters", "Filters", "Filter", "Items", "Item");

            assertEquals("{PARAM_FILTER_ITEM_[N1]_[N2]}", item.path("value").asText());
            assertEquals("VARIABLE", item.path("valueType").asText());
            assertEquals("Request.Parameters.UserId != NULL",
                    child(nodes, parameters, "PageSize").path("displayCondition").asText());
        }
    }

    /* ================================================================== */
    /* 참조 변수 목록 (§12.2)                                                */
    /* ================================================================== */

    /**
     * <b>왜 정적 목록이 필요한가</b>: 단축 평가 때문에 논리 연산 오른쪽의 오타 변수는
     * 데이터에 따라 평가조차 되지 않아 경고로 드러나지 않는다. 화면이 "이 템플릿이 쓰는
     * 변수"를 보여주려면 평가와 무관한 정적 수집이 있어야 한다.
     */
    @Nested
    @DisplayName("참조 변수 목록")
    class Variables {

        @Test
        @DisplayName("예시2 의 전 변수를 등장 순으로 수집한다")
        void collectedInAppearanceOrder() throws Exception {
            assertEquals(Arrays.asList(
                            "API_KEY", "TIMESTAMP", "PARAM_USERID", "PARAM_ACTION",
                            "PARAM_PAGE_SIZE", "PARAM_FILTER_CATEGORY",
                            "PARAM_FILTER_CATEGORY_[N1]", "PARAM_FILTER_PRICE_[N1]",
                            "PARAM_FILTER_ITEM_[N1]", "PARAM_FILTER_ITEM_[N1]_[N2]"),
                    variablesOf(SPEC_EXAMPLE_2));
        }

        @Test
        @DisplayName("노드 경로와 예약어는 제외된다")
        void pathsAndReservedWordsExcluded() throws Exception {
            List<String> variables = variablesOf(SPEC_EXAMPLE_2);
            assertFalse(variables.contains("NULL"), "예약어가 변수로 잡혔다: " + variables);
            assertFalse(variables.contains("Request.Parameters.UserId"),
                    "노드 경로가 변수로 잡혔다: " + variables);
        }

        /** 함수 인자도 변수다 — COUNT 인자를 빼면 "쓰이는데 목록에 없는" 변수가 생긴다. */
        @Test
        @DisplayName("COUNT 인자 포함 + 중복 제거")
        void functionArgumentIncludedAndDeduplicated() throws Exception {
            assertEquals(List.of("K"),
                    variablesOf("<a><b repeatCountExpr=\"COUNT({K})\">{K}</b><c>{K}</c></a>"));
        }

        /**
         * 치환 판정과 <b>같은 스캐너</b>를 써야 한다 — 다르면 목록과 실제 치환이 갈라진다.
         *
         * <b>R2 세 번째 행</b>: 변수가 <b>무시되는 속성 안에만</b> 있으면 목록에 실리지
         * 않는다. 실렸다면 프론트가 사용자에게 "이 값을 채우라"고 요구하는데 그 값은 어디에도
         * 쓰이지 않는다 — 조용한 거짓 요구가 된다.
         */
        @ParameterizedTest(name = "{0}")
        @CsvSource(delimiter = '|', value = {
            "<a>총 {{CNT}} 건</a>                        |",
            "<a>총 {{LIT}} {REAL} 건</a>                 | REAL",
            "<a lang=\"총 {{LIT}} {REAL} 건\">v</a>      |",
        })
        @DisplayName("이스케이프된 중괄호는 변수로 세지 않는다 (무시된 속성의 변수도 제외)")
        void escapedBracesAreNotVariables(String structureXml, String expected) throws Exception {
            List<String> want = (expected == null || expected.isBlank())
                    ? List.of() : List.of(expected.trim());
            assertEquals(want, variablesOf(structureXml.trim()));
        }
    }

    /* ================================================================== */
    /* 일반 속성 — R2 에서 폐지, 버리되 알린다                                 */
    /* ================================================================== */

    private static final String ATTRIBUTE_XML =
            "<book id=\"1\" lang=\"{LANG}\" grade=\"{N} &gt; 5 ? 'A' : 'B'\">"
                    + "<title>{T}</title></book>";

    /**
     * R2 에서 일반 XML 속성 기능이 제거됐다. 임포트는 <b>거부가 아니라 경고 후 버림</b>이다 —
     * 사용자가 올린 원본 XML 에 속성이 있는 것은 자연스러운 일이라 거부하면 기존 파일을 아예
     * 가져올 수 없게 된다. 대신 <b>조용히 버리면 안 된다</b>: "올린 대로 저장됐다"고 오해한
     * 채 생성 결과에서 속성이 사라진 것을 나중에 발견하게 된다.
     *
     * (요청 경로는 정반대로 <b>거부</b>한다 — {@code TombstoneContractApiTest} 참조.
     *  임포트는 사용자 파일을 받는 입구라 관대하고, 저장·미리보기는 우리 계약이라 엄격하다.)
     */
    @Nested
    @DisplayName("일반 속성 무시와 경고")
    class Attributes {

        @Test
        @DisplayName("일반 속성은 응답 트리에 실리지 않는다 (키 자체가 없다)")
        void generalAttributesNotInResponse() throws Exception {
            mvc.perform(importRequest(ATTRIBUTE_XML))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.template.nodes[0].attributes").doesNotExist())
                    .andExpect(jsonPath("$.template.nodes[1].attributes").doesNotExist());
        }

        /**
         * 버린 속성마다 하나씩 경고가 나오고, <b>이름과 값이 메시지에 실린다</b>.
         * 개수만 맞추면 "무엇을 버렸는지"를 사용자가 알 수 없어 경고의 목적이 사라진다.
         */
        @Test
        @DisplayName("버린 속성마다 GENERAL_ATTR_IGNORED 경고에 이름·값이 실린다")
        void ignoredAttributesReportedWithNameAndValue() throws Exception {
            String body = mvc.perform(importRequest(ATTRIBUTE_XML))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.warnings[?(@.code == 'GENERAL_ATTR_IGNORED')]",
                            Matchers.hasSize(3)))
                    .andReturn().getResponse().getContentAsString();

            assertTrue(body.contains("id=\\\"1\\\""), "버린 속성 id 의 값이 경고에 없다: " + body);
            assertTrue(body.contains("lang=\\\"{LANG}\\\""), "버린 속성 lang 의 값이 경고에 없다");
            assertTrue(body.contains("grade="), "버린 속성 grade 가 경고에 없다");
        }

        /**
         * 경고가 <b>어느 노드의</b> 속성인지 {@code nodePath} 로 지목한다.
         *
         * 큰 문서에서 "속성 몇 개를 버렸다"만 알면 사용자는 어디를 고칠지 알 수 없다.
         * 같은 이름의 속성이 여러 노드에 있는 경우가 흔하므로 이름만으로는 특정되지 않는다.
         * 프론트가 경고를 트리 위에 표시하려면 이 필드가 정확해야 한다.
         */
        @Test
        @DisplayName("GENERAL_ATTR_IGNORED 경고가 nodePath 로 노드를 지목한다 (중첩 포함)")
        void ignoredAttributeWarningCarriesNodePath() throws Exception {
            mvc.perform(importRequest("<order id=\"1\"><item seq=\"2\">x</item></order>"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath(
                            "$.warnings[?(@.code == 'GENERAL_ATTR_IGNORED')].nodePath",
                            Matchers.containsInAnyOrder("order", "order.item")));
        }

        /**
         * 생성 XML 에 속성이 <b>하나도</b> 나오지 않는다.
         *
         * 응답 트리에 없다는 것만으로는 부족하다 — 생성기가 다른 경로로 속성을 만들어 내면
         * 트리에는 없는데 출력에는 있는 상태가 된다. {@code XmlAssert} 는 속성 차이를
         * 정규화하지 않으므로 여기서 걸린다.
         */
        @Test
        @DisplayName("생성 XML 에 일반 속성이 출력되지 않는다")
        void attributesNotRenderedInOutput() throws Exception {
            String template = importXml(ATTRIBUTE_XML).get("template").toString();
            assertNull(XmlAssert.diff("<book><title>제목</title></book>",
                    previewXml(template, "{\"LANG\":\"ko\",\"N\":\"9\",\"T\":\"제목\"}")));
        }
    }

    /* ================================================================== */
    /* 경고: 강등 / 무시                                                     */
    /* ================================================================== */

    /**
     * 삼항으로 <b>보이지만</b> 파싱에 실패하는 값은 오류가 아니라 FIXED 강등이다 —
     * 사용자가 식으로 의도하지 않았을 수 있으므로 막지 않고 알린다.
     */
    @Test
    @DisplayName("경고 코드: 삼항 파싱 실패 -> FIXED 강등 + TYPE_DEMOTED")
    void ternaryParseFailureDemotes() throws Exception {
        mvc.perform(importRequest("<a>x ? y : z : w</a>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[0].valueType").value("FIXED"))
                .andExpect(jsonPath("$.warnings[?(@.code == 'TYPE_DEMOTED')]").exists());
    }

    /** 주석은 모델에 자리가 없다 — 버리되 버렸다고 알린다. */
    @Test
    @DisplayName("경고 코드: 주석 무시 + COMMENT_IGNORED")
    void commentIgnoredWithWarning() throws Exception {
        mvc.perform(importRequest("<a><!-- 메모 --><b>x</b></a>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[?(@.code == 'COMMENT_IGNORED')]").exists());
    }

    /* ================================================================== */
    /* 추론 FUNCTION 의 강등 vs 명시 FUNCTION 의 오류                         */
    /* ================================================================== */

    @Test
    @DisplayName("임포트: 추론 FUNCTION 의 전방 참조는 FIXED 강등 + TYPE_DEMOTED")
    void inferredForwardReferenceDemotes() throws Exception {
        mvc.perform(importRequest("<R><A>EXISTS(R.B) ? 'Y' : 'N'</A><B>x</B></R>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[1].valueType").value("FIXED"))
                .andExpect(jsonPath("$.warnings[?(@.code == 'TYPE_DEMOTED')]").exists());
    }

    /**
     * 명시 {@code valueType="FUNCTION"} 은 <b>강등하지 않는다</b> — 사용자가 식이라고
     * 선언했으므로 오류를 감추면 안 된다. 그 결과 검증 오류가 살아남아 400 이 된다.
     * <b>이 400 자체가 "강등되지 않았다"의 증거다</b>: 강등됐다면 FIXED 문자열이 되어
     * 노드 경로 검증을 아예 받지 않고 200 으로 통과했을 것이다.
     */
    @Test
    @DisplayName("임포트: 명시 FUNCTION 의 전방 참조는 검증 오류로 남는다 (400)")
    void explicitForwardReferenceFails() throws Exception {
        mvc.perform(importRequest(
                        "<R><A valueType=\"FUNCTION\">EXISTS(R.B) ? 'Y' : 'N'</A><B>x</B></R>"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"))
                .andExpect(jsonPath("$.errors[*].code")
                        .value(Matchers.hasItem("FORWARD_REFERENCE")));
    }

    /** 오인 추론의 탈출구 — 명시하면 추론을 건너뛴다. */
    @Test
    @DisplayName("명시 valueType 은 추론을 덮어쓴다")
    void explicitTypeOverridesInference() throws Exception {
        mvc.perform(importRequest("<a valueType=\"FIXED\">{NOT_A_VARIABLE}</a>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[0].valueType").value("FIXED"));
    }

    /* ================================================================== */
    /* 거부 — 조용한 소실 금지                                               */
    /* ================================================================== */

    /**
     * 전부 "무시하고 넘어갈 수도 있는" 입력이다. 그러면 사용자가 쓴 것이 결과에 없는데
     * 이유를 알 수 없게 된다 — 표현할 수 없으면 거부하는 것이 §3 의 규칙이다.
     */
    @ParameterizedTest(name = "{0}")
    @CsvSource(delimiter = '|', value = {
        "혼합 콘텐츠                    | <a>텍스트<b>x</b></a>",
        "네임스페이스 엘리먼트           | <ns:a><b>x</b></ns:a>",
        "네임스페이스 속성               | <a xml:lang=\"ko\">x</a>",
        "v2 에서 폐지된 repeatCondition | <a repeatCondition=\"{X} == 'Y'\">x</a>",
        "dataType 값 오류               | <a dataType=\"date\">x</a>",
        "valueType 값 오류              | <a valueType=\"NUMBER\">x</a>",
        "루트에 displayCondition        | <a displayCondition=\"{X} == 'Y'\"><b>x</b></a>",
        "루트에 repeatCountExpr         | <a repeatCountExpr=\"3\"><b>x</b></a>",
        "명시 FUNCTION 의 식 파싱 실패   | <a valueType=\"FUNCTION\">x ? y : z : w</a>",
        "displayCondition 문법 오류      | <a displayCondition=\"{X} &lt;&lt; 3\">x</a>",
    })
    @DisplayName("임포트 거부 규칙")
    void importRejected(String rule, String structureXml) throws Exception {
        mvc.perform(importRequest(structureXml.trim()))
                .andExpect(status().isBadRequest());
    }

    /** multipart 경로에도 XXE 방어가 걸린다 (원문 본문 경로는 계약 테스트가 덮는다). */
    @Test
    @DisplayName("거부: DOCTYPE — 임포트 경로에도 XXE 방어 적용")
    void doctypeRejectedOnMultipart() throws Exception {
        mvc.perform(importRequest("<?xml version=\"1.0\"?>"
                        + "<!DOCTYPE a [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]><a>&xxe;</a>"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("XML_SECURITY"));
    }

    /* ---------------- helpers ---------------- */

    private List<String> variablesOf(String structureXml) throws Exception {
        List<String> variables = new ArrayList<String>();
        for (JsonNode name : importXml(structureXml).path("variables")) {
            variables.add(name.asText());
        }
        return variables;
    }

    /* ---------------- 평면 목록 탐색 (R4) ---------------- */
    /*
     * 응답이 평면 목록이 되면서 "자식"은 중첩 배열이 아니라 <b>parentSn 링크</b>다.
     * 인덱스로 단언하면 형제 순서가 바뀔 때 무슨 일이 일어났는지 읽히지 않으므로,
     * 이름으로 내려가는 탐색기를 둔다 — 구 child(node, name) 과 같은 역할이다.
     */

    private static JsonNode nodesOf(JsonNode importResult) {
        return importResult.path("template").path("nodes");
    }

    /** 루트에서 이름을 따라 내려간다. {@code node(nodes, "Parameters", "Filters")} 형태. */
    private static JsonNode node(JsonNode nodes, String... names) {
        JsonNode current = nodes.path(0);
        for (String name : names) {
            current = child(nodes, current, name);
        }
        return current;
    }

    /** {@code parent} 의 sn 을 parentSn 으로 갖는 노드 중 이름이 같은 것. */
    private static JsonNode child(JsonNode nodes, JsonNode parent, String name) {
        int parentSn = parent.path("sn").asInt();
        for (JsonNode candidate : nodes) {
            if (candidate.path("parentSn").asInt(-1) == parentSn
                    && name.equals(candidate.path("name").asText())) {
                return candidate;
            }
        }
        throw new IllegalStateException("자식 노드를 찾을 수 없습니다: " + name
                + " (부모: " + parent.path("name").asText() + ")");
    }

    /** {@code root.<parent>.<child>} 노드. 이름으로 찾으므로 순서 변경에 흔들리지 않는다. */
    private static JsonNode childOf(JsonNode importResult, String parentName, String childName) {
        return node(nodesOf(importResult), parentName, childName);
    }
}
