package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * 프론트가 <b>분기 없이</b> 소비하려면 지켜져야 하는 응답 형태 (UI/UX 검토 결과).
 *
 * 여기 있는 것은 전부 "없으면 프론트가 방어 코드를 들고 있어야 하는" 항목이다.
 * 그런 방어는 한 번 들어가면 계약이 고쳐져도 사라지지 않고, 결국 어느 쪽이 진짜 계약인지
 * 알 수 없게 된다 — 이 프로젝트가 프론트 2종 시절에 겪은 형태다.
 *
 * 개별 기능의 의미론은 다른 클래스가 덮는다. 여기서는 <b>형태</b>만 본다.
 */
class ContractHardeningApiTest extends ApiTestSupport {

    private static final String SIMPLE_TEMPLATE =
            "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\","
                    + "\"value\":\"v\"}]}";

    /**
     * {@code variables[]} 는 <b>문자열 배열</b>이다.
     *
     * 객체 배열({@code [{"name":"T"}]})로 바뀌면 화면의 변수 목록이 {@code [object Object]}
     * 로 렌더링된다 — 타입이 없는 JSON 계약에서 조용히 깨지는 전형적 지점이다.
     */
    @Test
    @DisplayName("variables[] 는 문자열 배열이다")
    void variablesAreStrings() throws Exception {
        JsonNode variables = importXml("<a><b>{T}</b><c>{U}</c></a>").path("variables");

        assertTrue(variables.isArray(), "variables 가 배열이 아니다: " + variables);
        assertEquals(2, variables.size());
        for (JsonNode variable : variables) {
            assertTrue(variable.isTextual(),
                    "variables 원소가 문자열이 아니다: " + variable.getNodeType() + " " + variable);
        }
    }

    /**
     * 삭제는 <b>204 + 본문 없음</b>이다.
     *
     * 본문을 실으면 프론트가 "JSON 을 기대했는데 비어 있음" 예외를 밟거나, 반대로 빈 본문에
     * 파서를 돌려 실패한다. 어느 쪽이든 삭제는 성공했는데 화면은 실패로 보인다.
     */
    @Test
    @DisplayName("DELETE 는 204 이고 본문이 없다")
    void deleteReturnsNoContent() throws Exception {
        mvc.perform(put("/api/templates/del").contentType(MediaType.APPLICATION_JSON)
                .content(SIMPLE_TEMPLATE)).andExpect(status().isOk());

        mvc.perform(delete("/api/templates/del"))
                .andExpect(status().isNoContent())
                .andExpect(content().string(""));
    }

    /**
     * 미리보기 실패는 <b>4xx + ProblemDetail</b> 이다.
     *
     * 200 에 오류 문구를 담으면 프론트는 성공 경로에서 오류를 찾아야 하고, 500 이면
     * 사용자는 "내 입력 문제"인지 "서버 장애"인지 구분할 수 없다. {@code detail} 이 비면
     * 화면에 표시할 문장이 없어 "HTTP 400" 만 남는다.
     */
    @Test
    @DisplayName("미리보기 오류는 4xx + ProblemDetail 이고 detail 이 비어 있지 않다")
    void previewErrorIsProblemDetail() throws Exception {
        preview("{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FUNCTION\","
                        + "\"value\":\"SUM({X})\"}]}", "{\"X_1\":\"숫자아님\"}", true)
                .andExpect(status().is4xxClientError())
                .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.detail").isNotEmpty())
                .andExpect(jsonPath("$.code").isNotEmpty())
                /* 검증 오류가 아니어도 배열이 있어야 프론트가 분기하지 않는다 */
                .andExpect(jsonPath("$.errors").isArray());
    }

    /**
     * 경고에는 항상 {@code nodePath} 가 있다 (노드가 특정되지 않으면 빈 문자열).
     *
     * 화면은 경고를 트리의 해당 노드에 붙여 보여준다. 키가 없거나 null 이면 그 자리에서
     * {@code undefined} 를 렌더링하게 된다 — "없음"은 null 이 아니라 "" 로 표현한다 (§2.9).
     */
    @Test
    @DisplayName("warnings[] 에는 nodePath 가 항상 있다 (문서 단위 경고는 빈 문자열)")
    void warningsCarryNodePath() throws Exception {
        /* 노드 단위 경고 — 임포트의 유형 추론 */
        JsonNode importWarnings = importXml("<a><b>{T}</b></a>").path("warnings");
        assertTrue(importWarnings.size() > 0, "임포트 경고가 없다");
        for (JsonNode warning : importWarnings) {
            assertTrue(warning.has("nodePath"), "nodePath 키가 없다: " + warning);
            assertTrue(warning.path("nodePath").isTextual(),
                    "nodePath 가 문자열이 아니다: " + warning);
        }

        /* 문서 단위 경고 — 생성 경고는 노드를 특정하지 않는다 */
        mvc.perform(put("/api/templates/w").contentType(MediaType.APPLICATION_JSON)
                .content(SIMPLE_TEMPLATE)).andExpect(status().isOk());
        preview("{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"VARIABLE\","
                        + "\"value\":\"{MISSING}\"}]}", "{}", true)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].nodePath").exists())
                .andExpect(jsonPath("$.warnings[0].nodePath").value(Matchers.notNullValue()));
    }

    /* ================================================================== */
    /* §10 출력 규칙 — 골든 대조로는 증명되지 않는 것                          */
    /* ================================================================== */

    /**
     * {@code xml} 필드는 <b>XML 선언 없이</b> 시작한다.
     *
     * <b>왜 따로 보는가</b>: {@link com.xmltemplate.support.XmlAssert} 는 선언 유무를
     * 정규화해 무시한다. 즉 골든 케이스 13건이 전부 통과해도 선언이 붙었는지는 알 수 없다.
     * 이 값은 사용자가 복사해 다른 문서에 끼워 넣는 조각이므로 선언이 끼면 그 자리에서
     * 깨진다 — 문자열로 직접 봐야 하는 이유다.
     */
    @Test
    @DisplayName("§10: 생성 결과는 XML 선언을 출력하지 않는다")
    void generatedXmlHasNoDeclaration() throws Exception {
        String xml = previewXml(SIMPLE_TEMPLATE, "{}");
        assertTrue(!xml.startsWith("<?xml"), "생성 결과에 XML 선언이 붙었다:\n" + xml);
    }

    /**
     * 값이 빈 리프는 <b>self-closing</b> 이다.
     *
     * 이것도 정규화 비교로는 증명되지 않는다 — {@code <a/>} 와 {@code <a></a>} 는 같다고
     * 판정되기 때문이다. 출력 형태 자체가 계약이라면 문자열로 확인해야 한다.
     */
    @Test
    @DisplayName("§10: 값이 빈 리프는 self-closing")
    void emptyLeafIsSelfClosing() throws Exception {
        String xml = previewXml(
                "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"VARIABLE\","
                        + "\"value\":\"{EMPTY}\"}]}",
                "{\"EMPTY\":\"\"}");
        assertTrue(xml.contains("<R/>"), "빈 리프가 self-closing 이 아니다:\n" + xml);
    }

    /**
     * 목록이 비면 <b>빈 배열 200</b> 이다 — 404 가 아니다.
     *
     * 404 로 내면 첫 방문(저장된 템플릿 0건)이 화면에 오류로 뜬다. "아직 없음"은 정상 상태다.
     */
    @Test
    @DisplayName("템플릿이 하나도 없으면 목록은 빈 배열 200")
    void emptyListIsEmptyArray() throws Exception {
        mvc.perform(get("/api/templates"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isEmpty());
    }
}
