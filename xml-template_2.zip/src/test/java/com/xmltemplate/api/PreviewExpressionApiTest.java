package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.xmltemplate.support.XmlAssert;

/**
 * 표현식 의미론을 미리보기 경로로 검증한다 — 구 {@code SelfTest.checkFunctionsAndNull} /
 * {@code checkLazyEvaluation}(생성 부분) / {@code checkDisplayAwarePathReference} 이관본.
 *
 * <b>평가 껍데기</b>: 구 검증의 {@code evalExpr} 은 FUNCTION 값 노드 하나짜리 템플릿으로
 * 식을 감싸 실제 생성 경로를 태웠다. 여기서도 같은 형태를 쓰되 진입점만
 * {@code POST /api/preview} 로 바꾼다 — 식 평가가 <b>HTTP 를 지나서도 같은 답</b>을 내는지가
 * 이제 계약이기 때문이다.
 */
class PreviewExpressionApiTest extends ApiTestSupport {

    /** 구 checkFunctionsAndNull 의 데이터 맵 그대로. */
    private static final String DATA = """
            {"EMPTY":"","BLANK":" ","VALUE":"x",
             "N_1":"1","N_2":"2","N_3":"3",
             "GAP_1":"a","GAP_3":"c",
             "D_1":"0.1","D_2":"0.2",
             "S_1":"1.50","S_2":"2.5",
             "MIX_1":"1","MIX_2":"십만원",
             "HOLE_1":"1","HOLE_2":"","HOLE_3":"2"}
            """;

    /* ================================================================== */
    /* 값 평가 — NULL 3상태 / COUNT / SUM / EXISTS / 순서 비교                */
    /* ================================================================== */

    @ParameterizedTest(name = "{0} -> {1}")
    @MethodSource("valueCases")
    @DisplayName("식 평가 결과 (§4, §6, §7)")
    void expressionValue(String expression, String expected, String rule) throws Exception {
        assertEquals(expected, evalExpr(expression, DATA), rule + " — 식: " + expression);
    }

    static Stream<Arguments> valueCases() {
        return Stream.of(
                /* ---------- NULL 3상태 (§7) ---------- */
                arguments("{MISSING} == NULL", "true", "키 부재는 NULL"),
                arguments("{EMPTY} == NULL", "true", "빈 문자열은 NULL"),
                arguments("{BLANK} == NULL", "false", "공백만 있는 값은 NULL 이 아니다 (trim 안 함)"),
                arguments("{VALUE} == NULL", "false", "값이 있으면 NULL 이 아니다"),
                arguments("{VALUE} != NULL", "true", "!= 비교"),
                arguments("NULL == NULL", "true", "NULL == NULL 은 참"),
                arguments("{EMPTY} == ''", "true", "{X} == NULL 은 {X} == '' 와 동치"),

                /* ---------- COUNT (§6.1) — 키의 존재를 센다 ---------- */
                arguments("COUNT({N})", "3", "연속 3건"),
                arguments("COUNT({NOPE})", "0", "하나도 없으면 0"),
                arguments("COUNT({GAP})", "1", "불연속이면 연속 구간까지만 (GAP_1 만)"),
                arguments("COUNT({HOLE})", "3", "값이 비어도 키가 있으면 센다"),

                /* ---------- SUM (§6.2) — 값을 더한다 ---------- */
                arguments("SUM({D})", "0.3", "BigDecimal 누적 (이진 부동소수점 아님)"),
                arguments("SUM({S})", "4.00", "입력 최대 소수 자릿수 유지 (1.50 + 2.5)"),
                arguments("SUM({N})", "6", "정수 합"),
                arguments("SUM({NOPE})", "0", "빈 그룹은 0"),
                arguments("SUM({HOLE})", "3", "빈 값은 건너뛴다 (NUMBER 정책과 일관)"),

                /* ---------- EXISTS (§6.3) — 키의 존재 ---------- */
                arguments("EXISTS({EMPTY})", "true", "값이 비어도 키가 있으면 true"),
                arguments("EXISTS({MISSING})", "false", "키가 없으면 false"),

                /* ---------- 순서 비교 (§4) ---------- */
                arguments("{EMPTY} > 10", "false", "NULL 이면 거짓"),
                arguments("{N_3} > 2", "true", "양쪽 숫자면 정상 비교"));
    }

    /* ================================================================== */
    /* 거부 — 조용한 폴백 금지                                               */
    /* ================================================================== */

    /**
     * 세 경우 모두 "그럴듯한 기본값"이 있지만 쓰지 않는다.
     * 문자열 폴백·0 반환은 잘못된 결과를 <b>정상 응답으로</b> 내보내는 길이다.
     */
    @ParameterizedTest(name = "{0}")
    @ValueSource(strings = {
        "SUM({MIX})",         // 비숫자가 섞이면 생성 오류 (§6.2)
        "{VALUE} > 10",       // 한쪽만 숫자면 생성 오류 — 문자열 폴백 금지 (§4)
        "COUNT({N_[N1]})",    // 반복 밖의 [N1] 은 스코프 깊이 초과 (조용히 0 아님)
    })
    @DisplayName("평가 실패는 400 GENERATION_FAILED")
    void expressionRejected(String expression) throws Exception {
        preview(singleNode("FUNCTION", expression), DATA, true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
    }

    /* ================================================================== */
    /* 경고 — 실패시키지 않되 조용히 넘기지도 않는다                           */
    /* ================================================================== */

    @Nested
    @DisplayName("생성 경고")
    class Warnings {

        @Test
        @DisplayName("COUNT: 불연속 지점 뒤에 키가 더 있으면 경고 (데이터 유실 방지)")
        void countGapWarns() throws Exception {
            assertTrue(previewWarningCodes(singleNode("FUNCTION", "COUNT({GAP})"), DATA)
                            .contains("COUNT_GAP"),
                    "COUNT_GAP 경고가 없다");
        }

        /**
         * 고정 폭 탐침이면 {@code W_50} 을 못 본다 — 간격이 넓어도 놓치지 않아야 한다.
         * 값은 여전히 연속 구간까지(1)이고, 뒤에 키가 있다는 사실만 경고로 알린다.
         */
        @Test
        @DisplayName("COUNT: 간격이 넓어도(W_1, W_50) 값은 1 이고 불연속 경고가 나온다")
        void wideCountGapWarns() throws Exception {
            String wide = "{\"W_1\":\"a\",\"W_50\":\"z\"}";
            assertEquals("1", evalExpr("COUNT({W})", wide));
            assertTrue(previewWarningCodes(singleNode("FUNCTION", "COUNT({W})"), wide)
                            .contains("COUNT_GAP"),
                    "넓은 간격에서 COUNT_GAP 경고가 없다");
        }

        /** 전체 생성을 실패시키지 않는다 — 거짓으로 두고 경고만 남긴다. */
        @Test
        @DisplayName("순서 비교: NULL 피연산자는 거짓 + 경고")
        void nullOrderComparisonWarns() throws Exception {
            assertTrue(previewWarningCodes(singleNode("FUNCTION", "{EMPTY} > 10"), DATA)
                            .contains("NULL_ORDER_COMPARISON"),
                    "NULL_ORDER_COMPARISON 경고가 없다");
        }
    }

    /* ================================================================== */
    /* 단축 평가 — 평가되지 않은 가지의 오류는 없는 것 (§4)                    */
    /* ================================================================== */

    /**
     * 오른쪽 식은 문법은 유효하되 <b>평가 시점에</b> 실패해야 한다. 파싱 오류를 쓰면
     * 단축 평가와 무관하게 터져 증명이 되지 않는다. 실패 유발 수단은 {@code SUM(비숫자)} —
     * 명세 §6.2 가 영구 규칙으로 못박은 것이라 이후 단계에서 뒤집히지 않는다.
     */
    @Nested
    @DisplayName("단축 평가 (§4)")
    class ShortCircuit {

        private static final String LAZY_DATA = "{\"A\":\"Y\",\"BAD_1\":\"십만원\"}";

        private String conditioned(String displayCondition) {
            return "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                    + "{\"sn\":2,\"parentSn\":1,\"name\":\"C\",\"valueType\":\"FIXED\","
                    + "\"value\":\"보임\",\"displayCondition\":" + quote(displayCondition)
                    + "}]}";
        }

        @Test
        @DisplayName("'||' 왼쪽이 참이면 오른쪽 평가 오류가 있어도 생성 성공")
        void orShortCircuits() throws Exception {
            assertTrue(previewXml(conditioned("{A} == 'Y' || SUM({BAD}) > 0"), LAZY_DATA)
                    .contains("<C>보임</C>"));
        }

        @Test
        @DisplayName("'&&' 왼쪽이 거짓이면 오른쪽 평가 오류가 있어도 생성 성공")
        void andShortCircuits() throws Exception {
            assertFalse(previewXml(conditioned("{A} == 'N' && SUM({BAD}) > 0"), LAZY_DATA)
                    .contains("<C>"));
        }

        @Test
        @DisplayName("삼항의 선택되지 않은 분기에 평가 오류가 있어도 생성 성공")
        void ternaryShortCircuits() throws Exception {
            String template = "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                    + "{\"sn\":2,\"parentSn\":1,\"name\":\"C\",\"valueType\":\"FUNCTION\","
                    + "\"value\":" + quote("{A} == 'Y' ? '보임' : SUM({BAD})") + "}]}";
            assertTrue(previewXml(template, LAZY_DATA).contains("<C>보임</C>"));
        }

        /** 완화가 과하지 않은지 — 가려지지 않으면 여전히 실패해야 한다. */
        @Test
        @DisplayName("대조군: 가려지지 않으면 여전히 생성 실패")
        void unguardedFailureStillFails() throws Exception {
            preview(conditioned("SUM({BAD}) > 0"), LAZY_DATA, true)
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
        }
    }

    /* ================================================================== */
    /* 표시 제외 노드 경로 참조 (§8)                                         */
    /* ================================================================== */

    /**
     * 정본 예시 1 의 {@code publish_date} 시나리오를 반복 없이 재현한다.
     *
     * {@code price} 가 표시 제외되면 {@code catalog.book.price != NULL} 도 거짓이어야 한다.
     * 값만 다시 계산하면 삼항의 거짓 분기 값('저')이 나와 조건이 <b>참</b>이 되어 버리는 것이
     * §8 규칙이 필요한 이유다.
     */
    @Nested
    @DisplayName("표시 제외 노드 참조는 NULL (§8)")
    class DisplayAwarePathReference {

        private static final String PRICE_AND_DATE = """
                {"nodes":[
                  {"sn":1,"name":"catalog","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"book","valueType":"FIXED"},
                  {"sn":3,"parentSn":2,"name":"price","valueType":"FUNCTION",
                   "value":"{BOOK_PRICE} > 1000000 ? '고' : '저'",
                   "displayCondition":"{BOOK_PRICE} != NULL"},
                  {"sn":4,"parentSn":2,"name":"publish_date","valueType":"VARIABLE",
                   "value":"{BOOK_PUBLISH_DATE}",
                   "displayCondition":"catalog.book.price != NULL"}]}
                """;

        /** 위 트리에 {@code EXISTS(경로)} 플래그를 하나 더 단 것 — "출력 확정 여부"의 관찰창. */
        private static final String WITH_EXISTS_FLAG = """
                {"nodes":[
                  {"sn":1,"name":"catalog","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"book","valueType":"FIXED"},
                  {"sn":3,"parentSn":2,"name":"price","valueType":"FUNCTION",
                   "value":"{BOOK_PRICE} > 1000000 ? '고' : '저'",
                   "displayCondition":"{BOOK_PRICE} != NULL"},
                  {"sn":4,"parentSn":2,"name":"flag","valueType":"FUNCTION",
                   "value":"EXISTS(catalog.book.price) ? 'Y' : 'N'"}]}
                """;

        private static final String WITH_PRICE =
                "{\"BOOK_PRICE\":\"1500000\",\"BOOK_PUBLISH_DATE\":\"2024-01-01\"}";
        private static final String WITHOUT_PRICE = "{\"BOOK_PUBLISH_DATE\":\"2024-02-01\"}";

        @Test
        @DisplayName("참조 노드가 출력되면 경로 참조도 그 값을 본다")
        void referencedNodeVisible() throws Exception {
            assertNull(XmlAssert.diff(
                    "<catalog><book><price>고</price>"
                            + "<publish_date>2024-01-01</publish_date></book></catalog>",
                    previewXml(PRICE_AND_DATE, WITH_PRICE)));
        }

        /** 날짜 데이터가 <b>있어도</b> 미출력이어야 한다 — 참조 노드가 표시 제외라서. */
        @Test
        @DisplayName("표시 제외된 노드 참조는 NULL — 날짜 데이터가 있어도 publish_date 미생성")
        void hiddenNodeReferenceIsNull() throws Exception {
            assertNull(XmlAssert.diff("<catalog><book/></catalog>",
                    previewXml(PRICE_AND_DATE, WITHOUT_PRICE)));
        }

        @Test
        @DisplayName("EXISTS(경로): 출력되는 노드는 true")
        void existsOnVisibleNode() throws Exception {
            assertTrue(previewXml(WITH_EXISTS_FLAG, WITH_PRICE).contains("<flag>Y</flag>"));
        }

        @Test
        @DisplayName("EXISTS(경로): 표시 제외된 노드는 false")
        void existsOnHiddenNode() throws Exception {
            assertTrue(previewXml(WITH_EXISTS_FLAG, WITHOUT_PRICE).contains("<flag>N</flag>"));
        }
    }

    /* ---------------- helpers ---------------- */

    /**
     * 식 하나를 평가한 결과 문자열 (구 {@code SelfTest.evalExpr} 의 API 판).
     * 값이 비면 리프가 self-closing 이 되므로 {@code <V/>} 를 빈 문자열로 읽는다 (§10).
     */
    private String evalExpr(String expression, String dataJson) throws Exception {
        String xml = previewXml(singleNode("FUNCTION", expression), dataJson);
        int open = xml.indexOf("<V>");
        if (open < 0) {
            return xml.contains("<V/>") ? "" : xml;
        }
        return xml.substring(open + 3, xml.indexOf("</V>"));
    }
}
