package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * 미리보기 ↔ 생성 동등성 (docs/API_V4_FLAT.md §4.5·§4.6) — <b>핵심 게이트</b>.
 *
 * <b>이 테스트가 지키는 것</b>: 화면에서 본 미리보기({@code POST /api/preview})와 저장분
 * 생성({@code POST /api/generate/{name}})이 정말로 {@code TemplateService} 한 벌을
 * 공유하는지. 두 경로에 정책이 조금씩 복사되면 각 경로의 단독 테스트는 통과하지만
 * "미리보기로 확인한 XML 과 실제 생성 결과가 다르다"는 형태로 터진다.
 *
 * (전신은 {@code XmlJsonEquivalenceTest} — 레거시 {@code POST /generate/{name}} 와 신규
 * JSON 경로를 맞대던 게이트였다. 레거시 경로가 제거되면서 대조 축을 미리보기↔생성으로
 * 옮겼다. 경로 제거 자체는 {@code LegacyRemovedTest} 가 고정한다.)
 */
class PreviewGenerateEquivalenceTest extends ApiTestSupport {

    private final ObjectMapper json = new ObjectMapper();

    /**
     * 반복·인덱스·조건·집계를 한 번에 쓰는 템플릿 (명세 §14 형태).
     *
     * <b>R2</b>: 일반 속성이 폐지되어 {@code attributes} 를 뺐다 — 남겨 두면 요청 자체가
     * 400 {@code GENERAL_ATTR_REMOVED} 로 거부된다. {@code {INDEX}} 는 속성이 아니라
     * <b>자식 노드 값</b>으로 옮겨 인덱스 변수 커버리지를 그대로 유지한다.
     */
    private static final String TEMPLATE_JSON = """
            {"nodes":[
              {"sn":1,"name":"catalog","valueType":"FIXED"},
              {"sn":2,"parentSn":1,"name":"book","valueType":"FIXED",
               "repeatCountExpr":"COUNT({TITLE})"},
              {"sn":3,"parentSn":2,"name":"seq","valueType":"VARIABLE","value":"{INDEX}"},
              {"sn":4,"parentSn":2,"name":"title","valueType":"VARIABLE","value":"{TITLE_[N]}"},
              {"sn":5,"parentSn":2,"name":"price","valueType":"VARIABLE","value":"{PRICE_[N]}",
               "valueDataType":"NUMBER","displayCondition":"{PRICE_[N]} != NULL"},
              {"sn":6,"parentSn":1,"name":"total","valueType":"FUNCTION","value":"SUM({PRICE})",
               "valueDataType":"NUMBER"}]}
            """;

    private static final String DATA =
            "{\"TITLE_1\":\"자바\",\"TITLE_2\":\"코틀린\",\"PRICE_1\":\"30000\",\"PRICE_2\":\"25000\"}";

    /* ================================================================== */
    /* 1. 미리보기와 생성의 바이트 동일성                                     */
    /* ================================================================== */

    /**
     * 같은 저장분에 대한 미리보기와 생성 결과가 <b>바이트 단위로</b> 같아야 한다.
     * 정규화 비교가 아니라 문자열 동일성을 요구하는 이유: 두 경로 모두 엔진 출력을
     * 그대로 담는 계약이라, 어느 한쪽에 후처리가 끼어드는 순간 여기서 드러나야 한다.
     */
    @Test
    @DisplayName("/api/preview 와 /api/generate 의 XML 이 바이트 동일 (§3.4 보장)")
    void previewMatchesGenerate() throws Exception {
        save("pv", TEMPLATE_JSON);

        JsonNode template = json.readTree(mvc.perform(get("/api/templates/pv"))
                .andReturn().getResponse().getContentAsString());
        ObjectNode body = json.createObjectNode();
        body.set("template", template);
        body.set("data", json.readTree(DATA));

        String preview = jsonField(mvc.perform(post("/api/preview")
                        .contentType(MediaType.APPLICATION_JSON).content(body.toString()))
                .andExpect(status().isOk()).andReturn(), "xml");

        String generated = jsonField(mvc.perform(post("/api/generate/pv")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":" + DATA + "}"))
                .andExpect(status().isOk()).andReturn(), "xml");

        assertEquals(generated, preview, "미리보기와 생성 결과가 다르다");
        assertTrue(generated.contains("<title>자바</title>"), "반복 1회차 값이 없다: " + generated);
        assertTrue(generated.contains("<seq>2</seq>"), "인덱스 변수 결과가 없다: " + generated);
        assertTrue(generated.contains("<total>55000</total>"), "SUM 결과가 없다: " + generated);
    }

    /** 저장·삭제·생성이 같은 저장소를 봐야 한다 — 지운 템플릿은 생성이 404 다. */
    @Test
    @DisplayName("저장/삭제/생성이 같은 저장소를 본다")
    void repositoryIsShared() throws Exception {
        save("shared", "{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                + "\"valueType\":\"VARIABLE\",\"value\":\"{V}\"}]}");

        mvc.perform(post("/api/generate/shared").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":{\"V\":\"값\"}}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.xml").value(
                        org.hamcrest.Matchers.containsString("<R>값</R>")));

        mvc.perform(delete("/api/templates/shared")).andExpect(status().isNoContent());
        mvc.perform(post("/api/generate/shared").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":{}}"))
                .andExpect(status().isNotFound());
    }

    /** 경고 생성도 한 곳이어야 한다 — 미리보기와 생성이 같은 코드를 낸다. */
    @Test
    @DisplayName("생성 경고가 미리보기와 생성에서 같은 코드로 나온다")
    void generationWarningsMatch() throws Exception {
        save("warn", "{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                + "\"valueType\":\"VARIABLE\",\"value\":\"{MISSING}\"}]}");

        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"template\":{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                                + "\"valueType\":\"VARIABLE\",\"value\":\"{MISSING}\"}]},"
                                + "\"withWarnings\":true}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("MISSING_VARIABLE"));

        mvc.perform(post("/api/generate/warn").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":{}}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("MISSING_VARIABLE"));
    }

    /* ---------------- helpers ---------------- */

    private void save(String name, String templateJson) throws Exception {
        mvc.perform(put("/api/templates/" + name).contentType(MediaType.APPLICATION_JSON)
                .content(templateJson)).andExpect(status().isOk());
    }

    private String jsonField(MvcResult result, String field) throws Exception {
        return json.readTree(result.getResponse().getContentAsString()).get(field).asText();
    }
}
