package com.xmltemplate.api;

import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.MediaType;

import com.xmltemplate.util.template.TemplateValidator;

/**
 * 저장 시점 정적 검증 (§8, §11) — 구 {@code SelfTest.checkStaticValidation} 이관본.
 *
 * <b>왜 저장 시점인가</b>: 이 오류들은 전부 <b>데이터와 무관</b>하다. 존재하지 않는 노드
 * 경로, 전방 참조, 결정 불가능한 인덱스 — 어떤 데이터를 넣어도 틀린 것이다. 생성 시점까지
 * 미루면 사용자는 미리보기를 눌러 봐야 알게 되고, 그때는 이미 저장된 뒤다(§11).
 *
 * <b>왜 한 벌로 몰아 놓았나</b>: 규칙마다 클래스를 나누면 "이 규칙이 저장에서 걸리는가"를
 * 확인하려고 여러 파일을 뒤져야 한다. 표로 두면 규칙 목록 자체가 문서가 된다.
 */
class ValidationApiTest extends ApiTestSupport {

    /* ================================================================== */
    /* 거부되어야 하는 템플릿                                                */
    /* ================================================================== */

    @ParameterizedTest(name = "{0}")
    @MethodSource("rejectedCases")
    @DisplayName("정적 검증: 저장 거부 (400 + errors[])")
    void saveRejected(String rule, String templateJson, String expectedCode) throws Exception {
        mvc.perform(save(templateJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"))
                .andExpect(jsonPath("$.errors[*].code").value(Matchers.hasItem(expectedCode)));
    }

    static Stream<Arguments> rejectedCases() {
        return Stream.of(
                /* ---------- 노드 경로 참조 (§8) ---------- */
                arguments("미지 노드 경로 (예시2 의 'Paramters' 오타)",
                        pathReference("Request.Paramters.UserId != NULL"),
                        TemplateValidator.ERR_UNKNOWN_PATH),
                arguments("전방 참조 — 뒤에 있는 노드는 아직 값이 없다",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FIXED","value":"x",
                           "displayCondition":"R.B != NULL"},
                          {"sn":3,"parentSn":1,"name":"B","valueType":"FIXED","value":"x"}]}
                        """,
                        TemplateValidator.ERR_FORWARD_REFERENCE),
                arguments("자기 참조",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FIXED","value":"x",
                           "displayCondition":"R.A != NULL"}]}
                        """,
                        TemplateValidator.ERR_SELF_REFERENCE),
                arguments("동명 형제로 경로가 모호한 참조",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FIXED","value":"x"},
                          {"sn":3,"parentSn":1,"name":"A","valueType":"FIXED","value":"y"},
                          {"sn":4,"parentSn":1,"name":"B","valueType":"FIXED","value":"z",
                           "displayCondition":"R.A != NULL"}]}
                        """,
                        TemplateValidator.ERR_AMBIGUOUS_PATH),
                arguments("다른 반복 스코프의 노드 참조 (인스턴스 결정 불가)",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"LoopA","valueType":"FIXED","repeatCountExpr":"2"},
                          {"sn":3,"parentSn":2,"name":"InA","valueType":"FIXED","value":"x"},
                          {"sn":4,"parentSn":1,"name":"LoopB","valueType":"FIXED","repeatCountExpr":"2"},
                          {"sn":5,"parentSn":4,"name":"InB","valueType":"FIXED","value":"y",
                           "displayCondition":"R.LoopA.InA != NULL"}]}
                        """,
                        TemplateValidator.ERR_SCOPE_CHAIN),

                /* ---------- EXISTS 인자도 같은 검증을 받는다 ---------- */
                /*
                 * Expr.Call.children() 이 인자를 포함하기 때문에 성립하는 성질인데, 그 의존이
                 * 암묵적이라 children() 을 리팩터링하면 조용히 뚫린다. 계약으로 고정한다.
                 */
                arguments("EXISTS 인자의 전방 참조도 거부 (Expr.Call.children() 계약)",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FUNCTION",
                           "value":"EXISTS(R.B) ? 'Y' : 'N'"},
                          {"sn":3,"parentSn":1,"name":"B","valueType":"FIXED","value":"x"}]}
                        """,
                        TemplateValidator.ERR_FORWARD_REFERENCE),
                arguments("EXISTS 인자의 미지 경로도 거부",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FUNCTION",
                           "value":"EXISTS(R.NOPE) ? 'Y' : 'N'"}]}
                        """,
                        TemplateValidator.ERR_UNKNOWN_PATH),

                /* ---------- 순서 비교 (§4) ---------- */
                arguments("리터럴 NULL 의 순서 비교는 정적 오류",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FIXED","value":"x",
                           "displayCondition":"{X} > NULL"}]}
                        """,
                        TemplateValidator.ERR_NULL_ORDER),

                /* ---------- 인덱스 깊이 (§5.1) ---------- */
                arguments("반복 조상 2개인 곳의 [N] 축약형은 오류 (모호함을 저장 시점에)",
                        nestedLeaf("{K_[N]}"), TemplateValidator.ERR_INDEX_DEPTH),
                arguments("체인 깊이를 넘는 [N3] 은 오류",
                        nestedLeaf("{K_[N3]}"), TemplateValidator.ERR_INDEX_DEPTH),
                arguments("반복 밖에서 인덱스 표기 사용은 오류",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"VARIABLE","value":"{K_[N1]}"}]}
                        """,
                        TemplateValidator.ERR_INDEX_DEPTH),
                arguments("반복 노드의 횟수식은 자기 회차를 쓸 수 없다",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"L","valueType":"FIXED",
                           "repeatCountExpr":"{K_[N1]}"}]}
                        """,
                        TemplateValidator.ERR_INDEX_DEPTH),

                /* ---------- 변수명의 리터럴 대괄호 (§3.1) ---------- */
                /*
                 * 파서는 '_[N' 3글자로 인덱스를 인식하므로 {A[N1]} 은 기준 이름의 일부로 남는다.
                 * 거부하지 않으면 (a) 치환기가 [N 2글자를 보던 시절엔 조용히 A1 을 조회했고
                 * (b) {AB[N2]C} 는 검증 통과 후 생성에서 실패해 §11(저장 시 오류)을 위반한다.
                 */
                arguments("변수명 {A[N1]} 은 저장 오류 (조용히 A1 을 조회하던 지점)",
                        repeatedLeaf("{A[N1]}"), TemplateValidator.ERR_VARIABLE_NAME),
                arguments("변수명 {AB[N2]C} 는 저장 오류 (생성에서 실패하던 §11 위반 지점)",
                        repeatedLeaf("{AB[N2]C}"), TemplateValidator.ERR_VARIABLE_NAME),

                /* ---------- 문법 ---------- */
                arguments("표현식 문법 오류도 검증 오류로 모인다",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"A","valueType":"FIXED","value":"x",
                           "displayCondition":"{X} =="}]}
                        """,
                        TemplateValidator.ERR_SYNTAX));
    }

    /* ================================================================== */
    /* 통과해야 하는 템플릿 — 과잉 차단 대조군                                */
    /* ================================================================== */

    /**
     * 거부 규칙만 있으면 "전부 거부"로도 통과한다. 정상 입력이 막히지 않는지가
     * 같은 무게로 중요하다 — 과잉 차단은 사용자가 우회할 방법이 없는 결함이다.
     */
    @ParameterizedTest(name = "{0}")
    @MethodSource("acceptedCases")
    @DisplayName("정적 검증: 저장 통과 (과잉 차단 방지)")
    void saveAccepted(String rule, String templateJson) throws Exception {
        mvc.perform(save(templateJson)).andExpect(status().isOk());
    }

    static Stream<Arguments> acceptedCases() {
        return Stream.of(
                arguments("오타를 고치면 통과",
                        pathReference("Request.Parameters.UserId != NULL")),
                arguments("EXISTS 인자가 앞쪽 노드면 통과",
                        """
                        {"nodes":[
                          {"sn":1,"name":"R","valueType":"FIXED"},
                          {"sn":2,"parentSn":1,"name":"B","valueType":"FIXED","value":"x"},
                          {"sn":3,"parentSn":1,"name":"A","valueType":"FUNCTION",
                           "value":"EXISTS(R.B) ? 'Y' : 'N'"}]}
                        """),
                arguments("[N1]/[N2] 명시는 통과", nestedLeaf("{K_[N1]_[N2]}")),
                arguments("정상 인덱스 표기 {A_[N1]} 은 통과", repeatedLeaf("{A_[N1]}")));
    }

    /* ---------------- 템플릿 조각 ---------------- */

    /** 정본 예시 2 의 노드 경로 참조 구조 — 조건식만 갈아 끼운다. */
    private static String pathReference(String displayCondition) {
        return "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"Request\",\"valueType\":\"FIXED\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"Parameters\",\"valueType\":\"FIXED\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"UserId\",\"valueType\":\"VARIABLE\","
                + "\"value\":\"{PARAM_USERID}\"},"
                + "{\"sn\":4,\"parentSn\":2,\"name\":\"PageSize\",\"valueType\":\"FIXED\",\"value\":\"x\","
                + "\"displayCondition\":\"" + displayCondition + "\"}]}";
    }

    /** Outer(반복) > Inner(반복) > Leaf — 반복 조상이 2개인 자리. */
    private static String nestedLeaf(String leafValue) {
        return "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"Outer\",\"valueType\":\"FIXED\","
                + "\"repeatCountExpr\":\"2\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"Inner\",\"valueType\":\"FIXED\","
                + "\"repeatCountExpr\":\"2\"},"
                + "{\"sn\":4,\"parentSn\":3,\"name\":\"Leaf\",\"valueType\":\"VARIABLE\","
                + "\"value\":\"" + leafValue + "\"}]}";
    }

    /** L(반복) > V — 반복 조상이 1개인 자리. */
    private static String repeatedLeaf(String leafValue) {
        return "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"L\",\"valueType\":\"FIXED\","
                + "\"repeatCountExpr\":\"2\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"V\",\"valueType\":\"VARIABLE\","
                + "\"value\":\"" + leafValue + "\"}]}";
    }

    private org.springframework.test.web.servlet.RequestBuilder save(String templateJson) {
        return put("/api/templates/validation-case")
                .contentType(MediaType.APPLICATION_JSON).content(templateJson);
    }
}
