package com.xmltemplate.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

/**
 * 라우팅·검증 적용 범위·경고 정책의 회귀 고정 (docs/API_V4_FLAT.md §4).
 *
 * 전신은 구 {@code HttpApiServer} 실기동 검사 19건의 이관본이다. 레거시 경로와
 * 문법 v1 이 제거되면서 해당 케이스들은 함께 삭제되었고, 남은 케이스는
 * 현행 JSON 계약의 규칙을 검사한다. 판정 자체는 코어 {@code TemplateService} 가
 * 하므로 미리보기·생성 경로와 같은 규칙이다.
 */
class RoutingMigratedTest extends ApiTestSupport {

    private static final String SIMPLE = "{\"name\":\"%s\",\"nodes\":["
            + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\",\"value\":\"v\"}]}";

    /* 조건식을 한 자식에 다는 형태 */
    private static final String WITH_COND = "{\"name\":\"%s\",\"nodes\":["
            + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
            + "{\"sn\":2,\"parentSn\":1,\"name\":\"A\","
            + "\"valueType\":\"FIXED\",\"value\":\"x\",\"displayCondition\":\"%s\"}]}";

    /* ================================================================== */
    /* 라우팅 — import 예약 경로                                            */
    /* ================================================================== */

    @Test
    @DisplayName("라우팅: 이름이 'import' 인 템플릿도 PUT 으로 저장된다")
    void importNamedTemplateSavesViaPut() throws Exception {
        mvc.perform(put("/api/templates/import").contentType(MediaType.APPLICATION_JSON)
                .content(String.format(SIMPLE, "import"))).andExpect(status().isOk());
    }

    @Test
    @DisplayName("라우팅: 이름이 'import' 인 템플릿도 GET 으로 조회된다")
    void importNamedTemplateLoadsViaGet() throws Exception {
        mvc.perform(put("/api/templates/import").contentType(MediaType.APPLICATION_JSON)
                .content(String.format(SIMPLE, "import"))).andExpect(status().isOk());
        mvc.perform(get("/api/templates/import")).andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("import"));
    }

    @Test
    @DisplayName("라우팅: POST /templates/import 는 임포트로 동작한다 (예약은 POST 에만)")
    void postImportIsImport() throws Exception {
        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "book.xml", "application/xml",
                                "<book><t>{T}</t></book>".getBytes(StandardCharsets.UTF_8))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[0].name").value("book"))
                .andExpect(jsonPath("$.variables[0]").value("T"));
    }

    @Test
    @DisplayName("라우팅: 이름이 'import' 인 템플릿도 DELETE 로 삭제된다")
    void importNamedTemplateDeletes() throws Exception {
        mvc.perform(put("/api/templates/import").contentType(MediaType.APPLICATION_JSON)
                .content(String.format(SIMPLE, "import"))).andExpect(status().isOk());
        mvc.perform(delete("/api/templates/import")).andExpect(status().isNoContent());
    }

    /* ================================================================== */
    /* 경고 응답 opt-in                                                     */
    /* ================================================================== */

    /**
     * `/api/*` 는 응답 형태가 고정이고 `warnings` 가 비는 것으로 대응한다 (§2.3).
     * 검사하는 규칙 — "요청하지 않으면 경고를 싣지 않는다" — 이 요점이다.
     */
    @Test
    @DisplayName("경고 응답: 요청하지 않으면 생성 XML 원문 그대로 (기존 파싱 유지)")
    void warningsAbsentWhenNotRequested() throws Exception {
        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content(missingVarPreview(false)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.xml").isNotEmpty())
                .andExpect(jsonPath("$.warnings").isEmpty());
    }

    @Test
    @DisplayName("경고 응답: withWarnings=\"true\" 면 generationResult 로 감싼다")
    void warningsPresentWhenRequested() throws Exception {
        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content(missingVarPreview(true)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("MISSING_VARIABLE"));
    }

    /* ================================================================== */
    /* 정적 검증 적용 범위                                                   */
    /* ================================================================== */

    @Test
    @DisplayName("정적 검증: 저장은 오류 목록과 함께 400")
    void saveRunsStaticValidation() throws Exception {
        mvc.perform(put("/api/templates/bad2").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(WITH_COND, "bad2", "R.NOPE != NULL")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0].code").value("UNKNOWN_NODE_PATH"));
    }

    @Test
    @DisplayName("정적 검증: NULL 리터럴 비교는 정상 저장된다 (§7)")
    void nullComparisonSaves() throws Exception {
        mvc.perform(put("/api/templates/g2").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(WITH_COND, "g2", "{X} == NULL")))
                .andExpect(status().isOk());
    }

    /* ================================================================== */
    /* repeatCondition 폐지 (§2)                                            */
    /* ================================================================== */

    private static final String REPEAT_COND = "{\"name\":\"%s\",\"nodes\":["
            + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
            + "{\"sn\":2,\"parentSn\":1,\"name\":\"I\","
            + "\"valueType\":\"FIXED\",\"value\":\"x\",\"repeatCondition\":\"{USE} == 'Y'\","
            + "\"repeatCountExpr\":\"2\"}]}";

    @Test
    @DisplayName("저장: repeatCondition 이 남아 있으면 400 (임포트 우회 경로도 막힌다)")
    void saveRejectsRepeatCondition() throws Exception {
        mvc.perform(put("/api/templates/rc2").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(REPEAT_COND, "rc2")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[*].code")
                        .value(Matchers.hasItem("REPEAT_CONDITION_REMOVED")));
    }

    /* ================================================================== */
    /* NULL 이름 노드 경고                                                   */
    /* ================================================================== */

    private static final String NULL_NAMED = "{\"name\":\"%s\",\"nodes\":["
            + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
            + "{\"sn\":2,\"parentSn\":1,\"name\":\"NULL\","
            + "\"valueType\":\"FIXED\",\"value\":\"v\"}]}";

    @Test
    @DisplayName("NULL 이름 노드: 저장은 성공하되 짧은 경로가 가려진다는 경고를 낸다")
    void nullNamedWarns() throws Exception {
        mvc.perform(put("/api/templates/n2").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(NULL_NAMED, "n2")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("NULL_NAMED_NODE"))
                .andExpect(jsonPath("$.warnings[0].message")
                        .value(Matchers.containsString("전체 경로")));
    }

    @Test
    @DisplayName("NULL 이름 노드: 해당 노드가 없으면 경고가 붙지 않는다")
    void noWarningWithoutNullNamedNode() throws Exception {
        mvc.perform(put("/api/templates/n3").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(WITH_COND, "n3", "{X} == NULL")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings").isEmpty());
    }

    /* ---------------- helpers ---------------- */

    private static String missingVarPreview(boolean withWarnings) {
        return "{\"template\":{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                + "\"valueType\":\"VARIABLE\",\"value\":\"{MISSING}\"}]},"
                + "\"withWarnings\":" + withWarnings + "}";
    }
}
