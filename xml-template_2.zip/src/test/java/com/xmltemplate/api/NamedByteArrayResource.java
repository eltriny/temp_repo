package com.xmltemplate.api;

import org.springframework.core.io.ByteArrayResource;

/**
 * 파일 이름을 갖는 바이트 배열 리소스.
 *
 * <b>왜 필요한가</b>: {@code RestTemplate} 의 multipart 인코더는 파트의 파일 이름을
 * {@code Resource#getFilename()} 에서 가져온다. 기본 {@link ByteArrayResource} 는 null 을
 * 돌려주므로 파트에 {@code filename} 이 붙지 않고, 서버의 {@code MultipartFile} 경로가
 * 그대로 재현되지 않는다.
 *
 * 이전에는 익명 하위 클래스로 재정의했으나 <b>inner/익명 클래스 금지</b> 규칙에 따라
 * 최상위 클래스로 분리했다.
 */
class NamedByteArrayResource extends ByteArrayResource {

    private final String filename;

    NamedByteArrayResource(byte[] content, String filename) {
        super(content);
        this.filename = filename;
    }

    @Override
    public String getFilename() {
        return filename;
    }
}
