package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.JsonNode;

import com.xmltemplate.support.XmlAssert;

/**
 * 파일 기반 골든 케이스 (구 {@code backend/testcases/} + {@code CaseRunner} 이관본).
 *
 * <h3>왜 파일로 두는가</h3>
 * 자바 소스에 문자열로 박아 넣은 기대 XML 은 이스케이프에 파묻혀 읽히지 않고, 명세 예시와
 * 대조하기도 어렵다. 케이스를 파일로 두면 명세 문서에서 <b>그대로 복사해</b> 넣을 수 있고,
 * 브라우저 E2E 가 붙여넣을 입력과 같은 파일을 쓴다.
 *
 * <h3>케이스 한 건의 구성</h3>
 * <pre>
 * src/test/resources/cases/010-무엇을검증하는가/
 *   case.properties   설명과 기대 (선택 - 없으면 전부 기본값)
 *   template.xml      구조 XML  → 임포트 경로(POST /api/templates/import)를 그대로 탄다
 *   template.json     TemplateDto(<b>평면 nodes[] — R4</b>) → 임포트를 우회한다
 *                     (저장 경로 전용 규칙 검증용)
 *   data.json         외부 데이터 (없으면 빈 데이터)
 *   expected.xml      기대 생성 결과 (오류를 기대하는 케이스에는 없어도 된다)
 * </pre>
 *
 * <h3>구 CaseRunner 와 달라진 점</h3>
 * 판정 주체가 <b>HTTP API</b> 다. 구 러너는 파서·검증기·생성기를 직접 불러 중간 상태를 볼 수
 * 있었지만, API 에는 그 중간 상태가 없다 — 임포트가 정적 검증까지 함께 돌리므로 검증 실패
 * 케이스(100/120)는 경고 목록을 받지 못하고 400 이 된다. 그 두 케이스의
 * {@code expectImportWarnings} 를 뺀 이유가 이것이고, 각 {@code case.properties} 에
 * 사유를 적어 두었다. <b>메타 포맷(template.tpl.xml)은 HTTP 표면에 없으므로</b>
 * 130 번은 {@code template.json} 으로 옮겼다.
 *
 * <h3>경고 기대는 집합 일치다</h3>
 * "포함"으로 두면 기대하지 않은 경고가 늘어나도 통과해서, 경고가 조용히 증식하는 것을 막지
 * 못한다. 같은 코드가 여러 번 나오는 것은 회차 수에 딸린 값이지 규칙이 아니므로 개수는 보지
 * 않는다. 키가 아예 없으면 "경고가 없어야 한다"로 읽는다.
 */
class GoldenCaseApiTest extends ApiTestSupport {

    /** surefire 의 작업 디렉터리는 모듈 루트(backend/)다. */
    private static final Path CASE_ROOT = Paths.get("src/test/resources/cases");

    /** 케이스 수의 하한. 디렉터리를 못 찾아 조용히 "전부 통과"가 되는 것을 막는다. */
    private static final int MIN_CASES = 13;

    /**
     * {@code case.properties} 가 알아듣는 키 전부.
     *
     * <b>왜 화이트리스트인가</b>: 모르는 키는 그냥 무시되므로 {@code expectWarnigns} 같은
     * 오타가 <b>기대를 통째로 없앤 채 초록으로</b> 통과한다. 경고 집합을 집합 일치로 보는
     * 이유(경고가 조용히 증식하는 것을 막는다)가 오타 하나로 무력화되는 셈이다.
     */
    private static final Set<String> KNOWN_KEYS = Set.of(
            "description",
            "expectImportError",
            "expectImportWarnings",
            "expectValidationError",
            "expectGenerationError",
            "expectWarnings");

    @ParameterizedTest(name = "{0} — {1}")
    @MethodSource("cases")
    @DisplayName("골든 케이스")
    void goldenCase(String name, String description) throws Exception {
        Path dir = CASE_ROOT.resolve(name);
        Properties props = properties(dir.resolve("case.properties"));

        Set<String> unknown = new TreeSet<String>(props.stringPropertyNames());
        unknown.removeAll(KNOWN_KEYS);
        assertTrue(unknown.isEmpty(),
                "case.properties 에 알 수 없는 키가 있습니다 " + unknown + " — 오타라면 그 기대가 "
                        + "조용히 무시된 채 케이스가 통과합니다. 사용 가능: " + new TreeSet<>(KNOWN_KEYS));

        Path structureXml = dir.resolve("template.xml");
        JsonNode template = Files.isRegularFile(structureXml)
                ? importedTemplate(name, readFile(structureXml), props)
                : savedTemplate(name, readFile(dir.resolve("template.json")), props);
        if (template == null) {
            return; /* 임포트/저장 단계에서 기대한 오류로 끝난 케이스 */
        }

        generateAndCompare(dir, props, template);
    }

    /* ================================================================== */
    /* 1. 템플릿 확보                                                        */
    /* ================================================================== */

    /**
     * 구조 XML 케이스 — 임포트 경로를 그대로 탄다.
     *
     * @return 저장까지 마친 템플릿 DTO. 기대한 오류로 끝났으면 null.
     */
    private JsonNode importedTemplate(String name, String structureXml, Properties props)
            throws Exception {
        String expectedImportError = props.getProperty("expectImportError");
        String expectedValidationError = props.getProperty("expectValidationError");

        if (expectedImportError != null) {
            MvcResult result = mvc.perform(importRequest(structureXml))
                    .andExpect(status().isBadRequest()).andReturn();
            requireContains(detailOf(result), expectedImportError.trim(), "임포트 오류");
            return null;
        }
        if (expectedValidationError != null) {
            /* 임포트가 정적 검증까지 돌리므로 여기서 400 이 난다 (구 러너의 2단계에 해당) */
            MvcResult result = mvc.perform(importRequest(structureXml))
                    .andExpect(status().isBadRequest()).andReturn();
            requireContains(joinErrors(result), expectedValidationError.trim(), "정적 검증 오류");
            return null;
        }

        JsonNode imported = importXml(structureXml);
        assertCodes(props, "expectImportWarnings", codesOf(imported.get("warnings")), "임포트 경고");

        JsonNode template = imported.get("template");
        /* 저장 경로도 같은 판정을 해야 한다 — 임포트는 통과하는데 저장이 막히면 막다른 길이다 */
        mvc.perform(save(name, template.toString())).andExpect(status().isOk());
        return template;
    }

    /** {@code template.json} 케이스 — 임포트를 우회하고 저장(PUT)만 검증한다. */
    private JsonNode savedTemplate(String name, String templateJson, Properties props)
            throws Exception {
        String expectedValidationError = props.getProperty("expectValidationError");
        if (expectedValidationError != null) {
            MvcResult result = mvc.perform(save(name, templateJson))
                    .andExpect(status().isBadRequest()).andReturn();
            requireContains(joinErrors(result), expectedValidationError.trim(), "정적 검증 오류");
            return null;
        }
        mvc.perform(save(name, templateJson)).andExpect(status().isOk());
        return json.readTree(templateJson);
    }

    /* ================================================================== */
    /* 2. 생성과 대조                                                        */
    /* ================================================================== */

    private void generateAndCompare(Path dir, Properties props, JsonNode template)
            throws Exception {
        Path dataFile = dir.resolve("data.json");
        String data = Files.isRegularFile(dataFile) ? readFile(dataFile) : "{}";

        String expectedGenerationError = props.getProperty("expectGenerationError");
        if (expectedGenerationError != null) {
            MvcResult result = preview(template.toString(), data, true)
                    .andExpect(status().isBadRequest()).andReturn();
            requireContains(detailOf(result), expectedGenerationError.trim(), "생성 오류");
            return;
        }

        JsonNode body = previewBody(template.toString(), data);
        assertCodes(props, "expectWarnings", codesOf(body.get("warnings")), "생성 경고");

        Path expectedFile = dir.resolve("expected.xml");
        assertTrue(Files.isRegularFile(expectedFile),
                "expected.xml 이 없습니다 (오류를 기대하는 케이스라면 expectGenerationError 를 쓰세요): "
                        + dir);
        XmlAssert.assertEqual(readFile(expectedFile), body.get("xml").asText(), dir.toString());
    }

    /* ================================================================== */
    /* 케이스 목록                                                          */
    /* ================================================================== */

    static Stream<org.junit.jupiter.params.provider.Arguments> cases() throws IOException {
        assertTrue(Files.isDirectory(CASE_ROOT),
                "케이스 디렉터리를 찾지 못했습니다: " + CASE_ROOT.toAbsolutePath());

        List<org.junit.jupiter.params.provider.Arguments> found =
                new ArrayList<org.junit.jupiter.params.provider.Arguments>();
        try (Stream<Path> entries = Files.list(CASE_ROOT)) {
            /* 이름순 고정 — 실패 목록을 이전 실행과 그대로 대조할 수 있게 한다 */
            for (Path dir : entries.filter(Files::isDirectory).sorted().toList()) {
                String description = properties(dir.resolve("case.properties"))
                        .getProperty("description", dir.getFileName().toString());
                found.add(org.junit.jupiter.params.provider.Arguments.of(
                        dir.getFileName().toString(), description));
            }
        }
        assertTrue(found.size() >= MIN_CASES,
                "케이스가 " + found.size() + "건뿐입니다 (기대 " + MIN_CASES + "건 이상) — "
                        + "케이스가 통째로 빠진 채 '전부 통과'가 되는 것을 막기 위한 하한입니다.");
        return found.stream();
    }

    /* ---------------- helpers ---------------- */

    private org.springframework.test.web.servlet.RequestBuilder save(String name,
            String templateJson) {
        return put("/api/templates/" + name)
                .contentType(MediaType.APPLICATION_JSON).content(templateJson);
    }

    /**
     * 경고 코드 집합 비교. 키가 없으면 "경고가 없어야 한다"로 읽는다 —
     * 그래야 새 경고가 조용히 늘어나는 것을 케이스가 잡아낸다.
     */
    private static void assertCodes(Properties props, String key, Set<String> actualCodes,
            String label) {
        assertEquals(parseCodeSet(props.getProperty(key)), new TreeSet<String>(actualCodes),
                label + " 집합이 기대와 다릅니다");
    }

    private static Set<String> parseCodeSet(String raw) {
        Set<String> result = new TreeSet<String>();
        if (raw != null) {
            for (String token : raw.split(",")) {
                if (!token.trim().isEmpty()) {
                    result.add(token.trim());
                }
            }
        }
        return result;
    }

    private static void requireContains(String actual, String needle, String label) {
        assertTrue(actual != null && actual.contains(needle),
                label + " 메시지에 '" + needle + "' 이(가) 없습니다. 실제:\n" + actual);
    }

    private String detailOf(MvcResult result) throws Exception {
        return json.readTree(result.getResponse().getContentAsString()).path("detail").asText();
    }

    /** 구 {@code CaseRunner.joinErrors} 와 같은 형태 — {@code expectValidationError} 문구가 그대로 맞는다. */
    private String joinErrors(MvcResult result) throws Exception {
        JsonNode body = json.readTree(result.getResponse().getContentAsString());
        StringBuilder joined = new StringBuilder();
        for (JsonNode error : body.path("errors")) {
            joined.append(" - [").append(error.path("code").asText()).append("] ")
                    .append(error.path("nodePath").asText())
                    .append(" (").append(error.path("where").asText()).append("): ")
                    .append(error.path("message").asText()).append('\n');
        }
        return joined.length() == 0 ? body.path("detail").asText() : joined.toString();
    }

    /**
     * UTF-8 로 파일을 읽는다. BOM 이 있으면 떼어낸다 — 케이스 파일은 사람이 편집기로
     * 만들기 때문에 BOM 이 붙어 들어올 수 있고, 남아 있으면 XML 파서가 루트 엘리먼트 앞의
     * 문자로 보고 거부한다.
     */
    private static String readFile(Path file) throws IOException {
        String text = Files.readString(file, StandardCharsets.UTF_8);
        return text.startsWith("﻿") ? text.substring(1) : text;
    }

    /**
     * {@code case.properties} 를 읽는다.
     * {@code Properties.load(InputStream)} 은 ISO-8859-1 로 읽어 한국어 설명이 깨지므로
     * 반드시 Reader 판을 쓴다.
     */
    private static Properties properties(Path file) throws IOException {
        Properties props = new Properties();
        if (Files.isRegularFile(file)) {
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                props.load(reader);
            }
        }
        return props;
    }
}
