package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

/**
 * 폐지된 {@code attributes} 필드의 <b>tombstone 계약</b> (R2).
 *
 * <h3>왜 필드를 계약에서 빼지 않았나</h3>
 * 전역 설정이 {@code fail-on-unknown-properties=false} 라 DTO 에서 필드를 없애면 사용자가
 * 보낸 값이 <b>아무 말 없이 사라진다</b>. 저장은 200 으로 성공하고, 생성 결과에서 속성이
 * 빠진 것을 한참 뒤에 발견하며, 그때는 원인을 추적할 단서가 없다. 받아서 <b>명확한 오류로
 * 거부</b>해야 사용자가 무엇을 고쳐야 하는지 안다. 그래서 필드는 남기고 값만 막는다.
 *
 * <h3>세 갈래를 모두 고정한다</h3>
 * <ul>
 *   <li><b>비어 있지 않음</b> → 400 {@code GENERAL_ATTR_REMOVED}</li>
 *   <li><b>빈 배열 {@code []}</b> → 통과. 전환기의 구 클라이언트가 계속 보내는 형태이고,
 *       이것까지 막으면 화면이 상시 400 이 된다</li>
 *   <li><b>필드 누락(null)</b> → 통과. 갱신된 프론트가 보내는 형태다</li>
 * </ul>
 *
 * 세 갈래 중 가운데가 가장 놓치기 쉽다 — {@code != null} 만 보고 거부하면 빈 배열도 걸려
 * <b>정상 사용자가 전부 막힌다</b>. 반대로 {@code isEmpty()} 만 보면 {@code null} 에서
 * NPE 가 난다. 그래서 세 갈래를 각각 고정한다.
 *
 * 임포트 경로는 정반대로 <b>버리고 경고</b>한다 — {@code ImportApiTest.Attributes} 참조.
 */
class TombstoneContractApiTest extends ApiTestSupport {

    /** 속성이 실린 노드. {@code attributes} 원소는 구조를 보지 않으므로 아무 객체나 된다. */
    private static final String WITH_ATTRIBUTES =
            "{\"nodes\":[{\"sn\":1,\"name\":\"order\",\"valueType\":\"FIXED\",\"value\":\"\","
                    + "\"attributes\":[{\"name\":\"id\",\"valueType\":\"FIXED\",\"value\":\"1\"}]}]}";

    private static final String EMPTY_ATTRIBUTES =
            "{\"nodes\":[{\"sn\":1,\"name\":\"order\",\"valueType\":\"FIXED\",\"value\":\"v\","
                    + "\"attributes\":[]}]}";

    private static final String NULL_ATTRIBUTES =
            "{\"nodes\":[{\"sn\":1,\"name\":\"order\",\"valueType\":\"FIXED\",\"value\":\"v\","
                    + "\"attributes\":null}]}";

    private static final String NO_ATTRIBUTES_FIELD =
            "{\"nodes\":[{\"sn\":1,\"name\":\"order\",\"valueType\":\"FIXED\",\"value\":\"v\"}]}";

    /* ================================================================== */
    /* 거부                                                                */
    /* ================================================================== */

    @Test
    @DisplayName("저장: 속성이 실려 오면 400 GENERAL_ATTR_REMOVED")
    void saveRejectsGeneralAttributes() throws Exception {
        mvc.perform(put("/api/templates/tomb").contentType(MediaType.APPLICATION_JSON)
                        .content(WITH_ATTRIBUTES))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERAL_ATTR_REMOVED"))
                .andExpect(jsonPath("$.detail")
                        .value(Matchers.containsString("자식 노드로 옮기세요")));

        /* 거부된 저장은 흔적을 남기지 않는다 */
        mvc.perform(get("/api/templates/tomb")).andExpect(status().isNotFound());
    }

    /**
     * 미리보기도 같은 지점에서 막힌다.
     *
     * <b>이것이 이 테스트의 핵심이다</b>: 미리보기는 저장 검증을 거치지 않으므로, 거부를
     * 검증기에 두면 "미리보기는 되는데 저장은 안 되는" 상태가 된다. 사용자는 화면에서
     * 결과를 확인하고 저장을 눌렀다가 거부당한다 — {@code repeatCondition} 폐지 때 실제로
     * 겪은 실패 모드다.
     */
    @Test
    @DisplayName("미리보기: 속성이 실려 오면 400 GENERAL_ATTR_REMOVED (저장과 같은 지점)")
    void previewRejectsGeneralAttributes() throws Exception {
        preview(WITH_ATTRIBUTES, "{}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERAL_ATTR_REMOVED"));
    }

    /**
     * 오류 메시지가 <b>전체 경로</b>로 어느 노드인지 특정한다.
     *
     * 이름만 실으면 동명 노드가 여럿일 때 어느 것을 고쳐야 할지 알 수 없다. 트리가 깊을수록
     * "속성이 있다는 건 알겠는데 어디?"가 실질적인 문제가 된다.
     */
    @Test
    @DisplayName("거부 메시지가 중첩 노드의 전체 경로를 지목한다")
    void rejectionNamesFullPathOfOffendingNode() throws Exception {
        String nested = "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"order\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"item\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"price\",\"valueType\":\"FIXED\",\"value\":\"1\","
                + "\"attributes\":[{\"name\":\"cur\"},{\"name\":\"unit\"}]}]}";

        mvc.perform(put("/api/templates/tomb-deep").contentType(MediaType.APPLICATION_JSON)
                        .content(nested))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERAL_ATTR_REMOVED"))
                .andExpect(jsonPath("$.detail")
                        .value(Matchers.containsString("order.item.price")))
                .andExpect(jsonPath("$.detail").value(Matchers.containsString("2개")));
    }

    /* ================================================================== */
    /* 통과                                                                */
    /* ================================================================== */

    @Test
    @DisplayName("저장: 빈 배열 attributes 는 통과한다 (전환기 구 클라이언트)")
    void saveAcceptsEmptyAttributeArray() throws Exception {
        mvc.perform(put("/api/templates/tomb-empty").contentType(MediaType.APPLICATION_JSON)
                        .content(EMPTY_ATTRIBUTES))
                .andExpect(status().isOk());
        mvc.perform(get("/api/templates/tomb-empty")).andExpect(status().isOk());
    }

    @Test
    @DisplayName("저장: attributes 필드가 아예 없으면 통과한다 (갱신된 프론트)")
    void saveAcceptsMissingAttributeField() throws Exception {
        mvc.perform(put("/api/templates/tomb-none").contentType(MediaType.APPLICATION_JSON)
                        .content(NO_ATTRIBUTES_FIELD))
                .andExpect(status().isOk());
    }

    /**
     * 명시적 {@code "attributes": null} 도 통과한다.
     *
     * <b>필드 누락과 같은 갈래로 보이지만 코드 경로가 다르다</b> — 누락이면 Jackson 이 필드를
     * 손대지 않아 초기값(null)이 남고, 명시적 null 이면 Jackson 이 <b>null 을 대입</b>한다.
     * 필드 기본값을 빈 배열로 바꾸는 리팩터링이 들어오면 두 경로가 갈라진다(누락은 `[]`,
     * 명시 null 은 `null`). JSON 을 손으로 만드는 클라이언트나 직렬화기가 실제로 이 형태를
     * 보내므로 별도로 고정한다.
     */
    @Test
    @DisplayName("저장: 명시적 attributes:null 도 통과한다 (누락과 다른 코드 경로)")
    void saveAcceptsExplicitNullAttributes() throws Exception {
        mvc.perform(put("/api/templates/tomb-null").contentType(MediaType.APPLICATION_JSON)
                        .content(NULL_ATTRIBUTES))
                .andExpect(status().isOk());
        mvc.perform(get("/api/templates/tomb-null")).andExpect(status().isOk());
    }

    @Test
    @DisplayName("미리보기: 명시적 attributes:null 도 통과한다")
    void previewAcceptsExplicitNullAttributes() throws Exception {
        preview(NULL_ATTRIBUTES, "{}", true).andExpect(status().isOk());
    }

    @Test
    @DisplayName("미리보기: 빈 배열 attributes 는 통과한다")
    void previewAcceptsEmptyAttributeArray() throws Exception {
        preview(EMPTY_ATTRIBUTES, "{}", true).andExpect(status().isOk());
    }

    /* ================================================================== */
    /* 응답 — 폐지된 개념은 나가지 않는다                                      */
    /* ================================================================== */

    /**
     * 응답에는 {@code attributes} 키가 <b>아예 실리지 않는다</b>.
     *
     * 빈 배열로 내보내면 폐지된 개념이 계속 살아 있는 것처럼 보이고, 프론트가 "속성이 0개인
     * 노드"와 "속성 개념이 없는 노드"를 구분할 수 없다. 더 실질적인 위험은 <b>왕복</b>이다 —
     * 프론트가 받은 것을 그대로 되돌려 보내는 흔한 패턴에서, 응답에 실린 빈 배열이 다음
     * 요청에 그대로 실려 오게 된다.
     *
     * 빈 배열을 보내 저장한 뒤 읽어야 한다 — 매퍼가 요청값을 그대로 흘려보내면 여기서 걸린다.
     */
    @Test
    @DisplayName("응답 트리에 attributes 키가 실리지 않는다 (빈 배열로도 나가지 않는다)")
    void responseOmitsAttributesKeyEntirely() throws Exception {
        mvc.perform(put("/api/templates/tomb-out").contentType(MediaType.APPLICATION_JSON)
                .content(EMPTY_ATTRIBUTES)).andExpect(status().isOk());

        mvc.perform(get("/api/templates/tomb-out"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nodes[0].attributes").doesNotExist());

        /* 미리보기 응답에도 템플릿이 실리지 않는지와 무관하게, 임포트 응답 트리도 같은 규약이다 */
        mvc.perform(importRequest("<order id=\"1\"><item>x</item></order>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[0].attributes").doesNotExist());
    }

    /**
     * 세 응답 경로의 <b>본문 전체</b>에 {@code "attributes"} 문자열이 한 번도 나오지 않는다.
     *
     * <b>왜 jsonPath 로는 부족한가</b>: {@code $.nodes[0].attributes} 같은 경로 단언은 <b>내가
     * 지목한 자리</b>만 본다. 트리가 깊거나 반복으로 불어난 노드 중 하나에서만 키가 새면
     * 그 단언은 전부 통과한다. 폐지된 개념은 응답 어디에도 없어야 하므로 위치를 지목하지
     * 않는 검사가 필요하다.
     *
     * 속성이 든 XML 을 임포트해 <b>3단 중첩 트리</b>를 만들고, 그것을 저장한 뒤 세 경로를
     * 모두 훑는다 — 매퍼가 한 층에서만 키를 흘려도 걸린다.
     */
    @Test
    @DisplayName("GET / import / preview 응답 본문에 \"attributes\" 문자열이 0건이다")
    void noResponseBodyMentionsAttributes() throws Exception {
        String structureXml = "<order id=\"1\" lang=\"ko\">"
                + "<item seq=\"1\" code=\"A\"><price cur=\"KRW\">100</price></item>"
                + "</order>";

        String importBody = mvc.perform(importRequest(structureXml))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertFalse(importBody.contains("\"attributes\""),
                "임포트 응답에 attributes 키가 있다: " + importBody);

        String templateJson = json.readTree(importBody).get("template").toString();
        mvc.perform(put("/api/templates/tomb-scan").contentType(MediaType.APPLICATION_JSON)
                .content(templateJson)).andExpect(status().isOk());

        String getBody = mvc.perform(get("/api/templates/tomb-scan"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertFalse(getBody.contains("\"attributes\""),
                "조회 응답에 attributes 키가 있다: " + getBody);

        String previewBody = preview(templateJson, "{}", true)
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertFalse(previewBody.contains("attributes"),
                "미리보기 응답에 attributes 가 있다: " + previewBody);

        /*
         * 대조군 — 스캔이 살아 있다는 증거. 위 세 단언은 "응답이 비었다"로도 통과한다.
         * 임포트 응답에는 버린 속성의 경고가 실려 있어야 하고, 저장분은 되읽혀야 한다.
         */
        assertTrue(importBody.contains("GENERAL_ATTR_IGNORED"),
                "버린 속성의 경고가 없다 — 스캔 대상 응답이 비었을 수 있다");
        assertTrue(getBody.contains("\"price\""), "저장한 트리가 되읽히지 않았다: " + getBody);
    }
}
