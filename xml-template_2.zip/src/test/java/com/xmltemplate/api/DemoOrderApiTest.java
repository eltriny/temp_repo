package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

/**
 * 데모 주문 템플릿의 생성 의미론 (구 {@code SelfTest.checkGeneration} 17건 이관본).
 *
 * <b>무엇이 바뀌었나</b>: 구 검증은 {@code DemoTemplate.build()} 로 자바 트리를 만들어
 * {@code XmlGenerator} 를 직접 불렀다. 백엔드가 API 전용이 되면서 그 진입점이 사라졌으므로
 * 같은 트리를 {@code src/test/resources/fixtures/demo-order.json} 픽스처로 옮기고
 * {@code POST /api/preview} 로 태운다 — <b>프론트가 실제로 보내는 것과 같은 형태</b>다.
 *
 * 픽스처는 frontend 의 {@code model.js buildDemoTemplate} 과 동일 구조를 유지한다.
 * 한쪽만 바꾸면 "화면의 데모"와 "서버가 검증하는 데모"가 갈라진다.
 */
class DemoOrderApiTest extends ApiTestSupport {

    private static final String DEMO = resource("fixtures/demo-order.json");

    /** 국내 주문 — 반복 파라미터 ITEM_NAME_1..3 이 있어 ITEM 이 3회 생성된다. */
    private static final String DOMESTIC = """
            {"ORDER_NO":"ORD-2026-0001","ORDER_TYPE":"D","MEMO":"빠른 배송 요청",
             "ITEM_NAME_1":"노트북","ITEM_PRICE_1":1500000,
             "ITEM_NAME_2":"마우스","ITEM_PRICE_2":30000,
             "ITEM_NAME_3":"키보드","ITEM_PRICE_3":80000}
            """;

    /** 해외 주문 — 반복 파라미터가 없어 ITEM 이 생성되지 않는다. */
    private static final String OVERSEAS =
            "{\"ORDER_NO\":\"ORD-2026-0002\",\"ORDER_TYPE\":\"O\",\"MEMO\":\"\"}";

    /* ================================================================== */
    /* 시나리오 1: 국내 주문                                                 */
    /* ================================================================== */

    @Nested
    @DisplayName("국내 주문 (조건 참 / 반복 3회)")
    class Domestic {

        @Test
        @DisplayName("함수(삼항연산자) 값 - 참 분기 / 변수 치환 / 표시 조건 참")
        void headerValues() throws Exception {
            String xml = previewXml(DEMO, DOMESTIC);

            assertContains(xml, "<ORDER-TYPE-NAME>국내</ORDER-TYPE-NAME>", "삼항 참 분기");
            assertContains(xml, "<ORDER-NO>ORD-2026-0001</ORDER-NO>", "변수 치환");
            assertContains(xml, "<MEMO>빠른 배송 요청</MEMO>", "표시 조건 참 -> 노드 생성");
        }

        @Test
        @DisplayName("COUNT 기반 반복: ITEM_NAME_1..3 -> 3회")
        void repeatsByCount() throws Exception {
            assertEquals(3, countElements(previewXml(DEMO, DOMESTIC), "ITEM"),
                    "COUNT({ITEM_NAME}) 회차 수가 다르다");
        }

        @Test
        @DisplayName("인덱스 표기 해석: {ITEM_NAME_[N]} / {ITEM_PRICE_[N]} -> 회차별 키")
        void indexNotationResolvesPerIteration() throws Exception {
            String xml = previewXml(DEMO, DOMESTIC);

            assertContains(xml, "<NAME>노트북</NAME>", "1회차 ITEM_NAME");
            assertContains(xml, "<NAME>키보드</NAME>", "3회차 ITEM_NAME");
            /* 숫자 리터럴로 보낸 값도 표기 그대로 실린다 */
            assertContains(xml, "<PRICE>30000</PRICE>", "2회차 ITEM_PRICE");
        }

        @Test
        @DisplayName("내장 변수 {INDEX}")
        void builtinIndexVariable() throws Exception {
            String xml = previewXml(DEMO, DOMESTIC);

            assertContains(xml, "<SEQ>1</SEQ>", "첫 회차 {INDEX}");
            assertContains(xml, "<SEQ>3</SEQ>", "마지막 회차 {INDEX}");
        }

        /** 조건 피연산자가 <b>다른 노드의 출력값</b>이다 — 변수 기준 조건과 다른 경로다 (§8). */
        @Test
        @DisplayName("노드 경로 피연산자 표시 조건 -> 노드 생성")
        void nodePathConditionTrue() throws Exception {
            assertContains(previewXml(DEMO, DOMESTIC),
                    "<DOMESTIC-ONLY>국내 전용 항목</DOMESTIC-ONLY>", "노드 경로 조건 참");
        }
    }

    /* ================================================================== */
    /* 시나리오 2: 해외 주문                                                 */
    /* ================================================================== */

    @Nested
    @DisplayName("해외 주문 (조건 거짓 / 반복 0회)")
    class Overseas {

        @Test
        @DisplayName("함수(삼항연산자) 값 - 거짓 분기")
        void ternaryFalseBranch() throws Exception {
            assertContains(previewXml(DEMO, OVERSEAS),
                    "<ORDER-TYPE-NAME>해외</ORDER-TYPE-NAME>", "삼항 거짓 분기");
        }

        /** {@code MEMO} 는 <b>빈 문자열</b>이다 — §7 이 이것을 NULL 로 규정한다. */
        @Test
        @DisplayName("표시 조건 거짓 -> 노드 미생성 (빈 문자열 = NULL)")
        void displayConditionFalseOmitsNode() throws Exception {
            assertElementAbsent(previewXml(DEMO, OVERSEAS), "MEMO", "표시 조건 거짓");
        }

        @Test
        @DisplayName("COUNT 기반 반복: 파라미터 없음 -> 0회(미생성)")
        void zeroRepeatWhenNoParameters() throws Exception {
            assertEquals(0, countElements(previewXml(DEMO, OVERSEAS), "ITEM"),
                    "반복 파라미터가 없는데 ITEM 이 생성됐다");
        }

        @Test
        @DisplayName("노드 경로 조건 거짓 -> 노드 미생성")
        void nodePathConditionFalseOmitsNode() throws Exception {
            assertElementAbsent(previewXml(DEMO, OVERSEAS), "DOMESTIC-ONLY", "노드 경로 조건 거짓");
        }
    }

    /* ================================================================== */
    /* 삼항식 게이트 — 폐지된 repeatCondition 의 대체 표현 (§9.1)             */
    /* ================================================================== */

    /**
     * {@code repeatCondition} 이 없어진 뒤 "조건이 참일 때만 N회"를 쓰는 방법이다.
     * 이 표현이 동작하지 않으면 폐지가 기능 후퇴가 된다.
     */
    @Nested
    @DisplayName("삼항식 반복 게이트 (§9.1)")
    class TernaryRepeatGate {

        private static final String GATE = """
                {"nodes":[
                  {"sn":1,"name":"ROOT","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"ROW","valueType":"VARIABLE","value":"{INDEX}",
                   "repeatCountExpr":"{USE_REPEAT} == 'Y' ? 4 : 0"}]}
                """;

        @Test
        @DisplayName("조건 참 -> 4회")
        void gateOpen() throws Exception {
            assertEquals(4, countElements(previewXml(GATE, "{\"USE_REPEAT\":\"Y\"}"), "ROW"));
        }

        @Test
        @DisplayName("조건 거짓 -> 0회(미생성)")
        void gateClosed() throws Exception {
            assertEquals(0, countElements(previewXml(GATE, "{\"USE_REPEAT\":\"N\"}"), "ROW"));
        }
    }

    /* ================================================================== */
    /* 입력 데이터 타입 / 반복 횟수식 오류                                    */
    /* ================================================================== */

    private static final String NUMBER_NODE = """
            {"nodes":[
              {"sn":1,"name":"ROOT","valueType":"FIXED"},
              {"sn":2,"parentSn":1,"name":"AMOUNT","valueType":"VARIABLE","value":"{AMOUNT}",
               "valueDataType":"NUMBER"}]}
            """;

    @Test
    @DisplayName("NUMBER 타입: 숫자 값 통과")
    void numberDataTypeAcceptsNumber() throws Exception {
        assertContains(previewXml(NUMBER_NODE, "{\"AMOUNT\":\"12345.67\"}"),
                "<AMOUNT>12345.67</AMOUNT>", "NUMBER 값");
    }

    /** 조용히 빈 값으로 떨어뜨리지 않는다 — 잘못된 데이터는 400 이다. */
    @Test
    @DisplayName("NUMBER 타입: 숫자 아닌 값 -> 400 GENERATION_FAILED")
    void numberDataTypeRejectsText() throws Exception {
        preview(NUMBER_NODE, "{\"AMOUNT\":\"십만원\"}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
    }

    @Test
    @DisplayName("잘못된 반복 횟수 조건 -> 400 GENERATION_FAILED")
    void invalidRepeatCountExprRejected() throws Exception {
        preview("""
                {"nodes":[
                  {"sn":1,"name":"ROOT","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"CHILD","valueType":"FIXED",
                   "repeatCountExpr":"abc"}]}
                """, "{}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
    }

    /* ---------------- helpers ---------------- */

    private static void assertContains(String xml, String token, String what) {
        assertTrue(xml.contains(token), what + " — '" + token + "' 이 없다:\n" + xml);
    }

    /**
     * 엘리먼트가 <b>생성되지 않았음</b>을 단언한다.
     *
     * <b>왜 문자열 {@code "<MEMO>"} 로는 안 되는가</b>: 값이 빈 리프는 §10 에 따라
     * self-closing 으로 나온다. 표시 조건이 깨져 MEMO 가 생성되더라도 값이 비어 있으면
     * 출력은 {@code <MEMO/>} 라서 {@code "<MEMO>"} 부재 검사는 <b>항상 통과</b>한다 —
     * 즉 아무것도 검사하지 않는 단언이 된다(실서버로 실증됨).
     *
     * 그래서 여는 태그를 <b>이름 경계까지 보고</b> 센다: {@code <MEMO>}, {@code <MEMO/>},
     * {@code <MEMO attr=…>} 를 모두 잡고 {@code <MEMOS>} 같은 접두 일치는 배제한다.
     */
    private static void assertElementAbsent(String xml, String name, String what) {
        assertEquals(0, countElements(xml, name),
                what + " — <" + name + "> 이 생성됐다:\n" + xml);
    }

    /**
     * 여는 태그 개수. 이름 뒤가 {@code >} / {@code /} / 공백일 때만 같은 엘리먼트로 본다 —
     * 접두 일치({@code <ITEM} 이 {@code <ITEMS>} 를 세는 것)를 막기 위한 경계 검사다.
     */
    private static int countElements(String xml, String name) {
        String open = "<" + name;
        int found = 0;
        int index = 0;
        while ((index = xml.indexOf(open, index)) >= 0) {
            int after = index + open.length();
            if (after < xml.length() && isTagBoundary(xml.charAt(after))) {
                found++;
            }
            index = after;
        }
        return found;
    }

    private static boolean isTagBoundary(char c) {
        return c == '>' || c == '/' || Character.isWhitespace(c);
    }
}
