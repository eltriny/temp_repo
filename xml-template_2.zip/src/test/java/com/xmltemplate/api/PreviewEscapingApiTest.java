package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import com.fasterxml.jackson.databind.JsonNode;

import com.xmltemplate.support.XmlAssert;

/**
 * 리터럴 중괄호 이스케이프 (§3.1) — 구 {@code SelfTest.checkBraceEscaping} 이관본.
 *
 * <b>핵심 규칙</b>: 저장값은 <b>항상 원문</b>(이스케이프 유지)이고, 해제는 <b>생성 시점</b>에
 * 한다. 임포트 시점에 해제하면 VARIABLE 에서 역전이 일어난다 —
 * {@code 총 {{X}} {CNT} 건} 을 해제해 저장하면 {@code 총 {X} {CNT} 건} 이 되고, 생성 시
 * {@code {X}} 까지 변수로 치환되어 <b>리터럴이어야 할 것이 값으로 바뀐다</b>.
 *
 * <b>기준은 위치가 아니라 유형</b>이다: FIXED/VARIABLE 은 노드 값·속성값 공통으로 해제하고,
 * FUNCTION 에는 적용하지 않는다(식에서 리터럴 중괄호는 {@code '{X}'} 따옴표 문자열로 쓴다).
 * 그래서 3유형 × 추론/명시 6조합을 전부 고정한다 — 한 조합만 뚫려도 사용자 입력이 조용히
 * 다른 값이 된다.
 */
class PreviewEscapingApiTest extends ApiTestSupport {

    private static final String DATA = "{\"X\":\"치환됨\",\"CNT\":\"7\",\"VALUE\":\"V\"}";

    /* ================================================================== */
    /* 노드 값: 3유형 × 추론/명시 = 6조합                                     */
    /* ================================================================== */

    @ParameterizedTest(name = "{0} -> {1}")
    @MethodSource("escapeCases")
    @DisplayName("이스케이프: 값 유형별 해제 규칙")
    void escapedNodeValue(String structureXml, String expectedType, String expectedOutput)
            throws Exception {
        JsonNode imported = importXml(structureXml);
        JsonNode template = imported.get("template");

        assertEquals(expectedType, template.path("nodes").path(0).path("valueType").asText(),
                "값 유형 추론이 다르다: " + structureXml);
        assertNull(XmlAssert.diff("<a>" + expectedOutput + "</a>",
                        previewXml(template.toString(), DATA)),
                "생성 결과가 기대와 다르다: " + structureXml);
    }

    static Stream<Arguments> escapeCases() {
        return Stream.of(
                Arguments.of("<a>총 {{X}} 건</a>", "FIXED", "총 {X} 건"),
                Arguments.of("<a valueType=\"FIXED\">총 {{X}} 건</a>", "FIXED", "총 {X} 건"),

                /* 핵심 케이스 — 이스케이프와 실제 변수가 공존한다 */
                Arguments.of("<a>총 {{X}} {CNT} 건</a>", "VARIABLE", "총 {X} 7 건"),
                Arguments.of("<a valueType=\"VARIABLE\">총 {{X}} {CNT} 건</a>",
                        "VARIABLE", "총 {X} 7 건"),

                /* FUNCTION 은 해제 대상이 아니다 — 식 안의 '{X}' 는 그냥 문자열이다 */
                Arguments.of("<a>{CNT} == '7' ? '{X}' : 'no'</a>", "FUNCTION", "{X}"),
                Arguments.of("<a valueType=\"FUNCTION\">{CNT} == '7' ? '{X}' : 'no'</a>",
                        "FUNCTION", "{X}"));
    }

    /** 해제된 채 저장되면 위의 역전이 재발한다 — 응답에 실려 오는 값이 원문이어야 한다. */
    @Test
    @DisplayName("이스케이프: 저장값은 원문 유지 (임포트 시점에 해제하지 않는다)")
    void storedValueKeepsEscapes() throws Exception {
        assertEquals("총 {{X}} {CNT} 건",
                importXml("<a>총 {{X}} {CNT} 건</a>")
                        .path("template").path("nodes").path(0).path("value").asText());
    }

    /* ================================================================== */
    /* 속성값 — R2 에서 경로 자체가 사라졌다                                   */
    /* ================================================================== */

    /**
     * 이스케이프가 든 속성이 섞여 있어도 <b>노드 값의 처리는 영향받지 않는다</b>.
     *
     * <b>R2 이전</b> 이 자리에는 "속성값도 3유형으로 추론된다"와 "속성값이 노드 값과 같은
     * 규칙으로 해제된다" 두 테스트가 있었다. 그 규칙이 존재한 이유는 <b>노드 값만 고치고
     * 속성 경로를 놓치는 재발</b>을 막기 위해서였는데, 일반 속성 기능이 제거되며 속성 경로
     * 자체가 없어졌다.
     *
     * 대신 남은 위험은 방향이 반대다 — <b>버려지는 속성이 노드 값 처리를 오염시키는 것</b>.
     * 같은 문서 안에서 속성은 버려지고 노드 값의 이스케이프는 정확히 해제되는지를 본다.
     * (속성이 버려진다는 사실 자체는 {@code ImportApiTest.Attributes} 가 덮는다.)
     */
    private static final String ATTRIBUTE_XML =
            "<a id=\"총 {{X}} 건\" lang=\"총 {{X}} {CNT} 건\""
                    + " grade=\"{CNT} == '7' ? '{X}' : 'no'\">총 {{X}} {CNT} 건</a>";

    @Test
    @DisplayName("이스케이프: 버려지는 속성이 노드 값의 해제를 오염시키지 않는다")
    void discardedAttributesDoNotAffectNodeValue() throws Exception {
        mvc.perform(importRequest(ATTRIBUTE_XML))
                .andExpect(status().isOk())
                /* 원문 보존 — 해제는 생성 시점에 한다 */
                .andExpect(jsonPath("$.template.nodes[0].value").value("총 {{X}} {CNT} 건"))
                .andExpect(jsonPath("$.template.nodes[0].valueType").value("VARIABLE"))
                .andExpect(jsonPath("$.template.nodes[0].attributes").doesNotExist());

        String template = importXml(ATTRIBUTE_XML).get("template").toString();
        assertNull(XmlAssert.diff("<a>총 {X} 7 건</a>", previewXml(template, DATA)));
    }

    /* ================================================================== */
    /* 식에는 {{ 가 없다 (§3.1 일관성 규칙)                                   */
    /* ================================================================== */

    @Test
    @DisplayName("이스케이프: 명시 FUNCTION 식의 '{{' 는 400 (파싱 오류)")
    void explicitFunctionRejectsEscape() throws Exception {
        mvc.perform(importRequest("<a valueType=\"FUNCTION\">{{X}} == '1' ? 'a' : 'b'</a>"))
                .andExpect(status().isBadRequest());
    }

    /** 추론은 <b>강등</b>한다 — 사용자가 식으로 의도하지 않았을 수 있으므로 경고로 알린다. */
    @Test
    @DisplayName("이스케이프: 추론 FUNCTION 식의 '{{' 는 FIXED 강등 + TYPE_DEMOTED")
    void inferredFunctionDemotes() throws Exception {
        mvc.perform(importRequest("<a>{{X}} == '1' ? 'a' : 'b'</a>"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[0].valueType").value("FIXED"))
                .andExpect(jsonPath("$.warnings[?(@.code == 'TYPE_DEMOTED')]").exists());
    }

    /* ================================================================== */
    /* 스캐너 동작이 규범이다 — {{ 를 안 쓰면 변수로 읽힌다                     */
    /* ================================================================== */

    /**
     * JSON 스니펫처럼 중괄호가 든 문자열을 그냥 넣으면 어떻게 되는지 고정한다.
     * "그럴 리 없다"가 아니라 <b>이렇게 된다</b>를 문서화해 두는 편이 낫다 —
     * 실제로 사용자가 값에 JSON 을 넣는 일이 있고, 그때 원인이 즉시 보여야 한다.
     */
    @Test
    @DisplayName("이스케이프하지 않은 중첩 중괄호는 변수명으로 해석된다 (§3.1 - {{ 필수)")
    void unescapedBracesBecomeVariable() throws Exception {
        assertEquals(" }", valueOfVariableNode("{ \"key\": {VALUE} }"));
    }

    @Test
    @DisplayName("{{ 로 이스케이프하면 JSON 스니펫이 그대로 출력된다")
    void escapedBracesKeepJsonSnippet() throws Exception {
        assertEquals("{ \"key\": {VALUE} }",
                valueOfVariableNode("{{ \"key\": {{VALUE}} }}"));
    }

    /* ---------------- helpers ---------------- */

    /** 값 노드 하나(VARIABLE)를 생성해 출력 값만 꺼낸다 — 구 {@code SelfTest.valueOf} 의 API 판. */
    private String valueOfVariableNode(String value) throws Exception {
        String xml = previewXml(singleNode("VARIABLE", value), DATA);
        int open = xml.indexOf("<V>");
        return (open < 0) ? "" : xml.substring(open + 3, xml.indexOf("</V>"));
    }
}
