package com.xmltemplate.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.servlet.MultipartProperties;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

import com.xmltemplate.util.xml.SecureXml;

/**
 * JSON 계약 테스트 (docs/API_V4_FLAT.md — 계약 정본).
 *
 * R4 부터 노드는 <b>평면 목록</b>으로 오간다 — 본문·응답 경로가 모두 {@code nodes[]} 기준이다.
 */
class TemplateApiContractTest extends ApiTestSupport {

    @Autowired
    private MultipartProperties multipartProperties;

    /** catalog(sn=1) → book(sn=2) → title(sn=3). DFS 전위, 루트는 parentSn 없음. */
    private static final String TEMPLATE_JSON = """
            {"name":"c","nodes":[
             {"sn":1,"name":"catalog","valueType":"FIXED"},
             {"sn":2,"parentSn":1,"name":"book","valueType":"FIXED",
              "repeatCountExpr":"COUNT({BOOK_NAME})"},
             {"sn":3,"parentSn":2,"name":"title","valueType":"VARIABLE",
              "value":"{BOOK_NAME_[N]}"}]}
            """;

    @Test
    @DisplayName("CRUD 왕복 — 저장/조회/목록/삭제")
    void crudRoundTrip() throws Exception {
        mvc.perform(put("/api/templates/c").contentType(MediaType.APPLICATION_JSON)
                        .content(TEMPLATE_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.created").value(true))
                .andExpect(jsonPath("$.warnings").isArray());

        mvc.perform(get("/api/templates/c"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("c"))
                .andExpect(jsonPath("$.updatedAt").isNotEmpty())
                .andExpect(jsonPath("$.nodes[1].repeatCountExpr")
                        .value("COUNT({BOOK_NAME})"))
                /* 구조는 sn/parentSn 으로만 표현된다 — 루트는 parentSn 키가 없다 */
                .andExpect(jsonPath("$.nodes[0].parentSn").doesNotExist())
                .andExpect(jsonPath("$.nodes[2].parentSn").value(2))
                /*
                 * 폐지된 개념(attributes, children)은 <b>키 자체가 실리지 않는다</b>.
                 * 빈 배열로 내보내면 폐지된 개념이 살아 있는 것처럼 보이고, 프론트가 받은 것을
                 * 그대로 되돌려 보내는 왕복에서 그 배열이 다시 요청에 실린다.
                 *
                 * <b>R4 에서 단언이 뒤집힌 자리다</b>: 예전에는 마지막 줄이
                 * {@code $.root.children[0].children[0].children).isArray()} 였다 — 즉
                 * children 이 응답에 <b>존재함</b>을 고정하고 있었다. 경로만 치환해 이관하면
                 * 새 계약과 정반대되는 규약을 고정하게 되므로 doesNotExist 로 뒤집는다.
                 */
                .andExpect(jsonPath("$.nodes[0].attributes").doesNotExist())
                .andExpect(jsonPath("$.nodes[2].children").doesNotExist())
                .andExpect(jsonPath("$.root").doesNotExist());

        mvc.perform(get("/api/templates"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("c"));

        mvc.perform(delete("/api/templates/c")).andExpect(status().isNoContent());
        mvc.perform(get("/api/templates/c")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("TEMPLATE_NOT_FOUND"));
    }

    /**
     * repeatCondition 은 폐지된 필드다 — 값이 실려 오면 조용히 버리지 않고
     * 저장·미리보기 모두 명확한 오류로 거부한다 (§2).
     */
    @Test
    @DisplayName("repeatCondition 이 실려 오면 미리보기도 400")
    void previewRejectsRepeatCondition() throws Exception {
        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"template\":{\"nodes\":["
                                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                                + "{\"sn\":2,\"parentSn\":1,\"name\":\"I\","
                                + "\"valueType\":\"FIXED\",\"value\":\"v\","
                                + "\"repeatCondition\":\"{NOPE} == 'Y'\"}]}}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value(
                        org.hamcrest.Matchers.containsString("repeatCondition")));
    }

    /**
     * §2.9 "null 금지" + §2.6 "sourceXml 미전송".
     *
     * <b>키가 있고 값이 null 인 것</b>과 <b>키 자체가 없는 것</b>은 다르다. 전자면 프론트가
     * `x === null` 과 `x === undefined` 를 둘 다 방어해야 하고, 실제로 프론트 2종이 중복
     * 방어를 넣게 만들었다. 계약은 후자다 — 값이 없으면 필드를 싣지 않는다.
     */
    @Test
    @DisplayName("응답에 null 값 필드가 없다 (sourceXml 은 아예 없음)")
    void nullFieldsAreOmitted() throws Exception {
        mvc.perform(put("/api/templates/c").contentType(MediaType.APPLICATION_JSON)
                .content(TEMPLATE_JSON)).andExpect(status().isOk());

        /* 조회 — sourceXml 은 요청으로도 응답으로도 오가지 않는다 (§2.6) */
        mvc.perform(get("/api/templates/c")).andExpect(status().isOk())
                .andExpect(jsonPath("$.sourceXml").doesNotExist())
                .andExpect(jsonPath("$.updatedAt").isNotEmpty());

        /* import 결과는 아직 저장 전이라 updatedAt 이 없다 → 키 자체가 없어야 한다 */
        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "a.xml", "application/xml",
                                "<a><b>{V}</b></a>".getBytes(StandardCharsets.UTF_8))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.updatedAt").doesNotExist())
                .andExpect(jsonPath("$.template.sourceXml").doesNotExist())
                /* 빈 문자열은 null 이 아니므로 그대로 실린다 — 정규 표현이다 */
                .andExpect(jsonPath("$.template.nodes[0].displayCondition").value(""))
                .andExpect(jsonPath("$.warnings").isArray());
    }

    /**
     * §2.7 "{@code detail} 은 사람이 읽는 한 줄".
     *
     * 코어 예외 메시지는 요약 + 노드별 상세가 줄바꿈으로 이어진 형태인데 그 상세는
     * {@code errors[]} 와 완전히 겹친다. 통째로 실으면 화면에 같은 내용이 두 번 나온다.
     */
    @Test
    @DisplayName("detail 은 한 줄 요약이고 errors[] 와 중복되지 않는다")
    void detailIsSingleLineSummary() throws Exception {
        String body = mvc.perform(put("/api/templates/bad2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"bad2\",\"nodes\":["
                                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                                + "{\"sn\":2,\"parentSn\":1,\"name\":\"A\","
                                + "\"valueType\":\"FIXED\",\"value\":\"x\","
                                + "\"displayCondition\":\"R.NOPE != NULL\"},"
                                + "{\"sn\":3,\"parentSn\":1,\"name\":\"B\","
                                + "\"valueType\":\"FIXED\",\"value\":\"y\","
                                + "\"displayCondition\":\"R.ALSO_NOPE != NULL\"}]}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value("템플릿 검증 오류 2건"))
                /* 상세는 errors[] 에만 — 오류가 2건이어도 detail 은 한 줄이다 */
                .andExpect(jsonPath("$.errors.length()").value(2))
                .andReturn().getResponse().getContentAsString();

        String detail = new com.fasterxml.jackson.databind.ObjectMapper()
                .readTree(body).get("detail").asText();
        assertFalse(detail.contains("\n"), "detail 에 줄바꿈이 있다: " + detail);
        assertFalse(detail.contains("UNKNOWN_NODE_PATH"),
                "detail 이 errors[] 내용을 중복해 담고 있다: " + detail);
    }

    @Test
    @DisplayName("enum 오타는 조용한 기본값이 아니라 400")
    void unknownEnumRejected() throws Exception {
        mvc.perform(put("/api/templates/e").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"e\",\"nodes\":["
                                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FUCNTION\"}]}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("BAD_REQUEST"));
    }

    /**
     * 폐지된 {@code syntaxVersion} 필드도 알 수 없는 필드와 같은 규칙이다 —
     * 구버전 클라이언트가 실어 보내도 저장이 깨지지 않는다.
     */
    @Test
    @DisplayName("알 수 없는 필드는 무시 (폐지된 syntaxVersion 포함)")
    void unknownFieldIgnored() throws Exception {
        mvc.perform(put("/api/templates/u").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"u\",\"syntaxVersion\":2,\"futureField\":123,"
                                + "\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"}]}"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("검증 오류는 errors[] 목록 전체를 싣는다 (§11)")
    void validationErrorsListed() throws Exception {
        mvc.perform(put("/api/templates/bad").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"bad\",\"nodes\":["
                                + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                                + "{\"sn\":2,\"parentSn\":1,\"name\":\"A\","
                                + "\"valueType\":\"FIXED\",\"value\":\"x\","
                                + "\"displayCondition\":\"R.NOPE != NULL\"}]}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"))
                .andExpect(jsonPath("$.detail").isNotEmpty())
                .andExpect(jsonPath("$.errors[0].code").value("UNKNOWN_NODE_PATH"))
                .andExpect(jsonPath("$.errors[0].where").value("displayCondition"));
    }

    @Test
    @DisplayName("data — 문자열/숫자 리터럴 모두 수용 (§2.4, §2.6)")
    void dataShapesAccepted() throws Exception {
        mvc.perform(put("/api/templates/d").contentType(MediaType.APPLICATION_JSON)
                .content(TEMPLATE_JSON.replace("\"c\"", "\"d\""))).andExpect(status().isOk());

        /* 숫자 리터럴 — 구 JsonDataParser 와 같은 규칙 (표기 그대로 문자열화) */
        mvc.perform(post("/api/generate/d").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":{\"BOOK_NAME_1\":1500000}}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.xml").value(org.hamcrest.Matchers.containsString("1500000")));

        /* C# DataContract 배열 형태는 C# 프론트 제거와 함께 수용을 중단했다 — 400 */
        mvc.perform(post("/api/generate/d").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":[{\"Key\":\"BOOK_NAME_1\",\"Value\":\"노트북\"}]}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("응답 형태는 withWarnings 와 무관하게 고정 (§2.3)")
    void generationResultShapeIsStable() throws Exception {
        String preview = "{\"template\":{\"nodes\":[{\"sn\":1,"
                + "\"name\":\"R\",\"valueType\":\"VARIABLE\",\"value\":\"{MISSING}\"}]},"
                + "\"withWarnings\":%s}";

        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(preview, "false")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.xml").isNotEmpty())
                .andExpect(jsonPath("$.warnings").isEmpty());

        mvc.perform(post("/api/preview").contentType(MediaType.APPLICATION_JSON)
                        .content(String.format(preview, "true")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("MISSING_VARIABLE"))
                .andExpect(jsonPath("$.warnings[0].nodePath").value(""));
    }

    /* ---------------- import ---------------- */

    @Test
    @DisplayName("multipart import — 파일명 기반 제안 이름 + variables")
    void multipartImport() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "catalog.xml",
                "application/xml",
                "<catalog><book><title>{T}</title></book></catalog>".getBytes(StandardCharsets.UTF_8));

        mvc.perform(multipart("/api/templates/import").file(file))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.name").value("catalog"))
                .andExpect(jsonPath("$.variables[0]").value("T"))
                .andExpect(jsonPath("$.warnings").isArray());
    }

    @Test
    @DisplayName("multipart — file 파트 없으면 400")
    void multipartWithoutFile() throws Exception {
        mvc.perform(multipart("/api/templates/import"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("BAD_REQUEST"));
    }

    /**
     * 바이트 스트림 파싱 — 현행 결함(UTF-8 강제 디코딩) 회피 (§4.5).
     *
     * EUC-KR 로 선언된 파일을 UTF-8 로 먼저 디코딩하면 파서가 선언을 보기도 전에 깨진다.
     * 이 테스트가 실패하면 어딘가에서 바이트를 문자열로 먼저 바꾸고 있다는 뜻이다.
     */
    @Test
    @DisplayName("multipart — EUC-KR 선언 파일도 정상 파싱 (레거시 결함 회피)")
    void multipartRespectsEncodingDeclaration() throws Exception {
        String xml = "<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>";
        byte[] eucKr = xml.getBytes(Charset.forName("EUC-KR"));
        MockMultipartFile file = new MockMultipartFile("file", "euckr.xml",
                "application/xml", eucKr);

        mvc.perform(multipart("/api/templates/import").file(file))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[1].value").value("한글값"));
    }

    /**
     * §4.1 붙여넣기 경로: 파트 charset 이 <b>내부 선언보다 우선</b>한다 (RFC 7303).
     *
     * 프론트는 원본 바이트가 없는 텍스트를 UTF-8 로 인코딩해 보내므로, 사용자가 붙여넣은
     * 내용에 {@code encoding="EUC-KR"} 선언이 남아 있어도 서버는 UTF-8 로 읽어야 한다.
     * 선언을 따르면 그 자리에서 한글이 깨진다 — 실제 바이트는 UTF-8 이기 때문이다.
     */
    @Test
    @DisplayName("multipart — 파트 charset 이 내부 선언을 이긴다 (붙여넣기 경로)")
    void partCharsetWinsOverDeclaration() throws Exception {
        byte[] utf8Bytes = ("<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>")
                .getBytes(StandardCharsets.UTF_8);
        MockMultipartFile file = new MockMultipartFile("file", "pasted.xml",
                "application/xml;charset=UTF-8", utf8Bytes);

        mvc.perform(multipart("/api/templates/import").file(file))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[1].value").value("한글값"));
    }

    /** 파일명이 합성값(`pasted.xml`)이어도 동작해야 한다 — 제안 이름만 영향받는다 (§4.2). */
    @Test
    @DisplayName("multipart — templateName 파트가 파일명보다 우선한다")
    void templateNamePartWins() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "pasted.xml",
                "application/xml;charset=UTF-8",
                "<a><b>{V}</b></a>".getBytes(StandardCharsets.UTF_8));

        mvc.perform(multipart("/api/templates/import").file(file)
                        .param("templateName", "주문서"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.name").value("주문서"));

        /* 아무 단서도 없으면 서버가 이름을 지어내지 않는다 — 빈 문자열 */
        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "", "application/xml",
                                "<a><b>{V}</b></a>".getBytes(StandardCharsets.UTF_8))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.name").value(""));
    }

    /**
     * §4.4: multipart 상한이 {@code SecureXml.MAX_BODY_BYTES} 와 <b>같은 값</b>이어야 한다.
     * 프로퍼티에 10MB 를 따로 적으면 두 값이 조용히 갈라져, 한쪽만 통과하는 크기가 생긴다.
     */
    @Test
    @DisplayName("multipart 상한 프로퍼티가 SecureXml.MAX_BODY_BYTES 와 일치")
    void uploadLimitMatchesCoreConstant() {
        assertEquals(SecureXml.MAX_BODY_BYTES, multipartProperties.getMaxFileSize().toBytes(),
                "max-file-size 가 코어 상한과 다르다");
        assertEquals(SecureXml.MAX_BODY_BYTES, multipartProperties.getMaxRequestSize().toBytes(),
                "max-request-size 가 코어 상한과 다르다");
    }

    /**
     * §4.3 {@code ENCODING_USED} — <b>어떤 인코딩으로 읽었는지</b> 알린다.
     *
     * 서버는 인코딩 불일치를 <b>감지할 수 없다</b>. "EUC-KR 선언 + 실제로는 UTF-8 바이트"가
     * 오면 선언대로 읽어 깨진 문자열이 200 으로 통과하는데, 어느 쪽이 진실인지 판단할 근거가
     * 없기 때문이다. 그래서 "감지했다"가 아니라 "무엇으로 해석했다"를 알려 사용자가 결과를
     * 보고 판단하게 한다.
     *
     * <b>charset 이 명시된 요청에는 경고하지 않는다</b> — 클라이언트가 이미 선언한 것이라
     * 알릴 새 정보가 없고, 붙여넣기마다 쌓이면 정작 봐야 할 경고가 묻힌다.
     */
    @Test
    @DisplayName("ENCODING_USED — charset 명시 요청에는 경고하지 않는다")
    void encodingWarningAbsentWhenCharsetGiven() throws Exception {
        byte[] utf8 = "<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>"
                .getBytes(StandardCharsets.UTF_8);

        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "pasted.xml",
                                "application/xml;charset=UTF-8", utf8)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[1].value").value("한글값"))
                .andExpect(jsonPath("$.warnings[?(@.code == 'ENCODING_USED')]").isEmpty());
    }

    @Test
    @DisplayName("ENCODING_USED — charset 없음 + 선언 준수: 정상이어도 사용 인코딩을 알린다")
    void encodingWarningWhenNoCharsetAndDeclarationHonoured() throws Exception {
        byte[] eucKr = "<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>"
                .getBytes(Charset.forName("EUC-KR"));

        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "euckr.xml", "application/xml", eucKr)))
                .andExpect(status().isOk())
                /* 값은 정상 — 그래도 무엇으로 읽었는지는 알린다 */
                .andExpect(jsonPath("$.template.nodes[1].value").value("한글값"))
                .andExpect(jsonPath("$.warnings[0].code").value("ENCODING_USED"))
                /* 문서 단위 경고라 nodePath 는 "" */
                .andExpect(jsonPath("$.warnings[0].nodePath").value(""))
                .andExpect(jsonPath("$.warnings[0].message")
                        .value(org.hamcrest.Matchers.containsString("EUC-KR")));
    }

    /**
     * 이 조합이 경고를 넣은 이유다 — 외부 클라이언트만 만들 수 있고, 값이 깨진 채
     * 200 을 통과한다. 프론트 2종은 charset 을 명시하므로 이 경로를 타지 않는다.
     */
    @Test
    @DisplayName("ENCODING_USED — charset 없음 + 선언 불일치: 깨진 값이 통과해도 경고가 남는다")
    void encodingWarningWhenDeclarationMismatches() throws Exception {
        byte[] utf8BytesWithEucKrDecl =
                "<?xml version=\"1.0\" encoding=\"EUC-KR\"?><a><b>한글값</b></a>"
                        .getBytes(StandardCharsets.UTF_8);

        String body = mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "mismatch.xml", "application/xml",
                                utf8BytesWithEucKrDecl)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warnings[0].code").value("ENCODING_USED"))
                .andReturn().getResponse().getContentAsString();

        /* 값이 실제로 깨져 있다 — 서버가 막을 수 없는 조합임을 여기 명시해 둔다 */
        assertFalse(body.contains("한글값"),
                "이 조합에서 값이 온전하면 전제가 바뀐 것이다: " + body);
    }

    @Test
    @DisplayName("ENCODING_USED — 선언도 charset 도 없으면 UTF-8 로 해석했다고 알린다")
    void encodingWarningWhenNothingDeclared() throws Exception {
        mvc.perform(multipart("/api/templates/import")
                        .file(new MockMultipartFile("file", "plain.xml", "application/xml",
                                "<a><b>한글값</b></a>".getBytes(StandardCharsets.UTF_8))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.template.nodes[1].value").value("한글값"))
                .andExpect(jsonPath("$.warnings[0].code").value("ENCODING_USED"))
                .andExpect(jsonPath("$.warnings[0].message")
                        .value(org.hamcrest.Matchers.containsString("UTF-8")));
    }

    @Test
    @DisplayName("XXE 는 400 XML_SECURITY")
    void xxeRejected() throws Exception {
        mvc.perform(post("/api/templates/import").contentType(MediaType.APPLICATION_XML)
                        .content("<?xml version=\"1.0\"?><!DOCTYPE a ["
                                + "<!ENTITY x SYSTEM \"file:///etc/passwd\">]><a>&x;</a>"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("XML_SECURITY"));
    }

    /**
     * 리터럴 경로가 경로 변수보다 우선한다는 <b>프레임워크 동작에 기댄 설계</b>라 고정한다 (§3.3).
     * 이름이 "import" 인 템플릿의 PUT/GET/DELETE 가 막히면 기존 저장분이 조회 불능이 된다.
     */
    @Test
    @DisplayName("이름이 'import' 인 템플릿도 PUT/GET/DELETE 가 동작한다")
    void importIsReservedOnlyForPost() throws Exception {
        mvc.perform(put("/api/templates/import").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"import\",\"nodes\":[{\"sn\":1,"
                                + "\"name\":\"R\",\"valueType\":\"FIXED\",\"value\":\"v\"}]}"))
                .andExpect(status().isOk());
        mvc.perform(get("/api/templates/import")).andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("import"));
        mvc.perform(delete("/api/templates/import")).andExpect(status().isNoContent());
    }

    /**
     * 오류 본문 형태 (§2.7). 프론트 2종이 <b>{@code detail} 을 사람이 읽는 한 줄로</b> 쓰고
     * 없을 때만 {@code title} 로 폴백한다 — 필드명이 어긋나면 화면에 "HTTP 400" 만 뜬다.
     */
    @Test
    @DisplayName("오류는 ProblemDetail + code/errors 확장")
    void errorsAreProblemDetail() throws Exception {
        mvc.perform(get("/api/templates/nope"))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith("application/problem+json"))
                .andExpect(jsonPath("$.type").value("about:blank"))
                .andExpect(jsonPath("$.title").value("Not Found"))
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.detail").value("템플릿이 존재하지 않습니다: nope"))
                .andExpect(jsonPath("$.instance").value("/api/templates/nope"))
                .andExpect(jsonPath("$.code").value("TEMPLATE_NOT_FOUND"))
                /* 검증 오류가 아니어도 빈 배열 — 프론트가 존재 검사를 하지 않아도 되게 */
                .andExpect(jsonPath("$.errors").isArray())
                .andExpect(jsonPath("$.errors").isEmpty());
    }

    /**
     * CORS 헤더 3종은 구 서버와 <b>값까지 같아야 한다</b> (§3.6, 실측 대조 완료).
     *
     * 특히 {@code Access-Control-Allow-Origin} 이 {@code *} 여야 한다 —
     * {@code allowedOriginPatterns} 를 쓰면 요청 Origin 을 되비추어 값이 달라진다.
     *
     * 상태 코드는 구 서버 204, Spring 200 으로 다르다. 브라우저는 프리플라이트를 2xx 로만
     * 판정하므로 동작 차이가 없고, §7.4 가 <b>"2xx + 헤더 3종 값 동일, Max-Age 추가 허용"</b>
     * 으로 정정되어 이것이 계약이다 — 커스텀 {@code CorsProcessor} 로 204 를 만들지 않는다.
     *
     * 즉 <b>느슨한 것은 상태 코드뿐이고 헤더 값은 정확히 일치해야 한다.</b>
     */
    @Test
    @DisplayName("CORS 프리플라이트 — 헤더 3종이 구 서버와 동일")
    void corsPreflight() throws Exception {
        mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .options("/api/templates")
                        .header("Origin", "http://localhost:5173")
                        .header("Access-Control-Request-Method", "PUT")
                        .header("Access-Control-Request-Headers", "Content-Type"))
                .andExpect(status().isOk())
                .andExpect(content().string(""))
                .andExpect(header().string("Access-Control-Allow-Origin", "*"))
                .andExpect(header().string("Access-Control-Allow-Methods",
                        "GET,POST,PUT,DELETE,OPTIONS"))
                .andExpect(header().string("Access-Control-Allow-Headers", "Content-Type"));
    }

    /**
     * 경로의 템플릿 이름 왕복 (§3.6 — "프레임워크 교체로 조용히 깨지기 가장 쉬운 지점").
     *
     * 구 서버는 {@code getRawPath()} + 자체 디코딩으로 {@code +} 를 리터럴로 보존한다.
     * Spring 은 경로 변수를 자체 규칙으로 디코딩하므로 결과가 갈릴 수 있어, 구/신 서버
     * 실기동 대조로 5종(`a+b`/`a%b`/`a b`/한글/일반)이 동일함을 확인했다.
     * 여기서는 그 결과를 회귀로 고정한다.
     */
    @ParameterizedTest(name = "이름 왕복: {0}")
    @ValueSource(strings = { "a+b", "a%b", "a b", "한글", "a.b_c-d" })
    void pathNameRoundTrip(String name) throws Exception {
        mvc.perform(put("/api/templates/{name}", name).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                                + "\"valueType\":\"FIXED\",\"value\":\"v\"}]}"))
                .andExpect(status().isOk());

        /* 저장된 이름이 요청한 이름 그대로여야 한다 — 인코딩이 새어 들어가면 여기서 갈린다 */
        mvc.perform(get("/api/templates/{name}", name)).andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(name));
        mvc.perform(get("/api/templates"))
                .andExpect(jsonPath("$[0].name").value(name));
        mvc.perform(delete("/api/templates/{name}", name)).andExpect(status().isNoContent());
    }

    /**
     * 이름 규칙 위반은 400 이다 (§7.4).
     *
     * <b>경로를 인코딩된 형태로 넘긴다.</b> {@code put("/api/templates/{name}", "a/b")} 는
     * URI 템플릿 확장 시 슬래시를 인코딩하지 않아 {@code /api/templates/a/b} 가 되고,
     * 그건 이름 검증이 아니라 <b>매핑 없는 경로</b>를 때린다 — 검사하려던 것과 다른 것을
     * 검사하게 된다. 실제 클라이언트는 percent-encoding 해서 보낸다 (§3.6).
     */
    @ParameterizedTest(name = "이름 거부: {0}")
    @ValueSource(strings = { "a%2Fb", "a%5Cb" })
    @DisplayName("이름에 / 또는 \\ 가 있으면 400")
    void invalidNamesRejected(String encodedName) throws Exception {
        mvc.perform(put(java.net.URI.create("/api/templates/" + encodedName))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nodes\":[{\"sn\":1,\"name\":\"R\","
                                + "\"valueType\":\"FIXED\",\"value\":\"v\"}]}"))
                .andExpect(status().isBadRequest());
    }

    /**
     * 매핑 없는 경로는 <b>404</b> 다 — 구 서버와 같다(실측 대조).
     * 포괄 {@code @ExceptionHandler(Exception.class)} 가 프레임워크 예외를 삼키면
     * 여기가 500 이 되고, 경로 오타가 서버 장애로 보인다.
     */
    @Test
    @DisplayName("매핑 없는 경로는 404 (500 으로 퇴화하지 않는다)")
    void unmappedPathIsNotFound() throws Exception {
        mvc.perform(get("/api/nope")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("NOT_FOUND"));
        /* 예외 클래스명이 본문에 새지 않아야 한다 */
        mvc.perform(get("/api/templates/a/b")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.detail")
                        .value(org.hamcrest.Matchers.not(
                                org.hamcrest.Matchers.containsString("Exception"))));
    }
}
