package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.xmltemplate.util.engine.XmlGenerator;
import com.xmltemplate.support.XmlAssert;
import com.xmltemplate.util.template.TemplateValidator;

/**
 * 반복 의미론 R①~③ 과 상한 (구 {@code SelfTest.checkRepeatSemantics} 이관본).
 *
 * <b>세 규칙</b>
 * <ul>
 *   <li><b>R①</b> 변수 조회는 명시 인덱스만이다. {@code {X}} 는 회차와 무관하게 전역 키 X 만
 *       본다 — "회차 키가 있으면 그쪽을 본다"는 암묵 폴백은 없다 (§5.2-3).</li>
 *   <li><b>R②</b> {@code repeatCountExpr} 은 <b>식의 값</b>이 횟수다. 개수를 세려면
 *       {@code COUNT({X})} 로 명시한다 — 같은 식이 경우에 따라 값도 개수도 되면 안 된다.</li>
 *   <li><b>R③</b> {@code {INDEX}} 는 반복 조상이 정확히 1개일 때만. 여러 개면 어느 회차인지
 *       모호하므로 {@code {INDEX1}} 처럼 레벨을 명시한다 (§5.2-4).</li>
 * </ul>
 */
class PreviewRepeatApiTest extends ApiTestSupport {

    /** OUTER 2회 × INNER 2회, 리프 값만 갈아 끼운다. */
    private String nestedRepeat(String leafValue) {
        return "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"OUTER\",\"valueType\":\"FIXED\","
                + "\"repeatCountExpr\":\"2\"},"
                + "{\"sn\":3,\"parentSn\":2,\"name\":\"INNER\",\"valueType\":\"FIXED\","
                + "\"repeatCountExpr\":\"2\"},"
                + "{\"sn\":4,\"parentSn\":3,\"name\":\"V\",\"valueType\":\"VARIABLE\","
                + "\"value\":" + quote(leafValue) + "}]}";
    }

    private static final String NESTED_DATA = "{\"X_1\":\"안쪽1\",\"X_2\":\"안쪽2\"}";

    /* ================================================================== */
    /* R① 변수 조회는 명시 인덱스만 (§5.2-3)                                  */
    /* ================================================================== */

    @Nested
    @DisplayName("R① 인덱스 지목")
    class IndexTargeting {

        /**
         * X_1/X_2 가 <b>둘 다 있는데도</b> 전부 빈 값이어야 한다.
         * 폴백이 있으면 여기서 값이 채워지고, 사용자는 {@code {X}} 와 {@code {X_[N1]}} 의
         * 차이를 영원히 눈치채지 못한다.
         */
        @Test
        @DisplayName("암묵 폴백 없음 — {X} 는 전역 키만 조회한다")
        void noImplicitFallback() throws Exception {
            assertNull(XmlAssert.diff(
                    "<R><OUTER><INNER><V/></INNER><INNER><V/></INNER></OUTER>"
                            + "<OUTER><INNER><V/></INNER><INNER><V/></INNER></OUTER></R>",
                    previewXml(nestedRepeat("{X}"), NESTED_DATA)));
        }

        @Test
        @DisplayName("[N1] 은 바깥 반복 회차를 가리킨다")
        void level1IsOuter() throws Exception {
            assertNull(XmlAssert.diff(
                    "<R><OUTER><INNER><V>안쪽1</V></INNER><INNER><V>안쪽1</V></INNER></OUTER>"
                            + "<OUTER><INNER><V>안쪽2</V></INNER><INNER><V>안쪽2</V></INNER></OUTER></R>",
                    previewXml(nestedRepeat("{X_[N1]}"), NESTED_DATA)));
        }

        @Test
        @DisplayName("[N2] 는 안쪽 반복 회차를 가리킨다 (밖→안 순서)")
        void level2IsInner() throws Exception {
            assertNull(XmlAssert.diff(
                    "<R><OUTER><INNER><V>안쪽1</V></INNER><INNER><V>안쪽2</V></INNER></OUTER>"
                            + "<OUTER><INNER><V>안쪽1</V></INNER><INNER><V>안쪽2</V></INNER></OUTER></R>",
                    previewXml(nestedRepeat("{X_[N2]}"), NESTED_DATA)));
        }
    }

    /* ================================================================== */
    /* R② repeatCountExpr 은 '값'이 횟수                                     */
    /* ================================================================== */

    @Nested
    @DisplayName("R② 반복 횟수식")
    class RepeatCount {

        private String repeated(String countExpr) {
            return "{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                    + "{\"sn\":2,\"parentSn\":1,\"name\":\"ITEM\",\"valueType\":\"FIXED\","
                    + "\"value\":\"x\",\"repeatCountExpr\":" + quote(countExpr) + "}]}";
        }

        @Test
        @DisplayName("repeatCountExpr=\"{ITEM_NAME}\" 은 값(2회)")
        void valueIsTheCount() throws Exception {
            assertEquals(2, countOf(previewXml(repeated("{ITEM_NAME}"),
                    "{\"ITEM_NAME\":\"2\"}"), "<ITEM>"));
        }

        @Test
        @DisplayName("개수는 COUNT({ITEM_NAME}) 로 명시한다")
        void countFunctionForCardinality() throws Exception {
            assertEquals(3, countOf(previewXml(repeated("COUNT({ITEM_NAME})"),
                    "{\"ITEM_NAME_1\":\"a\",\"ITEM_NAME_2\":\"b\",\"ITEM_NAME_3\":\"c\"}"),
                    "<ITEM>"));
        }

        @Test
        @DisplayName("횟수 0 이면 미생성 (§9.1)")
        void zeroMeansAbsent() throws Exception {
            assertEquals(0, countOf(previewXml(repeated("0"), "{}"), "<ITEM>"));
        }

        /** 반복 횟수는 <b>0 이상 정수</b>다. 반올림·절대값 같은 관대한 해석은 하지 않는다. */
        @ParameterizedTest(name = "{0}: {1}")
        @CsvSource({
            "소수,    2.5",
            "음수,    -1",
            "비숫자,  많이",
        })
        @DisplayName("정수 아닌 반복 횟수는 400")
        void nonIntegerCountRejected(String kind, String badValue) throws Exception {
            preview(repeated("{BAD}"), "{\"BAD\":" + quote(badValue) + "}", true)
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
        }
    }

    /* ================================================================== */
    /* R③ {INDEX} 는 반복 조상이 1개일 때만 (§5.2-4)                          */
    /* ================================================================== */

    @Nested
    @DisplayName("R③ 내장 인덱스 변수")
    class BuiltinIndex {

        /** 저장 시점에 막는다 — 생성까지 가서야 실패하면 §11(저장 시 오류) 위반이다. */
        @Test
        @DisplayName("반복 조상 2개인 곳의 {INDEX} 는 저장 오류")
        void ambiguousIndexRejectedOnSave() throws Exception {
            save("idx-ambiguous", nestedRepeat("{INDEX}"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors[*].code")
                            .value(Matchers.hasItem(TemplateValidator.ERR_INDEX_DEPTH)));
        }

        /** 미리보기는 저장 검증을 거치지 않으므로 생성기도 같은 규칙을 들고 있어야 한다. */
        @Test
        @DisplayName("생성 시점에도 {INDEX} 다중 반복은 오류")
        void ambiguousIndexRejectedOnGenerate() throws Exception {
            preview(nestedRepeat("{INDEX}"), NESTED_DATA, true)
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
        }

        @Test
        @DisplayName("{INDEX2} 레벨 표기는 저장 통과")
        void leveledIndexSaves() throws Exception {
            save("idx-leveled", nestedRepeat("{INDEX2}")).andExpect(status().isOk());
        }

        @Test
        @DisplayName("{INDEX2} 는 레벨 2(안쪽) 회차")
        void level2Index() throws Exception {
            assertNull(XmlAssert.diff(
                    "<R><OUTER><INNER><V>1</V></INNER><INNER><V>2</V></INNER></OUTER>"
                            + "<OUTER><INNER><V>1</V></INNER><INNER><V>2</V></INNER></OUTER></R>",
                    previewXml(nestedRepeat("{INDEX2}"), NESTED_DATA)));
        }

        @Test
        @DisplayName("{INDEX1} 은 레벨 1(바깥) 회차")
        void level1Index() throws Exception {
            assertNull(XmlAssert.diff(
                    "<R><OUTER><INNER><V>1</V></INNER><INNER><V>1</V></INNER></OUTER>"
                            + "<OUTER><INNER><V>2</V></INNER><INNER><V>2</V></INNER></OUTER></R>",
                    previewXml(nestedRepeat("{INDEX1}"), NESTED_DATA)));
        }
    }

    /* ================================================================== */
    /* repeatCondition 폐지 — 대체 표현을 안내한다 (§2)                       */
    /* ================================================================== */

    /**
     * 거부만 하고 끝내면 사용자는 "그럼 어떻게 쓰라는 건가"에서 막힌다.
     * 폐지된 기능에는 <b>대체 경로</b>를 오류 문구에 담는 것이 이 프로젝트의 규약이다.
     *
     * (거부 자체는 {@code TemplateApiContractTest}(미리보기)와
     *  {@code RoutingMigratedTest}(저장)가 이미 고정한다 — 여기서는 안내 문구만 본다.)
     */
    @Test
    @DisplayName("§2 이중 방어: 오류 메시지가 대체 표현(삼항식)을 안내한다")
    void repeatConditionErrorSuggestsTernary() throws Exception {
        preview("""
                {"nodes":[
                  {"sn":1,"name":"R","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"ROW","valueType":"FIXED","value":"x",
                   "repeatCondition":"{USE} == 'Y'","repeatCountExpr":"2"}]}
                """, "{\"USE\":\"N\"}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value(Matchers.containsString("repeatCountExpr")))
                .andExpect(jsonPath("$.detail").value(Matchers.containsString("삼항식")));
    }

    /* ================================================================== */
    /* 상한 (§9.2)                                                          */
    /* ================================================================== */

    @Nested
    @DisplayName("상한")
    class Limits {

        /** 중첩 반복은 곱셈으로 커진다 — 깊이를 저장 시점에 자른다. */
        @Test
        @DisplayName("중첩 반복 깊이 초과는 저장 오류")
        void repeatNestingRejectedOnSave() throws Exception {
            /*
             * 평면 목록이라 중첩 괄호를 열고 닫을 필요가 없다 — L1..Ln 이 한 줄로 이어지고
             * parentSn 이 직전 노드를 가리키면 그것이 곧 사슬형 중첩이다 (R4).
             */
            StringBuilder body = new StringBuilder("{\"nodes\":["
                    + "{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"}");
            for (int level = 1; level <= TemplateValidator.MAX_REPEAT_NESTING + 1; level++) {
                body.append(",{\"sn\":").append(level + 1)
                        .append(",\"parentSn\":").append(level)
                        .append(",\"name\":\"L").append(level)
                        .append("\",\"valueType\":\"FIXED\",\"repeatCountExpr\":\"1\"}");
            }
            save("repeat-deep", body + "]}")
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors[*].code")
                            .value(Matchers.hasItem(TemplateValidator.ERR_REPEAT_DEPTH)));
        }

        /** 횟수식의 값은 데이터에 달렸으므로 저장 시점에 알 수 없다 — 생성에서 막는다. */
        @Test
        @DisplayName("단일 노드 반복 상한 초과는 생성 오류")
        void repeatPerNodeRejectedOnGenerate() throws Exception {
            preview("{\"nodes\":[{\"sn\":1,\"name\":\"R\",\"valueType\":\"FIXED\"},"
                            + "{\"sn\":2,\"parentSn\":1,\"name\":\"M\","
                            + "\"valueType\":\"FIXED\",\"value\":\"x\","
                            + "\"repeatCountExpr\":\"" + (XmlGenerator.MAX_REPEAT_PER_NODE + 1)
                            + "\"}]}", "{}", true)
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("GENERATION_FAILED"));
        }
    }

    /* ================================================================== */
    /* 진단 — 어느 회차에서 터졌는지 (§10)                                    */
    /* ================================================================== */

    /**
     * 반복 안에서 실패하면 "price 가 숫자가 아니다"만으로는 못 고친다.
     * 몇 번째 회차인지가 있어야 데이터에서 그 항목을 찾을 수 있다.
     */
    @Test
    @DisplayName("오류 메시지에 회차 인덱스 경로 포함 (catalog.book[2].price)")
    void errorMessageCarriesIterationPath() throws Exception {
        preview("""
                {"nodes":[
                  {"sn":1,"name":"catalog","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"book","valueType":"FIXED","repeatCountExpr":"2"},
                  {"sn":3,"parentSn":2,"name":"price","valueType":"VARIABLE","value":"{P_[N1]}",
                   "valueDataType":"NUMBER"}]}
                """, "{\"P_1\":\"100\",\"P_2\":\"십만원\"}", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail")
                        .value(Matchers.containsString("catalog.book[2].price")));
    }

    /* ---------------- helpers ---------------- */

    /** 반복 규칙은 저장 시점에도 걸려야 하므로 PUT 도 자주 쓴다. */
    private ResultActions save(String name, String templateJson) throws Exception {
        return mvc.perform(put("/api/templates/" + name)
                .contentType(MediaType.APPLICATION_JSON).content(templateJson));
    }

    private static int countOf(String text, String token) {
        int found = 0;
        int index = 0;
        while ((index = text.indexOf(token, index)) >= 0) {
            found++;
            index += token.length();
        }
        return found;
    }
}
