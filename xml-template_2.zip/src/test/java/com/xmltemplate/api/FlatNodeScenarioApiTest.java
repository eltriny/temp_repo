package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.RequestBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * <b>작업 목표 4단계의 종단 검증</b> — 구조 XML 업로드 → 평면 목록 → 속성 편집 → 미리보기.
 *
 * <h3>{@code FlatNodeContractApiTest} 와의 분업</h3>
 * 계약 테스트는 <b>형태</b>를 본다 — 응답에 {@code nodes} 가 있는지, 불변식 (I1)(I2) 가
 * 성립하는지, 구조 오류가 어떤 code 로 나오는지. 여기서는 그 형태를 타고 흐르는
 * <b>사용자 시나리오</b>를 본다: 실제 파일을 올리면 문서 순서가 살아 있는지, 노드 속성을
 * 바꾸면 미리보기 XML 이 정말 달라지는지.
 *
 * <h3>왜 불변식만으로는 부족한가 (이 클래스의 존재 이유)</h3>
 * (I1)(I2) 는 <b>어떤 올바른 트리든</b> 만족한다 — 형제 순서를 통째로 뒤집어도 성립한다.
 * 즉 불변식 단언은 "목록이 트리로 조립 가능하다"까지만 증명하고 <b>"원본 문서 순서다"는
 * 증명하지 않는다</b>. 임포트 파서가 자식을 역순으로 담는 회귀는 기존 단언 전부를 통과한다
 * (기존 {@code ImportApiTest} 는 형제 순서에 흔들리지 않으려고 <b>일부러</b> 이름으로
 * 노드를 찾는다). 그래서 여기서는 전체 목록을 <b>순서 그대로</b> 대조한다.
 *
 * <h3>미리보기 단언의 형태 — "달라졌다"가 아니라 "이렇게 달라졌다"</h3>
 * 편집 반영을 볼 때 두 XML 이 <b>다르다</b>만 단언하면 엉뚱한 이유(예: 오류 문자열)로
 * 달라져도 통과한다. 그래서 편집 전/후의 <b>요소 개수와 존재 여부</b>를 각각 못박고,
 * 편집을 되돌리면 <b>원본과 완전히 같은 XML</b> 이 나오는 것까지 본다.
 */
class FlatNodeScenarioApiTest extends ApiTestSupport {

    /**
     * 골든 케이스의 구조 XML 을 <b>디스크에서 바이트 그대로</b> 올린다.
     *
     * 문자열 상수를 쓰지 않는 이유: 시나리오의 1단계가 "구조 XML <b>파일</b> 업로드"라
     * 파일 경로·인코딩·multipart 파트까지가 검증 대상이다. 또 이 파일은 골든 케이스와
     * 브라우저 E2E 가 함께 쓰는 정본이므로, 한쪽만 바뀌면 여기서 먼저 드러난다.
     */
    private static final Path CASE_020 = Paths.get("src/test/resources/cases/020-spec-example-2");

    /** {@code 020-spec-example-2/template.xml} 의 문서 순서 — {@code sn:이름:parentSn}. */
    private static final List<String> DOCUMENT_ORDER_020 = Arrays.asList(
            "1:Request:-",
            "2:Header:1",
            "3:ApiKey:2",
            "4:Timestamp:2",
            "5:Parameters:1",
            "6:UserId:5",
            "7:Action:5",
            "8:PageSize:5",
            "9:Filters:5",
            "10:Filter:9",
            "11:Category:10",
            "12:MinPrice:10",
            "13:Items:10",
            "14:Item:13");

    /* ================================================================== */
    /* 1단계 — 구조 XML 파일 업로드 → 평면 목록                               */
    /* ================================================================== */

    /**
     * S-1 — 업로드한 문서의 <b>순서가 그대로</b> 평면 목록이 된다.
     *
     * 목록 전체를 한 번에 비교하므로 형제 순서가 바뀌거나 노드가 하나 빠지면 실패한다.
     * {@code assertEquals(List, List)} 의 실패 메시지가 두 목록을 나란히 찍어 주므로
     * "어디가 어긋났는지"가 바로 읽힌다.
     */
    @Test
    @DisplayName("S-1: 구조 XML 파일을 올리면 문서 순서 그대로 평면 목록이 된다 (14노드, 5단 중첩)")
    void importPreservesDocumentOrder() throws Exception {
        JsonNode nodes = importedTemplate().path("nodes");

        assertEquals(DOCUMENT_ORDER_020, outline(nodes), "임포트 목록이 문서 순서와 다르다");
    }

    /**
     * S-1 대조군 — 위 단언이 <b>정말 순서를 보는지</b>.
     *
     * 같은 노드 집합을 형제 순서만 바꿔 올리면 목록도 그만큼 달라져야 한다. 이 테스트가
     * 없으면 {@code outline} 이 (예컨대 정렬을 하거나 이름만 모아) 순서를 지워 버려도
     * S-1 이 통과한다 — 순서를 검증한다고 <b>믿는</b> 초록이 가장 위험하다.
     */
    @Test
    @DisplayName("S-1(대조군): 형제 순서를 바꾼 문서는 다른 목록을 낸다")
    void siblingOrderIsActuallyObserved() throws Exception {
        String swapped = "<Request><Parameters><UserId>{U}</UserId></Parameters>"
                + "<Header><ApiKey>{K}</ApiKey></Header></Request>";

        List<String> outline = outline(importXml(swapped).path("template").path("nodes"));

        assertEquals(Arrays.asList("1:Request:-", "2:Parameters:1", "3:UserId:2",
                "4:Header:1", "5:ApiKey:4"), outline);
        /* 같은 이름 집합을 문서 순서만 바꿔 올린 경우 — 목록이 따라 바뀌어야 한다 */
        assertNotEquals(outline, outline(importXml(
                "<Request><Header><ApiKey>{K}</ApiKey></Header>"
                        + "<Parameters><UserId>{U}</UserId></Parameters></Request>")
                .path("template").path("nodes")));
    }

    /* ================================================================== */
    /* 3·4단계 — 속성 편집이 미리보기에 반영된다                               */
    /* ================================================================== */

    /**
     * S-2 — {@code repeatCountExpr} 을 바꾼 평면 목록으로 미리보기하면 <b>반복 횟수가 바뀐다</b>.
     *
     * 화면에서 "노드 선택 → 반복 횟수 편집 → 적용 → 미리보기 갱신"(UX §3 E2E-A A-8)을 지나는
     * 경로 그대로다. 프론트는 트리를 편집해 <b>목록을 새로 직렬화</b>해 보내므로, 서버 입장에서
     * 편집이란 "필드 하나만 다른 평면 목록"이다 — 그것을 그대로 재현한다.
     *
     * 편집 전후가 <b>같은 목록의 한 필드만</b> 다르다는 점이 요점이다. 두 개의 다른 템플릿을
     * 비교하면 무엇이 결과를 바꿨는지 단정할 수 없다.
     */
    @Test
    @DisplayName("S-2: repeatCountExpr 을 바꾼 목록으로 미리보기하면 반복 횟수가 바뀐다")
    void editingRepeatCountExprChangesPreviewRepetition() throws Exception {
        JsonNode template = importedTemplate();
        String data = readCase("data.json");

        String before = previewXml(template.toString(), data);
        assertEquals(3, countOf(before, "<Filter>"), "원본은 COUNT(...)=3 회여야 한다");

        String edited = withField(template, "Filter", "repeatCountExpr", "1");
        String after = previewXml(edited, data);

        assertEquals(1, countOf(after, "<Filter>"), "반복 횟수 편집이 미리보기에 반영되지 않았다");
        /* 편집한 노드만 영향을 받는다 — 첫 회차 내용은 그대로다 */
        assertTrue(after.contains("<Category>대그룹</Category>"), after);
        assertFalse(after.contains("중그룹"), "1회로 줄였는데 2회차 데이터가 남아 있다: " + after);
    }

    /**
     * S-3 — {@code displayCondition} 을 바꾸면 <b>요소가 나타나고 사라진다</b>.
     *
     * 조건을 <b>지우는</b> 방향(숨겨져 있던 요소가 나타난다)과 <b>거짓으로 바꾸는</b> 방향
     * (보이던 요소가 사라진다)을 모두 본다. 한 방향만 보면 "조건을 무시하고 항상 생성한다"는
     * 회귀가 절반은 통과한다.
     */
    @Test
    @DisplayName("S-3: displayCondition 편집이 미리보기의 요소 존재 여부를 바꾼다")
    void editingDisplayConditionChangesPreviewVisibility() throws Exception {
        JsonNode template = importedTemplate();
        String data = readCase("data.json");

        /* 원본: PARAM_USERID 가 빈 값이라 PageSize 의 표시 조건이 거짓 -> 미생성 */
        assertFalse(previewXml(template.toString(), data).contains("<PageSize>"),
                "골든 기대와 달리 PageSize 가 생성됐다 — 이 테스트의 전제가 깨졌다");

        /* 조건을 지우면 나타난다 */
        String shown = previewXml(withField(template, "PageSize", "displayCondition", ""), data);
        assertTrue(shown.contains("<PageSize>10</PageSize>"),
                "표시 조건을 지웠는데도 요소가 나오지 않는다: " + shown);

        /* 보이던 요소를 거짓 조건으로 숨긴다 */
        String hidden = previewXml(
                withField(template, "Action", "displayCondition", "{PARAM_ACTION} == '없는값'"), data);
        assertFalse(hidden.contains("<Action>"),
                "거짓 표시 조건을 넣었는데 요소가 남아 있다: " + hidden);
        assertTrue(hidden.contains("<UserId/>"), "다른 형제까지 사라졌다: " + hidden);
    }

    /**
     * S-4 — 편집을 <b>되돌리면</b> 원본과 완전히 같은 XML 로 복귀한다.
     *
     * UX §3 E2E-A 의 A-10("편집 왕복이 상태를 오염시키지 않음")을 API 계층에서 자동화한 것이다.
     * S-2/S-3 은 "바꾸면 달라진다"를 보는데, 그것만으로는 편집 경로가 <b>남기는 찌꺼기</b>를
     * 잡지 못한다 — 되돌린 결과가 원본과 문자 단위로 같아야 왕복이 깨끗하다.
     */
    @Test
    @DisplayName("S-4: 편집했다가 되돌리면 원본과 완전히 같은 미리보기 XML 이 나온다")
    void revertingAnEditRestoresTheOriginalXml() throws Exception {
        JsonNode template = importedTemplate();
        String data = readCase("data.json");
        String original = previewXml(template.toString(), data);

        previewXml(withField(template, "Filter", "repeatCountExpr", "1"), data);
        String reverted = previewXml(
                withField(template, "Filter", "repeatCountExpr",
                        "COUNT({PARAM_FILTER_CATEGORY})"), data);

        assertEquals(original, reverted, "편집을 되돌렸는데 XML 이 원본과 다르다");
    }

    /* ================================================================== */
    /* 4단계의 뒤 — 편집한 목록을 저장해도 살아남는다                           */
    /* ================================================================== */

    /**
     * S-5 — 편집한 평면 목록을 <b>저장하고 다시 열면</b> 편집 내용과 문서 순서가 모두 남아 있다.
     *
     * 미리보기는 저장소를 지나지 않는다. 저장 경로에는 "DTO → 도메인 트리 → 엔티티 행 →
     * 도메인 트리 → DTO" 네 번의 변환이 더 있고, 그 사이에서 순서가 바뀌거나 편집한 필드가
     * 정규화되어 사라질 수 있다. 시나리오의 마지막 고리를 여기서 잠근다.
     */
    @Test
    @DisplayName("S-5: 편집한 목록을 저장 → 재조회해도 편집 내용과 문서 순서가 남는다")
    void editedListSurvivesSaveAndReload() throws Exception {
        String edited = withField(importedTemplate(), "Filter", "repeatCountExpr", "2");

        mvc.perform(put("/api/templates/scenario-edited")
                .contentType(MediaType.APPLICATION_JSON).content(edited))
                .andExpect(status().isOk());
        JsonNode loaded = json.readTree(mvc.perform(get("/api/templates/scenario-edited"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString());

        assertEquals(DOCUMENT_ORDER_020, outline(loaded.path("nodes")),
                "저장 왕복에서 문서 순서가 어긋났다");
        assertEquals("2", fieldOf(loaded.path("nodes"), "Filter", "repeatCountExpr"),
                "편집한 repeatCountExpr 이 저장 왕복에서 사라졌다");
        /* 저장분으로 미리보기하면 편집한 횟수대로 나온다 — 저장 전후의 의미가 같다 */
        assertEquals(2, countOf(previewXml(loaded.toString(), readCase("data.json")), "<Filter>"));
    }

    /* ================================================================== */
    /* 헬퍼                                                                */
    /* ================================================================== */

    /** 구조 XML 파일을 바이트 그대로 올려 받은 {@code template} 노드. */
    private JsonNode importedTemplate() throws Exception {
        String body = mvc.perform(uploadCaseFile())
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(body).path("template");
    }

    /** 프론트의 파일 선택 경로와 같은 형태 — 파일명·charset 을 실제 파일에서 가져온다. */
    private RequestBuilder uploadCaseFile() throws IOException {
        byte[] bytes = Files.readAllBytes(CASE_020.resolve("template.xml"));
        return multipart("/api/templates/import")
                .file(new MockMultipartFile("file", "spec-example-2.xml",
                        "application/xml;charset=UTF-8", bytes));
    }

    private static String readCase(String fileName) throws IOException {
        return new String(Files.readAllBytes(CASE_020.resolve(fileName)),
                java.nio.charset.StandardCharsets.UTF_8);
    }

    /**
     * 목록을 {@code sn:이름:parentSn} 문자열로 편다 — 루트는 {@code -}.
     *
     * <b>왜 문자열인가</b>: 실패 메시지가 사람이 읽을 수 있어야 한다. 숫자 배열 3개를 따로
     * 비교하면 "3번째가 다르다"까지만 알려 주지만, 이 형태는 두 목록을 나란히 찍어
     * 어느 노드가 어디로 갔는지 바로 보인다.
     */
    private static List<String> outline(JsonNode nodes) {
        List<String> out = new ArrayList<String>();
        for (JsonNode node : nodes) {
            out.add(node.path("sn").asInt() + ":" + node.path("name").asText() + ":"
                    + (node.has("parentSn") ? node.path("parentSn").asText() : "-"));
        }
        return out;
    }

    /**
     * 노드 하나의 필드를 바꾼 <b>새 템플릿 JSON</b> — 프론트의 "트리 편집 후 재직렬화"에 해당한다.
     *
     * 원본을 {@code deepCopy} 로 복제해 바꾼다. 제자리에서 고치면 한 테스트 안에서 편집 전후를
     * 비교할 때 <b>이미 바뀐 것</b>과 비교하게 된다 — 조용히 항상 통과하는 단언이 된다.
     */
    private String withField(JsonNode template, String nodeName, String field, String value) {
        ObjectNode copy = template.deepCopy();
        int changed = 0;
        for (JsonNode node : copy.path("nodes")) {
            if (nodeName.equals(node.path("name").asText())) {
                ((ObjectNode) node).put(field, value);
                changed++;
            }
        }
        assertEquals(1, changed, "편집 대상 노드 '" + nodeName + "' 를 정확히 1개 찾지 못했다");
        return copy.toString();
    }

    /** 이름으로 노드를 찾아 필드 값을 읽는다 (편집 결과 확인용). */
    private static String fieldOf(JsonNode nodes, String nodeName, String field) {
        for (JsonNode node : nodes) {
            if (nodeName.equals(node.path("name").asText())) {
                return node.path(field).asText();
            }
        }
        return null;
    }

    /** {@code needle} 이 몇 번 나오는지. 반복 횟수를 세는 용도라 겹침은 고려하지 않는다. */
    private static int countOf(String xml, String needle) {
        int count = 0;
        for (int at = xml.indexOf(needle); at >= 0; at = xml.indexOf(needle, at + needle.length())) {
            count++;
        }
        return count;
    }
}
