package com.xmltemplate.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import com.xmltemplate.support.XmlAssert;

/**
 * 외부 데이터 맵({@code data})의 값 계약 (§2.4, §2.6) — 구 {@code SelfTest.checkJsonData}
 * 이관본 + 실측된 계약 위반의 회귀.
 *
 * <b>계약</b>: 값은 <b>문자열 또는 숫자만</b>이고, 숫자는 <b>입력 표기 그대로</b> 문자열이 된다.
 * 프론트 {@code serializer.js} 의 {@code parseSampleData} 와 동일 정책이다 — 같은 입력을
 * 두 곳이 다르게 받아들이면 "화면에서는 되는데 서버에서는 안 된다"가 된다.
 *
 * <b>무엇이 깨져 있었나</b>: 역직렬화가 {@code readTree().asText()} 였을 때 ① 중첩 객체·배열이
 * 예외 없이 빈 문자열이 되고 ② {@code true} 가 {@code "true"} 라는 값으로 들어가고
 * ③ {@code 1.50} 이 {@code "1.5"} 로 재포맷됐다. ①은 데이터가 조용히 사라지는 것이고
 * ③은 SUM 의 결과 자릿수를 바꾼다(§6.2). 세 경로를 여기서 고정한다.
 */
class DataMapContractApiTest extends ApiTestSupport {

    /** {A} 를 그대로 출력하는 최소 템플릿. */
    private String echoA() {
        return singleNode("VARIABLE", "{A}");
    }

    /* ================================================================== */
    /* 거부 — 스칼라가 아니면 조용히 넘기지 않는다                             */
    /* ================================================================== */

    /**
     * 네 값 모두 "빈 문자열로 떨구고 계속"이 가능하다. 그러면 사용자가 보낸 데이터가
     * <b>200 응답 안에서</b> 사라지고, 왜 이 변수만 비었는지 추적할 단서가 없다.
     */
    @ParameterizedTest(name = "{0}")
    @CsvSource(delimiter = '|', value = {
        "중첩 객체 | {\"A\": {\"B\": 1}}",
        "배열      | {\"A\": [1, 2]}",
        "boolean   | {\"A\": true}",
        "null      | {\"A\": null}",
    })
    @DisplayName("문자열/숫자 외의 값은 400 (키 이름을 알려준다)")
    void nonScalarValueRejected(String kind, String dataJson) throws Exception {
        preview(echoA(), dataJson.trim(), true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("BAD_REQUEST"))
                /* 어느 키가 문제인지 없으면 큰 데이터에서 찾을 수 없다 */
                .andExpect(jsonPath("$.detail").value(Matchers.containsString("'A'")))
                .andExpect(jsonPath("$.detail")
                        .value(Matchers.containsString("문자열 또는 숫자")));
    }

    /* ================================================================== */
    /* 숫자 표기 보존                                                        */
    /* ================================================================== */

    /**
     * {@code 1.50} 은 {@code "1.50"} 이다.
     *
     * 소수 자릿수는 의미를 가진다 — §6.2 가 SUM 의 결과 자릿수를 "입력 최대 자릿수"로
     * 규정하므로, 여기서 {@code 1.5} 로 정규화되면 합계의 표기가 통째로 달라진다.
     * 금액 표기처럼 사용자가 자릿수를 의도해 보낸 값이 조용히 바뀌는 것이기도 하다.
     */
    @Test
    @DisplayName("숫자 리터럴은 표기 그대로 (1.50 이 1.5 가 되지 않는다)")
    void numberNotationPreserved() throws Exception {
        /* 들여쓰기는 의미가 없고 리프 텍스트는 원문 비교다 (§10) — XmlAssert 기준으로 본다 */
        assertNull(XmlAssert.diff("<V>1.50</V>", previewXml(echoA(), "{\"A\": 1.50}")));
    }

    @Test
    @DisplayName("JSON 스칼라 변환: 숫자 표기 유지 + 문자열 이스케이프 해석")
    void scalarConversion() throws Exception {
        String template = """
                {"nodes":[
                  {"sn":1,"name":"R","valueType":"FIXED"},
                  {"sn":2,"parentSn":1,"name":"C","valueType":"VARIABLE","value":"{C}"},
                  {"sn":3,"parentSn":1,"name":"D","valueType":"VARIABLE","value":"{D}"}]}
                """;
        String xml = previewXml(template, "{\"C\": 1.50, \"D\": \"줄1\\n줄2\"}");

        assertNull(XmlAssert.diff("<R><C>1.50</C><D>줄1\n줄2</D></R>", xml),
                "숫자 표기 또는 문자열 이스케이프 해석이 다르다:\n" + xml);
    }

    /* ================================================================== */
    /* 유효 데이터 — 숫자로 보내든 문자열로 보내든 같은 결과                    */
    /* ================================================================== */

    /**
     * 구 검증의 "JSON 해석: KEY=VALUE 와 동일한 맵" / "JSON 데이터로 동일한 XML 생성" 에
     * 대응한다. KEY=VALUE 입력 형식은 API 전용 구조에서 사라졌으므로, 대조 축을
     * <b>숫자 리터럴 ↔ 문자열</b>로 옮겼다 — 표기가 같으면 결과도 같아야 한다.
     */
    @Test
    @DisplayName("숫자 리터럴 데이터와 문자열 데이터가 같은 XML 을 만든다")
    void numberAndStringDataAgree() throws Exception {
        String demo = resource("fixtures/demo-order.json");

        String withNumbers = previewXml(demo, """
                {"ORDER_NO":"ORD-2026-0001","ORDER_TYPE":"D","MEMO":"빠른 배송 요청",
                 "ITEM_NAME_1":"노트북","ITEM_PRICE_1":1500000,
                 "ITEM_NAME_2":"마우스","ITEM_PRICE_2":30000,
                 "ITEM_NAME_3":"키보드","ITEM_PRICE_3":80000}
                """);
        String withStrings = previewXml(demo, """
                {"ORDER_NO":"ORD-2026-0001","ORDER_TYPE":"D","MEMO":"빠른 배송 요청",
                 "ITEM_NAME_1":"노트북","ITEM_PRICE_1":"1500000",
                 "ITEM_NAME_2":"마우스","ITEM_PRICE_2":"30000",
                 "ITEM_NAME_3":"키보드","ITEM_PRICE_3":"80000"}
                """);

        assertEquals(withStrings, withNumbers, "숫자 리터럴과 문자열의 해석이 갈렸다");
    }

    /** {@code data} 자체가 객체가 아니면 400 — 값 하나가 아니라 형태의 문제다. */
    @Test
    @DisplayName("data 가 객체가 아니면 400")
    void nonObjectDataRejected() throws Exception {
        preview(echoA(), "[{\"Key\":\"A\",\"Value\":\"v\"}]", true)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail")
                        .value(Matchers.containsString("data 는 객체여야 합니다")));
    }
}
