package com.xmltemplate.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.MediaType;

/**
 * 레거시 XML 표면의 <b>완전 제거</b>를 고정한다 (2026-08-07 확정).
 *
 * 마지막까지 남아 있던 동결 경로 {@code POST /generate/{name}} 까지 제거되어 레거시 루트
 * 경로는 전부 404 다. 이 테스트가 없으면 나중에 누군가 "호환을 위해" 매핑을 되살려도
 * 아무도 알아채지 못한다 — 제거는 코드가 아니라 테스트가 지킨다.
 *
 * 오류 표현도 하나다: 레거시가 쓰던 text/plain 오류는 사라졌고, 모든 오류는
 * RFC 7807 {@code application/problem+json} 이다.
 */
class LegacyRemovedTest extends ApiTestSupport {

    @ParameterizedTest(name = "제거 확인: {0}")
    @ValueSource(strings = { "/templates", "/templates/x", "/templates/import", "/preview",
            "/generate/x" })
    @DisplayName("레거시 루트 경로는 모두 404")
    void legacyRootPathsAreGone(String path) throws Exception {
        mvc.perform(get(path)).andExpect(status().isNotFound());
        mvc.perform(post(path).contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isNotFound());
        mvc.perform(put(path).contentType(MediaType.APPLICATION_XML).content("<a/>"))
                .andExpect(status().isNotFound());
    }

    /**
     * 저장된 템플릿이 <b>있어도</b> 레거시 생성 경로는 404 다 — 경로가 살아 있으면서
     * 템플릿만 없어서 404 가 나는 것과 구분해야 제거가 증명된다.
     */
    @Test
    @DisplayName("템플릿이 존재해도 POST /generate/{name} 은 404")
    void generateGoneEvenForExistingTemplate() throws Exception {
        mvc.perform(put("/api/templates/alive").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"alive\",\"nodes\":[{\"sn\":1,"
                                + "\"name\":\"R\",\"valueType\":\"FIXED\",\"value\":\"v\"}]}"))
                .andExpect(status().isOk());

        mvc.perform(post("/generate/alive").contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isNotFound());

        /* 같은 템플릿이 신규 경로로는 정상 생성된다 — 제거 범위가 넘치지 않았는지 */
        mvc.perform(post("/api/generate/alive").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"data\":{}}"))
                .andExpect(status().isOk());
    }

    /** 레거시 평문 오류 계약도 함께 사라졌다 — 404 본문은 ProblemDetail JSON 이다. */
    @Test
    @DisplayName("제거된 경로의 404 도 application/problem+json 으로 나온다")
    void removedPathErrorsAreProblemJson() throws Exception {
        mvc.perform(post("/generate/anything").contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith("application/problem+json"));
    }
}
