package com.xmltemplate.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.function.Supplier;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.xmltemplate.api.ApiTestSupport;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.repository.TemplateStore;

/**
 * 저장 트랜잭션 경계 — <b>실패한 저장이 기존 저장분을 훼손하지 않는가</b>.
 *
 * 저장은 "노드·속성 전건 삭제 → 재삽입"이다. 삭제만 커밋되고 삽입이 실패하면 화면에는
 * <b>이름만 남고 내용이 사라진 템플릿</b>이 보이고, 사용자는 자기가 방금 저장을 눌러서
 * 원본을 잃었다는 사실만 알게 된다. 되돌릴 방법이 없다.
 *
 * 두 각도로 본다 — 검증이 저장 <b>앞에서</b> 막는가(정상 경로), 그리고 저장 <b>도중에</b>
 * 실패해도 롤백되는가(경계 자체).
 */
class TransactionBoundaryTest extends ApiTestSupport {

    @Autowired
    private TemplateStore store;

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private PlatformTransactionManager txManager;

    /**
     * 검증 실패(400)는 기존 저장분을 <b>한 행도</b> 건드리지 않는다.
     *
     * 사용자가 편집 중 실수한 조건식으로 저장을 누르는 것은 흔한 일이다. 그때 원본이
     * 날아가면 안 된다. {@code repeatCondition} 은 폐지된 필드라 저장 경로에서 항상
     * 거부된다(계약 §3.1 필드표 · §5.2 V11) — 재현이 결정적이라 여기 쓴다.
     */
    @Test
    @DisplayName("검증 실패 저장(400)은 기존 저장분을 그대로 둔다")
    void validationFailureLeavesExistingTemplateIntact() throws Exception {
        String valid = "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"ORDER\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"A\",\"valueType\":\"FIXED\",\"value\":\"1\"},"
                + "{\"sn\":3,\"parentSn\":1,\"name\":\"B\",\"valueType\":\"FIXED\",\"value\":\"2\"}]}";
        mvc.perform(put("/api/templates/tx-guard").contentType(MediaType.APPLICATION_JSON)
                .content(valid)).andExpect(status().isOk());
        assertEquals(3, nodeCount("tx-guard"), "사전 저장이 이루어지지 않았다");

        String invalid = "{\"nodes\":["
                + "{\"sn\":1,\"name\":\"ORDER\",\"valueType\":\"FIXED\",\"value\":\"\"},"
                + "{\"sn\":2,\"parentSn\":1,\"name\":\"ITEM\",\"valueType\":\"FIXED\",\"value\":\"x\","
                + "\"repeatCondition\":\"{USE} == 'Y'\",\"repeatCountExpr\":\"2\"}]}";
        mvc.perform(put("/api/templates/tx-guard").contentType(MediaType.APPLICATION_JSON)
                        .content(invalid))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[*].code")
                        .value(org.hamcrest.Matchers.hasItem("REPEAT_CONDITION_REMOVED")));

        assertEquals(3, nodeCount("tx-guard"), "검증 실패 저장이 기존 노드 행을 지웠다");
        mvc.perform(get("/api/templates/tx-guard"))
                .andExpect(status().isOk())
                /* 평면 목록: [0]=ORDER(루트), [1]=A, [2]=B — DFS 전위 순서가 그대로 보존된다 */
                .andExpect(jsonPath("$.nodes[1].name").value("A"))
                .andExpect(jsonPath("$.nodes[2].name").value("B"))
                .andExpect(jsonPath("$.nodes[2].value").value("2"));
    }

    /**
     * 저장 <b>도중</b> 실패해도 이미 나간 삭제가 커밋되지 않는다.
     *
     * 위 테스트는 검증이 {@code store.save} <b>앞</b>에 있어 삭제 자체가 일어나지 않는다 —
     * 즉 트랜잭션 경계를 실제로 시험하지 않는다. 여기서는 삭제가 나간 <b>뒤</b>에 실패를
     * 일으켜, 경계가 없으면 반드시 데이터가 사라지는 상황을 만든다. 경계가 살아 있으면
     * 원본이 온전하다.
     */
    @Test
    @DisplayName("저장 도중 예외가 나면 이미 나간 삭제까지 롤백된다")
    void failureMidSaveRollsBackTheDeletes() {
        TemplateNode original = fixedNode("ORDER", "");
        original.addChild(fixedNode("A", "1"));
        original.addChild(fixedNode("B", "2"));
        original.addChild(fixedNode("C", "3"));
        inTransaction(() -> store.save("tx-rollback", original));
        assertEquals(4, nodeCount("tx-rollback"), "사전 저장이 이루어지지 않았다");

        TemplateNode replacement = fixedNode("ORDER", "");
        replacement.addChild(fixedNode("Z", "9"));

        assertThrows(IllegalStateException.class, () -> inTransaction(() -> {
            store.save("tx-rollback", replacement);
            throw new IllegalStateException("저장 직후 실패를 의도적으로 일으킨다");
        }));

        assertEquals(4, nodeCount("tx-rollback"), "롤백되지 않아 노드 행이 사라졌다");
        TemplateNode reloaded = inTransactionGet(() -> store.load("tx-rollback"));
        assertNotNull(reloaded, "롤백 후 템플릿을 읽을 수 없다");
        assertEquals(3, reloaded.getChildren().size(), "롤백 후 자식 수가 다르다");
        assertEquals("A", reloaded.getChildren().get(0).getName());
        assertEquals("C", reloaded.getChildren().get(2).getName());
    }

    /* ---------------- helpers ---------------- */

    private static TemplateNode fixedNode(String name, String value) {
        TemplateNode node = new TemplateNode(name);
        node.setValueType(ValueType.FIXED);
        node.setValue(value);
        return node;
    }

    /** R3: 노드는 대리키 {@code TEMPLATE_ID} 로 매달리므로 이름으로 세려면 조인해야 한다. */
    private int nodeCount(String name) {
        Integer value = jdbc.queryForObject(
                "SELECT COUNT(*) FROM XML_TEMPLATE_NODE n"
                        + " JOIN XML_TEMPLATE t ON n.TEMPLATE_ID = t.ID"
                        + " WHERE t.TEMPLATE_NAME = ?",
                Integer.class, name);
        return (value == null) ? 0 : value.intValue();
    }

    private void inTransaction(Runnable action) {
        new TransactionTemplate(txManager).executeWithoutResult(status -> action.run());
    }

    private <T> T inTransactionGet(Supplier<T> action) {
        return new TransactionTemplate(txManager).execute(status -> action.get());
    }
}
