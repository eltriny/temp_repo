package com.xmltemplate.expression;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.xmltemplate.exception.ExpressionException;
import com.xmltemplate.util.expression.BinaryExpr;
import com.xmltemplate.util.expression.CallExpr;
import com.xmltemplate.util.expression.Expr;
import com.xmltemplate.util.expression.ExpressionEvaluator;
import com.xmltemplate.util.expression.ExpressionResolver;
import com.xmltemplate.util.expression.VarExpr;

/**
 * 표현식 AST·렉서 계약 (명세 §4, §5.1) — 구 {@code SelfTest.checkExpressionAst} /
 * {@code checkIndexNotation} / {@code checkLazyEvaluation} 의 파서 부분 이관본.
 *
 * <b>왜 API 테스트로 옮기지 않았나</b>: 여기서 고정하는 것은 <b>AST 의 모양</b>과
 * <b>무엇을 조회하지 않았는가</b>다. 둘 다 HTTP 응답으로는 관찰할 수 없다 —
 * 단축 평가는 "평가되지 않았음"을 봐야 증명되고, 지연 인자는 {@code CallExpr} 이
 * 인자를 값이 아니라 AST 로 들고 있어야 성립한다. 프로브 {@link ExpressionResolver}
 * 로 조회 흔적을 기록해 판정한다.
 *
 * 생성 경로에서 관찰되는 단축 평가(오류가 가려지면 생성이 성공한다)는
 * {@code com.xmltemplate.api.PreviewExpressionApiTest} 가 API 기준으로 덮는다.
 *
 * Spring 컨텍스트 없음 — 엔진은 Spring 을 모른다.
 */
class ExpressionEvaluatorTest {

    /** 조회된 변수·노드 경로의 흔적. 단축 평가는 "조회하지 않았음"으로만 증명된다. */
    private final List<String> touched = new ArrayList<String>();
    private final Map<String, String> data = new HashMap<String, String>();
    private ExpressionEvaluator evaluator;

    @BeforeEach
    void setUp() {
        touched.clear();
        data.clear();
        data.put("A", "Y");
        data.put("B", "Y");
        evaluator = new ExpressionEvaluator(new ExpressionResolver() {
            @Override
            public String resolveNodePath(String path) {
                touched.add("path:" + path);
                return "";
            }

            @Override
            public String resolveVariable(String name) {
                touched.add(name);
                return data.get(name);
            }
        });
    }

    /* ================================================================== */
    /* 단축 평가 — 평가되지 않은 가지는 조회 흔적이 없어야 한다                 */
    /* ================================================================== */

    @Nested
    @DisplayName("단축 평가 (§4)")
    class ShortCircuit {

        @Test
        @DisplayName("'||' 왼쪽이 참이면 오른쪽을 평가하지 않는다")
        void orSkipsRight() {
            assertTrue(evaluator.evaluateCondition("{A} == 'Y' || {B} == 'Y'"));
            assertFalse(touched.contains("B"), "오른쪽 피연산자를 조회했다: " + touched);
        }

        @Test
        @DisplayName("'&&' 왼쪽이 거짓이면 오른쪽을 평가하지 않는다")
        void andSkipsRight() {
            assertFalse(evaluator.evaluateCondition("{A} == 'N' && {B} == 'Y'"));
            assertFalse(touched.contains("B"), "오른쪽 피연산자를 조회했다: " + touched);
        }

        @Test
        @DisplayName("삼항: 선택되지 않은 분기를 평가하지 않는다")
        void ternarySkipsUnselectedBranch() {
            assertEquals("yes", evaluator.evaluate("{A} == 'Y' ? 'yes' : {B}"));
            assertFalse(touched.contains("B"), "선택되지 않은 분기를 조회했다: " + touched);
        }
    }

    /* ================================================================== */
    /* AST — 파싱과 평가의 분리로 확보한 성질                                 */
    /* ================================================================== */

    @Nested
    @DisplayName("AST 구조")
    class Ast {

        @Test
        @DisplayName("AST 를 미리 파싱해 두고 재평가할 수 있다")
        void parsedAstIsReusable() {
            Expr ast = ExpressionEvaluator.parse("{A} == 'Y'");
            assertInstanceOf(BinaryExpr.class, ast);
            assertTrue(evaluator.evaluateCondition(ast));
        }

        @Test
        @DisplayName("AST 순회: Binary + Var + Literal = 3 노드")
        void flattenVisitsEveryNode() {
            assertEquals(3, ExpressionEvaluator.parse("{A} == 'Y'").flatten().size());
        }

        @Test
        @DisplayName("파싱 오류 메시지에 식 안의 위치가 포함된다")
        void syntaxErrorCarriesPosition() {
            ExpressionException thrown = assertThrows(
                    ExpressionException.class,
                    () -> ExpressionEvaluator.parse("{A} == "));
            assertTrue(thrown.getMessage().contains("위치"),
                    "위치 정보가 없다: " + thrown.getMessage());
        }

        /**
         * COUNT/SUM 은 인자를 <b>값이 아니라 이름</b>으로 받는 특수형식이다.
         * 인자를 평가해 버리면 {@code COUNT({X})} 가 "X 의 값을 센다"가 되어 의미가 뒤집힌다.
         */
        @Test
        @DisplayName("COUNT 인자를 평가하지 않고 {변수} AST 그대로 보관한다")
        void functionArgumentStaysUnevaluated() {
            Expr parsed = ExpressionEvaluator.parse("COUNT({BOOK_NAME}) > 1");
            BinaryExpr binary = assertInstanceOf(BinaryExpr.class, parsed);
            CallExpr call = assertInstanceOf(CallExpr.class, binary.getLeft());

            assertEquals("COUNT", call.getName());
            VarExpr argument = assertInstanceOf(VarExpr.class, call.getArgument());
            assertEquals("BOOK_NAME", argument.getName());
        }

        @Test
        @DisplayName("함수 의미 미구현 시 명확한 오류 (인자는 값으로 조회되지 않음)")
        void unsupportedFunctionFailsWithoutTouchingArgument() {
            Expr countExpr = ExpressionEvaluator.parse("COUNT({BOOK_NAME}) > 1");
            assertThrows(ExpressionException.class,
                    () -> evaluator.evaluate(countExpr));
            assertFalse(touched.contains("BOOK_NAME"),
                    "미구현 함수가 인자를 값으로 조회했다: " + touched);
        }
    }

    /* ================================================================== */
    /* 인덱스 표기 분해 (명세 §4 렉서 전략, §5.1)                             */
    /* ================================================================== */

    @Nested
    @DisplayName("인덱스 표기 분해")
    class IndexNotation {

        @Test
        @DisplayName("인덱스 표기 없는 변수는 분해 전후가 동일")
        void plainVariableUnchanged() {
            VarExpr plain = variableOf("{ITEM_NAME}");
            assertEquals("ITEM_NAME", plain.getName());
            assertEquals("ITEM_NAME", plain.getBaseName());
            assertFalse(plain.hasIndexRefs());
        }

        /** 이름에 '_' 가 흔하므로 구분자를 '_' 하나로 잡으면 경계가 모호해진다. */
        @Test
        @DisplayName("'_[N' 최장일치 우선 스캔: 이름에 '_' 가 있어도 경계가 결정된다")
        void longestMatchResolvesAmbiguity() {
            assertEquals("PARAM_FILTER_ITEM", variableOf("{PARAM_FILTER_ITEM_[N1]_[N2]}").getBaseName());
        }

        @Test
        @DisplayName("인덱스 참조는 왼쪽부터 바깥 반복 순서로 보관된다 ([N1], [N2])")
        void indexRefsAreOuterToInner() {
            List<Integer> refs = variableOf("{PARAM_FILTER_ITEM_[N1]_[N2]}").getIndexRefs();
            assertEquals(2, refs.size());
            assertEquals(1, refs.get(0).intValue());
            assertEquals(2, refs.get(1).intValue());
        }

        @Test
        @DisplayName("getName() 은 중괄호 안 원문을 그대로 유지한다")
        void nameKeepsRawText() {
            assertEquals("PARAM_FILTER_ITEM_[N1]_[N2]",
                    variableOf("{PARAM_FILTER_ITEM_[N1]_[N2]}").getName());
        }

        @Test
        @DisplayName("[N] 축약형은 SHORTHAND_LEVEL 로 구분된다")
        void shorthandUsesSentinelLevel() {
            VarExpr shorthand = variableOf("{BOOK_PRICE_[N]}");
            assertEquals(1, shorthand.getIndexRefs().size());
            assertEquals(VarExpr.SHORTHAND_LEVEL, shorthand.getIndexRefs().get(0).intValue());
        }

        @Test
        @DisplayName("[N] 축약형도 기준 이름을 분리한다")
        void shorthandSplitsBaseName() {
            assertEquals("BOOK_PRICE", variableOf("{BOOK_PRICE_[N]}").getBaseName());
        }

        /** '_[N' 3글자가 아니면 인덱스가 아니다 — 대괄호는 이름의 일부로 남는다. */
        @Test
        @DisplayName("'_[N' 이 아닌 대괄호는 이름의 일부로 남는다")
        void bracketsWithoutUnderscoreAreName() {
            VarExpr brackets = variableOf("{A[B]}");
            assertEquals("A[B]", brackets.getBaseName());
            assertFalse(brackets.hasIndexRefs());
        }
    }

    /* ================================================================== */
    /* 렉서 거부 규칙 — 조용한 빈 값 금지                                     */
    /* ================================================================== */

    /**
     * {@code '_[N'} 으로 인덱스 표기를 열었으면 <b>반드시 올바르게 닫혀야 한다</b>.
     * 어긋난 표기를 평범한 이름으로 흘려보내면 존재하지 않는 키를 조회해 조용히 빈 값이
     * 되고, 사용자는 "왜 이 변수만 안 나오지"를 추적할 단서가 없다.
     */
    @ParameterizedTest(name = "{0}")
    @ValueSource(strings = {
        "{X_[N0]} == '1'",          // 레벨은 1부터
        "{X_[N1]tail} == '1'",      // 인덱스 표기 뒤 잔여 문자
        "{X_[N1} == '1'",           // 닫히지 않은 인덱스 참조
        "{A_[NOTE]} == '1'",        // '_[N' 뒤가 레벨 숫자가 아님
        "{A_[N1]_B} == '1'",        // 인덱스 표기 뒤에 이름이 이어짐
        "{A_[N1} == '1'",           // 닫히지 않은 인덱스 참조 (다른 기준 이름으로도 동일)
        "{A_[N0]} == '1'",          // 레벨 0
        "{_[N1]} == '1'",           // 기준 이름 없음 — 조합할 키를 만들 수 없다
        "COUNT(PARAM_FILTER_ITEM) > 0",  // 중괄호 없는 함수 인자 (명세 §6.1)
        "TOTAL({X})",               // 알 수 없는 함수 이름
    })
    @DisplayName("렉서·파서 거부 규칙")
    void parseRejected(String expression) {
        assertThrows(ExpressionException.class,
                () -> ExpressionEvaluator.parse(expression),
                "거부되어야 할 식이 통과했다: " + expression);
    }

    /** 과잉 차단 대조군 — 이 셋이 막히면 평범한 이름과 노드 경로를 쓸 수 없게 된다. */
    @ParameterizedTest(name = "{0}")
    @ValueSource(strings = {
        "{A_NOTE} == '1'",                 // '_[N' 이 아니면 평범한 변수명
        "{A[N1]} == '1'",                  // '_' 없는 대괄호는 이름의 일부
        "EXISTS(catalog.book.price)",      // EXISTS 는 노드 경로 인자 허용 (§6.3)
    })
    @DisplayName("렉서 거부 규칙의 대조군 (과잉 차단 방지)")
    void parseAccepted(String expression) {
        ExpressionEvaluator.parse(expression);
    }

    /* ---------------- helpers ---------------- */

    /** 식에서 첫 번째 변수 노드를 꺼낸다. */
    private static VarExpr variableOf(String expression) {
        for (Expr node : ExpressionEvaluator.parse(expression).flatten()) {
            if (node instanceof VarExpr) {
                return (VarExpr) node;
            }
        }
        throw new IllegalStateException("변수를 찾을 수 없습니다: " + expression);
    }
}
