package com.xmltemplate.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.function.Supplier;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.xmltemplate.api.ApiTestSupport;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.repository.TemplateStore;

/**
 * 엔티티 ↔ 컬럼 매핑의 <b>실측</b> 계약.
 *
 * 여기서 고정하는 것은 전부 "설정 한 줄이 어긋나면 조용히 잘못되는" 항목이다 —
 * enum 관대 복원, 큰 텍스트 컬럼의 실제 용량, 시각 문자열 형식, 한글 인코딩.
 * API 테스트는 짧은 ASCII 값만 쓰므로 이 중 어느 것도 건드리지 않는다.
 *
 * 드라이버를 2.7.12 에서 3.5.6 으로 올린 전환의 검증 항목이기도 하다.
 */
class PersistenceMappingTest extends ApiTestSupport {

    @Autowired
    private TemplateStore store;

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private PlatformTransactionManager txManager;

    /* ================================================================== */
    /* ① enum 관대 복원 — 미지 값이 조회 전체를 죽이지 않는다                   */
    /* ================================================================== */

    /**
     * {@code @Enumerated(EnumType.STRING)} 은 DB 에 알 수 없는 값이 있으면 예외를 던지고
     * <b>조회 전체가 실패</b>한다. 기존 운영 DB 에는 구 문법 시절의 데이터나 손으로 넣은 행이
     * 남아 있을 수 있고, 그때 목록/조회가 통째로 죽으면 <b>화면에서 그 템플릿을 지울 수조차
     * 없다</b>. {@code AttributeConverter} 로 관대 복원(미지 값 → FIXED / STRING)을 유지한다.
     *
     * 오타 {@code 'FUCNTION'} 은 가공의 예가 아니다 — 이런 값이 들어가는 경로가 실제로 있었다.
     */
    @Test
    @DisplayName("DB 의 미지 INPUT_TYPE 은 FIXED 로, 미지 INPUT_DATA_TYPE 은 STRING 으로 복원된다")
    void unknownEnumValuesFallBackLeniently() {
        insertMaster("legacy-enum");
        insertRootNode("legacy-enum", "FUCNTION", "DECIMAL");

        TemplateNode loaded = inTransactionGet(() -> store.load("legacy-enum"));

        assertNotNull(loaded, "미지 enum 값 때문에 조회가 실패했다");
        assertEquals(ValueType.FIXED, loaded.getValueType(),
                "미지 INPUT_TYPE 이 FIXED 로 복원되지 않았다");
        assertEquals(ValueDataType.STRING, loaded.getValueDataType(),
                "미지 INPUT_DATA_TYPE 이 STRING 으로 복원되지 않았다");
    }

    /** 목록 조회도 함께 살아 있어야 한다 — 개별 조회만 죽는 상태가 더 고약하다. */
    @Test
    @DisplayName("미지 enum 값이 있어도 목록 조회가 살아 있다")
    void listSurvivesUnknownEnumValues() {
        insertMaster("legacy-enum-list");
        insertRootNode("legacy-enum-list", "fixed", "number");

        assertEquals(1, inTransactionGet(() -> Integer.valueOf(store.listSummaries().size()))
                .intValue(), "목록 조회가 미지 enum 값에 걸렸다");
    }

    /* ================================================================== */
    /* ② TEXT 컬럼 용량 — 조건식은 짧지 않을 수 있다                           */
    /* ================================================================== */

    /**
     * {@code DISPLAY_COND} 는 {@code TEXT} 다.
     *
     * <b>왜 65,535 인가</b>: MariaDB 의 {@code TEXT} 상한은 <b>65,535 바이트</b>다.
     * 명세가 말하는 "64KB"(65,536)는 물리적으로 담기지 않으므로 <b>컬럼의 실제 경계</b>인
     * 65,535 를 쓴다. 여기서 잘리면 {@code sql_mode=STRICT_TRANS_TABLES} 라 예외가 나고,
     * 만약 Hibernate 가 이 컬럼을 {@code varchar(255)} 로 추정해 매핑했다면 그 사실이
     * 이 테스트에서 드러난다.
     */
    @Test
    @DisplayName("TEXT 컬럼(DISPLAY_COND)에 65,535자 조건식이 왕복한다")
    void textColumnHoldsFullSizedCondition() {
        String longCondition = "x".repeat(65535);
        TemplateNode root = fixedNode("root", "v");
        root.setDisplayCondition(longCondition);

        inTransaction(() -> store.save("big-text", root));
        TemplateNode loaded = inTransactionGet(() -> store.load("big-text"));

        assertNotNull(loaded);
        assertEquals(65535, loaded.getDisplayCondition().length(), "조건식 길이가 달라졌다");
        assertEquals(longCondition, loaded.getDisplayCondition(), "조건식 내용이 달라졌다");
    }

    /* ================================================================== */
    /* ③ LONGTEXT 10MB 왕복                                                 */
    /* ================================================================== */

    /**
     * 업로드 상한이 10MB 이므로 {@code SOURCE_XML} 에는 그만한 값이 들어올 수 있다.
     *
     * {@code @Lob} 을 쓰지 않고 평범한 {@code String} 으로 둔 판단(Hibernate 가
     * {@code setString} 을 쓴다)이 실제로 통하는지, 그리고 {@code max_allowed_packet}
     * (실측 16MB)에 걸리지 않는지를 실측한다. 확인은 JPA 1차 캐시를 우회해 <b>DB 에서 직접
     * 다시 읽어</b> 한다 — 캐시된 엔티티를 보면 저장이 안 됐어도 통과한다.
     */
    @Test
    @DisplayName("LONGTEXT(SOURCE_XML)에 10MB 문자열이 왕복한다")
    void longTextColumnHoldsTenMegabytes() {
        int size = 10 * 1024 * 1024;
        String payload = "a".repeat(size);

        inTransaction(() -> store.save("big-source", fixedNode("root", "v")));
        jdbc.update("UPDATE XML_TEMPLATE SET SOURCE_XML = ? WHERE TEMPLATE_NAME = ?",
                payload, "big-source");

        Integer storedLength = jdbc.queryForObject(
                "SELECT CHAR_LENGTH(SOURCE_XML) FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?",
                Integer.class, "big-source");
        assertEquals(Integer.valueOf(size), storedLength, "10MB 가 온전히 저장되지 않았다");

        String reread = jdbc.queryForObject(
                "SELECT SOURCE_XML FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?",
                String.class, "big-source");
        assertNotNull(reread);
        assertEquals(size, reread.length(), "다시 읽은 10MB 의 길이가 다르다");
    }

    /* ================================================================== */
    /* ④ updatedAt ISO 문자열 형식                                          */
    /* ================================================================== */

    /**
     * 계약({@code docs/API_V4_FLAT.md})의 형식은 {@code 2026-08-06T13:02:11} 이다.
     * 소수점 이하 초가 붙으면 프론트 표시가 달라진다.
     */
    @Test
    @DisplayName("updatedAt 에 소수점 이하 초가 붙지 않는다")
    void updatedAtHasNoFractionalSeconds() {
        inTransaction(() -> store.save("stamp", fixedNode("root", "v")));

        String updatedAt = inTransactionGet(() -> store.loadUpdatedAt("stamp"));

        assertNotNull(updatedAt, "updatedAt 이 null 이다");
        assertTrue(updatedAt.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}(:\\d{2})?"),
                "updatedAt 형식이 ISO-8601 초 단위가 아니다: " + updatedAt);
    }

    /**
     * 초가 0이 아닌 시각은 {@code HH:mm:ss} 로 나온다.
     *
     * 시각을 DB 에 직접 심어 <b>결정적으로</b> 관찰한다 — {@code LocalDateTime.now()} 에
     * 의존하면 실행 순간에 따라 결과가 달라져 형식 회귀를 놓친다.
     */
    @Test
    @DisplayName("updatedAt 은 yyyy-MM-ddTHH:mm:ss 형식이다 (초가 0이 아닐 때)")
    void updatedAtUsesIsoSecondsFormat() {
        insertMaster("stamp-11", "2026-08-06 13:02:11");

        assertEquals("2026-08-06T13:02:11",
                inTransactionGet(() -> store.loadUpdatedAt("stamp-11")));
    }

    /**
     * <b>초가 0이면 초 필드가 생략된다 — 계약 문서와 어긋나지만 구 구현과 동일하다.</b>
     *
     * {@code java.time.LocalTime#toString()} 은 초와 나노가 모두 0이면 초 필드를
     * <b>생략</b>한다({@code 2026-08-06T13:00}). 계약 문서
     * ({@code docs/API_V4_FLAT.md})의 예시는 {@code 2026-08-06T13:02:11} 로 항상 초를 포함하므로
     * 이 동작은 문서와 어긋난다.
     *
     * <b>그런데 재작성이 만든 회귀는 아니다.</b> 구 {@code JdbcTemplateRepository.iso()} 도
     * {@code timestamp.toLocalDateTime().withNano(0).toString()} 이라 같은 결과를 냈다
     * (백업 소스 실측). 즉 이전부터 있던 어긋남을 그대로 이어받은 것이고, 고칠지 말지는
     * 계약 소유자의 판단이다.
     *
     * 그래서 여기서는 <b>현행 동작을 고정</b>한다. 누군가 형식을 바꾸면 이 테스트가 실패해
     * "의식적인 계약 변경"이 되도록 만드는 것이 목적이다. 60초에 1초꼴로만 나타나므로
     * {@code LocalDateTime.now()} 에 의존해서는 절대 관찰되지 않는다 — 시각을 심어 고정한다.
     *
     * 고치기로 결정되면 한 줄이다:
     * {@code updatedAt.truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)}
     * 가 아니라(이것도 초를 생략한다) 명시적 패턴
     * {@code DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")} 를 써야 한다.
     */
    @Test
    @DisplayName("초가 0인 시각은 초 필드가 생략된다 (구 구현과 동일 — 계약 문서와는 어긋남)")
    void updatedAtOmitsSecondsFieldAtZeroSeconds() {
        insertMaster("stamp-00", "2026-08-06 13:00:00");

        assertEquals("2026-08-06T13:00",
                inTransactionGet(() -> store.loadUpdatedAt("stamp-00")));
    }

    /* ================================================================== */
    /* ⑤ 한글 왕복                                                          */
    /* ================================================================== */

    /**
     * 컬럼은 {@code utf8mb4} 이고 JVM 은 UTF-16 이다. 커넥션 문자셋이 어긋나면 한글이
     * {@code ???} 가 되거나 길이가 바이트 수로 잘린다. 템플릿 이름(PK)·노드 이름·값·조건식
     * 전부에서 본다 — 템플릿 이름은 {@code VARCHAR(100)} PK 라 잘리면 조회 키가 깨진다.
     */
    @Test
    @DisplayName("한글이 템플릿 이름·노드 이름·값·조건식에서 온전히 왕복한다")
    void koreanTextSurvivesRoundTrip() {
        TemplateNode root = fixedNode("주문서", "주문번호: 가나다라마바사 ①②③");
        root.setDisplayCondition("한글조건");
        root.addChild(fixedNode("배송지", "서울특별시 강남구"));

        inTransaction(() -> store.save("한글템플릿", root));
        TemplateNode loaded = inTransactionGet(() -> store.load("한글템플릿"));

        assertNotNull(loaded, "한글 이름의 템플릿을 로드하지 못했다");
        assertEquals("주문서", loaded.getName());
        assertEquals("주문번호: 가나다라마바사 ①②③", loaded.getValue());
        assertEquals("한글조건", loaded.getDisplayCondition());
        assertEquals("배송지", loaded.getChildren().get(0).getName());
        assertEquals("서울특별시 강남구", loaded.getChildren().get(0).getValue());

        /*
         * 문자 수로 저장됐는지 — 바이트 수로 잘렸다면 여기서 드러난다.
         *
         * R3: 루트를 "NODE_SN = 1" 로 지목할 수 없다(전역 시퀀스라 값이 계속 커진다).
         * 루트의 정의는 <b>PARENT_SN IS NULL</b> 이므로 그것으로 찾는다.
         */
        Integer valueLength = jdbc.queryForObject(
                "SELECT CHAR_LENGTH(n.INPUT_VALUE) FROM XML_TEMPLATE_NODE n"
                        + " JOIN XML_TEMPLATE t ON n.TEMPLATE_ID = t.ID"
                        + " WHERE t.TEMPLATE_NAME = ? AND n.PARENT_SN IS NULL",
                Integer.class, "한글템플릿");
        assertEquals(Integer.valueOf("주문번호: 가나다라마바사 ①②③".length()), valueLength);
    }

    /* ---------------- helpers ---------------- */

    private static TemplateNode fixedNode(String name, String value) {
        TemplateNode node = new TemplateNode(name);
        node.setValueType(ValueType.FIXED);
        node.setValue(value);
        return node;
    }

    private void insertMaster(String name) {
        insertMaster(name, "2026-08-06 13:02:11");
    }

    /**
     * 마스터 행을 직접 심는다.
     *
     * <b>R3</b>: {@code ID} 는 대리키이고 DB 기본값이 없다(시퀀스는 Hibernate 가 부른다).
     * 손으로 넣을 때는 같은 시퀀스에서 값을 받아야 한다 — 임의의 상수를 쓰면 나중에
     * Hibernate 가 발급한 값과 충돌할 수 있다. {@code INCREMENT BY 50} 이라 {@code NEXTVAL}
     * 한 번이 블록 하나를 통째로 소비하지만, 테스트에서 소비되는 양은 무시할 수 있다.
     */
    private void insertMaster(String name, String updatedAt) {
        jdbc.update("INSERT INTO XML_TEMPLATE (ID, TEMPLATE_NAME, UPDATED_AT, SOURCE_XML)"
                + " VALUES (NEXTVAL(SEQ_XML_TEMPLATE), ?, ?, NULL)", name, updatedAt);
    }

    /**
     * 루트 노드 행 하나를 직접 심는다 — enum 컬럼에 <b>임의의 문자열</b>을 넣기 위한 통로다.
     * 엔티티를 거치면 컨버터가 정상 값으로 바꿔 버려 관대 복원을 시험할 수 없다.
     */
    private void insertRootNode(String templateName, String inputType, String inputDataType) {
        jdbc.update("INSERT INTO XML_TEMPLATE_NODE"
                + " (NODE_SN, TEMPLATE_ID, NODE_NAME, PARENT_SN, INPUT_TYPE, INPUT_VALUE,"
                + "  INPUT_DATA_TYPE, DISPLAY_COND, REPEAT_COND, REPEAT_COUNT_COND)"
                + " VALUES (NEXTVAL(SEQ_XML_TEMPLATE_NODE),"
                + "  (SELECT ID FROM XML_TEMPLATE WHERE TEMPLATE_NAME = ?),"
                + "  'root', NULL, ?, 'v', ?, '', '', '')",
                templateName, inputType, inputDataType);
    }

    private void inTransaction(Runnable action) {
        new TransactionTemplate(txManager).executeWithoutResult(status -> action.run());
    }

    private <T> T inTransactionGet(Supplier<T> action) {
        return new TransactionTemplate(txManager).execute(status -> action.get());
    }
}
