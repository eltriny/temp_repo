package com.xmltemplate.util.template;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import com.xmltemplate.dto.NodeDto;
import com.xmltemplate.dto.StructureImportResult;
import com.xmltemplate.dto.TemplateDto;
import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.exception.GeneralAttributeRemovedException;
import com.xmltemplate.exception.InvalidRequestException;
import com.xmltemplate.exception.MappingException;
import com.xmltemplate.exception.NodeListStructureException;
import com.xmltemplate.util.xml.SecureXml;

/**
 * 평면 노드 목록 ↔ 도메인 트리 변환 (R4) — {@link TemplateEntityMapperTest} 와 같은 위치·같은 성격.
 *
 * <b>왜 Spring 없이 도는가</b>: 트리 조립은 이 시스템에서 <b>조용히 틀리기 가장 쉬운 로직</b>이라
 * (부모 순서·고아 참조·루트 중복) 저장소나 웹 계층 없이 단독 검증할 수 있어야 한다. 같은 근거가
 * {@code TemplateEntityMapper} 클래스 주석에 이미 적혀 있다.
 *
 * <h3>API 통합 테스트와의 분업</h3>
 * 여기서는 <b>규칙 하나하나</b>를 최소 입력으로 고정한다. HTTP 상태·응답 형태·저장 왕복은
 * {@code api.FlatNodeContractApiTest} 가 덮는다. 규칙을 API 테스트로만 덮으면 실패했을 때
 * "매퍼가 틀렸나 컨트롤러가 틀렸나"를 가릴 수 없다.
 */
class TemplateMapperTest {

    /* ================================================================== */
    /* T-B1 · 왕복 항등                                                     */
    /* ================================================================== */

    /**
     * <b>{@code toString()} 비교는 금지다.</b> {@link TemplateNode} 에는 equals/hashCode 가 없고
     * {@code toString()} 은 경로만 찍으므로({@code "TemplateNode[ORDER.HEADER]"}) <b>값 회귀를
     * 전혀 잡지 못한다</b> — 이름만 같으면 통과한다. 그래서 필드별 재귀 비교 헬퍼를 테스트 쪽에
     * 둔다.
     */
    @Test
    @DisplayName("T-B1: 데모 트리 → toNodeList → toModel 왕복이 필드까지 동일하다")
    void roundTripPreservesEveryField() {
        TemplateNode original = demoTree();

        TemplateNode restored = TemplateMapper.toModel(TemplateMapper.toNodeList(original));

        assertTreeEquals(original, restored, "ORDER");
    }

    /** 대조군 — 헬퍼가 실제로 값 차이를 잡는지. 이게 없으면 위 단언이 항상 통과해도 알 수 없다. */
    @Test
    @DisplayName("T-B1(대조군): 값이 한 글자만 달라도 비교 헬퍼가 잡는다")
    void comparisonHelperDetectsValueDrift() {
        TemplateNode a = demoTree();
        TemplateNode b = demoTree();
        b.getChildren().get(0).getChildren().get(0).setValue("{ORDER_NO_CHANGED}");

        assertThrows(AssertionError.class, () -> assertTreeEquals(a, b, "ORDER"));
    }

    /* ================================================================== */
    /* T-B2 · T-B3 — 평면화의 불변식                                         */
    /* ================================================================== */

    @Test
    @DisplayName("T-B2: toNodeList 는 sn=인덱스+1, parentSn<sn, DFS 전위를 만족한다")
    void flatteningSatisfiesInvariants() {
        List<NodeDto> nodes = TemplateMapper.toNodeList(demoTree());

        assertInvariants(nodes);
        /* 계약 §8(부록)의 데모 표와 정확히 같은 순서여야 한다 — 형제 순서 보존까지 본다 */
        assertEquals(Arrays.asList("ORDER", "HEADER", "ORDER-NO", "ORDER-TYPE-NAME", "MEMO",
                        "ITEMS", "ITEM", "SEQ", "NAME", "PRICE", "DOMESTIC-ONLY"),
                namesOf(nodes));
        assertEquals(Arrays.asList(null, 1, 2, 2, 2, 1, 6, 7, 7, 7, 1), parentSnsOf(nodes));
    }

    /**
     * 루트의 {@code parentSn} 은 <b>null</b> 이다 — 직렬화 시 {@code non_null} 정책이 키를
     * 통째로 생략한다. {@code 0} 같은 매직 넘버로 채우면 프론트가 "0번 노드"를 찾게 된다.
     */
    @Test
    @DisplayName("T-B3: 루트의 parentSn 은 null (직렬화 시 키 생략)")
    void rootHasNoParentSn() {
        List<NodeDto> nodes = TemplateMapper.toNodeList(demoTree());

        assertNull(nodes.get(0).parentSn);
        assertEquals(Integer.valueOf(1), nodes.get(0).sn);
    }

    /**
     * T-B4 — <b>임포트 경로가 구조 검증을 건너뛰는 근거</b>를 테스트로 고정한다.
     *
     * 설계는 "서버가 자기 도메인 트리에서 목록을 만드니 불변식이 구성적으로 성립한다"고 주장하며
     * 임포트에 구조 검증을 걸지 않았다. 주장으로만 두면 파서가 바뀌었을 때 조용히 무너진다.
     */
    @Test
    @DisplayName("T-B4: 임포트 파서가 만든 트리를 평면화해도 (I1)(I2)가 성립한다")
    void importedTreeSatisfiesInvariants() {
        String structureXml = "<Request><Header><ApiKey>{K}</ApiKey></Header>"
                + "<Parameters><Filters><Filter repeatCountExpr=\"COUNT({C})\">"
                + "<Category>{C_[N1]}</Category></Filter></Filters></Parameters></Request>";
        StructureImportResult parsed = StructureTemplateParser.parse(
                new ByteArrayInputStream(structureXml.getBytes(StandardCharsets.UTF_8)), "UTF-8");

        List<NodeDto> nodes = TemplateMapper.toNodeList(parsed.getRoot());

        assertInvariants(nodes);
        /* 되조립까지 되어야 "검증을 건너뛰어도 안전하다"가 성립한다 */
        assertTreeEquals(parsed.getRoot(), TemplateMapper.toModel(nodes), "Request");
    }

    /* ================================================================== */
    /* T-B5 ~ T-B9 — 구조 검증                                              */
    /* ================================================================== */

    @Nested
    @DisplayName("구조 검증 (V3~V6)")
    class Structure {

        @Test
        @DisplayName("T-B5: sn 누락 / 건너뜀 / 중복 / 0 은 모두 NODE_SN_SEQUENCE")
        void snSequenceViolations() {
            assertCode(NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(null, null, "R")));                       // 누락
            assertCode(NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(1, null, "R"), node(3, 1, "A")));         // 건너뜀
            assertCode(NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(1, null, "R"), node(1, 1, "A")));         // 중복
            assertCode(NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(0, null, "R")));                          // 0
            assertCode(NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(-1, null, "R")));                         // 음수
        }

        @Test
        @DisplayName("T-B5: 메시지가 몇 번째 노드인지와 기대값을 함께 싣는다")
        void snSequenceMessageCarriesPosition() {
            NodeListStructureException e = assertCode(
                    NodeListStructureException.NODE_SN_SEQUENCE,
                    list(node(1, null, "R"), node(7, 1, "A")));

            assertTrue(e.getMessage().contains("sn=7"), e.getMessage());
            assertTrue(e.getMessage().contains("기대값 2"), e.getMessage());
        }

        @Test
        @DisplayName("T-B6: parentSn 없는 노드가 2개면 MULTIPLE_ROOTS (두 sn 을 모두 싣는다)")
        void multipleRoots() {
            NodeListStructureException e = assertCode(NodeListStructureException.MULTIPLE_ROOTS,
                    list(node(1, null, "R"), node(2, 1, "A"), node(3, null, "R2")));
            assertTrue(e.getMessage().contains("sn=1"), e.getMessage());
            assertTrue(e.getMessage().contains("sn=3"), e.getMessage());
        }

        /**
         * T-B6 — "루트가 없다"({@code NO_ROOT_NODE})는 <b>도달할 수 없는 상태</b>다.
         *
         * (I1) 이 첫 노드의 sn 을 1로 못박고 (I2) 가 {@code parentSn < sn} 을 요구하므로,
         * sn=1 이 부모를 가지려면 {@code parentSn < 1} 이어야 하는데 그건 범위 밖이다.
         * 즉 <b>"루트는 목록의 맨 앞"이 파생 정리로 따라온다</b>.
         *
         * 그 사실을 여기서 고정한다 — sn=1 에 어떤 parentSn 을 넣어도 루트가 사라지는 것이
         * 아니라 <b>다른 코드로</b> 걸린다. 이 성질이 무너지면 NO_ROOT_NODE 분기가 살아나며,
         * 그때는 이 테스트가 먼저 실패해 알려 준다.
         */
        @Test
        @DisplayName("T-B6: sn=1 은 반드시 루트다 (NO_ROOT_NODE 는 도달 불가 — 파생 정리)")
        void firstNodeIsAlwaysRoot() {
            assertCode(NodeListStructureException.ORPHAN_NODE, list(node(1, 0, "R")));
            assertCode(NodeListStructureException.PARENT_AFTER_CHILD,
                    list(node(1, 1, "R")));
            assertCode(NodeListStructureException.ORPHAN_NODE, list(node(1, -5, "R")));

            /* 빈 목록은 NO_ROOT_NODE 가 아니라 V1 이 먼저 잡는다 */
            InvalidRequestException e = assertThrows(InvalidRequestException.class,
                    () -> TemplateMapper.toModel(new ArrayList<NodeDto>()));
            assertTrue(e.getMessage().contains("nodes"), e.getMessage());
        }

        @Test
        @DisplayName("T-B7: 부모 후행과 자기참조는 둘 다 PARENT_AFTER_CHILD")
        void parentAfterChild() {
            /* 부모가 뒤에 있다 (범위 안) */
            assertCode(NodeListStructureException.PARENT_AFTER_CHILD,
                    list(node(1, null, "R"), node(2, 3, "A"), node(3, 1, "B")));
            /* 자기참조 */
            assertCode(NodeListStructureException.PARENT_AFTER_CHILD,
                    list(node(1, null, "R"), node(2, 2, "A")));
        }

        @Test
        @DisplayName("T-B8: 범위 밖 parentSn 은 ORPHAN_NODE (노드 수를 메시지에 싣는다)")
        void orphanNode() {
            NodeListStructureException e = assertCode(NodeListStructureException.ORPHAN_NODE,
                    list(node(1, null, "R"), node(2, 1, "A"), node(3, 999, "B")));
            assertTrue(e.getMessage().contains("999"), e.getMessage());
            assertTrue(e.getMessage().contains("노드 수 3"), e.getMessage());

            /* parentSn = 0 도 범위 밖이다 — 0 은 "부모 없음"의 매직 넘버가 아니다 */
            assertCode(NodeListStructureException.ORPHAN_NODE,
                    list(node(1, null, "R"), node(2, 0, "A")));
        }

        /**
         * T-B9 — <b>순환 탐지 코드를 두지 않는 근거</b>를 고정한다.
         *
         * 순환은 반드시 "뒤를 참조하는 간선"을 포함하는데 V5 가 그것을 금지하므로 표현 자체가
         * 불가능하다. 이 테스트가 없으면 다음 사람이 "순환 검사가 빠졌다"고 판단해 절대 실행되지
         * 않는 죽은 분기를 다시 넣는다.
         */
        @Test
        @DisplayName("T-B9: 순환은 표현 자체가 불가능하다 (뒤를 보는 간선이 전부 V5 에서 걸린다)")
        void cyclesAreUnrepresentable() {
            /* A→B→C→A 를 만들려면 어느 한 간선은 반드시 자기보다 뒤를 가리켜야 한다 */
            for (int badParent = 2; badParent <= 4; badParent++) {
                List<NodeDto> nodes = list(node(1, null, "R"), node(2, 1, "A"),
                        node(3, 2, "B"), node(4, 3, "C"));
                nodes.get(1).parentSn = badParent;   // sn=2 가 뒤(또는 자기)를 본다
                assertCode(NodeListStructureException.PARENT_AFTER_CHILD, nodes);
            }
        }
    }

    /* ================================================================== */
    /* T-B10 ~ T-B11 — 상한                                                 */
    /* ================================================================== */

    @Nested
    @DisplayName("상한 (V2·V7)")
    class Limits {

        @Test
        @DisplayName("T-B10: 깊이 50 은 통과, 51 은 400")
        void depthLimit() {
            assertNotNull(TemplateMapper.toModel(chain(SecureXml.MAX_TREE_DEPTH)));

            InvalidRequestException e = assertThrows(InvalidRequestException.class,
                    () -> TemplateMapper.toModel(chain(SecureXml.MAX_TREE_DEPTH + 1)));
            assertTrue(e.getMessage().contains("깊이가 상한을 초과"), e.getMessage());
        }

        /**
         * T-B11 — 노드 수 상한은 <b>조립 전에</b> 걸려야 한다. 10,000개를 다 조립한 뒤 거부하면
         * 상한의 목적(자원 보호)이 반쯤 무너진다.
         *
         * <b>어떻게 "조립 전"을 관찰하는가</b>: 목록의 두 번째 노드에 sn 오류를 심어 둔다.
         * 조립이 먼저 돌면 {@code NODE_SN_SEQUENCE} 가 나오고, 길이 검사가 먼저 돌면
         * 노드 수 메시지가 나온다. 나오는 메시지가 순서를 증언한다.
         */
        @Test
        @DisplayName("T-B11: 노드 수 상한은 조립을 시작하기 전에 걸린다")
        void nodeCountLimitCheckedBeforeAssembly() {
            List<NodeDto> tooMany = wide(SecureXml.MAX_TEMPLATE_NODES + 1);
            tooMany.get(1).sn = Integer.valueOf(999);   // 조립이 돌면 여기서 터진다

            InvalidRequestException e = assertThrows(InvalidRequestException.class,
                    () -> TemplateMapper.toModel(tooMany));
            assertTrue(e.getMessage().contains("노드 수가 상한을 초과"),
                    "조립이 먼저 돌았다 (sn 오류가 먼저 보고됐다): " + e.getMessage());
        }

        @Test
        @DisplayName("T-B11(경계): 정확히 10,000개는 통과한다")
        void nodeCountAtLimitAccepted() {
            assertNotNull(TemplateMapper.toModel(wide(SecureXml.MAX_TEMPLATE_NODES)));
        }

        @Test
        @DisplayName("V1: nodes 가 null 이거나 비어 있으면 400")
        void emptyNodeList() {
            assertThrows(InvalidRequestException.class,
                    () -> TemplateMapper.toModel((List<NodeDto>) null));
            assertThrows(InvalidRequestException.class,
                    () -> TemplateMapper.toModel(new ArrayList<NodeDto>()));
        }
    }

    /* ================================================================== */
    /* T-B12 ~ T-B15 — tombstone 과 값 검증                                  */
    /* ================================================================== */

    @Nested
    @DisplayName("tombstone / 값 검증")
    class Tombstones {

        @Test
        @DisplayName("T-B12: TemplateDto.root 가 실려 오면 LEGACY_TREE_PAYLOAD")
        void legacyRootRejected() {
            TemplateDto dto = new TemplateDto();
            dto.root = "무엇이든";        // 타입이 Object 라 형태를 가리지 않는다
            dto.nodes = list(node(1, null, "R"));

            NodeListStructureException e = assertThrows(NodeListStructureException.class,
                    () -> TemplateMapper.toModel(dto));
            assertEquals(NodeListStructureException.LEGACY_TREE_PAYLOAD, e.getCode());
        }

        /**
         * {@code root} 없이 {@code children} 만 남긴 <b>반쯤 고친 클라이언트</b>가 이 갈래다.
         * 막지 않으면 자식이 통째로 사라진 트리가 조용히 저장된다.
         */
        @Test
        @DisplayName("T-B12: NodeDto.children 이 비어 있지 않으면 LEGACY_TREE_PAYLOAD (경로 병기)")
        void legacyChildrenRejected() {
            List<NodeDto> nodes = list(node(1, null, "ORDER"), node(2, 1, "HEADER"));
            nodes.get(1).children = new ArrayList<Object>(Arrays.asList("자식1", "자식2"));

            NodeListStructureException e = assertThrows(NodeListStructureException.class,
                    () -> TemplateMapper.toModel(nodes));
            assertEquals(NodeListStructureException.LEGACY_TREE_PAYLOAD, e.getCode());
            assertTrue(e.getMessage().contains("ORDER.HEADER"),
                    "오류 메시지에 전체 경로가 없다: " + e.getMessage());
        }

        /**
         * T-B12(순서) — 계약 §5.1 의 검사 순서(tombstone V8·V9 → 값 V10·V-NAME)를 고정한다.
         *
         * <b>왜 순서가 계약인가</b>: 평면화를 반쯤 고친 직렬화기는 "이름 없는 노드 + 남아 있는
         * children" 을 함께 만들어 낸다. 두 위반이 동시에 걸릴 때 나가는 안내가
         * "노드 이름이 비어 있습니다"면 개발자는 이름 필드를 채우려 들고 <b>진짜 원인(구 계약
         * 본문)은 그대로 남는다</b>. 어느 쪽이든 400 이지만 <b>고쳐야 할 대상이 다르므로</b>
         * 우선순위를 테스트로 못박는다.
         */
        @Test
        @DisplayName("T-B12(순서): 이름 누락 + children 동시 위반은 LEGACY_TREE_PAYLOAD 가 이긴다")
        void tombstoneWinsOverFieldValueChecks() {
            List<NodeDto> blankNameWithChildren = list(node(1, null, "ORDER"), node(2, 1, ""));
            blankNameWithChildren.get(1).children =
                    new ArrayList<Object>(Arrays.asList("사라질 자식"));

            NodeListStructureException e = assertThrows(NodeListStructureException.class,
                    () -> TemplateMapper.toModel(blankNameWithChildren),
                    "V-NAME 이 먼저 걸렸다 — 계약 §5.1 의 순서와 어긋난다");
            assertEquals(NodeListStructureException.LEGACY_TREE_PAYLOAD, e.getCode());

            /* enum 오타(V10)보다도 tombstone 이 먼저다 */
            List<NodeDto> badEnumWithAttributes = list(node(1, null, "ORDER"), node(2, 1, "A"));
            badEnumWithAttributes.get(1).valueType = "FUCNTION";
            badEnumWithAttributes.get(1).attributes = new ArrayList<Object>(Arrays.asList("id"));

            assertThrows(GeneralAttributeRemovedException.class,
                    () -> TemplateMapper.toModel(badEnumWithAttributes),
                    "V10(enum)이 V9(attributes)보다 먼저 걸렸다");
        }

        /** 대조군 — 위반이 하나뿐일 때는 그 규칙이 그대로 보고된다(순서가 다른 규칙을 삼키지 않는다). */
        @Test
        @DisplayName("T-B12(순서, 대조군): tombstone 이 없으면 V-NAME 이 정상 보고된다")
        void fieldValueChecksStillReportedWithoutTombstone() {
            MappingException e = assertThrows(MappingException.class,
                    () -> TemplateMapper.toModel(list(node(1, null, "ORDER"), node(2, 1, ""))));
            assertTrue(e.getMessage().contains("노드 이름이 비어 있습니다"), e.getMessage());
        }

        @Test
        @DisplayName("T-B13: children 이 빈 배열이거나 null 이면 통과한다 (전환기 클라이언트)")
        void emptyChildrenAccepted() {
            List<NodeDto> empty = list(node(1, null, "R"));
            empty.get(0).children = new ArrayList<Object>();
            assertNotNull(TemplateMapper.toModel(empty));

            List<NodeDto> nullChildren = list(node(1, null, "R"));
            nullChildren.get(0).children = null;
            assertNotNull(TemplateMapper.toModel(nullChildren));
        }

        @Test
        @DisplayName("T-B14: attributes 가 비어 있지 않으면 GENERAL_ATTR_REMOVED (현행 회귀)")
        void generalAttributesRejected() {
            List<NodeDto> nodes = list(node(1, null, "ORDER"), node(2, 1, "ITEM"));
            nodes.get(1).attributes = new ArrayList<Object>(Arrays.asList("id", "lang"));

            GeneralAttributeRemovedException e = assertThrows(
                    GeneralAttributeRemovedException.class,
                    () -> TemplateMapper.toModel(nodes));
            assertTrue(e.getMessage().contains("ORDER.ITEM"), e.getMessage());
            assertTrue(e.getMessage().contains("2개"), e.getMessage());
        }

        @Test
        @DisplayName("T-B15: enum 오타는 조용한 폴백이 아니라 400 (경로 병기)")
        void unknownEnumRejected() {
            List<NodeDto> badType = list(node(1, null, "R"), node(2, 1, "A"));
            badType.get(1).valueType = "FUCNTION";
            MappingException e = assertThrows(MappingException.class,
                    () -> TemplateMapper.toModel(badType));
            assertEquals("BAD_REQUEST", e.getCode());
            assertTrue(e.getMessage().contains("R.A"), e.getMessage());

            List<NodeDto> badDataType = list(node(1, null, "R"));
            badDataType.get(0).valueDataType = "DATE";
            assertThrows(MappingException.class, () -> TemplateMapper.toModel(badDataType));
        }

        /** 빈 값·누락은 <b>기본값</b>이다 — 여기까지 400 을 내면 정상 클라이언트가 막힌다. */
        @Test
        @DisplayName("T-B15(대조군): valueType/valueDataType 누락은 기본값으로 통과")
        void missingEnumFallsBackToDefault() {
            List<NodeDto> nodes = list(node(1, null, "R"));
            nodes.get(0).valueType = null;
            nodes.get(0).valueDataType = "";

            TemplateNode root = TemplateMapper.toModel(nodes);
            assertEquals(ValueType.FIXED, root.getValueType());
            assertEquals(ValueDataType.STRING, root.getValueDataType());
        }

        /**
         * V-NAME (L-5 결정) — 이 검사는 R4 이전에 <b>어디에도 없었다</b>.
         * {@code TemplateValidator} 에 이름 규칙이 없고 {@code XmlGenerator} 가 생성 시점에야
         * 거부했으므로, 이름 없는 노드는 <b>저장은 되는데 생성이 안 되는</b> 상태를 만들 수 있었다.
         */
        @Test
        @DisplayName("V-NAME: 빈 이름은 400 이고 메시지가 sn 과 부모 경로를 싣는다")
        void blankNameRejected() {
            List<NodeDto> nodes = list(node(1, null, "ORDER"), node(2, 1, "HEADER"),
                    node(3, 2, "   "));

            MappingException e = assertThrows(MappingException.class,
                    () -> TemplateMapper.toModel(nodes));
            assertTrue(e.getMessage().contains("sn=3"), e.getMessage());
            assertTrue(e.getMessage().contains("ORDER.HEADER"),
                    "부모 경로가 없다: " + e.getMessage());
        }

        @Test
        @DisplayName("V-NAME: 루트의 빈 이름은 부모 경로를 '(루트)' 로 안내한다")
        void blankRootNameRejected() {
            MappingException e = assertThrows(MappingException.class,
                    () -> TemplateMapper.toModel(list(node(1, null, ""))));
            assertTrue(e.getMessage().contains("(루트)"), e.getMessage());
        }
    }

    /* ================================================================== */
    /* toDto — 조용한 키 생략 금지 (DA #10)                                  */
    /* ================================================================== */

    @Test
    @DisplayName("toDto(name, root=null, …) 은 조용한 빈 응답 대신 IllegalStateException")
    void toDtoRejectsNullRoot() {
        assertThrows(IllegalStateException.class,
                () -> TemplateMapper.toDto("t", null, "2026-08-11T00:00:00"));
    }

    @Test
    @DisplayName("toDto 는 nodes 를 채우고 root 는 null 로 남긴다 (응답에서 키 생략)")
    void toDtoProducesFlatNodes() {
        TemplateDto dto = TemplateMapper.toDto("demo-order", demoTree(), "2026-08-11T00:00:00");

        assertEquals("demo-order", dto.name);
        assertNull(dto.root);
        assertEquals(11, dto.nodes.size());
        assertInvariants(dto.nodes);
    }

    /* ================================================================== */
    /* 비교 · 단언 헬퍼                                                      */
    /* ================================================================== */

    /**
     * 두 도메인 트리를 <b>필드별로</b> 재귀 비교한다.
     *
     * {@code assertEquals(a, b)} 는 {@link TemplateNode} 에 equals 가 없어 참조 비교가 되고,
     * {@code toString()} 비교는 경로만 보므로 값 회귀를 놓친다. 왕복 항등이 이 테스트의
     * 핵심 단언이라 비교 수단을 직접 만든다.
     */
    private static void assertTreeEquals(TemplateNode expected, TemplateNode actual, String path) {
        assertEquals(expected.getName(), actual.getName(), path + ".name");
        assertEquals(expected.getValueType(), actual.getValueType(), path + ".valueType");
        assertEquals(expected.getValue(), actual.getValue(), path + ".value");
        assertEquals(expected.getValueDataType(), actual.getValueDataType(),
                path + ".valueDataType");
        assertEquals(expected.getDisplayCondition(), actual.getDisplayCondition(),
                path + ".displayCondition");
        assertEquals(expected.getRepeatCondition(), actual.getRepeatCondition(),
                path + ".repeatCondition");
        assertEquals(expected.getRepeatCountExpr(), actual.getRepeatCountExpr(),
                path + ".repeatCountExpr");
        assertEquals(expected.getChildren().size(), actual.getChildren().size(),
                path + " 의 자식 수");
        for (int i = 0; i < expected.getChildren().size(); i++) {
            TemplateNode expectedChild = expected.getChildren().get(i);
            assertTreeEquals(expectedChild, actual.getChildren().get(i),
                    path + "." + expectedChild.getName());
        }
    }

    /** (I1) {@code sn == 인덱스 + 1} · (I2) {@code 1 ≤ parentSn < sn} · 루트는 정확히 1개. */
    private static void assertInvariants(List<NodeDto> nodes) {
        int roots = 0;
        for (int i = 0; i < nodes.size(); i++) {
            NodeDto dto = nodes.get(i);
            assertEquals(Integer.valueOf(i + 1), dto.sn, i + "번째 노드의 sn (I1)");
            if (dto.parentSn == null) {
                roots++;
            } else {
                assertTrue(dto.parentSn >= 1 && dto.parentSn < dto.sn,
                        "sn=" + dto.sn + " 의 parentSn=" + dto.parentSn + " 이 (I2) 를 어긴다");
            }
            /* 폐지된 개념은 채우지 않는다 — 응답에서 키가 사라져야 한다 */
            assertNull(dto.children, "sn=" + dto.sn + " 에 children 이 채워져 있다");
            assertNull(dto.attributes, "sn=" + dto.sn + " 에 attributes 가 채워져 있다");
        }
        assertEquals(1, roots, "루트(parentSn 없음)는 정확히 1개여야 한다");
    }

    private static NodeListStructureException assertCode(String expectedCode,
            List<NodeDto> nodes) {
        NodeListStructureException e = assertThrows(NodeListStructureException.class,
                () -> TemplateMapper.toModel(nodes));
        assertEquals(expectedCode, e.getCode(), "오류 코드가 다르다: " + e.getMessage());
        return e;
    }

    /* ================================================================== */
    /* 픽스처                                                               */
    /* ================================================================== */

    private static List<NodeDto> list(NodeDto... nodes) {
        return new ArrayList<NodeDto>(Arrays.asList(nodes));
    }

    private static NodeDto node(Integer sn, Integer parentSn, String name) {
        NodeDto dto = new NodeDto();
        dto.sn = sn;
        dto.parentSn = parentSn;
        dto.name = name;
        return dto;
    }

    /** 깊이 {@code depth} 인 사슬 — {@code parentSn = sn - 1} 이 곧 "한 칸 더 깊다"이다. */
    private static List<NodeDto> chain(int depth) {
        List<NodeDto> nodes = new ArrayList<NodeDto>(depth);
        for (int i = 1; i <= depth; i++) {
            nodes.add(node(i, (i == 1) ? null : i - 1, "L" + i));
        }
        return nodes;
    }

    /** 루트 + 자식 {@code total - 1} 개 (깊이 2). */
    private static List<NodeDto> wide(int total) {
        List<NodeDto> nodes = new ArrayList<NodeDto>(total);
        nodes.add(node(1, null, "R"));
        for (int i = 2; i <= total; i++) {
            nodes.add(node(i, 1, "C" + i));
        }
        return nodes;
    }

    /**
     * 데모 주문 템플릿 — {@code src/test/resources/fixtures/demo-order.json} 및 프론트의
     * {@code buildDemoTemplate} 과 같은 구조. 왕복 항등의 대상이므로 모든 필드 종류
     * (조건식·반복 횟수식·NUMBER 타입)를 하나씩은 쓴다.
     */
    private static TemplateNode demoTree() {
        TemplateNode order = fixed("ORDER", "");

        TemplateNode header = fixed("HEADER", "");
        header.addChild(variable("ORDER-NO", "{ORDER_NO}"));
        TemplateNode typeName = new TemplateNode("ORDER-TYPE-NAME");
        typeName.setValueType(ValueType.FUNCTION);
        typeName.setValue("{ORDER_TYPE} == 'D' ? '국내' : '해외'");
        header.addChild(typeName);
        TemplateNode memo = variable("MEMO", "{MEMO}");
        memo.setDisplayCondition("{MEMO} != NULL");
        header.addChild(memo);
        order.addChild(header);

        TemplateNode items = fixed("ITEMS", "");
        TemplateNode item = fixed("ITEM", "");
        item.setRepeatCountExpr("COUNT({ITEM_NAME})");
        TemplateNode seq = variable("SEQ", "{INDEX}");
        seq.setValueDataType(ValueDataType.NUMBER);
        item.addChild(seq);
        item.addChild(variable("NAME", "{ITEM_NAME_[N]}"));
        TemplateNode price = variable("PRICE", "{ITEM_PRICE_[N]}");
        price.setValueDataType(ValueDataType.NUMBER);
        item.addChild(price);
        items.addChild(item);
        order.addChild(items);

        TemplateNode domestic = fixed("DOMESTIC-ONLY", "국내 전용 항목");
        domestic.setDisplayCondition("ORDER.HEADER.ORDER-TYPE-NAME == '국내'");
        order.addChild(domestic);

        return order;
    }

    private static TemplateNode fixed(String name, String value) {
        TemplateNode node = new TemplateNode(name);
        node.setValueType(ValueType.FIXED);
        node.setValue(value);
        return node;
    }

    private static TemplateNode variable(String name, String value) {
        TemplateNode node = new TemplateNode(name);
        node.setValueType(ValueType.VARIABLE);
        node.setValue(value);
        return node;
    }

    private static List<String> namesOf(List<NodeDto> nodes) {
        List<String> names = new ArrayList<String>(nodes.size());
        for (NodeDto dto : nodes) {
            names.add(dto.name);
        }
        return names;
    }

    private static List<Integer> parentSnsOf(List<NodeDto> nodes) {
        List<Integer> parents = new ArrayList<Integer>(nodes.size());
        for (NodeDto dto : nodes) {
            parents.add(dto.parentSn);
        }
        return parents;
    }
}
