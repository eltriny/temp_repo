package com.xmltemplate.util.template;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.xmltemplate.dto.TemplateNode;
import com.xmltemplate.entity.ValueDataType;
import com.xmltemplate.entity.ValueType;
import com.xmltemplate.entity.XmlTemplateNode;
import com.xmltemplate.exception.RepositoryException;

/**
 * 엔티티 행 ↔ 도메인 트리 변환기의 단위 계약 (R3).
 *
 * <h3>왜 단위 테스트인가</h3>
 * 트리 조립은 이 시스템에서 <b>조용히 틀리기 가장 쉬운 로직</b>이다 — 부모가 자식보다 먼저
 * 나오지 않거나, 부모 참조가 깨졌거나, 루트가 둘이거나. 그런데 이 경계 입력들은 <b>정상적인
 * DB 가 절대 만들어 주지 않는다</b>. 통합 테스트로는 "제대로 저장하면 제대로 읽힌다"까지만
 * 확인할 수 있고, 망가진 데이터를 만나면 어떻게 되는지는 볼 수 없다.
 *
 * 변환기를 {@code TemplateStore} 밖으로 꺼낸 이유가 이것이다. 여기서는 행 목록을 손으로
 * 만들어 <b>고장난 상태를 직접 주입</b>할 수 있다.
 *
 * <h3>Spring 컨텍스트가 없다</h3>
 * {@code util} 은 Spring/Jackson/JPA 를 모르고({@code PackageBoundaryTest}), 이 변환기도
 * 엔티티 <b>클래스</b>만 참조할 뿐 JPA API 를 쓰지 않는다. 그래서 부팅 없이 순수 자바로 돈다.
 */
class TemplateEntityMapperTest {

    private static final Long TEMPLATE_ID = Long.valueOf(7L);

    /* ================================================================== */
    /* toDomain — 행 하나                                                   */
    /* ================================================================== */

    @Test
    @DisplayName("toDomain: 모든 컬럼이 도메인 노드로 전달된다")
    void toDomainCarriesEveryColumn() {
        XmlTemplateNode row = row(100L, "price", Long.valueOf(99L), ValueType.VARIABLE,
                "{PRICE_[N]}", ValueDataType.NUMBER, "{P} != NULL", "", "COUNT({P})");

        TemplateNode node = TemplateEntityMapper.toDomain(row);

        assertEquals("price", node.getName());
        assertEquals(ValueType.VARIABLE, node.getValueType());
        assertEquals("{PRICE_[N]}", node.getValue());
        assertEquals(ValueDataType.NUMBER, node.getValueDataType());
        assertEquals("{P} != NULL", node.getDisplayCondition());
        assertEquals("COUNT({P})", node.getRepeatCountExpr());
        /* 행 하나만 보는 변환이므로 자식은 붙지 않는다 */
        assertTrue(node.getChildren().isEmpty(), "toDomain 이 자식을 만들었다");
    }

    /**
     * DB 의 {@code NULL} 은 빈 문자열로 정규화된다.
     *
     * <b>왜 중요한가</b>: 응답 계약이 "null 금지, 빈 조건식은 {@code \"\"}" 이고, 전역 설정이
     * {@code default-property-inclusion=non_null} 이다. 정규화가 빠지면 그 필드가 응답에서
     * <b>아예 사라지고</b>, 프론트는 "필드가 없는 노드"와 "빈 값인 노드"를 구분하지 못한다.
     */
    @Test
    @DisplayName("toDomain: NULL 인 문자열 컬럼 5개가 모두 빈 문자열로 정규화된다")
    void toDomainNormalizesNullToEmptyString() {
        XmlTemplateNode row = row(100L, null, null, ValueType.FIXED,
                null, ValueDataType.STRING, null, null, null);

        TemplateNode node = TemplateEntityMapper.toDomain(row);

        assertEquals("", node.getName(), "NODE_NAME");
        assertEquals("", node.getValue(), "INPUT_VALUE");
        assertEquals("", node.getDisplayCondition(), "DISPLAY_COND");
        assertEquals("", node.getRepeatCondition(), "REPEAT_COND");
        assertEquals("", node.getRepeatCountExpr(), "REPEAT_COUNT_COND");
    }

    /**
     * enum 컬럼이 {@code NULL} 이어도 조회가 죽지 않는다.
     *
     * 컬럼은 {@code NOT NULL} 이지만 <b>스키마를 우회해 들어온 행</b>(수동 INSERT, 이관 잔재)이
     * 있을 수 있다. 문자열 5개만 정규화하고 enum 두 개를 빠뜨리면 그 행에서 트리 전체가
     * {@code NullPointerException} 으로 무너진다 — 관대 복원({@code ValueTypeConverter})이
     * 지키려는 성질과 같은 것을, 변환기 층에서도 지켜야 한다.
     */
    @Test
    @DisplayName("toDomain: NULL 인 enum 컬럼은 기본값(FIXED / STRING)으로 복원된다")
    void toDomainNormalizesNullEnumsToDefaults() {
        XmlTemplateNode row = row(100L, "n", null, null, "v", null, "", "", "");

        TemplateNode node = TemplateEntityMapper.toDomain(row);

        assertEquals(ValueType.FIXED, node.getValueType(), "INPUT_TYPE");
        assertEquals(ValueDataType.STRING, node.getValueDataType(), "INPUT_DATA_TYPE");
    }

    /**
     * {@code REPEAT_COUNT_COND} 는 정규화에 더해 <b>양끝 공백을 떼어낸다</b>.
     *
     * 반복 횟수식은 그대로 파서에 들어가므로 공백이 붙으면 식 해석이 달라질 수 있다.
     * 다른 필드와 처리가 다른 유일한 지점이라 명시적으로 고정한다.
     */
    @Test
    @DisplayName("toDomain: repeatCountExpr 은 양끝 공백을 떼고 복원된다")
    void toDomainTrimsRepeatCountExpression() {
        XmlTemplateNode row = row(100L, "n", null, ValueType.FIXED, "v",
                ValueDataType.STRING, "", "", "  COUNT({A})  ");

        assertEquals("COUNT({A})", TemplateEntityMapper.toDomain(row).getRepeatCountExpr());
    }

    /* ================================================================== */
    /* toDomainTree — 정상 조립                                             */
    /* ================================================================== */

    @Test
    @DisplayName("toDomainTree: 행이 없으면 null (빈 목록·null 입력 모두)")
    void toDomainTreeReturnsNullForNoRows() {
        assertNull(TemplateEntityMapper.toDomainTree(new ArrayList<XmlTemplateNode>(), "t"));
        assertNull(TemplateEntityMapper.toDomainTree(null, "t"));
    }

    /**
     * 트리:  A ─ B ─ D
     *          └ C
     *
     * 형제 순서(B 다음 C)와 깊이가 모두 보존되어야 한다.
     */
    @Test
    @DisplayName("toDomainTree: DFS 전위 행 목록을 트리로 조립하고 형제 순서를 지킨다")
    void toDomainTreeAssemblesPreorderRows() {
        List<XmlTemplateNode> rows = List.of(
                plain(10L, "A", null),
                plain(11L, "B", Long.valueOf(10L)),
                plain(12L, "D", Long.valueOf(11L)),
                plain(13L, "C", Long.valueOf(10L)));

        TemplateNode root = TemplateEntityMapper.toDomainTree(rows, "t");

        assertNotNull(root);
        assertEquals("A", root.getName());
        assertEquals(List.of("B", "C"), childNames(root), "형제 순서가 바뀌었다");
        assertEquals(List.of("D"), childNames(root.getChildren().get(0)), "손자가 다른 부모에 붙었다");
        assertTrue(root.getChildren().get(1).getChildren().isEmpty(), "C 에 없는 자식이 붙었다");
    }

    /**
     * <b>R3 의 핵심</b>: {@code NODE_SN} 은 전역 시퀀스 값이라 1부터 시작하지도, 연속되지도
     * 않는다. 저장할 때마다 값이 커지고 구간이 비어 있다.
     *
     * 변환기가 SN 을 <b>키로만</b> 쓰고 값의 크기나 연속성에 기대지 않는지 본다. 예컨대
     * 인덱스로 배열에 넣는 구현이었다면 여기서 터진다.
     */
    @Test
    @DisplayName("toDomainTree: NODE_SN 이 1부터가 아니고 띄엄띄엄해도 조립된다")
    void toDomainTreeHandlesSparseGlobalSequenceKeys() {
        List<XmlTemplateNode> rows = List.of(
                plain(4_000_000_051L, "A", null),
                plain(4_000_000_101L, "B", Long.valueOf(4_000_000_051L)),
                plain(9_999_999_999L, "C", Long.valueOf(4_000_000_101L)));

        TemplateNode root = TemplateEntityMapper.toDomainTree(rows, "t");

        assertNotNull(root);
        assertEquals("A", root.getName());
        assertEquals(List.of("B"), childNames(root));
        assertEquals(List.of("C"), childNames(root.getChildren().get(0)));
    }

    /* ================================================================== */
    /* toDomainTree — 고장난 데이터는 조용히 지나가지 않는다                    */
    /* ================================================================== */

    /**
     * 루트가 둘이면 어느 쪽을 반환해도 <b>사용자가 저장한 것과 다른 트리</b>가 된다.
     * 조용히 하나를 고르는 것이 최악이다 — 나머지 절반이 소리 없이 사라진다.
     */
    @Test
    @DisplayName("toDomainTree: 루트가 2개면 거부한다 (조용히 하나를 고르지 않는다)")
    void toDomainTreeRejectsTwoRoots() {
        List<XmlTemplateNode> rows = List.of(
                plain(10L, "A", null),
                plain(11L, "B", null));

        RepositoryException thrown = assertThrows(RepositoryException.class,
                () -> TemplateEntityMapper.toDomainTree(rows, "dup"));
        assertTrue(thrown.getMessage().contains("dup"), "메시지에 템플릿 식별자가 없다: " + thrown);
        assertTrue(thrown.getMessage().contains("루트"), "메시지가 원인을 말하지 않는다: " + thrown);
    }

    /**
     * 모든 행이 부모를 가리키면 트리가 될 수 없다 — 루트 행이 지워졌거나 순환이 생긴 것이다.
     *
     * <b>자기 참조로 재현하는 이유</b>: 변환기는 행을 순회하며 <b>지도에 먼저 넣고</b> 부모를
     * 찾는다. 그래서 "아직 안 나온 부모"를 가리키는 행은 루트 검사에 닿기 전에
     * "존재하지 않는 부모"로 먼저 걸린다(그 경로는 아래 정렬 위반 테스트가 덮는다).
     * 부모 참조가 <b>전부 해소되는데도</b> 루트가 없는 상태를 만들려면 이미 나온 키를
     * 가리켜야 하고, 자기 참조가 그 최소 형태다.
     */
    @Test
    @DisplayName("toDomainTree: 부모 참조는 다 풀리는데 루트가 없으면 거부한다 (순환)")
    void toDomainTreeRejectsMissingRoot() {
        List<XmlTemplateNode> rows = List.of(
                plain(10L, "A", Long.valueOf(10L)),
                plain(11L, "B", Long.valueOf(10L)));

        RepositoryException thrown = assertThrows(RepositoryException.class,
                () -> TemplateEntityMapper.toDomainTree(rows, "noroot"));
        assertTrue(thrown.getMessage().contains("루트"),
                "순환이 루트 없음으로 보고되지 않았다: " + thrown.getMessage());
        assertTrue(thrown.getMessage().contains("noroot"),
                "메시지에 템플릿 식별자가 없다: " + thrown.getMessage());
    }

    /**
     * 부모가 자식보다 <b>뒤에</b> 오면 거부한다.
     *
     * 이것이 이 클래스에서 가장 값진 단언이다. 변환기는 "행이 DFS 전위로 정렬돼 있다"를
     * 전제로 O(n) 단일 패스를 돈다. 그 전제가 깨졌을 때 <b>조용히 잘못 조립하지 않고
     * 실패하는지</b>가 계약이다 — 누군가 {@code ORDER BY NODE_SN} 을 빼거나 정렬을 바꾸면
     * 여기서 드러나야 한다. 통합 테스트로는 이 상태를 만들 수 없다.
     */
    @Test
    @DisplayName("toDomainTree: 정렬이 어긋나 부모가 뒤에 오면 거부한다 (조용히 조립하지 않는다)")
    void toDomainTreeRejectsUnsortedRowsInsteadOfMisassembling() {
        List<XmlTemplateNode> rows = List.of(
                plain(10L, "A", null),
                plain(12L, "D", Long.valueOf(11L)),   /* 부모 B(11) 가 아직 안 나왔다 */
                plain(11L, "B", Long.valueOf(10L)));

        RepositoryException thrown = assertThrows(RepositoryException.class,
                () -> TemplateEntityMapper.toDomainTree(rows, "unsorted"));
        assertTrue(thrown.getMessage().contains("존재하지 않는 부모"),
                "정렬 위반이 다른 오류로 새어 나갔다: " + thrown.getMessage());
        assertTrue(thrown.getMessage().contains("11"),
                "메시지가 어느 부모를 못 찾았는지 말하지 않는다: " + thrown.getMessage());
    }

    /** 삭제되었거나 다른 템플릿에 속한 키를 가리키는 경우 — 위와 같은 방어에 걸린다. */
    @Test
    @DisplayName("toDomainTree: 존재하지 않는 부모를 가리키면 거부한다")
    void toDomainTreeRejectsDanglingParentReference() {
        List<XmlTemplateNode> rows = List.of(
                plain(10L, "A", null),
                plain(11L, "B", Long.valueOf(999L)));

        assertThrows(RepositoryException.class,
                () -> TemplateEntityMapper.toDomainTree(rows, "dangling"));
    }

    /* ================================================================== */
    /* toEntity — 도메인 -> 행                                              */
    /* ================================================================== */

    @Test
    @DisplayName("toEntity: 도메인 필드와 소속·부모 키가 그대로 실린다")
    void toEntityCarriesFieldsAndKeys() {
        TemplateNode node = new TemplateNode("price");
        node.setValueType(ValueType.FUNCTION);
        node.setValue("{A} ? 'y' : 'n'");
        node.setValueDataType(ValueDataType.NUMBER);
        node.setDisplayCondition("{A} != NULL");
        node.setRepeatCountExpr("COUNT({A})");

        XmlTemplateNode row = TemplateEntityMapper.toEntity(node, TEMPLATE_ID, Long.valueOf(42L));

        assertEquals(TEMPLATE_ID, row.getTemplateId());
        assertEquals(Long.valueOf(42L), row.getParentSn());
        assertEquals("price", row.getNodeName());
        assertEquals(ValueType.FUNCTION, row.getInputType());
        assertEquals("{A} ? 'y' : 'n'", row.getInputValue());
        assertEquals(ValueDataType.NUMBER, row.getInputDataType());
        assertEquals("{A} != NULL", row.getDisplayCond());
        assertEquals("COUNT({A})", row.getRepeatCountCond());
    }

    /**
     * 루트의 {@code PARENT_SN} 은 null 이다.
     *
     * 이 값이 0 이나 다른 기본값으로 채워지면 로드가 "존재하지 않는 부모 0 참조"로 실패한다 —
     * 저장은 성공하고 <b>다음 조회에서만</b> 터지는 종류의 고장이다.
     */
    @Test
    @DisplayName("toEntity: 루트의 PARENT_SN 은 null 이다")
    void toEntityLeavesRootParentNull() {
        XmlTemplateNode row = TemplateEntityMapper.toEntity(
                new TemplateNode("root"), TEMPLATE_ID, null);

        assertNull(row.getParentSn(), "루트에 부모 키가 채워졌다");
    }

    /**
     * 변환기는 {@code NODE_SN} 을 채우지 않는다 — 시퀀스가 발급하는 값이다.
     *
     * 변환기가 임의로 채우면 영속성 컨텍스트가 "이미 키가 있다"고 판단해 {@code persist} 대신
     * {@code merge} 경로를 타거나 키 충돌이 난다.
     */
    @Test
    @DisplayName("toEntity: NODE_SN 은 비워 둔다 (시퀀스가 발급한다)")
    void toEntityLeavesNodeSnUnassigned() {
        XmlTemplateNode row = TemplateEntityMapper.toEntity(
                new TemplateNode("root"), TEMPLATE_ID, null);

        assertNull(row.getNodeSn(), "변환기가 NODE_SN 을 임의로 채웠다");
    }

    /* ================================================================== */
    /* 왕복 대칭성                                                          */
    /* ================================================================== */

    /**
     * {@code toEntity → toDomain} 이 원래 노드를 되돌려 준다.
     *
     * <b>왜 개별 필드 단언으로 충분하지 않은가</b>: 두 방향을 따로 보면 <b>양쪽이 같은 방식으로
     * 틀린 경우</b>를 놓친다. 예컨대 두 함수가 {@code displayCondition} 과
     * {@code repeatCountExpr} 을 나란히 맞바꿔 읽으면 각 단언은 통과하고 왕복도 성립하는 것처럼
     * 보인다 — 그래서 <b>서로 다른 값</b>을 넣어 자리가 섞이면 드러나게 한다.
     *
     * 이 대칭성이 깨지면 저장 직후 조회에서 값이 뒤바뀌는데, 저장은 성공하므로 사용자는
     * 한참 뒤에야 알아차린다.
     */
    @Test
    @DisplayName("왕복: toEntity → toDomain 이 원래 노드를 되돌려 준다")
    void entityAndDomainConversionsAreSymmetric() {
        TemplateNode original = new TemplateNode("price");
        original.setValueType(ValueType.VARIABLE);
        original.setValue("값-VALUE");
        original.setValueDataType(ValueDataType.NUMBER);
        original.setDisplayCondition("조건-DISPLAY");
        original.setRepeatCountExpr("반복-REPEAT");

        XmlTemplateNode row = TemplateEntityMapper.toEntity(
                original, TEMPLATE_ID, Long.valueOf(5L));
        TemplateNode back = TemplateEntityMapper.toDomain(row);

        assertEquals(original.getName(), back.getName());
        assertEquals(original.getValueType(), back.getValueType());
        assertEquals(original.getValue(), back.getValue());
        assertEquals(original.getValueDataType(), back.getValueDataType());
        assertEquals(original.getDisplayCondition(), back.getDisplayCondition());
        assertEquals(original.getRepeatCondition(), back.getRepeatCondition());
        assertEquals(original.getRepeatCountExpr(), back.getRepeatCountExpr());
    }

    /**
     * 왕복은 <b>트리 전체</b>에서도 성립한다 — 부모 키를 손으로 이어 붙인 경우.
     *
     * {@code toEntity} 는 노드 하나만 다루므로(부모 키는 영속성 컨텍스트가 발급한다),
     * 트리 왕복은 "키를 이어 붙이는 쪽"이 제대로 하면 성립해야 한다. 여기서는 저장소가 하는
     * 일을 최소한으로 흉내 내어 변환기 쌍이 트리 수준에서도 대칭인지 본다.
     */
    @Test
    @DisplayName("왕복: 트리를 행으로 폈다가 다시 조립하면 같은 트리다")
    void treeSurvivesFlattenAndReassemble() {
        TemplateNode root = new TemplateNode("A");
        TemplateNode b = new TemplateNode("B");
        TemplateNode c = new TemplateNode("C");
        root.addChild(b);
        root.addChild(c);
        b.addChild(new TemplateNode("D"));

        List<XmlTemplateNode> rows = new ArrayList<XmlTemplateNode>();
        flatten(root, null, new long[] { 1000L }, rows);

        TemplateNode back = TemplateEntityMapper.toDomainTree(rows, "t");

        assertNotNull(back);
        assertEquals("A", back.getName());
        assertEquals(List.of("B", "C"), childNames(back));
        assertEquals(List.of("D"), childNames(back.getChildren().get(0)));
        assertTrue(back.getChildren().get(1).getChildren().isEmpty());
    }

    /** 저장소의 DFS persist 를 흉내 낸다 — 키는 증가하는 가짜 시퀀스가 발급한다. */
    private static void flatten(TemplateNode node, Long parentSn, long[] sequence,
            List<XmlTemplateNode> rows) {
        long sn = sequence[0];
        sequence[0] += 50;                       /* allocationSize 처럼 띄엄띄엄 */
        XmlTemplateNode row = TemplateEntityMapper.toEntity(node, TEMPLATE_ID, parentSn);
        assignNodeSn(row, sn);
        rows.add(row);
        for (TemplateNode child : node.getChildren()) {
            flatten(child, Long.valueOf(sn), sequence, rows);
        }
    }

    /* ---------------- helpers ---------------- */

    private static List<String> childNames(TemplateNode parent) {
        List<String> names = new ArrayList<String>();
        for (TemplateNode child : parent.getChildren()) {
            names.add(child.getName());
        }
        return names;
    }

    /** 이름·부모만 다른 최소 행. */
    private static XmlTemplateNode plain(long nodeSn, String name, Long parentSn) {
        return row(nodeSn, name, parentSn, ValueType.FIXED, "", ValueDataType.STRING, "", "", "");
    }

    private static XmlTemplateNode row(long nodeSn, String name, Long parentSn,
            ValueType inputType, String inputValue, ValueDataType inputDataType,
            String displayCond, String repeatCond, String repeatCountCond) {
        XmlTemplateNode row = new XmlTemplateNode(TEMPLATE_ID, name, parentSn, inputType,
                inputValue, inputDataType, displayCond, repeatCond, repeatCountCond);
        assignNodeSn(row, nodeSn);
        return row;
    }

    /**
     * {@code nodeSn} 을 리플렉션으로 심는다.
     *
     * <b>왜 setter 가 없는가</b>: {@code NODE_SN} 은 시퀀스가 발급하는 대리키다. setter 를
     * 두면 애플리케이션 코드가 키를 직접 지정할 길이 열리고, 그것이 바로 이 설계가 막으려는
     * 것이다(옛 복합키 시절의 "앱이 SN 을 부여한다"로 되돌아간다).
     *
     * 그래서 <b>테스트만</b> 리플렉션으로 심는다. 필드 이름이 바뀌면 즉시 실패하도록 예외를
     * 감싸 두었다 — 조용히 건너뛰면 이 클래스의 모든 트리 조립 검증이 무의미해진다.
     */
    private static void assignNodeSn(XmlTemplateNode row, long nodeSn) {
        try {
            Field field = XmlTemplateNode.class.getDeclaredField("nodeSn");
            field.setAccessible(true);
            field.set(row, Long.valueOf(nodeSn));
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(
                    "XmlTemplateNode.nodeSn 을 설정하지 못했다 — 필드 이름이 바뀌었는지 확인하라", e);
        }
    }
}
