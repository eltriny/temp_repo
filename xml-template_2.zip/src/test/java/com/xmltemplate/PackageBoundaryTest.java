package com.xmltemplate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * 패키지 의존 방향의 <b>집행자</b> — 폐기된 {@code ArchitectureBoundaryTest} 의 후신.
 *
 * <b>무엇이 바뀌었나</b>: 이전 경계는 "엔진은 Spring 을 모른다"였고, 새 규칙(모든 계층에서
 * Spring 어노테이션 허용)이 그것을 명시적으로 폐기했다. 그러나 <b>경계 자체가 필요 없어진
 * 것은 아니다</b>. 8패키지 구조의 의존은 단방향이며 순환이 없어야 하고, 그 방향은 pom.xml 이
 * 아니라 <b>패키지 규약</b>으로만 유지된다 — 컴파일러는 아무것도 막아 주지 않는다.
 *
 * 그래서 남은 세 경계를 실행 가능한 형태로 고정한다:
 *
 * <ul>
 *   <li><b>util(엔진)</b>: Spring · Jackson · JPA 를 모른다. 엔진은 XML 생성과 식 평가만
 *       한다. 여기에 프레임워크가 들어오면 생성 로직이 컨테이너 수명주기에 얽혀
 *       "미리보기와 저장분 생성이 갈라지는" 이 프로젝트의 고질적 실패 모드가 재발한다.</li>
 *   <li><b>dto(도메인 트리 · 와이어 계약)</b>: JPA 를 모른다. {@code TemplateNode} 에
 *       {@code @Entity} 를 붙이려는 유혹이 실재하고, 붙는 순간 트리가 영속 컨텍스트에
 *       묶여 지연 로딩 프록시가 엔진으로 샌다.</li>
 *   <li><b>entity(영속 어휘)</b>: Jackson 을 모른다. 엔티티가 직렬화 애노테이션을 갖는
 *       순간 "엔티티를 그대로 응답에 실어도 되겠네"가 되고, {@code open-in-view=false} 와
 *       충돌해 직렬화 시점에 예외가 난다.</li>
 * </ul>
 *
 * Spring 컨텍스트 없이 소스를 읽는다 — 규약은 런타임이 아니라 <b>소스</b>의 성질이다.
 *
 * <h3>R2: util 이 서브패키지로 나뉘었다</h3>
 * {@code util} 아래에 {@code engine} / {@code expression} / {@code template} / {@code xml} 이
 * 생겼다. 스캔은 재귀이므로 위 세 규칙은 서브패키지에도 그대로 걸린다 — 새 서브패키지가
 * 생겨도 자동으로 보호된다. 여기에 서브패키지 사이의 규칙 하나를 더한다(아래 잎 규칙).
 */
class PackageBoundaryTest {

    /** surefire 의 작업 디렉터리는 모듈 루트(backend/)다. */
    private static final Path SOURCE_ROOT = Paths.get("src/main/java/com/xmltemplate");

    private static final String SPRING = "org.springframework";
    private static final String JACKSON = "com.fasterxml";
    private static final String JPA = "jakarta.persistence";

    /** 다른 {@code util} 서브패키지를 참조하는 import 의 접두사. */
    private static final String UTIL_PACKAGE = "com.xmltemplate.util.";

    /* ================================================================== */
    /* 경계                                                                */
    /* ================================================================== */

    @Test
    @DisplayName("util 패키지는 Spring / Jackson / JPA 를 import 하지 않는다")
    void utilHasNoFrameworkImports() throws IOException {
        List<String> violations = importsMatching("util", SPRING, JACKSON, JPA);
        assertTrue(violations.isEmpty(),
                "엔진(util)에 프레임워크 의존이 들어왔다 — 계층을 다시 확인하라:\n"
                        + String.join("\n", violations));
    }

    @Test
    @DisplayName("dto 패키지는 JPA 를 import 하지 않는다")
    void dtoHasNoPersistenceImports() throws IOException {
        List<String> violations = importsMatching("dto", JPA);
        assertTrue(violations.isEmpty(),
                "dto 에 JPA 가 들어왔다 — 도메인 트리는 영속 컨텍스트에 묶이면 안 된다:\n"
                        + String.join("\n", violations));
    }

    @Test
    @DisplayName("entity 패키지는 Jackson 을 import 하지 않는다")
    void entityHasNoJacksonImports() throws IOException {
        List<String> violations = importsMatching("entity", JACKSON);
        assertTrue(violations.isEmpty(),
                "entity 에 Jackson 이 들어왔다 — 엔티티를 응답에 직접 싣게 된다:\n"
                        + String.join("\n", violations));
    }

    /* ================================================================== */
    /* util 서브패키지 사이의 경계 (R2)                                       */
    /* ================================================================== */

    /**
     * {@code util.expression} 과 {@code util.xml} 은 <b>잎</b>이다 — 다른 {@code util}
     * 서브패키지를 참조하지 않는다.
     *
     * <b>왜 이 둘인가</b>: 식 평가기와 XML 보안 계층은 이 프로젝트에서 가장 재사용 가치가
     * 높고 가장 단독으로 시험하기 쉬운 부분이다({@code ExpressionEvaluatorTest} 가 Spring
     * 컨텍스트 없이 도는 근거가 이것이다). 여기에 {@code engine} 이나 {@code template} 참조가
     * 하나만 들어와도 그 성질이 사라지는데, <b>컴파일러는 아무것도 막아 주지 않는다</b>.
     *
     * {@code engine} / {@code template} 은 이 규칙의 대상이 아니다 — 둘은 서로를 참조해도
     * 되는 상위 계층이다.
     */
    @Test
    @DisplayName("util.expression 과 util.xml 은 다른 util 서브패키지를 참조하지 않는다 (잎)")
    void expressionAndXmlAreLeafPackages() throws IOException {
        assertCrossUtilImportsEmpty("util/expression", "expression");
        assertCrossUtilImportsEmpty("util/xml", "xml");
    }

    /* ================================================================== */
    /* 검사기가 살아 있다는 증거 — 대조군과 하한                               */
    /* ================================================================== */

    /**
     * 대조군이 없으면 위 단언들은 "금지 문자열이 어디에도 없다"로도 통과한다.
     * 즉 스캔 경로가 틀렸을 때 조용히 무력화된다.
     */
    @Test
    @DisplayName("대조군: entity 는 JPA 를, service 는 Spring 을 실제로 쓴다")
    void scannerActuallyFindsImports() throws IOException {
        assertFalse(importsMatching("entity", JPA).isEmpty(),
                "entity 에서 JPA import 를 찾지 못했다 — 스캔 경로를 확인하라: "
                        + SOURCE_ROOT.toAbsolutePath());
        assertFalse(importsMatching("service", SPRING).isEmpty(),
                "service 에서 Spring import 를 찾지 못했다 — 스캔 경로를 확인하라");
    }

    /**
     * 스캔 대상이 0건이면 테스트가 "통과"하지만 아무것도 검사하지 않은 것이다.
     * 디렉터리 구조가 바뀌었을 때 드러나도록 하한을 둔다.
     *
     * <b>서브패키지도 개별로 센다</b> — {@code util} 합계만 보면 서브패키지 하나가 통째로
     * 사라지거나 이름이 바뀌어도 총합이 유지되는 한 통과한다. 그러면 위의 잎 규칙이 빈
     * 디렉터리를 검사하며 조용히 초록이 된다.
     *
     * 실측(2026-08-09): util 23(engine 2 / expression 15 / template 4 / xml 2) ·
     * dto 12 · entity 7 · service 1.
     */
    @Test
    @DisplayName("스캔 대상 파일 수 하한 (경로가 바뀌면 드러난다)")
    void scanCoversExpectedFileCounts() throws IOException {
        assertAtLeast("util", 20);
        assertAtLeast("util/engine", 2);
        assertAtLeast("util/expression", 10);
        assertAtLeast("util/template", 4);
        assertAtLeast("util/xml", 2);
        assertAtLeast("dto", 10);
        assertAtLeast("entity", 6);
        assertAtLeast("service", 1);
    }

    /* ---------------- helpers ---------------- */

    /**
     * {@code directory} 안에서 <b>자기 자신이 아닌</b> {@code util} 서브패키지를 import 하는
     * 곳이 없는지 확인한다.
     */
    private static void assertCrossUtilImportsEmpty(String directory, String ownSubpackage)
            throws IOException {
        List<String> violations = new ArrayList<String>();
        for (String hit : importsMatching(directory, UTIL_PACKAGE)) {
            if (!hit.contains(UTIL_PACKAGE + ownSubpackage + ".")) {
                violations.add(hit);
            }
        }
        assertTrue(violations.isEmpty(), "util." + ownSubpackage
                + " 가 다른 util 서브패키지를 참조한다 — 단독 사용·단위 테스트 가능성이 사라진다:\n"
                + String.join("\n", violations));
    }

    private static void assertAtLeast(String packageName, int minimum) throws IOException {
        int found = sourcesOf(packageName).size();
        assertTrue(found >= minimum, packageName + " 패키지에서 " + found
                + "개만 찾았다 (최소 " + minimum + ") — 경로가 바뀌었는지 확인하라: "
                + SOURCE_ROOT.resolve(packageName).toAbsolutePath());
    }

    /** {@code packageName} 안에서 금지 접두사로 시작하는 import 문을 모은다. */
    private static List<String> importsMatching(String packageName, String... prefixes)
            throws IOException {
        List<String> hits = new ArrayList<String>();
        for (Path source : sourcesOf(packageName)) {
            for (String line : Files.readAllLines(source, StandardCharsets.UTF_8)) {
                String trimmed = line.trim();
                if (!trimmed.startsWith("import ")) {
                    continue;
                }
                for (String prefix : prefixes) {
                    if (trimmed.contains(prefix)) {
                        hits.add(source + " → " + trimmed);
                    }
                }
            }
        }
        return hits;
    }

    private static List<Path> sourcesOf(String packageName) throws IOException {
        Path directory = SOURCE_ROOT.resolve(packageName);
        try (Stream<Path> paths = Files.walk(directory)) {
            return paths.filter(PackageBoundaryTest::isJava).sorted().toList();
        }
    }

    private static boolean isJava(Path path) {
        return Files.isRegularFile(path) && path.getFileName().toString().endsWith(".java");
    }
}
