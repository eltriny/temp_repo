-- XML 템플릿 저장 스키마 (MariaDB) — 스키마의 정본. (R3: 2026-08-10 대리키 도입)
--
-- ★ 이 스크립트는 사람이 먼저 적용해야 한다. 애플리케이션은 DDL 을 실행하지 않는다
--   (spring.jpa.hibernate.ddl-auto=none). 기동 시 테이블을 만들던 코드와
--   조건부 ALTER 를 수행하던 SchemaMigrator 는 모두 제거되었다 —
--   앱이 기동 시 DDL 을 내는 것 자체가 운영 리스크(권한·락·부분 적용)이기 때문이다.
--
-- 따라서 테이블이 없는 새 환경에서는 기동은 성공하고 첫 요청에서 실패한다.
-- 배포 사전 조건으로 이 스크립트 적용을 반드시 포함할 것.
-- (테스트 환경만 spring.sql.init 이 이 내용을 자동 적용한다.)
--
-- ★ 이 파일은 <신규 설치>용이다. R2 이하 스키마가 이미 적용된 DB 는
--   sql/migration-r3.sql 로 옮겨야 한다 — CREATE TABLE IF NOT EXISTS 는 이미 존재하는
--   테이블을 절대 바꾸지 않으므로 이 파일만으로는 기존 DB 가 갱신되지 않는다.
--
-- ─────────────────────────────────────────────────────────────────────
-- 식별자 정책 (R3)
--
-- 두 테이블 모두 <대리키>를 PK 로 쓴다. 이전에는 TEMPLATE_NAME 이 PK 이자 자식의 FK 였는데,
-- 그러면 업무 식별자(이름)와 물리 식별자가 같아져 이름을 바꾸는 순간 자식 행을 전부
-- 갱신해야 했다. 이름은 이제 UNIQUE 제약이 걸린 평범한 속성이다.
--
-- NODE_SN 의 의미가 바뀌었다 — 주의:
--   · 이전: 템플릿마다 1부터 앱이 부여 (DFS 전위 순서)
--   · 현재: DB 시퀀스가 채우는 전역 증가 값
--   · "ORDER BY NODE_SN = DFS 전위" 계약은 그대로 성립한다 (저장이 DFS 순서로 삽입하므로
--     생성 순서가 곧 DFS 순서다).
--   · 다만 더 이상 템플릿마다 1..n 이 아니다. 저장할 때마다 노드를 전건 삭제 후 재삽입하므로
--     값이 계속 커지고 구간이 비어 있다. "1부터"를 가정한 코드·테스트는 깨진다.
--     BIGINT 를 쓰는 이유가 이것이다 — 저장 횟수 × 노드 수만큼 값이 영구 소모된다.
-- ─────────────────────────────────────────────────────────────────────

-- ─────────────────────────────────────────────────────────────────────
-- 시퀀스 (R3)
--
-- ★ INCREMENT BY 값은 엔티티의 @SequenceGenerator(allocationSize) 와 <반드시> 같아야 한다.
--   현재 양쪽 모두 50 이다 (XmlTemplate.ALLOCATION_SIZE).
--
--   어긋나면 Hibernate 가 "내 블록"이라고 믿는 구간이 실제 시퀀스 간격보다 넓어져
--   <다음 블록과 겹친다> — 그 결과가 조용한 PK 충돌(Duplicate entry)이다. 한쪽만 고치는
--   변경이 가장 위험하므로, 값을 바꿀 때는 반드시 코드와 이 파일을 함께 고칠 것.
--
-- pooled-lo 최적화(application.properties 의
-- hibernate.id.optimizer.pooled.preferred=pooled-lo)는 NEXTVAL 이 돌려준 값을 블록의
-- <시작>으로 쓴다 — MariaDB 의 INCREMENT BY 의미와 맞는 조합이다.
-- ─────────────────────────────────────────────────────────────────────

CREATE SEQUENCE IF NOT EXISTS SEQ_XML_TEMPLATE      START WITH 1 INCREMENT BY 50;
CREATE SEQUENCE IF NOT EXISTS SEQ_XML_TEMPLATE_NODE START WITH 1 INCREMENT BY 50;

CREATE TABLE IF NOT EXISTS XML_TEMPLATE (
    ID             BIGINT        NOT NULL,   -- 대리키 (SEQ_XML_TEMPLATE)
    TEMPLATE_NAME  VARCHAR(100)  NOT NULL,                 -- 업무 식별자 (UNIQUE)
    UPDATED_AT     DATETIME      NOT NULL,                 -- 마지막 저장 시각
    SOURCE_XML     LONGTEXT      NULL,                     -- 업로드 원본 XML (참고용)
    PRIMARY KEY (ID),
    CONSTRAINT UK_XML_TEMPLATE_NAME UNIQUE (TEMPLATE_NAME)
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS XML_TEMPLATE_NODE (
    NODE_SN            BIGINT         NOT NULL,   -- 대리키 (SEQ_XML_TEMPLATE_NODE, 전역 증가)
    TEMPLATE_ID        BIGINT         NOT NULL,   -- 소속 템플릿 (XML_TEMPLATE.ID)
    NODE_NAME          VARCHAR(200)   NOT NULL,   -- 노드 이름
    PARENT_SN          BIGINT         NULL,       -- 부모 노드의 NODE_SN (루트는 NULL)
    INPUT_TYPE         VARCHAR(20)    NOT NULL,   -- 입력타입: FIXED / VARIABLE / FUNCTION
    INPUT_VALUE        TEXT           NULL,       -- 입력 내용 (노드 값)
    INPUT_DATA_TYPE    VARCHAR(20)    NOT NULL,   -- 입력 데이터 타입: STRING / NUMBER
    DISPLAY_COND       TEXT           NULL,       -- 표시 조건
    REPEAT_COND        TEXT           NULL,       -- 폐지된 반복 조건 (거부 안내용 — 새 저장은 항상 빈 값)
    REPEAT_COUNT_COND  VARCHAR(1000)  NULL,       -- 반복 횟수 식 (임의의 식)
    PRIMARY KEY (NODE_SN),
    KEY IX_XML_TEMPLATE_NODE_TEMPLATE (TEMPLATE_ID, NODE_SN),
    CONSTRAINT FK_XML_TEMPLATE_NODE FOREIGN KEY (TEMPLATE_ID)
        REFERENCES XML_TEMPLATE (ID)
) DEFAULT CHARSET=utf8mb4;

-- IX_XML_TEMPLATE_NODE_TEMPLATE 는 조회 경로 그 자체다 — 로드가
-- "WHERE TEMPLATE_ID = ? ORDER BY NODE_SN" 한 방이므로 이 복합 인덱스가 필터와 정렬을 함께
-- 덮는다. FK 컬럼 단독 인덱스는 이 인덱스의 선두 컬럼으로 대체되므로 따로 만들지 않는다.

-- ─────────────────────────────────────────────────────────────────────
-- XML_TEMPLATE_NODE_ATTR 은 과거에 존재했으나, 2026-08-09 일반 속성 기능 제거로
-- 신규 설치에서는 만들지 않는다.
--
-- 기존 DB 에 남아 있는 테이블은 그대로 두되 앱이 전혀 접근하지 않는다 — 엔티티도
-- 리포지토리도 없으므로 읽지도 쓰지도 지우지도 않는다. 따라서 그 테이블에 행이 남아
-- 있다면 영구히 고아로 남는다(개발 DB 실측 0행이라 실제 손실은 없다).
--
-- 드롭 여부는 운영자가 판단한다. 스크립트가 자동으로 지우지 않는 것은 의도다 —
-- 데이터 파괴는 되돌릴 수 없기 때문이다.
--
-- 다만 앱이 더 이상 이 테이블의 행을 정리하지 않으므로(삭제 경로에서도 손대지 않는다),
-- **행이 남아 있는 환경에서는 아래 DROP 적용을 권장한다.** 그대로 두면 어떤 코드도
-- 건드리지 않는 행이 영구히 남는다.
--
--   DROP TABLE IF EXISTS XML_TEMPLATE_NODE_ATTR;
-- ─────────────────────────────────────────────────────────────────────
