"""
이미지 전처리 파이프라인 - 산업용 디스플레이 인식 최적화

산업용 디스플레이 이미지를 OCR 처리하기 전에 품질을 향상시키는
종합적인 이미지 전처리 파이프라인을 제공합니다.

주요 기능:
    - CLAHE (적응형 히스토그램 평활화): 불균일한 조명 보정
    - 가우시안 블러: 노이즈 감소
    - 적응형 이진화: 텍스트 추출 최적화
    - 형태학적 연산: 노이즈 제거 및 텍스트 구조 개선
    - 커스텀 파이프라인: 단계별 순서 지정 가능
    - ROI (관심 영역) 처리: 특정 영역만 전처리

설계 패턴:
    - 전략 패턴: 각 전처리 단계를 독립적인 핸들러로 구현
    - 파이프라인 패턴: 설정 가능한 순서로 단계들을 체이닝
    - 팩토리 패턴: 사전 정의된 설정 생성 함수 제공

사용 예시:
    >>> config = PreprocessingConfig(enable_clahe=True, enable_binarization=True)
    >>> enhancer = ImageEnhancer(config)
    >>> result = enhancer.enhance(image)
    >>> processed_image = result.image
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING, Callable, Sequence

import cv2
import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

logger = logging.getLogger(__name__)


class PreprocessingStep(Enum):
    """전처리 파이프라인에서 사용 가능한 처리 단계

    각 단계는 이미지 품질 향상의 특정 목적을 담당합니다:
    - GRAYSCALE: 컬러 이미지를 그레이스케일로 변환
    - CLAHE: 대비 제한 적응형 히스토그램 평활화
    - GAUSSIAN_BLUR: 가우시안 커널을 이용한 블러 처리
    - BILATERAL_FILTER: 엣지 보존 스무딩 필터
    - BINARIZATION: 이진화 (흑백 변환)
    - MORPHOLOGICAL: 형태학적 연산 (침식, 팽창 등)
    - SHARPEN: 언샤프 마스킹을 이용한 선명화
    - DENOISE: 비지역 평균 노이즈 제거
    - RESIZE: 크기 조정
    - NORMALIZE: 픽셀 값 정규화
    - CHARACTER_BRIDGING: 끊어진 문자 연결 (수평/수직 DILATION)
    - EDGE_ENHANCEMENT: 엣지 강조 (유사 문자 구분 향상)
    """

    GRAYSCALE = auto()
    DESKEW = auto()  # 기울기 보정 (Deskewing)
    CLAHE = auto()
    GAUSSIAN_BLUR = auto()
    BILATERAL_FILTER = auto()
    BINARIZATION = auto()
    MORPHOLOGICAL = auto()
    SHARPEN = auto()
    DENOISE = auto()
    RESIZE = auto()
    NORMALIZE = auto()
    CHARACTER_BRIDGING = auto()  # 끊어진 문자 연결 (OCR 정확도 향상)
    EDGE_ENHANCEMENT = auto()  # 엣지 강조 (0/O, 1/l 구분 향상)


class BinarizationMethod(Enum):
    """텍스트 추출을 위한 이진화 방법

    각 방법의 특성:
    - OTSU: 오츠 알고리즘 - 히스토그램 기반 자동 임계값 결정
           균일한 조명에서 효과적, 이중 피크 히스토그램에 최적
    - ADAPTIVE_MEAN: 적응형 평균 - 로컬 영역의 평균값 기준
           불균일한 조명에 적합, 계산 속도 빠름
    - ADAPTIVE_GAUSSIAN: 적응형 가우시안 - 가우시안 가중 평균
           그림자가 있는 이미지에 효과적, 더 부드러운 결과
    - SIMPLE: 단순 임계값 - 고정 임계값 사용
           균일한 배경에서 가장 빠름
    """

    OTSU = "otsu"
    ADAPTIVE_MEAN = "adaptive_mean"
    ADAPTIVE_GAUSSIAN = "adaptive_gaussian"
    SIMPLE = "simple"
    SAUVOLA = "sauvola"  # Sauvola 적응형 이진화 (불균일 조명에 효과적)


class MorphologicalOperation(Enum):
    """이미지 처리를 위한 형태학적 연산

    각 연산의 효과:
    - EROSION (침식): 밝은 영역 축소, 작은 노이즈 제거
    - DILATION (팽창): 밝은 영역 확장, 끊어진 부분 연결
    - OPENING (열림): 침식 후 팽창 - 작은 밝은 점 제거
    - CLOSING (닫힘): 팽창 후 침식 - 작은 어두운 점 제거, 글자 끊김 연결
    - GRADIENT (그래디언트): 팽창 - 침식 = 경계선 추출
    - TOP_HAT (탑햇): 원본 - 열림 = 밝은 작은 객체 강조
    - BLACK_HAT (블랙햇): 닫힘 - 원본 = 어두운 작은 객체 강조
    """

    EROSION = "erosion"
    DILATION = "dilation"
    OPENING = "opening"
    CLOSING = "closing"
    GRADIENT = "gradient"
    TOP_HAT = "top_hat"
    BLACK_HAT = "black_hat"


class BlurType(Enum):
    """블러 유형 분류

    이미지의 블러 특성을 분류하여 적응형 선명화에 활용합니다:
    - SHARP: 선명한 이미지 (보정 불필요)
    - GAUSSIAN: 가우시안 블러 (초점 미스, 전체적 흐림)
    - MOTION: 모션 블러 (카메라/피사체 움직임으로 인한 방향성 흐림)
    - OUT_OF_FOCUS: 초점 이탈 (심한 아웃포커스)
    """

    SHARP = "sharp"
    GAUSSIAN = "gaussian"
    MOTION = "motion"
    OUT_OF_FOCUS = "out_of_focus"


@dataclass(frozen=True, slots=True)
class BlurAnalysis:
    """블러 분석 결과

    이미지의 블러 상태를 분석한 결과를 담는 데이터클래스입니다.
    적응형 선명화 알고리즘 선택에 활용됩니다.

    Attributes:
        blur_type: 감지된 블러 유형
        blur_score: 블러 정도 (0=선명, 1=심한 블러)
        motion_direction: 모션 블러의 방향 (도, 0-180). 모션 블러가 아니면 None
        motion_strength: 모션 블러의 강도 (0-1). 모션 블러가 아니면 None
        recommended_action: 권장 처리 방법 설명
    """

    blur_type: BlurType
    blur_score: float
    motion_direction: float | None = None
    motion_strength: float | None = None
    recommended_action: str = ""

    @property
    def needs_deblur(self) -> bool:
        """선명화 처리가 필요한지 여부"""
        return self.blur_type != BlurType.SHARP and self.blur_score > 0.3

    @property
    def is_motion_blur(self) -> bool:
        """모션 블러인지 여부"""
        return self.blur_type == BlurType.MOTION


class DisplayType(Enum):
    """디스플레이 유형 분류

    산업용 환경에서 자주 사용되는 디스플레이 유형입니다.
    각 유형에 최적화된 전처리 설정을 선택하는 데 사용됩니다.
    """

    SEVEN_SEGMENT = "7segment"  # 7-세그먼트 LED 디스플레이
    LCD_PANEL = "lcd"  # LCD 패널 (텍스트+숫자)
    HMI_TOUCHSCREEN = "hmi"  # HMI/터치스크린
    LED_DISPLAY = "led"  # 대형 LED 전광판
    UNKNOWN = "unknown"  # 자동 감지 실패 시


@dataclass
class PreprocessingConfig:
    """이미지 전처리 파이프라인 설정

    전처리 파이프라인의 모든 파라미터를 관리하는 설정 클래스입니다.
    각 전처리 단계의 활성화 여부와 세부 파라미터를 지정할 수 있습니다.

    Attributes:
        enable_grayscale: 그레이스케일 변환 활성화 (컬러가 아닌 경우 건너뜀)
        enable_clahe: CLAHE 대비 향상 활성화
        clahe_clip_limit: CLAHE 클립 제한값 (대비 제한, 높을수록 강한 향상)
        clahe_grid_size: CLAHE 타일 그리드 크기 (작을수록 지역적 향상)
        enable_gaussian_blur: 가우시안 블러 활성화 (노이즈 감소용)
        gaussian_kernel_size: 가우시안 커널 크기 (홀수, 클수록 강한 블러)
        gaussian_sigma: 가우시안 표준편차 (0이면 커널 크기에서 자동 계산)
        enable_bilateral_filter: 양방향 필터 활성화 (엣지 보존 스무딩)
        bilateral_d: 양방향 필터 직경 (픽셀 이웃 범위)
        bilateral_sigma_color: 색상 공간 시그마 (색상 유사도 범위)
        bilateral_sigma_space: 좌표 공간 시그마 (공간적 영향 범위)
        enable_binarization: 이진화 활성화 (텍스트 추출용)
        binarization_method: 이진화 방법 선택
        binary_threshold: 단순 이진화 임계값 (0-255)
        adaptive_block_size: 적응형 이진화 블록 크기 (홀수, 지역 영역 크기)
        adaptive_c: 적응형 이진화 상수 (평균/가우시안에서 뺄 값)
        enable_morphological: 형태학적 연산 활성화
        morphological_operation: 형태학적 연산 종류
        morphological_kernel_size: 형태학적 연산 커널 크기
        morphological_iterations: 형태학적 연산 반복 횟수
        enable_sharpen: 선명화 활성화
        sharpen_amount: 선명화 강도 (0.0-2.0, 높을수록 강함)
        enable_denoise: 노이즈 제거 활성화
        denoise_strength: 노이즈 제거 강도 (h 파라미터, 높을수록 강함)
        enable_resize: 크기 조정 활성화
        target_height: 목표 높이 (0이면 비활성화)
        maintain_aspect_ratio: 가로세로 비율 유지 여부
        enable_normalize: 픽셀 값 정규화 활성화
        normalize_alpha: 정규화 하한값
        normalize_beta: 정규화 상한값
        invert_colors: 색상 반전 (어두운 배경용)
        pipeline_order: 커스텀 파이프라인 순서 (None이면 기본 순서)

    Example:
        >>> # 기본 설정 사용
        >>> config = PreprocessingConfig()
        >>> # CLAHE와 이진화만 활성화
        >>> config = PreprocessingConfig(
        ...     enable_clahe=True,
        ...     enable_binarization=True,
        ...     enable_morphological=False
        ... )
    """

    # ========================================
    # 그레이스케일 변환 설정
    # ========================================
    enable_grayscale: bool = True

    # ========================================
    # 기울기 보정 (Deskewing) 설정
    # ========================================
    # Hough 변환을 이용해 텍스트 라인의 기울기를 감지하고 보정
    enable_deskew: bool = False
    deskew_max_angle: float = 15.0  # 최대 보정 각도 (도)

    # ========================================
    # CLAHE (적응형 히스토그램 평활화) 설정
    # ========================================
    # CLAHE는 이미지를 작은 타일로 나누어 각 타일에서
    # 히스토그램 평활화를 수행하여 지역적 대비를 향상시킵니다
    enable_clahe: bool = True
    clahe_clip_limit: float = 2.0  # 대비 제한값: 노이즈 증폭 방지
    clahe_grid_size: tuple[int, int] = (8, 8)  # 타일 그리드: (8,8) = 64개 타일

    # ========================================
    # 가우시안 블러 설정
    # ========================================
    # 고주파 노이즈를 제거하는 저역 통과 필터
    enable_gaussian_blur: bool = True
    gaussian_kernel_size: tuple[int, int] = (3, 3)  # 커널 크기 (홀수)
    gaussian_sigma: float = 0.0  # 0이면 커널 크기에서 자동 계산

    # ========================================
    # 양방향 필터 설정
    # ========================================
    # 엣지를 보존하면서 노이즈를 제거하는 비선형 필터
    # 가우시안 블러보다 느리지만 텍스트 경계 보존에 효과적
    enable_bilateral_filter: bool = False
    bilateral_d: int = 9  # 필터 직경
    bilateral_sigma_color: float = 75.0  # 색상 시그마
    bilateral_sigma_space: float = 75.0  # 공간 시그마

    # ========================================
    # 이진화 설정
    # ========================================
    # 그레이스케일 이미지를 흑백으로 변환
    enable_binarization: bool = True
    binarization_method: BinarizationMethod = BinarizationMethod.ADAPTIVE_GAUSSIAN
    binary_threshold: int = 127  # 단순 이진화용 고정 임계값
    adaptive_block_size: int = 11  # 적응형 이진화 블록 크기 (홀수)
    adaptive_c: int = 2  # 평균/가우시안에서 뺄 상수
    sauvola_window_size: int = 25  # Sauvola 윈도우 크기 (홀수)
    sauvola_k: float = 0.2  # Sauvola k 파라미터 (0.1-0.5)

    # ========================================
    # 형태학적 연산 설정
    # ========================================
    # 이진 이미지의 구조를 개선하는 연산
    enable_morphological: bool = True
    morphological_operation: MorphologicalOperation = MorphologicalOperation.CLOSING
    morphological_kernel_size: tuple[int, int] = (2, 2)  # 구조 요소 크기
    morphological_iterations: int = 1  # 연산 반복 횟수

    # ========================================
    # 선명화 설정
    # ========================================
    # 언샤프 마스킹 기법으로 엣지를 강조
    enable_sharpen: bool = False
    sharpen_amount: float = 1.0  # 선명화 강도 (0.0-2.0)

    # ========================================
    # 노이즈 제거 설정
    # ========================================
    # Non-local Means Denoising 알고리즘 사용
    enable_denoise: bool = False
    denoise_strength: float = 10.0  # h 파라미터 (높을수록 강한 제거)

    # ========================================
    # 크기 조정 설정
    # ========================================
    enable_resize: bool = False
    target_height: int = 64  # 목표 높이 (픽셀)
    maintain_aspect_ratio: bool = True  # 비율 유지

    # ========================================
    # 정규화 설정
    # ========================================
    # 픽셀 값을 지정된 범위로 스케일링
    enable_normalize: bool = False
    normalize_alpha: int = 0  # 최소값
    normalize_beta: int = 255  # 최대값

    # ========================================
    # 색상 반전 설정
    # ========================================
    # 어두운 배경의 밝은 텍스트용
    invert_colors: bool = False

    # ========================================
    # CHARACTER_BRIDGING (문자 연결) 설정
    # ========================================
    # 끊어진 문자 획을 Dilation으로 연결
    # 7-세그먼트 디스플레이나 저해상도 이미지에서 효과적
    enable_character_bridging: bool = False
    bridging_kernel_shape: str = "cross"  # "horizontal", "vertical", "cross"
    bridging_kernel_size: tuple[int, int] = (3, 3)  # 커널 크기
    bridging_iterations: int = 1  # 반복 횟수

    # ========================================
    # EDGE_ENHANCEMENT (엣지 강조) 설정
    # ========================================
    # Laplacian/Sobel로 엣지를 강조하여 유사 문자 구분 향상 (0/O, 1/l)
    enable_edge_enhancement: bool = False
    edge_method: str = "laplacian"  # "laplacian", "sobel"
    edge_weight: float = 0.3  # 엣지 합성 가중치 (0.0-1.0)

    # ========================================
    # 파이프라인 순서 설정
    # ========================================
    # None이면 기본 순서 사용 (산업용 디스플레이 OCR에 최적화)
    pipeline_order: tuple[PreprocessingStep, ...] | None = None

    def get_pipeline_order(self) -> tuple[PreprocessingStep, ...]:
        """실제 적용될 파이프라인 순서 반환

        사용자가 커스텀 순서를 지정하지 않으면 산업용 디스플레이 OCR에
        최적화된 기본 순서를 반환합니다.

        기본 순서의 설계 근거:
        1. GRAYSCALE: 컬러 정보 제거로 처리 단순화
        2. DESKEW: 기울기 보정은 초기에 적용
        3. RESIZE: 일관된 크기로 후속 처리 표준화
        4. DENOISE: 노이즈 제거 후 대비 향상 (노이즈 증폭 방지)
        5. CLAHE: 지역적 대비 향상
        6. BILATERAL_FILTER: 엣지 보존 스무딩
        7. GAUSSIAN_BLUR: 추가 노이즈 감소
        8. SHARPEN: 엣지 강조 (블러 후 복원)
        9. EDGE_ENHANCEMENT: 엣지 강조로 유사 문자 구분 (0/O, 1/l)
        10. NORMALIZE: 픽셀 범위 표준화
        11. BINARIZATION: 최종 이진화
        12. CHARACTER_BRIDGING: 끊어진 문자 연결 (이진화 후 적용)
        13. MORPHOLOGICAL: 이진 이미지 정리

        Returns:
            전처리 단계 순서 튜플
        """
        if self.pipeline_order is not None:
            return self.pipeline_order

        # 산업용 디스플레이 OCR에 최적화된 기본 순서
        return (
            PreprocessingStep.GRAYSCALE,
            PreprocessingStep.DESKEW,  # 기울기 보정은 초기에 적용
            PreprocessingStep.RESIZE,
            PreprocessingStep.DENOISE,
            PreprocessingStep.CLAHE,
            PreprocessingStep.BILATERAL_FILTER,
            PreprocessingStep.GAUSSIAN_BLUR,
            PreprocessingStep.SHARPEN,
            PreprocessingStep.EDGE_ENHANCEMENT,  # 유사 문자 구분 향상
            PreprocessingStep.NORMALIZE,
            PreprocessingStep.BINARIZATION,
            PreprocessingStep.CHARACTER_BRIDGING,  # 끊어진 문자 연결
            PreprocessingStep.MORPHOLOGICAL,
        )


@dataclass(frozen=True, slots=True)
class ProcessingResult:
    """이미지 전처리 결과

    전처리 파이프라인 실행 후 결과와 메타데이터를 담는 불변 객체입니다.

    Attributes:
        image: 전처리된 이미지 배열 (numpy ndarray)
        original_shape: 원본 이미지의 shape (처리 전)
        applied_steps: 실제 적용된 전처리 단계들의 튜플
        processing_time_ms: 전체 처리 소요 시간 (밀리초)

    Note:
        frozen=True로 설정되어 생성 후 수정 불가능합니다.
        slots=True로 메모리 효율성을 높였습니다.
    """

    image: NDArray[np.uint8]
    original_shape: tuple[int, ...]
    applied_steps: tuple[PreprocessingStep, ...]
    processing_time_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class ImageQualityScore:
    """이미지 품질 점수

    이미지의 다양한 품질 지표를 분석하여 적응형 전처리 설정 결정에 활용합니다.

    Attributes:
        blur_score: 블러 정도 (0=블러, 1=선명). Laplacian 분산 기반.
        noise_score: 노이즈 정도 (0=노이즈, 1=깨끗). 고주파 성분 분석.
        contrast_score: 대비 정도 (0=저대비, 1=고대비). 히스토그램 범위.
        brightness_score: 밝기 균일도 (0=불균일, 1=균일).
        overall_score: 종합 점수 (가중 평균).
    """

    blur_score: float
    noise_score: float
    contrast_score: float
    brightness_score: float
    overall_score: float

    @property
    def quality_level(self) -> str:
        """품질 등급 반환

        Returns:
            'high': overall_score >= 0.8
            'medium': 0.5 <= overall_score < 0.8
            'low': overall_score < 0.5
        """
        if self.overall_score >= 0.8:
            return "high"
        elif self.overall_score >= 0.5:
            return "medium"
        else:
            return "low"


class ImageEnhancer:
    """산업용 디스플레이 인식을 위한 이미지 전처리 파이프라인

    OCR 정확도 향상을 위해 산업용 디스플레이 이미지를 전처리하는
    종합적이고 설정 가능한 파이프라인을 제공합니다.

    주요 기능:
        - CLAHE를 이용한 적응형 대비 향상
        - 다양한 노이즈 감소 필터
        - 여러 이진화 방법 지원
        - 텍스트 정리를 위한 형태학적 연산
        - 커스텀 단계 순서 지정

    설계 패턴:
        - 전략 패턴: _step_handlers 딕셔너리로 각 단계 핸들러 매핑
        - 템플릿 메서드: enhance() 메서드가 파이프라인 흐름 제어

    Attributes:
        _config: 현재 적용된 전처리 설정
        _step_handlers: 각 전처리 단계의 핸들러 함수 매핑

    Example:
        >>> # 기본 설정으로 이미지 향상
        >>> enhancer = ImageEnhancer()
        >>> result = enhancer.enhance(image)
        >>> processed = result.image

        >>> # 커스텀 설정 사용
        >>> config = PreprocessingConfig(
        ...     enable_clahe=True,
        ...     enable_binarization=True,
        ...     binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN
        ... )
        >>> enhancer = ImageEnhancer(config)
        >>> result = enhancer.enhance(image)
    """

    def __init__(self, config: PreprocessingConfig | None = None) -> None:
        """ImageEnhancer 초기화

        Args:
            config: 전처리 설정. None이면 기본 설정 사용
        """
        self._config = config or PreprocessingConfig()

        # 각 전처리 단계에 대한 핸들러 함수 매핑
        # 전략 패턴: 단계별로 독립적인 처리 로직 분리
        self._step_handlers: dict[
            PreprocessingStep,
            Callable[[NDArray[np.uint8]], NDArray[np.uint8]],
        ] = {
            PreprocessingStep.GRAYSCALE: self._apply_grayscale,
            PreprocessingStep.DESKEW: self._apply_deskew,
            PreprocessingStep.CLAHE: self._apply_clahe,
            PreprocessingStep.GAUSSIAN_BLUR: self._apply_gaussian_blur,
            PreprocessingStep.BILATERAL_FILTER: self._apply_bilateral_filter,
            PreprocessingStep.BINARIZATION: self._apply_binarization,
            PreprocessingStep.MORPHOLOGICAL: self._apply_morphological,
            PreprocessingStep.SHARPEN: self._apply_sharpen,
            PreprocessingStep.DENOISE: self._apply_denoise,
            PreprocessingStep.RESIZE: self._apply_resize,
            PreprocessingStep.NORMALIZE: self._apply_normalize,
            PreprocessingStep.CHARACTER_BRIDGING: self._apply_character_bridging,
            PreprocessingStep.EDGE_ENHANCEMENT: self._apply_edge_enhancement,
        }
        logger.info("ImageEnhancer 초기화 완료")

    @property
    def config(self) -> PreprocessingConfig:
        """현재 설정 반환"""
        return self._config

    def update_config(self, config: PreprocessingConfig) -> None:
        """전처리 설정 업데이트

        Args:
            config: 새로 적용할 설정
        """
        self._config = config
        logger.info("ImageEnhancer 설정 업데이트됨")

    def _is_step_enabled(self, step: PreprocessingStep) -> bool:
        """특정 전처리 단계의 활성화 여부 확인

        Args:
            step: 확인할 전처리 단계

        Returns:
            해당 단계가 설정에서 활성화되어 있으면 True
        """
        # 각 단계의 활성화 플래그 매핑
        step_enable_map = {
            PreprocessingStep.GRAYSCALE: self._config.enable_grayscale,
            PreprocessingStep.DESKEW: self._config.enable_deskew,
            PreprocessingStep.CLAHE: self._config.enable_clahe,
            PreprocessingStep.GAUSSIAN_BLUR: self._config.enable_gaussian_blur,
            PreprocessingStep.BILATERAL_FILTER: self._config.enable_bilateral_filter,
            PreprocessingStep.BINARIZATION: self._config.enable_binarization,
            PreprocessingStep.MORPHOLOGICAL: self._config.enable_morphological,
            PreprocessingStep.SHARPEN: self._config.enable_sharpen,
            PreprocessingStep.DENOISE: self._config.enable_denoise,
            PreprocessingStep.RESIZE: self._config.enable_resize,
            PreprocessingStep.NORMALIZE: self._config.enable_normalize,
            PreprocessingStep.CHARACTER_BRIDGING: self._config.enable_character_bridging,
            PreprocessingStep.EDGE_ENHANCEMENT: self._config.enable_edge_enhancement,
        }
        return step_enable_map.get(step, False)

    def _apply_grayscale(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """이미지를 그레이스케일로 변환

        컬러 정보를 제거하여 단일 채널 이미지로 변환합니다.
        이미 그레이스케일인 경우 그대로 반환합니다.

        Args:
            image: 입력 이미지 (BGR 또는 그레이스케일)

        Returns:
            그레이스케일 이미지 (2D 배열)
        """
        # 이미 2D 배열이면 그대로 반환
        if len(image.shape) == 2:
            return image
        # 단일 채널 3D 배열이면 차원 축소
        if image.shape[2] == 1:
            return image.squeeze(axis=2)
        # BGR을 그레이스케일로 변환
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    def _apply_deskew(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """이미지 기울기 보정 (Deskewing)

        ========================================
        Hough 변환 기반 기울기 감지
        ========================================
        원리: 텍스트 라인은 대부분 수평이므로, Hough 변환으로
        감지된 선들의 각도 분포에서 중앙값을 구해 보정합니다.

        처리 과정:
        1. Canny 엣지 검출로 텍스트 경계 추출
        2. HoughLinesP로 선분 검출
        3. 선분들의 각도 중앙값 계산
        4. 해당 각도만큼 역회전하여 수평 정렬
        ========================================

        Args:
            image: 입력 이미지 (그레이스케일 또는 컬러)

        Returns:
            기울기가 보정된 이미지
        """
        # 그레이스케일 확인
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        # 엣지 감지
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)

        # Hough 변환으로 선 감지
        lines = cv2.HoughLinesP(
            edges,
            rho=1,
            theta=np.pi / 180,
            threshold=100,
            minLineLength=50,
            maxLineGap=10,
        )

        if lines is None or len(lines) == 0:
            return image

        # 각도 계산 (수평선 기준)
        angles: list[float] = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            if x2 - x1 != 0:
                angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
                if abs(angle) < self._config.deskew_max_angle:
                    angles.append(angle)

        if not angles:
            return image

        # 중앙값 각도로 회전
        median_angle = float(np.median(angles))

        # 회전 적용
        h, w = image.shape[:2]
        center = (w // 2, h // 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)

        # 회전 후 이미지 경계 계산
        cos_val = abs(rotation_matrix[0, 0])
        sin_val = abs(rotation_matrix[0, 1])
        new_w = int(h * sin_val + w * cos_val)
        new_h = int(h * cos_val + w * sin_val)

        # 회전 중심 조정
        rotation_matrix[0, 2] += (new_w - w) / 2
        rotation_matrix[1, 2] += (new_h - h) / 2

        rotated = cv2.warpAffine(
            image,
            rotation_matrix,
            (new_w, new_h),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE,
        )

        logger.debug("기울기 보정 적용: %.2f도", median_angle)
        return rotated

    def _apply_clahe(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """CLAHE (적응형 히스토그램 평활화) 적용

        ========================================
        CLAHE 알고리즘 (Contrast Limited Adaptive Histogram Equalization)
        ========================================
        일반 히스토그램 평활화의 문제점:
        - 전역적으로 적용되어 지역적 대비 손실
        - 노이즈가 증폭될 수 있음

        CLAHE의 해결책:
        1. 이미지를 작은 타일(예: 8x8)로 분할
        2. 각 타일에서 독립적으로 히스토그램 평활화 수행
        3. clip_limit으로 대비 증폭 제한 (노이즈 방지)
        4. 인접 타일 경계를 선형 보간으로 부드럽게 연결

        파라미터 의미:
        - clip_limit: 높을수록 대비 증가, 노이즈도 증가 (권장: 2.0-4.0)
        - grid_size: 작을수록 지역적 적응, 계산 비용 증가
        ========================================

        Args:
            image: 입력 그레이스케일 이미지

        Returns:
            대비가 향상된 이미지
        """
        # 컬러 이미지면 먼저 그레이스케일로 변환
        if len(image.shape) == 3:
            image = self._apply_grayscale(image)

        # CLAHE 객체 생성 및 적용
        clahe = cv2.createCLAHE(
            clipLimit=self._config.clahe_clip_limit,
            tileGridSize=self._config.clahe_grid_size,
        )
        return clahe.apply(image)

    def _apply_gaussian_blur(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """가우시안 블러 적용

        가우시안 커널을 이용한 저역 통과 필터로 고주파 노이즈를 제거합니다.
        커널 크기가 클수록 더 강한 블러 효과가 나타납니다.

        Args:
            image: 입력 이미지

        Returns:
            블러 처리된 이미지
        """
        return cv2.GaussianBlur(
            image,
            self._config.gaussian_kernel_size,
            self._config.gaussian_sigma,
        )

    def _apply_bilateral_filter(
        self,
        image: NDArray[np.uint8],
    ) -> NDArray[np.uint8]:
        """양방향 필터 적용 (엣지 보존 스무딩)

        ========================================
        양방향 필터 (Bilateral Filter)
        ========================================
        일반 가우시안 블러의 문제점:
        - 엣지(경계)도 함께 흐려짐
        - 텍스트 경계가 불명확해질 수 있음

        양방향 필터의 해결책:
        - 공간적 거리와 색상/밝기 유사도 모두 고려
        - 유사한 픽셀만 평균에 포함
        - 엣지 근처에서는 다른 쪽 픽셀 배제

        파라미터:
        - d: 필터 직경 (픽셀 이웃 범위)
        - sigma_color: 색상 공간 시그마 (유사도 판단 기준)
        - sigma_space: 좌표 공간 시그마 (거리 가중치)
        ========================================

        Args:
            image: 입력 이미지

        Returns:
            엣지가 보존된 스무딩 이미지
        """
        return cv2.bilateralFilter(
            image,
            self._config.bilateral_d,
            self._config.bilateral_sigma_color,
            self._config.bilateral_sigma_space,
        )

    def _apply_binarization(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """이진화 적용 (텍스트 추출용)

        ========================================
        이진화 방법 비교
        ========================================
        1. OTSU (오츠):
           - 히스토그램에서 클래스 간 분산 최대화
           - 이중 피크 히스토그램에서 최적
           - 균일한 조명 환경에 적합

        2. ADAPTIVE_MEAN (적응형 평균):
           - 각 픽셀 주변 블록의 평균값 사용
           - 빠른 계산 속도
           - 불균일 조명에 효과적

        3. ADAPTIVE_GAUSSIAN (적응형 가우시안):
           - 가우시안 가중 평균 사용 (중심에 더 가중치)
           - 그림자 영역에서 더 나은 결과
           - 가장 일반적으로 권장

        4. SIMPLE (단순):
           - 고정 임계값으로 단순 비교
           - 가장 빠름, 균일한 배경에서만 사용
        ========================================

        Args:
            image: 입력 그레이스케일 이미지

        Returns:
            이진화된 이미지 (0 또는 255)
        """
        # 컬러 이미지면 먼저 그레이스케일로 변환
        if len(image.shape) == 3:
            image = self._apply_grayscale(image)

        method = self._config.binarization_method

        if method == BinarizationMethod.OTSU:
            # 오츠 알고리즘: 히스토그램 기반 자동 임계값 결정
            _, binary = cv2.threshold(
                image,
                0,  # 오츠에서는 무시됨
                255,
                cv2.THRESH_BINARY + cv2.THRESH_OTSU,
            )
        elif method == BinarizationMethod.ADAPTIVE_MEAN:
            # 적응형 평균: 블록 내 평균값 - C를 임계값으로 사용
            binary = cv2.adaptiveThreshold(
                image,
                255,
                cv2.ADAPTIVE_THRESH_MEAN_C,
                cv2.THRESH_BINARY,
                self._config.adaptive_block_size,
                self._config.adaptive_c,
            )
        elif method == BinarizationMethod.ADAPTIVE_GAUSSIAN:
            # 적응형 가우시안: 가우시안 가중 평균 - C를 임계값으로 사용
            binary = cv2.adaptiveThreshold(
                image,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                self._config.adaptive_block_size,
                self._config.adaptive_c,
            )
        elif method == BinarizationMethod.SAUVOLA:
            # Sauvola 적응형 이진화: 불균일 조명에 효과적
            # T(x,y) = mean(x,y) * (1 + k * (std(x,y) / R - 1))
            try:
                from skimage.filters import threshold_sauvola

                thresh = threshold_sauvola(
                    image,
                    window_size=self._config.sauvola_window_size,
                    k=self._config.sauvola_k,
                )
                binary = ((image > thresh) * 255).astype(np.uint8)
            except ImportError:
                logger.warning(
                    "scikit-image 미설치, Sauvola 대신 OTSU 사용"
                )
                _, binary = cv2.threshold(
                    image,
                    0,
                    255,
                    cv2.THRESH_BINARY + cv2.THRESH_OTSU,
                )
        else:  # SIMPLE
            # 단순 이진화: 고정 임계값
            _, binary = cv2.threshold(
                image,
                self._config.binary_threshold,
                255,
                cv2.THRESH_BINARY,
            )

        # 색상 반전 (어두운 배경에 밝은 텍스트인 경우)
        if self._config.invert_colors:
            binary = cv2.bitwise_not(binary)

        return binary

    def _apply_morphological(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """형태학적 연산 적용

        ========================================
        형태학적 연산 (Morphological Operations)
        ========================================
        구조 요소(커널)를 사용하여 이미지 형태를 변형합니다.
        주로 이진 이미지에서 노이즈 제거 및 구조 개선에 사용됩니다.

        연산 종류:
        - EROSION (침식): 밝은 영역 축소, 작은 노이즈 제거
        - DILATION (팽창): 밝은 영역 확대, 끊어진 부분 연결
        - OPENING (열림) = 침식 → 팽창: 작은 밝은 점 제거
        - CLOSING (닫힘) = 팽창 → 침식: 작은 어두운 점 제거
        - GRADIENT = 팽창 - 침식: 경계선 추출
        - TOP_HAT = 원본 - 열림: 밝은 작은 객체 강조
        - BLACK_HAT = 닫힘 - 원본: 어두운 작은 객체 강조

        OCR 전처리에서의 활용:
        - CLOSING: 글자 내부의 작은 구멍 메우기, 끊어진 획 연결
        - OPENING: 글자 주변의 작은 노이즈 제거
        ========================================

        Args:
            image: 입력 이미지 (일반적으로 이진 이미지)

        Returns:
            형태학적 연산이 적용된 이미지
        """
        # 직사각형 구조 요소(커널) 생성
        kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT,
            self._config.morphological_kernel_size,
        )

        operation = self._config.morphological_operation
        iterations = self._config.morphological_iterations

        # 각 연산 타입에 따라 처리
        if operation == MorphologicalOperation.EROSION:
            return cv2.erode(image, kernel, iterations=iterations)
        elif operation == MorphologicalOperation.DILATION:
            return cv2.dilate(image, kernel, iterations=iterations)
        elif operation == MorphologicalOperation.OPENING:
            return cv2.morphologyEx(
                image,
                cv2.MORPH_OPEN,
                kernel,
                iterations=iterations,
            )
        elif operation == MorphologicalOperation.CLOSING:
            return cv2.morphologyEx(
                image,
                cv2.MORPH_CLOSE,
                kernel,
                iterations=iterations,
            )
        elif operation == MorphologicalOperation.GRADIENT:
            return cv2.morphologyEx(
                image,
                cv2.MORPH_GRADIENT,
                kernel,
                iterations=iterations,
            )
        elif operation == MorphologicalOperation.TOP_HAT:
            return cv2.morphologyEx(
                image,
                cv2.MORPH_TOPHAT,
                kernel,
                iterations=iterations,
            )
        elif operation == MorphologicalOperation.BLACK_HAT:
            return cv2.morphologyEx(
                image,
                cv2.MORPH_BLACKHAT,
                kernel,
                iterations=iterations,
            )
        else:
            return image

    def _apply_sharpen(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """언샤프 마스킹을 이용한 선명화 적용

        ========================================
        언샤프 마스킹 (Unsharp Masking)
        ========================================
        원리: 원본 이미지에서 블러 이미지를 빼면 고주파(엣지) 성분만 남음
        이 고주파 성분을 원본에 더해 엣지를 강조

        공식: sharpened = original + amount * (original - blurred)
             = (1 + amount) * original - amount * blurred

        amount가 클수록 선명화 효과 강해짐 (노이즈도 증폭될 수 있음)
        ========================================

        Args:
            image: 입력 이미지

        Returns:
            선명화된 이미지
        """
        # 블러 이미지 생성 (언샤프 마스크용)
        blurred = cv2.GaussianBlur(image, (0, 0), 3)
        # 언샤프 마스킹 적용
        sharpened = cv2.addWeighted(
            image,
            1.0 + self._config.sharpen_amount,  # 원본 가중치
            blurred,
            -self._config.sharpen_amount,  # 블러 가중치 (빼기)
            0,  # 감마
        )
        # 픽셀 값을 0-255 범위로 클리핑
        return np.clip(sharpened, 0, 255).astype(np.uint8)

    def _apply_denoise(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """노이즈 제거 필터 적용

        ========================================
        비지역 평균 노이즈 제거 (Non-local Means Denoising)
        ========================================
        기존 방법의 문제점:
        - 가우시안 블러: 엣지도 함께 흐려짐
        - 미디안 필터: 텍스처 디테일 손실

        NLM의 해결책:
        - 유사한 패치(영역)를 이미지 전체에서 검색
        - 유사한 패치들의 가중 평균으로 노이즈 제거
        - 반복되는 패턴의 디테일 보존에 효과적

        h 파라미터: 필터 강도 (높을수록 노이즈 제거 강함, 디테일 손실 증가)
        ========================================

        Args:
            image: 입력 이미지

        Returns:
            노이즈가 제거된 이미지
        """
        if len(image.shape) == 2:
            # 그레이스케일 이미지
            return cv2.fastNlMeansDenoising(
                image,
                h=self._config.denoise_strength,
            )
        else:
            # 컬러 이미지
            return cv2.fastNlMeansDenoisingColored(
                image,
                h=self._config.denoise_strength,
                hForColorComponents=self._config.denoise_strength,
            )

    def _apply_resize(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """이미지 크기 조정

        일관된 처리를 위해 이미지를 목표 크기로 조정합니다.
        OCR 모델이 특정 크기에서 최적화된 경우 유용합니다.

        Args:
            image: 입력 이미지

        Returns:
            크기가 조정된 이미지
        """
        # 목표 높이가 0 이하면 크기 조정 건너뜀
        if self._config.target_height <= 0:
            return image

        h, w = image.shape[:2]

        if self._config.maintain_aspect_ratio:
            # 가로세로 비율 유지하며 크기 조정
            scale = self._config.target_height / h
            new_w = int(w * scale)
            new_h = self._config.target_height
        else:
            # 높이만 변경 (가로는 유지)
            new_w = w
            new_h = self._config.target_height

        return cv2.resize(
            image,
            (new_w, new_h),
            interpolation=cv2.INTER_LINEAR,  # 양선형 보간
        )

    def _apply_normalize(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """픽셀 값 정규화

        픽셀 값을 지정된 범위(alpha ~ beta)로 스케일링합니다.
        전체 동적 범위를 사용하도록 히스토그램을 늘립니다.

        Args:
            image: 입력 이미지

        Returns:
            정규화된 이미지
        """
        return cv2.normalize(
            image,
            None,
            alpha=self._config.normalize_alpha,
            beta=self._config.normalize_beta,
            norm_type=cv2.NORM_MINMAX,
            dtype=cv2.CV_8U,
        )

    def _apply_character_bridging(
        self,
        image: NDArray[np.uint8],
    ) -> NDArray[np.uint8]:
        """끊어진 문자 획 연결 (Character Bridging)

        ========================================
        문자 브리징 (Dilation 기반)
        ========================================
        7-세그먼트 디스플레이나 저해상도 이미지에서 문자 획이
        끊어져 보이는 경우, Dilation(팽창) 연산으로 연결합니다.

        커널 형태:
        - horizontal: 가로 방향 연결 (수평 획 연결에 효과적)
        - vertical: 세로 방향 연결 (수직 획 연결에 효과적)
        - cross: 십자 형태 (모든 방향에 균일하게 연결)

        주의사항:
        - 과도한 적용 시 문자가 뭉개질 수 있음
        - 이진화 후 적용하면 효과가 더 좋음
        - iterations가 높을수록 강한 연결 효과
        ========================================

        Args:
            image: 입력 이미지 (그레이스케일 또는 이진 이미지 권장)

        Returns:
            끊어진 획이 연결된 이미지
        """
        # 커널 형태에 따른 구조 요소 생성
        kw, kh = self._config.bridging_kernel_size
        shape = self._config.bridging_kernel_shape

        if shape == "horizontal":
            # 가로 방향 커널: [1, 1, 1] 형태
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kw, 1))
        elif shape == "vertical":
            # 세로 방향 커널
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kh))
        else:  # "cross"
            # 십자 형태 커널
            kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (kw, kh))

        # Dilation 적용하여 끊어진 부분 연결
        bridged = cv2.dilate(
            image,
            kernel,
            iterations=self._config.bridging_iterations,
        )

        logger.debug(
            "문자 브리징 적용: shape=%s, size=%s, iterations=%d",
            shape,
            (kw, kh),
            self._config.bridging_iterations,
        )
        return bridged

    def _apply_edge_enhancement(
        self,
        image: NDArray[np.uint8],
    ) -> NDArray[np.uint8]:
        """엣지 강조 (Edge Enhancement)

        ========================================
        엣지 강조 알고리즘
        ========================================
        문자의 경계를 강조하여 유사 문자(0/O, 1/l, S/5, B/8)의
        구분력을 향상시킵니다.

        방법:
        1. Laplacian: 2차 미분으로 모든 방향의 엣지 검출
           - 장점: 방향에 무관, 연산 단순
           - 단점: 노이즈에 민감

        2. Sobel: 1차 미분 기반, X/Y 방향 분리
           - 장점: 노이즈에 덜 민감
           - 단점: 연산량 증가

        블렌딩:
        enhanced = original + weight * edges
        - weight가 높을수록 엣지 강조 효과 증가
        - 과도한 weight는 노이즈 증폭
        ========================================

        Args:
            image: 입력 이미지 (그레이스케일 권장)

        Returns:
            엣지가 강조된 이미지
        """
        # 컬러 이미지면 그레이스케일로 변환
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        method = self._config.edge_method
        weight = self._config.edge_weight

        if method == "laplacian":
            # Laplacian 엣지 검출
            edges = cv2.Laplacian(gray, cv2.CV_64F)
            # 절대값 취하고 정규화
            edges = np.abs(edges)
            edges = (edges / edges.max() * 255).astype(np.uint8) if edges.max() > 0 else edges.astype(np.uint8)
        else:  # "sobel"
            # Sobel X, Y 방향 엣지 검출
            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            # 크기(magnitude) 계산
            edges = np.sqrt(sobel_x**2 + sobel_y**2)
            edges = (edges / edges.max() * 255).astype(np.uint8) if edges.max() > 0 else edges.astype(np.uint8)

        # 원본에 엣지 블렌딩
        # enhanced = original * (1 - weight) + (original + edges) * weight
        #          = original + edges * weight
        enhanced = cv2.addWeighted(
            gray,
            1.0,
            edges,
            weight,
            0,
        )

        # 픽셀 값을 0-255 범위로 클리핑
        enhanced = np.clip(enhanced, 0, 255).astype(np.uint8)

        logger.debug(
            "엣지 강조 적용: method=%s, weight=%.2f",
            method,
            weight,
        )
        return enhanced

    def enhance(self, image: NDArray[np.uint8]) -> ProcessingResult:
        """전체 전처리 파이프라인 적용

        설정된 순서대로 활성화된 모든 전처리 단계를 적용합니다.

        처리 흐름:
        1. 입력 유효성 검사
        2. 파이프라인 순서 가져오기
        3. 각 단계 순회하며 활성화된 단계만 적용
        4. 처리 시간 측정
        5. 결과 객체 반환

        Args:
            image: 입력 이미지 (numpy 배열)

        Returns:
            처리된 이미지와 메타데이터가 포함된 ProcessingResult

        Raises:
            ValueError: 이미지가 비어있거나 None인 경우
            RuntimeError: 전처리 단계 실행 중 오류 발생 시
        """
        # 입력 유효성 검사
        if image is None or image.size == 0:
            raise ValueError("입력 이미지가 비어있거나 None입니다")

        import time

        start_time = time.perf_counter()
        original_shape = image.shape
        processed = image.copy()  # 원본 보존을 위해 복사
        applied_steps: list[PreprocessingStep] = []

        # 파이프라인 순서 가져오기
        pipeline = self._config.get_pipeline_order()

        # 각 단계 순회
        for step in pipeline:
            # 비활성화된 단계 건너뛰기
            if not self._is_step_enabled(step):
                continue

            handler = self._step_handlers.get(step)
            if handler is None:
                logger.warning("단계에 대한 핸들러 없음: %s", step)
                continue

            try:
                # 단계 적용
                processed = handler(processed)
                applied_steps.append(step)
                logger.debug("전처리 단계 적용됨: %s", step.name)
            except Exception as e:
                logger.error(
                    "단계 %s 적용 실패: %s",
                    step.name,
                    e,
                )
                raise RuntimeError(
                    f"전처리 단계 {step.name} 실패: {e}"
                ) from e

        # 처리 시간 계산 (밀리초)
        processing_time = (time.perf_counter() - start_time) * 1000

        return ProcessingResult(
            image=processed,
            original_shape=original_shape,
            applied_steps=tuple(applied_steps),
            processing_time_ms=processing_time,
        )

    def enhance_region(
        self,
        image: NDArray[np.uint8],
        region: tuple[int, int, int, int],
    ) -> ProcessingResult:
        """이미지의 특정 영역에만 전처리 적용

        전체 이미지가 아닌 관심 영역(ROI)만 처리하여
        계산 효율성을 높입니다.

        Args:
            image: 입력 이미지 (numpy 배열)
            region: 관심 영역 좌표 (x, y, width, height)

        Returns:
            지정된 영역의 전처리 결과

        Raises:
            ValueError: 영역 좌표가 유효하지 않거나 이미지 범위를 벗어난 경우
        """
        x, y, w, h = region

        # 영역 유효성 검사
        if x < 0 or y < 0 or w <= 0 or h <= 0:
            raise ValueError(f"유효하지 않은 영역 좌표: {region}")

        img_h, img_w = image.shape[:2]
        if x + w > img_w or y + h > img_h:
            raise ValueError(
                f"영역 {region}이 이미지 범위 ({img_w}, {img_h})를 벗어남"
            )

        # ROI 추출 및 처리
        roi = image[y : y + h, x : x + w]
        return self.enhance(roi)

    def enhance_batch(
        self,
        images: Sequence[NDArray[np.uint8]],
    ) -> list[ProcessingResult]:
        """여러 이미지에 전처리 일괄 적용

        배치 처리로 여러 이미지를 순차적으로 처리합니다.
        실패한 이미지는 원본 이미지가 담긴 빈 결과로 대체됩니다.

        Args:
            images: 입력 이미지들의 시퀀스

        Returns:
            각 이미지에 대한 ProcessingResult 리스트
        """
        results = []
        for i, image in enumerate(images):
            try:
                result = self.enhance(image)
                results.append(result)
            except Exception as e:
                logger.error("이미지 %d 처리 실패: %s", i, e)
                # 실패한 이미지는 빈 결과로 대체
                results.append(
                    ProcessingResult(
                        image=image,
                        original_shape=image.shape,
                        applied_steps=(),
                        processing_time_ms=0.0,
                    )
                )
        return results

    def get_quality_score(self, image: NDArray[np.uint8]) -> ImageQualityScore:
        """이미지 품질 점수 계산

        이미지의 블러, 노이즈, 대비, 밝기 균일도를 분석하여
        종합 품질 점수를 계산합니다. 적응형 전처리 설정에 활용됩니다.

        Args:
            image: 분석할 이미지 배열 (BGR 또는 그레이스케일)

        Returns:
            ImageQualityScore: 각 지표별 점수와 종합 점수

        Example:
            >>> enhancer = ImageEnhancer(PreprocessingConfig())
            >>> score = enhancer.get_quality_score(image)
            >>> print(f"품질 등급: {score.quality_level}")
        """
        # 그레이스케일로 변환 (필요시)
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        # 블러 점수: Laplacian 분산 (높을수록 선명)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        blur_score = min(laplacian_var / 500.0, 1.0)

        # 노이즈 점수: 고주파 성분 분석
        blur_img = cv2.GaussianBlur(gray, (5, 5), 0)
        noise = np.abs(gray.astype(float) - blur_img.astype(float))
        noise_level = np.mean(noise)
        noise_score = max(1.0 - noise_level / 50.0, 0.0)

        # 대비 점수: 히스토그램 범위
        hist_range = float(np.percentile(gray, 95) - np.percentile(gray, 5))
        contrast_score = min(hist_range / 200.0, 1.0)

        # 밝기 균일도: 지역 평균 분산
        mean_brightness = np.mean(gray)
        brightness_score = 1.0 - abs(mean_brightness - 128) / 128

        # 종합 점수 (가중 평균)
        overall = (
            blur_score * 0.3
            + noise_score * 0.2
            + contrast_score * 0.3
            + brightness_score * 0.2
        )

        return ImageQualityScore(
            blur_score=float(blur_score),
            noise_score=float(noise_score),
            contrast_score=float(contrast_score),
            brightness_score=float(brightness_score),
            overall_score=float(overall),
        )

    def analyze_blur(self, image: NDArray[np.uint8]) -> BlurAnalysis:
        """이미지 블러 분석

        Laplacian 분산과 FFT 분석을 통해 이미지의 블러 유형과 정도를 파악합니다.
        모션 블러의 경우 방향도 추정합니다.

        Args:
            image: 분석할 이미지 배열 (BGR 또는 그레이스케일)

        Returns:
            BlurAnalysis: 블러 유형, 정도, 방향 정보

        Example:
            >>> enhancer = ImageEnhancer(PreprocessingConfig())
            >>> analysis = enhancer.analyze_blur(image)
            >>> if analysis.needs_deblur:
            ...     print(f"블러 유형: {analysis.blur_type.value}")
        """
        # 그레이스케일로 변환
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        # 1. Laplacian 분산으로 전체 선명도 측정
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        laplacian_var = laplacian.var()

        # 블러 점수 계산 (0=선명, 1=블러)
        # 경험적 임계값: 100 이상이면 선명, 10 이하면 심한 블러
        blur_score = max(0.0, min(1.0, 1.0 - (laplacian_var / 100.0)))

        # 2. FFT 분석으로 모션 블러 방향 감지
        motion_direction = None
        motion_strength = None
        is_motion = False

        if blur_score > 0.3:  # 블러가 어느 정도 있을 때만 모션 분석
            motion_info = self._detect_motion_blur_direction(gray)
            if motion_info is not None:
                motion_direction, motion_strength = motion_info
                is_motion = motion_strength > 0.3

        # 3. 블러 유형 결정
        if blur_score <= 0.3:
            blur_type = BlurType.SHARP
            action = "선명화 불필요"
        elif is_motion:
            blur_type = BlurType.MOTION
            action = f"모션 블러 디컨볼루션 권장 (방향: {motion_direction:.1f}°)"
        elif blur_score > 0.7:
            blur_type = BlurType.OUT_OF_FOCUS
            action = "강한 언샤프 마스킹 또는 디컨볼루션 권장"
        else:
            blur_type = BlurType.GAUSSIAN
            action = "언샤프 마스킹 권장"

        return BlurAnalysis(
            blur_type=blur_type,
            blur_score=float(blur_score),
            motion_direction=motion_direction,
            motion_strength=motion_strength,
            recommended_action=action,
        )

    def _detect_motion_blur_direction(
        self, gray: NDArray[np.uint8]
    ) -> tuple[float, float] | None:
        """FFT를 이용한 모션 블러 방향 감지

        주파수 도메인에서 모션 블러의 특징적인 패턴(특정 방향의 줄무늬)을
        감지하여 블러 방향을 추정합니다.

        Args:
            gray: 그레이스케일 이미지

        Returns:
            (방향(도), 강도) 튜플 또는 감지 실패 시 None
        """
        # FFT 수행
        f = np.fft.fft2(gray.astype(np.float32))
        fshift = np.fft.fftshift(f)
        magnitude = np.log1p(np.abs(fshift))

        # 중심점 기준 방사형 프로파일 분석
        rows, cols = gray.shape
        center_row, center_col = rows // 2, cols // 2

        # 여러 각도에서 에너지 분포 측정
        angles = np.linspace(0, 180, 36)  # 5도 간격
        energies = []

        for angle in angles:
            # 해당 각도의 선을 따라 에너지 측정
            radian = np.deg2rad(angle)
            energy = 0.0
            count = 0

            for r in range(10, min(rows, cols) // 4):
                x = int(center_col + r * np.cos(radian))
                y = int(center_row + r * np.sin(radian))
                if 0 <= x < cols and 0 <= y < rows:
                    energy += magnitude[y, x]
                    count += 1

            energies.append(energy / max(count, 1))

        energies = np.array(energies)

        # 에너지 분산 분석 - 모션 블러는 특정 방향에 높은 에너지
        energy_std = np.std(energies)
        energy_mean = np.mean(energies)

        # 모션 블러 강도 (에너지 분포의 비균일성)
        motion_strength = min(1.0, energy_std / max(energy_mean, 1e-6))

        if motion_strength > 0.2:
            # 최대 에너지 방향이 모션 블러의 수직 방향
            max_idx = np.argmax(energies)
            blur_direction = (angles[max_idx] + 90) % 180
            return blur_direction, motion_strength

        return None

    def apply_adaptive_sharpen(
        self, image: NDArray[np.uint8], blur_analysis: BlurAnalysis | None = None
    ) -> NDArray[np.uint8]:
        """블러 유형에 따른 적응형 선명화

        블러 분석 결과에 따라 최적의 선명화 알고리즘을 선택하여 적용합니다:
        - SHARP: 원본 반환
        - GAUSSIAN: 언샤프 마스킹
        - MOTION: Wiener 필터 기반 디컨볼루션 (간소화 버전)
        - OUT_OF_FOCUS: 강한 언샤프 마스킹

        Args:
            image: 선명화할 이미지
            blur_analysis: 블러 분석 결과. None이면 자동 분석

        Returns:
            선명화된 이미지
        """
        if blur_analysis is None:
            blur_analysis = self.analyze_blur(image)

        if blur_analysis.blur_type == BlurType.SHARP:
            return image.copy()

        if blur_analysis.blur_type == BlurType.MOTION:
            return self._apply_motion_deblur(image, blur_analysis)
        elif blur_analysis.blur_type == BlurType.OUT_OF_FOCUS:
            return self._apply_strong_sharpen(image)
        else:  # GAUSSIAN
            return self._apply_sharpen(image)

    def _apply_motion_deblur(
        self, image: NDArray[np.uint8], blur_analysis: BlurAnalysis
    ) -> NDArray[np.uint8]:
        """모션 블러 복원 (간소화된 Wiener 필터)

        모션 블러 방향을 고려한 선명화를 적용합니다.
        완전한 Wiener 디컨볼루션 대신 방향성 샤프닝을 사용합니다.

        Args:
            image: 모션 블러가 있는 이미지
            blur_analysis: 블러 분석 결과 (방향 정보 포함)

        Returns:
            복원된 이미지
        """
        direction = blur_analysis.motion_direction or 0.0
        strength = blur_analysis.motion_strength or 0.5

        # 모션 방향에 수직인 방향으로 선명화 커널 생성
        kernel_size = 5
        kernel = np.zeros((kernel_size, kernel_size), dtype=np.float32)

        # 방향성 선명화 커널 (모션 방향과 수직)
        radian = np.deg2rad(direction + 90)
        center = kernel_size // 2

        for i in range(-center, center + 1):
            x = int(center + i * np.cos(radian))
            y = int(center + i * np.sin(radian))
            if 0 <= x < kernel_size and 0 <= y < kernel_size:
                kernel[y, x] = -0.2 * strength

        kernel[center, center] = 1.0 + 0.8 * strength

        # 커널 적용
        sharpened = cv2.filter2D(image, -1, kernel)

        # 추가 언샤프 마스킹
        blurred = cv2.GaussianBlur(sharpened, (3, 3), 1.0)
        final = cv2.addWeighted(sharpened, 1.3, blurred, -0.3, 0)

        return np.clip(final, 0, 255).astype(np.uint8)

    def _apply_strong_sharpen(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """강한 선명화 (심한 아웃포커스용)

        일반 언샤프 마스킹보다 강한 선명화를 적용합니다.
        두 단계의 선명화와 대비 향상을 결합합니다.

        Args:
            image: 선명화할 이미지

        Returns:
            강하게 선명화된 이미지
        """
        # 1단계: 가우시안 블러 기반 언샤프 마스킹
        blurred1 = cv2.GaussianBlur(image, (5, 5), 2.0)
        sharpened1 = cv2.addWeighted(image, 1.8, blurred1, -0.8, 0)

        # 2단계: 더 세밀한 언샤프 마스킹
        blurred2 = cv2.GaussianBlur(sharpened1, (3, 3), 1.0)
        sharpened2 = cv2.addWeighted(sharpened1, 1.3, blurred2, -0.3, 0)

        return np.clip(sharpened2, 0, 255).astype(np.uint8)

    def apply_single_step(
        self,
        image: NDArray[np.uint8],
        step: PreprocessingStep,
    ) -> NDArray[np.uint8]:
        """단일 전처리 단계만 적용

        디버깅이나 커스텀 파이프라인 구성 시 유용합니다.
        특정 단계의 효과만 확인하고 싶을 때 사용합니다.

        Args:
            image: 입력 이미지
            step: 적용할 전처리 단계

        Returns:
            처리된 이미지

        Raises:
            ValueError: 알 수 없는 전처리 단계인 경우
        """
        handler = self._step_handlers.get(step)
        if handler is None:
            raise ValueError(f"알 수 없는 전처리 단계: {step}")
        return handler(image)

    def __repr__(self) -> str:
        """문자열 표현 반환"""
        enabled_steps = [
            step.name
            for step in PreprocessingStep
            if self._is_step_enabled(step)
        ]
        return f"ImageEnhancer(활성화된_단계={enabled_steps})"


# ============================================================================
# 팩토리 함수: 사전 정의된 설정 생성
# ============================================================================


def create_industrial_display_config() -> PreprocessingConfig:
    """산업용 디스플레이 OCR에 최적화된 설정 생성

    7세그먼트 디스플레이, LCD 패널 등 일반적인 산업용 디스플레이를
    다양한 조명 조건에서 인식하기 위해 최적화된 설정입니다.

    특징:
        - CLAHE로 지역적 대비 향상 (불균일한 조명 보정)
        - 적응형 가우시안 이진화 (그림자 대응)
        - CLOSING 연산으로 글자 구조 개선

    Returns:
        산업용 디스플레이 OCR에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_clahe=True,
        clahe_clip_limit=3.0,  # 중간 강도의 대비 향상
        clahe_grid_size=(8, 8),
        enable_gaussian_blur=True,
        gaussian_kernel_size=(3, 3),  # 가벼운 블러
        enable_bilateral_filter=False,
        enable_binarization=True,
        binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
        adaptive_block_size=15,  # 중간 크기 블록
        adaptive_c=3,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.CLOSING,  # 글자 연결
        morphological_kernel_size=(2, 2),
        morphological_iterations=1,
        enable_sharpen=False,
        enable_denoise=False,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=False,
    )


def create_low_contrast_config() -> PreprocessingConfig:
    """저대비 디스플레이 이미지용 설정 생성

    색이 바래거나 조명이 약한 디스플레이를 위해
    대비 향상을 강조한 설정입니다.

    특징:
        - 강한 CLAHE 적용 (clip_limit=4.0, 작은 그리드)
        - 양방향 필터로 노이즈 제거하면서 엣지 보존
        - 정규화로 동적 범위 최대화
        - 선명화로 흐릿한 엣지 복원

    Returns:
        저대비 이미지 처리에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_clahe=True,
        clahe_clip_limit=4.0,  # 강한 대비 향상
        clahe_grid_size=(4, 4),  # 더 지역적인 적응
        enable_gaussian_blur=True,
        gaussian_kernel_size=(5, 5),
        enable_bilateral_filter=True,  # 엣지 보존 스무딩 활성화
        bilateral_d=9,
        bilateral_sigma_color=100.0,
        bilateral_sigma_space=100.0,
        enable_binarization=True,
        binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
        adaptive_block_size=21,  # 더 큰 블록 (저대비 보상)
        adaptive_c=5,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.OPENING,  # 노이즈 제거
        morphological_kernel_size=(3, 3),
        morphological_iterations=1,
        enable_sharpen=True,  # 선명화 활성화
        sharpen_amount=0.5,  # 적당한 선명화
        enable_denoise=True,  # 노이즈 제거 활성화
        denoise_strength=7.0,
        enable_resize=False,
        enable_normalize=True,  # 정규화 활성화
        normalize_alpha=0,
        normalize_beta=255,
        invert_colors=False,
        # 엣지 강조: 저대비에서 유사 문자 구분력 향상
        enable_edge_enhancement=True,
        edge_method="laplacian",
        edge_weight=0.3,
    )


def create_noisy_image_config() -> PreprocessingConfig:
    """노이즈가 많은 디스플레이 이미지용 설정 생성

    간섭이나 노이즈가 심한 이미지를 위해
    노이즈 제거를 강조한 설정입니다.

    특징:
        - 강한 노이즈 제거 (denoise_strength=12.0)
        - 양방향 필터와 가우시안 블러 병용
        - 오츠 이진화 (히스토그램 기반 자동 임계값)
        - OPENING 연산 2회 반복 (강력한 노이즈 제거)

    Returns:
        노이즈 이미지 처리에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_clahe=True,
        clahe_clip_limit=2.0,  # 노이즈 증폭 방지를 위해 낮게
        clahe_grid_size=(8, 8),
        enable_gaussian_blur=True,
        gaussian_kernel_size=(5, 5),  # 강한 블러
        gaussian_sigma=1.5,
        enable_bilateral_filter=True,  # 엣지 보존 노이즈 제거
        bilateral_d=9,
        bilateral_sigma_color=75.0,
        bilateral_sigma_space=75.0,
        enable_binarization=True,
        binarization_method=BinarizationMethod.OTSU,  # 자동 임계값
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.OPENING,  # 노이즈 제거
        morphological_kernel_size=(3, 3),
        morphological_iterations=2,  # 2회 반복
        enable_sharpen=False,  # 노이즈 증폭 방지
        enable_denoise=True,  # 강한 노이즈 제거
        denoise_strength=12.0,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=False,
    )


def create_adaptive_config(quality: ImageQualityScore) -> PreprocessingConfig:
    """이미지 품질에 따른 적응형 설정 생성

    ImageQualityScore의 품질 등급에 따라 최적화된 전처리 설정을 반환합니다.

    Args:
        quality: get_quality_score()로 계산된 품질 점수

    Returns:
        PreprocessingConfig: 품질 등급에 맞는 전처리 설정
            - high: 최소 처리 (품질 보존)
            - medium: 표준 처리 (산업용 디스플레이 설정)
            - low: 강화된 처리 (노이즈 제거, Sauvola, Deskew 활성화)

    Example:
        >>> enhancer = ImageEnhancer(PreprocessingConfig())
        >>> quality = enhancer.get_quality_score(image)
        >>> adaptive_config = create_adaptive_config(quality)
        >>> enhanced_enhancer = ImageEnhancer(adaptive_config)
        >>> result = enhanced_enhancer.enhance(image)
    """
    if quality.quality_level == "high":
        # 고품질: 최소 처리로 원본 품질 보존
        return PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_binarization=True,
            binarization_method=BinarizationMethod.OTSU,
            enable_morphological=False,
        )
    elif quality.quality_level == "medium":
        # 중간 품질: 산업용 디스플레이 표준 처리
        return create_industrial_display_config()
    else:
        # 저품질: 강화된 전처리 파이프라인
        return PreprocessingConfig(
            enable_grayscale=True,
            enable_deskew=True,
            enable_clahe=True,
            clahe_clip_limit=4.0,
            enable_gaussian_blur=True,
            enable_denoise=True,
            denoise_strength=12.0,
            enable_binarization=True,
            binarization_method=BinarizationMethod.SAUVOLA,
            enable_morphological=True,
            morphological_operation=MorphologicalOperation.CLOSING,
            enable_sharpen=True,
            sharpen_amount=0.5,
        )


def create_7segment_config() -> PreprocessingConfig:
    """7-세그먼트 LED 디스플레이 최적화 설정

    7-세그먼트 LED 디스플레이의 특성에 맞춰 최적화된 설정입니다:
    - 일반적으로 고대비 (밝은 세그먼트 on 어두운 배경)
    - 단순한 숫자 패턴
    - 색상 반전 필요할 수 있음

    특징:
        - OTSU 이진화: 고대비 이미지에 효과적
        - OPENING 연산: 세그먼트 간 노이즈 제거
        - 선명화 비활성화: 이미 선명한 엣지

    Returns:
        7-세그먼트 디스플레이 OCR에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_deskew=False,  # 7-세그먼트는 보통 수평
        enable_clahe=True,
        clahe_clip_limit=2.0,
        clahe_grid_size=(4, 4),  # 작은 그리드 (숫자 크기 고려)
        enable_gaussian_blur=False,  # 블러 불필요
        enable_bilateral_filter=False,
        enable_binarization=True,
        binarization_method=BinarizationMethod.OTSU,  # 고대비에 적합
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.OPENING,  # 세그먼트 분리
        morphological_kernel_size=(2, 2),
        morphological_iterations=1,
        enable_sharpen=False,
        enable_denoise=False,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=False,  # 필요시 True로 설정
        # 문자 브리징: 끊어진 세그먼트 연결
        enable_character_bridging=True,
        bridging_kernel_shape="horizontal",  # 7-세그먼트는 수평 획이 많음
        bridging_kernel_size=(3, 1),
        bridging_iterations=1,
    )


def create_lcd_panel_config() -> PreprocessingConfig:
    """LCD 패널 디스플레이 최적화 설정

    LCD 패널 (HMI 포함)의 특성에 맞춰 최적화된 설정입니다:
    - 반사 및 모아레 패턴 가능
    - 텍스트와 숫자 혼합
    - 다양한 폰트와 크기

    특징:
        - Bilateral 필터: 엣지 보존하면서 노이즈/모아레 감소
        - CLAHE: 화면 밝기 불균일 보정
        - Sauvola 이진화: 반사광에 강함

    Returns:
        LCD 패널 OCR에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_deskew=True,  # 카메라 각도 보정
        deskew_max_angle=10.0,
        enable_clahe=True,
        clahe_clip_limit=3.0,
        clahe_grid_size=(8, 8),
        enable_gaussian_blur=False,
        enable_bilateral_filter=True,  # 모아레 패턴 제거
        bilateral_d=5,
        bilateral_sigma_color=50,
        bilateral_sigma_space=50,
        enable_binarization=True,
        binarization_method=BinarizationMethod.SAUVOLA,  # 반사광 대응
        adaptive_block_size=21,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.CLOSING,
        morphological_kernel_size=(2, 2),
        morphological_iterations=1,
        enable_sharpen=False,
        enable_denoise=True,
        denoise_strength=6.0,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=False,
    )


def create_hmi_touchscreen_config() -> PreprocessingConfig:
    """HMI 터치스크린 최적화 설정

    산업용 HMI 터치스크린의 특성에 맞춰 최적화된 설정입니다:
    - 다양한 UI 요소 (버튼, 라벨, 숫자)
    - 밝은 배경에 어두운 텍스트가 일반적
    - 화면 크기와 해상도 다양

    특징:
        - 적응형 가우시안 이진화: 다양한 UI 요소 처리
        - 중간 강도 노이즈 제거
        - CLOSING 연산으로 얇은 폰트 보강

    Returns:
        HMI 터치스크린 OCR에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_deskew=True,
        deskew_max_angle=15.0,
        enable_clahe=True,
        clahe_clip_limit=2.5,
        clahe_grid_size=(8, 8),
        enable_gaussian_blur=True,
        gaussian_kernel_size=(3, 3),
        gaussian_sigma=0.5,
        enable_bilateral_filter=False,
        enable_binarization=True,
        binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
        adaptive_block_size=15,
        adaptive_c=3,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.CLOSING,
        morphological_kernel_size=(2, 2),
        morphological_iterations=1,
        enable_sharpen=False,
        enable_denoise=True,
        denoise_strength=8.0,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=False,
    )


def create_led_display_config() -> PreprocessingConfig:
    """대형 LED 전광판 최적화 설정

    대형 LED 전광판의 특성에 맞춰 최적화된 설정입니다:
    - 개별 LED 픽셀이 보이는 경우 있음
    - 높은 대비 (밝은 LED on 어두운 배경)
    - 주로 숫자와 간단한 텍스트

    특징:
        - 강한 가우시안 블러: LED 픽셀 병합
        - OTSU 이진화: 고대비에 적합
        - 형태학적 연산으로 문자 구조 정리

    Returns:
        LED 전광판 OCR에 최적화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_deskew=False,
        enable_clahe=False,  # 이미 고대비
        enable_gaussian_blur=True,
        gaussian_kernel_size=(5, 5),  # LED 픽셀 병합용
        gaussian_sigma=1.5,
        enable_bilateral_filter=False,
        enable_binarization=True,
        binarization_method=BinarizationMethod.OTSU,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.CLOSING,
        morphological_kernel_size=(3, 3),  # 큰 커널로 LED 간격 연결
        morphological_iterations=2,
        enable_sharpen=False,
        enable_denoise=False,
        enable_resize=False,
        enable_normalize=False,
        invert_colors=True,  # 밝은 글자 → 어두운 글자
    )


def create_blur_enhanced_config(blur_analysis: BlurAnalysis) -> PreprocessingConfig:
    """블러 분석 결과 기반 강화된 전처리 설정

    블러 분석 결과에 따라 선명화와 노이즈 제거를 조정한 설정입니다.

    Args:
        blur_analysis: ImageEnhancer.analyze_blur()의 결과

    Returns:
        블러 유형에 맞춰 최적화된 PreprocessingConfig
    """
    base_config = create_industrial_display_config()

    if blur_analysis.blur_type == BlurType.SHARP:
        # 선명한 이미지: 기본 설정 사용
        return base_config

    elif blur_analysis.blur_type == BlurType.MOTION:
        # 모션 블러: 선명화 강화, 노이즈 제거 감소
        return PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=True,
            clahe_clip_limit=2.5,
            enable_gaussian_blur=False,  # 블러 추가 금지
            enable_bilateral_filter=False,
            enable_binarization=True,
            binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
            adaptive_block_size=11,
            enable_morphological=True,
            morphological_operation=MorphologicalOperation.CLOSING,
            enable_sharpen=True,
            sharpen_amount=0.8 + (blur_analysis.blur_score * 0.5),  # 블러 정도에 비례
            enable_denoise=False,
        )

    elif blur_analysis.blur_type == BlurType.OUT_OF_FOCUS:
        # 심한 아웃포커스: 강한 선명화 + 노이즈 제거
        return PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=True,
            clahe_clip_limit=3.5,
            enable_gaussian_blur=False,
            enable_bilateral_filter=True,  # 엣지 보존 스무딩
            bilateral_d=5,
            enable_binarization=True,
            binarization_method=BinarizationMethod.SAUVOLA,
            enable_morphological=True,
            morphological_operation=MorphologicalOperation.CLOSING,
            morphological_iterations=2,
            enable_sharpen=True,
            sharpen_amount=1.2,
            enable_denoise=True,
            denoise_strength=10.0,
        )

    else:  # GAUSSIAN
        # 가우시안 블러: 표준 선명화
        return PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=True,
            clahe_clip_limit=3.0,
            enable_gaussian_blur=False,
            enable_bilateral_filter=False,
            enable_binarization=True,
            binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
            enable_morphological=True,
            morphological_operation=MorphologicalOperation.CLOSING,
            enable_sharpen=True,
            sharpen_amount=0.6 + (blur_analysis.blur_score * 0.4),
            enable_denoise=True,
            denoise_strength=6.0,
        )


def get_config_for_display_type(display_type: DisplayType) -> PreprocessingConfig:
    """디스플레이 유형에 맞는 설정 반환

    Args:
        display_type: 디스플레이 유형

    Returns:
        해당 유형에 최적화된 PreprocessingConfig
    """
    config_map = {
        DisplayType.SEVEN_SEGMENT: create_7segment_config,
        DisplayType.LCD_PANEL: create_lcd_panel_config,
        DisplayType.HMI_TOUCHSCREEN: create_hmi_touchscreen_config,
        DisplayType.LED_DISPLAY: create_led_display_config,
        DisplayType.UNKNOWN: create_industrial_display_config,
    }

    factory = config_map.get(display_type, create_industrial_display_config)
    return factory()


def create_ocr_optimized_config() -> PreprocessingConfig:
    """OCR 인식률 최적화 통합 설정

    OCR 정확도 향상을 위해 CHARACTER_BRIDGING과 EDGE_ENHANCEMENT를
    모두 활성화한 설정입니다. 다양한 디스플레이 유형에 범용으로 사용 가능합니다.

    특징:
        - 엣지 강조: 유사 문자(0/O, 1/l, S/5, B/8) 구분력 향상
        - 문자 브리징: 끊어진 문자 획 연결
        - 적응형 이진화: 다양한 조명 조건 대응
        - 형태학적 연산: 노이즈 제거 및 문자 보강

    Returns:
        OCR 인식률 최적화에 특화된 PreprocessingConfig
    """
    return PreprocessingConfig(
        enable_grayscale=True,
        enable_deskew=True,
        deskew_max_angle=10.0,
        enable_clahe=True,
        clahe_clip_limit=3.0,
        clahe_grid_size=(8, 8),
        enable_gaussian_blur=False,
        enable_bilateral_filter=True,
        bilateral_d=5,
        bilateral_sigma_color=50,
        bilateral_sigma_space=50,
        enable_binarization=True,
        binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
        adaptive_block_size=15,
        adaptive_c=4,
        enable_morphological=True,
        morphological_operation=MorphologicalOperation.CLOSING,
        morphological_kernel_size=(2, 2),
        morphological_iterations=1,
        enable_sharpen=False,
        enable_denoise=True,
        denoise_strength=5.0,
        enable_resize=False,
        enable_normalize=True,
        normalize_alpha=0,
        normalize_beta=255,
        invert_colors=False,
        # 엣지 강조: 유사 문자 구분력 향상
        enable_edge_enhancement=True,
        edge_method="laplacian",
        edge_weight=0.25,
        # 문자 브리징: 끊어진 획 연결
        enable_character_bridging=True,
        bridging_kernel_shape="cross",
        bridging_kernel_size=(3, 3),
        bridging_iterations=1,
    )
