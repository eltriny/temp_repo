"""
Image Preprocessing Module for Industrial Video Monitoring System.

This module provides image preprocessing capabilities optimized for
enhancing industrial display images before OCR recognition.

Features:
    - CLAHE (Contrast Limited Adaptive Histogram Equalization)
    - Gaussian blur noise reduction
    - Adaptive binarization (Otsu, adaptive threshold)
    - Morphological operations (erosion, dilation, opening, closing)
    - Customizable preprocessing pipeline

Example:
    >>> from src.preprocessing import ImageEnhancer, PreprocessingConfig
    >>> config = PreprocessingConfig(enable_clahe=True, enable_binarization=True)
    >>> enhancer = ImageEnhancer(config)
    >>> enhanced_image = enhancer.enhance(image)
"""

from .image_enhancer import (
    PreprocessingConfig,
    ImageEnhancer,
    PreprocessingStep,
    MorphologicalOperation,
    BinarizationMethod,
    ProcessingResult,
    ImageQualityScore,
    # 블러 분석 관련
    BlurType,
    BlurAnalysis,
    DisplayType,
    # 팩토리 함수
    create_industrial_display_config,
    create_low_contrast_config,
    create_noisy_image_config,
    create_adaptive_config,
    # 디스플레이 유형별 설정
    create_7segment_config,
    create_lcd_panel_config,
    create_hmi_touchscreen_config,
    create_led_display_config,
    create_blur_enhanced_config,
    get_config_for_display_type,
    # OCR 최적화 설정
    create_ocr_optimized_config,
)

__all__ = [
    "PreprocessingConfig",
    "ImageEnhancer",
    "PreprocessingStep",
    "MorphologicalOperation",
    "BinarizationMethod",
    "ProcessingResult",
    "ImageQualityScore",
    # 블러 분석 관련
    "BlurType",
    "BlurAnalysis",
    "DisplayType",
    # 팩토리 함수
    "create_industrial_display_config",
    "create_low_contrast_config",
    "create_noisy_image_config",
    "create_adaptive_config",
    # 디스플레이 유형별 설정
    "create_7segment_config",
    "create_lcd_panel_config",
    "create_hmi_touchscreen_config",
    "create_led_display_config",
    "create_blur_enhanced_config",
    "get_config_for_display_type",
    # OCR 최적화 설정
    "create_ocr_optimized_config",
]

__version__ = "0.2.0"
