"""
코어 처리 모듈

비디오 프레임 추출 및 병렬 처리를 담당합니다.

주요 구성요소:
- VideoProcessor: Generator 기반 메모리 효율적 프레임 추출
- ParallelProcessor: ROI별 병렬 처리 오케스트레이터
- FrameData: 프레임 메타데이터 및 데이터 컨테이너
"""

from .video_processor import VideoProcessor, FrameData
from .parallel_processor import ParallelProcessor

__all__ = [
    "VideoProcessor",
    "FrameData",
    "ParallelProcessor",
]
