"""
OCR Module for Industrial Video Monitoring System.

This module provides OCR (Optical Character Recognition) capabilities
optimized for industrial display digit recognition.

Features:
    - PaddleOCR PP-OCRv4 integration with optimized settings
    - Confidence score filtering
    - Batch processing support
    - Thread-safe operation
    - Text correction for similar character handling (0↔O, 1↔l, !→1)
    - Space normalization for improved accuracy

Example:
    >>> from src.ocr import OCREngine, OCRConfig, OCRResult
    >>> config = OCRConfig(numeric_only=True, confidence_threshold=0.8)
    >>> engine = OCREngine(config)
    >>> result = engine.recognize(image)
    >>> print(result.text, result.confidence)

Text Correction Example:
    >>> from src.ocr import TextCorrector, TextCorrectionConfig
    >>> corrector = TextCorrector()
    >>> result = corrector.correct("Temper ature: l23.45°C")
    >>> print(result.corrected_text)
    "Temperature: 123.45°C"
"""

from .ocr_engine import (
    OCRConfig,
    OCREngine,
    OCRResult,
    OCRBatchResult,
    OCRLanguage,
    create_7segment_ocr_config,
    create_industrial_ocr_config,
    create_label_value_ocr_config,
)
from .text_corrector import (
    CorrectionResult,
    CorrectionStep,
    TextContext,
    TextCorrectionConfig,
    TextCorrector,
    create_default_correction_config,
    create_minimal_correction_config,
    create_numeric_only_correction_config,
)

__all__ = [
    # 기본 OCR
    "OCRConfig",
    "OCREngine",
    "OCRResult",
    "OCRBatchResult",
    "OCRLanguage",
    # OCR 설정 팩토리
    "create_industrial_ocr_config",
    "create_7segment_ocr_config",
    "create_label_value_ocr_config",
    # 텍스트 교정
    "TextCorrector",
    "TextCorrectionConfig",
    "TextContext",
    "CorrectionStep",
    "CorrectionResult",
    "create_default_correction_config",
    "create_numeric_only_correction_config",
    "create_minimal_correction_config",
]

__version__ = "0.5.0"
