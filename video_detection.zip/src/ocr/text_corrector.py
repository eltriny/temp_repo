"""OCR 텍스트 교정 모듈

산업용 OCR 결과의 정확도를 향상시키기 위한 후처리 교정 모듈입니다.

주요 기능:
    - 공백 정규화: 불필요한 공백 제거, 의미 있는 공백 보존
    - 유사 문자 교정: 컨텍스트 기반 문자 교정 (0↔O, 1↔l, !→1 등)
    - 산업용 패턴 검증: 단위, 에러코드, 측정값 패턴 인식
    - 신뢰도 조정: 교정 적용 시 페널티, 패턴 일치 시 보너스

설계 패턴:
    - 전략 패턴: 각 교정 단계를 독립적인 핸들러로 구현
    - 파이프라인 패턴: 설정 가능한 순서로 단계들을 체이닝

Example:
    >>> from src.ocr.text_corrector import TextCorrector, TextCorrectionConfig
    >>> config = TextCorrectionConfig(enable_space_normalize=True)
    >>> corrector = TextCorrector(config)
    >>> result = corrector.correct("Temper ature: l23.45°C")
    >>> print(result.corrected_text)
    "Temperature: 123.45°C"
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable

logger = logging.getLogger(__name__)


# ========================================
# Enums
# ========================================


class CorrectionStep(Enum):
    """교정 파이프라인 단계

    파이프라인 순서:
        1. SPACE_NORMALIZE: 불필요한 공백 제거 (가장 먼저)
        2. CONTEXT_DETECT: 컨텍스트 자동 감지
        3. SIMILAR_CHAR_CORRECT: 유사 문자 교정
        4. PATTERN_VALIDATE: 산업용 패턴 검증
        5. UNIT_NORMALIZE: 단위 정규화
    """

    SPACE_NORMALIZE = auto()
    CONTEXT_DETECT = auto()
    SIMILAR_CHAR_CORRECT = auto()
    PATTERN_VALIDATE = auto()
    UNIT_NORMALIZE = auto()


class TextContext(Enum):
    """텍스트 컨텍스트 유형

    Attributes:
        NUMERIC: 순수 숫자 (예: 123.45, -67.89)
        MEASUREMENT: 측정값 + 단위 (예: 25.5°C, 100Hz)
        ERROR_CODE: 에러/상태 코드 (예: E01, ERR-123)
        LABEL: 순수 텍스트 라벨 (예: Temperature, Status)
        MIXED: 라벨 + 값 혼합 (예: Temperature: 25.5°C)
        UNKNOWN: 판별 불가
    """

    NUMERIC = "numeric"
    MEASUREMENT = "measurement"
    ERROR_CODE = "error_code"
    LABEL = "label"
    MIXED = "mixed"
    UNKNOWN = "unknown"


# ========================================
# 교정 규칙 상수
# ========================================


# 숫자 컨텍스트에서 적용할 문자 변환 (문자 → 숫자)
NUMERIC_CHAR_MAP: dict[str, str] = {
    "O": "0",
    "o": "0",
    "l": "1",
    "I": "1",
    "!": "1",
    "|": "1",
    "S": "5",
    "s": "5",
    "B": "8",
    "Z": "2",
    "z": "2",
    "G": "6",
    "g": "9",
    "q": "9",
}

# 영문 컨텍스트에서 적용할 문자 변환 (숫자 → 문자)
TEXT_CHAR_MAP: dict[str, str] = {
    "0": "O",
    "1": "l",
    "5": "S",
    "8": "B",
    "2": "Z",
    "6": "G",
}

# 산업용 단위 목록 (정규화된 형태)
INDUSTRIAL_UNITS: frozenset[str] = frozenset(
    {
        # 온도
        "°C",
        "°F",
        "K",
        "℃",
        "℉",
        # 주파수
        "Hz",
        "kHz",
        "MHz",
        "GHz",
        # 전기
        "V",
        "mV",
        "kV",
        "A",
        "mA",
        "μA",
        "W",
        "kW",
        "MW",
        "Ω",
        "kΩ",
        "MΩ",
        # 압력
        "bar",
        "mbar",
        "Pa",
        "kPa",
        "MPa",
        "psi",
        "atm",
        # 무게/질량
        "kg",
        "g",
        "mg",
        "lb",
        "oz",
        "t",
        # 길이
        "m",
        "cm",
        "mm",
        "μm",
        "nm",
        "km",
        "in",
        "ft",
        # 용량
        "L",
        "mL",
        "μL",
        "gal",
        # 유량
        "L/min",
        "L/h",
        "m³/h",
        "GPM",
        # 속도
        "rpm",
        "m/s",
        "km/h",
        "mph",
        # 퍼센트
        "%",
        "ppm",
        "ppb",
        # 시간
        "s",
        "ms",
        "μs",
        "min",
        "h",
    }
)

# 단위 정규화 맵 (오인식 → 정상)
UNIT_NORMALIZATION_MAP: dict[str, str] = {
    "0C": "°C",
    "OC": "°C",
    "0F": "°F",
    "OF": "°F",
    "H2": "Hz",
    "HZ": "Hz",
    "hz": "Hz",
    "k6": "kg",
    "K6": "kg",
    "K6": "kg",
    "kpa": "kPa",
    "KPA": "kPa",
    "mpa": "MPa",
    "MPA": "MPa",
    "PSI": "psi",
}

# 에러 코드 패턴 (정규식)
ERROR_CODE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"^E\d{1,4}$", re.IGNORECASE),  # E01, E001
    re.compile(r"^F\d{1,4}$", re.IGNORECASE),  # F01, F001
    re.compile(r"^A\d{1,4}$", re.IGNORECASE),  # A01, A001
    re.compile(r"^W\d{1,4}$", re.IGNORECASE),  # W01, W001
    re.compile(r"^ERR[-]?\d{1,4}$", re.IGNORECASE),  # ERR-001
    re.compile(r"^ALM[-]?\d{1,4}$", re.IGNORECASE),  # ALM-001
    re.compile(r"^WRN[-]?\d{1,4}$", re.IGNORECASE),  # WRN-001
)

# 상태 키워드 목록
STATUS_KEYWORDS: frozenset[str] = frozenset(
    {
        "OK",
        "READY",
        "RUN",
        "RUNNING",
        "STOP",
        "STOPPED",
        "PAUSE",
        "PAUSED",
        "ON",
        "OFF",
        "IDLE",
        "BUSY",
        "STANDBY",
        "ERROR",
        "ERR",
        "FAULT",
        "FAIL",
        "FAILED",
        "ALARM",
        "ALM",
        "WARNING",
        "WARN",
        "WRN",
        "CAUTION",
        "STATUS",
        "STATE",
        "MODE",
        "LEVEL",
        "TEMP",
        "TEMPERATURE",
        "PRESSURE",
        "FLOW",
        "SPEED",
        "VOLTAGE",
        "CURRENT",
        "POWER",
    }
)


# ========================================
# 데이터 클래스
# ========================================


@dataclass(frozen=True, slots=True)
class CorrectionResult:
    """교정 결과

    Attributes:
        original_text: 원본 OCR 텍스트
        corrected_text: 교정된 텍스트
        confidence_delta: 신뢰도 변화량 (음수: 페널티, 양수: 보너스)
        applied_corrections: 적용된 교정 목록 (설명 문자열)
        detected_context: 감지된 텍스트 컨텍스트

    Example:
        >>> result = CorrectionResult(
        ...     original_text="l23.45",
        ...     corrected_text="123.45",
        ...     confidence_delta=-0.01,
        ...     applied_corrections=("!→1 (숫자 문맥)",),
        ...     detected_context=TextContext.NUMERIC,
        ... )
    """

    original_text: str
    corrected_text: str
    confidence_delta: float = 0.0
    applied_corrections: tuple[str, ...] = ()
    detected_context: TextContext = TextContext.UNKNOWN

    @property
    def was_corrected(self) -> bool:
        """교정이 적용되었는지 확인합니다."""
        return self.original_text != self.corrected_text

    @property
    def correction_count(self) -> int:
        """적용된 교정 개수를 반환합니다."""
        return len(self.applied_corrections)


@dataclass
class TextCorrectionConfig:
    """텍스트 교정 설정

    Attributes:
        enable_space_normalize: 공백 정규화 활성화
        enable_similar_char_correction: 유사 문자 교정 활성화
        enable_context_detection: 컨텍스트 자동 감지 활성화
        enable_pattern_validation: 산업용 패턴 검증 활성화
        enable_unit_normalize: 단위 정규화 활성화
        confidence_penalty_per_correction: 교정당 신뢰도 페널티
        max_confidence_penalty: 최대 신뢰도 페널티
        pattern_match_bonus: 패턴 일치 시 신뢰도 보너스
        preserve_spaces_in_labels: 라벨 내 의미 있는 공백 보존
        pipeline_order: 커스텀 파이프라인 순서 (None이면 기본 순서)

    Example:
        >>> config = TextCorrectionConfig(
        ...     enable_space_normalize=True,
        ...     enable_similar_char_correction=True,
        ...     confidence_penalty_per_correction=0.01,
        ... )
    """

    enable_space_normalize: bool = True
    enable_similar_char_correction: bool = True
    enable_context_detection: bool = True
    enable_pattern_validation: bool = True
    enable_unit_normalize: bool = True
    confidence_penalty_per_correction: float = 0.01
    max_confidence_penalty: float = 0.15
    pattern_match_bonus: float = 0.03
    preserve_spaces_in_labels: bool = True
    pipeline_order: tuple[CorrectionStep, ...] | None = None

    def get_pipeline_order(self) -> tuple[CorrectionStep, ...]:
        """파이프라인 순서를 반환합니다.

        Returns:
            설정된 순서 또는 기본 순서
        """
        if self.pipeline_order is not None:
            return self.pipeline_order
        return (
            CorrectionStep.SPACE_NORMALIZE,
            CorrectionStep.CONTEXT_DETECT,
            CorrectionStep.SIMILAR_CHAR_CORRECT,
            CorrectionStep.PATTERN_VALIDATE,
            CorrectionStep.UNIT_NORMALIZE,
        )


# ========================================
# 메인 교정 클래스
# ========================================


class TextCorrector:
    """OCR 텍스트 교정기

    산업용 OCR 결과를 후처리하여 인식 정확도를 향상시킵니다.
    전략 패턴과 파이프라인 패턴을 적용하여 설정 가능한 교정을 수행합니다.

    Attributes:
        config: 교정 설정

    Example:
        >>> corrector = TextCorrector()
        >>> result = corrector.correct("Temper ature: l23.45°C")
        >>> print(result.corrected_text)
        "Temperature: 123.45°C"
        >>> print(result.applied_corrections)
        ("단어내부공백제거", "l→1 (숫자 문맥)")
    """

    def __init__(self, config: TextCorrectionConfig | None = None) -> None:
        """텍스트 교정기를 초기화합니다.

        Args:
            config: 교정 설정. None이면 기본값 사용.
        """
        self._config = config or TextCorrectionConfig()
        self._current_context = TextContext.UNKNOWN

        # 단계별 핸들러 매핑 (전략 패턴)
        self._step_handlers: dict[
            CorrectionStep,
            Callable[[str], tuple[str, list[str]]],
        ] = {
            CorrectionStep.SPACE_NORMALIZE: self._apply_space_normalize,
            CorrectionStep.CONTEXT_DETECT: self._apply_context_detect,
            CorrectionStep.SIMILAR_CHAR_CORRECT: self._apply_similar_char_correct,
            CorrectionStep.PATTERN_VALIDATE: self._apply_pattern_validate,
            CorrectionStep.UNIT_NORMALIZE: self._apply_unit_normalize,
        }

        logger.info("TextCorrector 초기화 완료, 설정: %s", self._config)

    @property
    def config(self) -> TextCorrectionConfig:
        """현재 설정을 반환합니다."""
        return self._config

    def correct(
        self,
        text: str,
        hint_context: TextContext | None = None,
    ) -> CorrectionResult:
        """텍스트 교정을 수행합니다.

        파이프라인 순서대로 교정 단계를 적용하고 결과를 반환합니다.

        Args:
            text: 원본 OCR 텍스트
            hint_context: 컨텍스트 힌트 (None이면 자동 감지)

        Returns:
            CorrectionResult: 교정 결과

        Example:
            >>> result = corrector.correct("l23.45°C")
            >>> result.corrected_text
            "123.45°C"
        """
        if not text:
            return CorrectionResult(
                original_text=text,
                corrected_text=text,
                detected_context=TextContext.UNKNOWN,
            )

        original = text
        corrected = text
        all_corrections: list[str] = []

        # 컨텍스트 초기화
        self._current_context = hint_context or TextContext.UNKNOWN

        # 파이프라인 실행
        for step in self._config.get_pipeline_order():
            if not self._is_step_enabled(step):
                continue

            handler = self._step_handlers.get(step)
            if handler is None:
                continue

            try:
                corrected, corrections = handler(corrected)
                all_corrections.extend(corrections)
            except Exception as e:
                logger.warning("교정 단계 %s 실패: %s", step.name, e)

        # 신뢰도 조정 계산
        confidence_delta = self._calculate_confidence_delta(
            all_corrections,
            self._current_context,
        )

        return CorrectionResult(
            original_text=original,
            corrected_text=corrected,
            confidence_delta=confidence_delta,
            applied_corrections=tuple(all_corrections),
            detected_context=self._current_context,
        )

    def _is_step_enabled(self, step: CorrectionStep) -> bool:
        """특정 교정 단계가 활성화되어 있는지 확인합니다."""
        step_config_map = {
            CorrectionStep.SPACE_NORMALIZE: self._config.enable_space_normalize,
            CorrectionStep.CONTEXT_DETECT: self._config.enable_context_detection,
            CorrectionStep.SIMILAR_CHAR_CORRECT: self._config.enable_similar_char_correction,
            CorrectionStep.PATTERN_VALIDATE: self._config.enable_pattern_validation,
            CorrectionStep.UNIT_NORMALIZE: self._config.enable_unit_normalize,
        }
        return step_config_map.get(step, True)

    def _calculate_confidence_delta(
        self,
        corrections: list[str],
        context: TextContext,
    ) -> float:
        """신뢰도 변화량을 계산합니다.

        Args:
            corrections: 적용된 교정 목록
            context: 감지된 컨텍스트

        Returns:
            신뢰도 변화량 (음수: 페널티, 양수: 보너스)
        """
        # 교정 페널티
        penalty = len(corrections) * self._config.confidence_penalty_per_correction
        penalty = min(penalty, self._config.max_confidence_penalty)

        # 패턴 일치 보너스
        bonus = 0.0
        if context in (TextContext.MEASUREMENT, TextContext.ERROR_CODE):
            bonus = self._config.pattern_match_bonus

        return bonus - penalty

    # ========================================
    # 파이프라인 단계 핸들러
    # ========================================

    def _apply_space_normalize(self, text: str) -> tuple[str, list[str]]:
        """공백 정규화를 적용합니다.

        처리 규칙:
            1. 연속 공백 → 단일 공백
            2. 단어 내부 공백 제거 (소문자-공백-소문자)
            3. CamelCase 내부 공백 제거 (대문자-공백-소문자)
            4. 대문자-공백-대문자 연결
            5. 소문자-공백-대문자 연결
            6. 숫자 내부 공백 제거
            7. 숫자-공백-영문자 연결
            8. 영문자-공백-숫자 연결
            9. 선행/후행 공백 제거

        Args:
            text: 입력 텍스트

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []
        result = text

        # 1. 연속 공백 단일화
        if re.search(r"\s{2,}", result):
            result = re.sub(r"\s{2,}", " ", result)
            corrections.append("연속공백단일화")

        # 2. 소문자-공백-소문자 패턴 (단어 내부 공백)
        # 예: "Temper ature" → "Temperature"
        pattern_lower = r"([a-z])\s+([a-z])"
        if re.search(pattern_lower, result):
            result = re.sub(pattern_lower, r"\1\2", result)
            corrections.append("단어내부공백제거")

        # 3. 대문자-공백-소문자 패턴 (CamelCase)
        # 예: "T emperature" → "Temperature"
        pattern_camel = r"([A-Z])\s+([a-z])"
        if re.search(pattern_camel, result):
            result = re.sub(pattern_camel, r"\1\2", result)
            corrections.append("대소문자연결")

        # 4. 대문자-공백-대문자 패턴
        # 예: "VYLvQ8Ky LXzv" → "VYLvQ8KyLXzv"
        pattern_upper_upper = r"([A-Z])\s+([A-Z])"
        if re.search(pattern_upper_upper, result):
            result = re.sub(pattern_upper_upper, r"\1\2", result)
            corrections.append("대문자연결")

        # 5. 소문자-공백-대문자 패턴
        # 예: "pPeOr IXJgJC" → "pPeOrIXJgJC"
        pattern_lower_upper = r"([a-z])\s+([A-Z])"
        if re.search(pattern_lower_upper, result):
            result = re.sub(pattern_lower_upper, r"\1\2", result)
            corrections.append("소대문자연결")

        # 6. 숫자-공백-숫자 패턴
        # 예: "123 45" → "12345"
        pattern_digit = r"(\d)\s+(\d)"
        if re.search(pattern_digit, result):
            result = re.sub(pattern_digit, r"\1\2", result)
            corrections.append("숫자내부공백제거")

        # 7. 숫자-공백-영문자 패턴
        # 예: "Q8 Ky" → "Q8Ky"
        pattern_digit_alpha = r"(\d)\s+([a-zA-Z])"
        if re.search(pattern_digit_alpha, result):
            result = re.sub(pattern_digit_alpha, r"\1\2", result)
            corrections.append("숫자영문연결")

        # 8. 영문자-공백-숫자 패턴
        # 예: "Ky L8" → "KyL8"
        pattern_alpha_digit = r"([a-zA-Z])\s+(\d)"
        if re.search(pattern_alpha_digit, result):
            result = re.sub(pattern_alpha_digit, r"\1\2", result)
            corrections.append("영문숫자연결")

        # 9. 선행/후행 공백 제거
        stripped = result.strip()
        if stripped != result:
            result = stripped
            corrections.append("선후행공백제거")

        return result, corrections

    def _apply_context_detect(self, text: str) -> tuple[str, list[str]]:
        """컨텍스트를 감지합니다.

        텍스트의 패턴을 분석하여 적절한 컨텍스트를 결정합니다.
        이미 힌트 컨텍스트가 설정되어 있으면 덮어쓰지 않습니다.

        Args:
            text: 입력 텍스트

        Returns:
            (텍스트 그대로, 빈 리스트) - 컨텍스트만 설정
        """
        # 힌트 컨텍스트가 이미 설정되어 있으면 유지
        if self._current_context == TextContext.UNKNOWN:
            self._current_context = self._detect_context(text)
        return text, []

    def _detect_context(self, text: str) -> TextContext:
        """텍스트의 컨텍스트를 감지합니다.

        감지 우선순위:
            1. 순수 숫자 → NUMERIC
            2. 에러 코드 패턴 → ERROR_CODE
            3. 숫자 + 단위 → MEASUREMENT
            4. 콜론/등호 포함 → MIXED
            5. 순수 영문 → LABEL
            6. 기타 → UNKNOWN

        Args:
            text: 분석할 텍스트

        Returns:
            감지된 TextContext
        """
        stripped = text.strip()

        # 1. 순수 숫자 (소수점, 부호 포함)
        if re.fullmatch(r"[-+]?\d+\.?\d*", stripped):
            return TextContext.NUMERIC

        # 2. 에러 코드 패턴 확인
        for pattern in ERROR_CODE_PATTERNS:
            if pattern.match(stripped):
                return TextContext.ERROR_CODE

        # 3. 측정값 패턴 (숫자 + 단위)
        # 예: "25.5°C", "100Hz", "50kg"
        if re.search(r"[-+]?\d+\.?\d*\s*[a-zA-Z°%/³]+$", stripped):
            return TextContext.MEASUREMENT

        # 4. 콜론 또는 등호 포함 → 혼합 타입
        if re.search(r"[=:]", stripped):
            return TextContext.MIXED

        # 5. 숫자가 없고 영문만 있으면 라벨
        if re.fullmatch(r"[a-zA-Z\s]+", stripped):
            return TextContext.LABEL

        return TextContext.UNKNOWN

    def _apply_similar_char_correct(self, text: str) -> tuple[str, list[str]]:
        """유사 문자 교정을 적용합니다.

        컨텍스트에 따라 적절한 교정 규칙을 적용합니다:
            - NUMERIC, MEASUREMENT: 문자 → 숫자 (O→0, l→1 등)
            - LABEL: 숫자 → 문자 (0→O, 1→l 등)
            - MIXED: 분할 후 개별 처리

        Args:
            text: 입력 텍스트

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        # MIXED 컨텍스트면 분할 처리
        if self._current_context == TextContext.MIXED:
            return self._correct_mixed_context(text)

        # 컨텍스트에 따른 규칙 선택
        if self._current_context in (TextContext.NUMERIC, TextContext.MEASUREMENT):
            return self._apply_numeric_corrections(text)
        elif self._current_context == TextContext.LABEL:
            return self._apply_text_corrections(text)
        elif self._current_context == TextContext.ERROR_CODE:
            return self._correct_error_code(text)
        else:
            # UNKNOWN인 경우 숫자 컨텍스트 교정 적용 (산업용 기본)
            return self._apply_numeric_corrections(text)

    def _apply_numeric_corrections(self, text: str) -> tuple[str, list[str]]:
        """숫자 컨텍스트 교정을 적용합니다.

        숫자 사이에 있거나 숫자와 인접한 문자를 숫자로 변환합니다.

        Args:
            text: 입력 텍스트

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []
        result = list(text)

        for i, char in enumerate(result):
            if char not in NUMERIC_CHAR_MAP:
                continue

            # 숫자 컨텍스트 확인: 앞뒤에 숫자가 있거나 소수점 근처
            is_numeric_context = self._is_char_in_numeric_context(text, i)

            if is_numeric_context:
                new_char = NUMERIC_CHAR_MAP[char]
                result[i] = new_char
                corrections.append(f"{char}→{new_char} (숫자문맥)")

        return "".join(result), corrections

    def _is_char_in_numeric_context(self, text: str, pos: int) -> bool:
        """특정 위치의 문자가 숫자 컨텍스트에 있는지 확인합니다.

        숫자 컨텍스트 조건:
            - 앞에 숫자가 있음
            - 뒤에 숫자가 있음
            - 소수점 근처
            - 단위 바로 앞

        Args:
            text: 전체 텍스트
            pos: 문자 위치

        Returns:
            숫자 컨텍스트 여부
        """
        # 앞 문자 확인
        prev_is_digit = pos > 0 and text[pos - 1].isdigit()

        # 뒤 문자 확인
        next_is_digit = pos < len(text) - 1 and text[pos + 1].isdigit()

        # 소수점 근처 확인
        prev_is_decimal = pos > 0 and text[pos - 1] == "."
        next_is_decimal = pos < len(text) - 1 and text[pos + 1] == "."

        return prev_is_digit or next_is_digit or prev_is_decimal or next_is_decimal

    def _apply_text_corrections(self, text: str) -> tuple[str, list[str]]:
        """영문 컨텍스트 교정을 적용합니다.

        영문 단어 내부의 숫자를 문자로 변환합니다.

        Args:
            text: 입력 텍스트

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []
        result = list(text)

        for i, char in enumerate(result):
            if char not in TEXT_CHAR_MAP:
                continue

            # 영문 컨텍스트 확인: 앞뒤에 영문자가 있음
            is_text_context = self._is_char_in_text_context(text, i)

            if is_text_context:
                new_char = TEXT_CHAR_MAP[char]
                result[i] = new_char
                corrections.append(f"{char}→{new_char} (텍스트문맥)")

        return "".join(result), corrections

    def _is_char_in_text_context(self, text: str, pos: int) -> bool:
        """특정 위치의 문자가 영문 컨텍스트에 있는지 확인합니다.

        Args:
            text: 전체 텍스트
            pos: 문자 위치

        Returns:
            영문 컨텍스트 여부
        """
        prev_is_alpha = pos > 0 and text[pos - 1].isalpha()
        next_is_alpha = pos < len(text) - 1 and text[pos + 1].isalpha()

        return prev_is_alpha and next_is_alpha

    def _correct_mixed_context(self, text: str) -> tuple[str, list[str]]:
        """혼합 컨텍스트 텍스트를 교정합니다.

        콜론/등호로 분할하여 라벨과 값을 개별 처리합니다.

        Args:
            text: 입력 텍스트 (예: "Temperature: l23.45°C")

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []

        # 구분자 찾기
        separator_match = re.search(r"[=:]\s*", text)
        if not separator_match:
            return self._apply_numeric_corrections(text)

        sep_start = separator_match.start()
        sep_end = separator_match.end()

        label_part = text[:sep_start]
        separator = text[sep_start:sep_end]
        value_part = text[sep_end:]

        # 라벨 부분: 영문 컨텍스트 교정
        label_corrected, label_corrections = self._apply_text_corrections(label_part)
        corrections.extend(label_corrections)

        # 값 부분: 숫자 컨텍스트 교정
        value_corrected, value_corrections = self._apply_numeric_corrections(value_part)
        corrections.extend(value_corrections)

        return label_corrected + separator + value_corrected, corrections

    def _correct_error_code(self, text: str) -> tuple[str, list[str]]:
        """에러 코드를 교정합니다.

        에러 코드는 접두사(영문) + 숫자 형태입니다.
        접두사는 영문 규칙, 숫자부는 숫자 규칙을 적용합니다.

        Args:
            text: 입력 텍스트 (예: "E0l" → "E01")

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []

        # 영문-숫자 경계 찾기
        match = re.match(r"^([A-Za-z]+[-]?)(.*)$", text)
        if not match:
            return self._apply_numeric_corrections(text)

        prefix = match.group(1)
        number_part = match.group(2)

        # 숫자 부분 교정
        number_corrected, num_corrections = self._apply_numeric_corrections(number_part)
        corrections.extend(num_corrections)

        return prefix + number_corrected, corrections

    def _apply_pattern_validate(self, text: str) -> tuple[str, list[str]]:
        """산업용 패턴을 검증합니다.

        현재는 패턴 일치 여부만 확인합니다.
        추후 패턴 기반 추가 교정을 구현할 수 있습니다.

        Args:
            text: 입력 텍스트

        Returns:
            (텍스트 그대로, 빈 리스트)
        """
        # 현재는 검증만 수행 (교정 없음)
        # 추후 패턴 기반 교정 추가 가능
        return text, []

    def _apply_unit_normalize(self, text: str) -> tuple[str, list[str]]:
        """단위를 정규화합니다.

        오인식된 단위를 올바른 형태로 교정합니다.

        Args:
            text: 입력 텍스트

        Returns:
            (교정된 텍스트, 적용된 교정 목록)
        """
        corrections: list[str] = []
        result = text

        for wrong_unit, correct_unit in UNIT_NORMALIZATION_MAP.items():
            if wrong_unit in result:
                result = result.replace(wrong_unit, correct_unit)
                corrections.append(f"{wrong_unit}→{correct_unit} (단위정규화)")

        return result, corrections


# ========================================
# 팩토리 함수
# ========================================


def create_default_correction_config() -> TextCorrectionConfig:
    """기본 교정 설정을 생성합니다.

    모든 교정 기능이 활성화된 기본 설정입니다.

    Returns:
        TextCorrectionConfig 인스턴스
    """
    return TextCorrectionConfig()


def create_numeric_only_correction_config() -> TextCorrectionConfig:
    """숫자 전용 교정 설정을 생성합니다.

    숫자 컨텍스트 교정에 최적화된 설정입니다.

    Returns:
        TextCorrectionConfig 인스턴스
    """
    return TextCorrectionConfig(
        enable_space_normalize=True,
        enable_similar_char_correction=True,
        enable_context_detection=False,  # 항상 숫자 컨텍스트 사용
        enable_pattern_validation=True,
        enable_unit_normalize=True,
        confidence_penalty_per_correction=0.005,  # 낮은 페널티
    )


def create_minimal_correction_config() -> TextCorrectionConfig:
    """최소 교정 설정을 생성합니다.

    공백 정규화만 수행하는 가벼운 설정입니다.

    Returns:
        TextCorrectionConfig 인스턴스
    """
    return TextCorrectionConfig(
        enable_space_normalize=True,
        enable_similar_char_correction=False,
        enable_context_detection=False,
        enable_pattern_validation=False,
        enable_unit_normalize=False,
    )
