"""ROI 템플릿 관리자 - 사전 정의된 ROI 템플릿 관리

이 모듈은 재사용 가능한 ROI 템플릿을 관리합니다.
한 번 정의한 ROI 세트를 여러 세션에서 재사용할 수 있습니다.

주요 기능:
    - 템플릿 생성, 조회, 수정, 삭제
    - 템플릿에서 ROI 리스트 로드
    - 템플릿을 세션에 적용 (복사)

사용 예시:
    >>> manager = ROITemplateManager(db_manager)
    >>> 
    >>> # 템플릿 생성
    >>> template = manager.create_template(
    ...     name="산업용 디스플레이 A",
    ...     description="온도/압력 모니터링 레이아웃"
    ... )
    >>> 
    >>> # ROI 추가
    >>> manager.add_roi_to_template(
    ...     template_id=template.id,
    ...     name="온도",
    ...     roi_type=ROIType.NUMERIC,
    ...     x=100, y=200, width=80, height=40
    ... )
    >>> 
    >>> # 템플릿 로드 및 사용
    >>> rois = manager.load_template_rois(template.id)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING

from .database import (
    DatabaseManager,
    ROITemplate,
    ROITemplateCreate,
    TemplateROI,
    TemplateROICreate,
    ROIType,
)

if TYPE_CHECKING:
    from ..detection.roi_types import ROI, BoundingBox

logger = logging.getLogger(__name__)


@dataclass
class TemplateInfo:
    """템플릿 정보 + ROI 개수"""
    template: ROITemplate
    roi_count: int


class ROITemplateManager:
    """ROI 템플릿 관리자
    
    재사용 가능한 ROI 템플릿을 관리합니다.
    DatabaseManager를 통해 데이터를 저장/로드합니다.
    
    Attributes:
        db: DatabaseManager 인스턴스
    """
    
    def __init__(self, db: DatabaseManager) -> None:
        """ROITemplateManager 초기화
        
        Args:
            db: 연결된 DatabaseManager 인스턴스
        """
        self.db = db
        logger.info("ROITemplateManager 초기화")
    
    # ========================================
    # 템플릿 관리
    # ========================================
    
    def create_template(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> ROITemplate:
        """새 템플릿 생성
        
        Args:
            name: 템플릿 이름 (고유해야 함)
            description: 템플릿 설명
            
        Returns:
            생성된 ROITemplate 객체
        """
        template = self.db.create_template(
            ROITemplateCreate(name=name, description=description)
        )
        logger.info(f"템플릿 생성: ID={template.id}, 이름='{name}'")
        return template
    
    def get_template(self, template_id: int) -> Optional[ROITemplate]:
        """ID로 템플릿 조회
        
        Args:
            template_id: 템플릿 ID
            
        Returns:
            ROITemplate 또는 None
        """
        return self.db.get_template_by_id(template_id)
    
    def get_template_by_name(self, name: str) -> Optional[ROITemplate]:
        """이름으로 템플릿 조회
        
        Args:
            name: 템플릿 이름
            
        Returns:
            ROITemplate 또는 None
        """
        return self.db.get_template_by_name(name)
    
    def list_templates(self) -> list[TemplateInfo]:
        """모든 템플릿 목록 조회 (ROI 개수 포함)
        
        Returns:
            TemplateInfo 리스트 (생성일 내림차순)
        """
        templates = self.db.get_all_templates()
        result = []
        
        for template in templates:
            rois = self.db.get_rois_by_template(template.id)
            result.append(TemplateInfo(template=template, roi_count=len(rois)))
        
        return result
    
    def update_template(
        self,
        template_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Optional[ROITemplate]:
        """템플릿 정보 수정
        
        Args:
            template_id: 수정할 템플릿 ID
            name: 새 이름 (None이면 변경 안 함)
            description: 새 설명 (None이면 변경 안 함)
            
        Returns:
            수정된 ROITemplate 또는 None
        """
        template = self.db.update_template(
            template_id, name=name, description=description
        )
        if template:
            logger.info(f"템플릿 수정: ID={template_id}")
        return template
    
    def delete_template(self, template_id: int) -> bool:
        """템플릿 삭제 (포함된 ROI도 삭제)
        
        Args:
            template_id: 삭제할 템플릿 ID
            
        Returns:
            삭제 성공 여부
        """
        success = self.db.delete_template(template_id)
        if success:
            logger.info(f"템플릿 삭제: ID={template_id}")
        return success
    
    # ========================================
    # ROI 관리
    # ========================================
    
    def add_roi_to_template(
        self,
        template_id: int,
        name: str,
        roi_type: ROIType,
        x: int,
        y: int,
        width: int,
        height: int,
        threshold: float = 0.1,
        metadata: Optional[str] = None,
    ) -> TemplateROI:
        """템플릿에 ROI 추가
        
        Args:
            template_id: 템플릿 ID
            name: ROI 이름 (템플릿 내 고유)
            roi_type: ROI 유형 (NUMERIC, TEXT, CHART 등)
            x, y: 좌상단 좌표 (픽셀)
            width, height: 크기 (픽셀)
            threshold: 변화 감지 임계값
            metadata: 추가 메타데이터 (JSON 문자열)
            
        Returns:
            생성된 TemplateROI 객체
        """
        roi = self.db.create_template_roi(
            TemplateROICreate(
                template_id=template_id,
                name=name,
                roi_type=roi_type,
                x=x,
                y=y,
                width=width,
                height=height,
                threshold=threshold,
                metadata=metadata,
            )
        )
        logger.info(
            f"ROI 추가: 템플릿={template_id}, 이름='{name}', "
            f"유형={roi_type.value}, 좌표=({x},{y},{width},{height})"
        )
        return roi
    
    def add_rois_batch(
        self,
        template_id: int,
        rois: list[dict],
    ) -> list[TemplateROI]:
        """템플릿에 여러 ROI 일괄 추가
        
        Args:
            template_id: 템플릿 ID
            rois: ROI 정보 딕셔너리 리스트
                  각 딕셔너리: {name, roi_type, x, y, width, height, threshold?, metadata?}
                  
        Returns:
            생성된 TemplateROI 리스트
        """
        create_data = []
        for roi_data in rois:
            roi_type = roi_data["roi_type"]
            if isinstance(roi_type, str):
                roi_type = ROIType(roi_type)
            
            create_data.append(
                TemplateROICreate(
                    template_id=template_id,
                    name=roi_data["name"],
                    roi_type=roi_type,
                    x=roi_data["x"],
                    y=roi_data["y"],
                    width=roi_data["width"],
                    height=roi_data["height"],
                    threshold=roi_data.get("threshold", 0.1),
                    metadata=roi_data.get("metadata"),
                )
            )
        
        created = self.db.create_template_rois_batch(create_data)
        logger.info(f"ROI 일괄 추가: 템플릿={template_id}, 개수={len(created)}")
        return created
    
    def get_template_rois(self, template_id: int) -> list[TemplateROI]:
        """템플릿에 속한 모든 ROI 조회
        
        Args:
            template_id: 템플릿 ID
            
        Returns:
            TemplateROI 리스트
        """
        return self.db.get_rois_by_template(template_id)
    
    def update_roi(
        self,
        roi_id: int,
        **kwargs,
    ) -> Optional[TemplateROI]:
        """ROI 수정
        
        Args:
            roi_id: ROI ID
            **kwargs: 수정할 필드 (name, roi_type, x, y, width, height, threshold, metadata)
            
        Returns:
            수정된 TemplateROI 또는 None
        """
        roi = self.db.update_template_roi(roi_id, **kwargs)
        if roi:
            logger.info(f"ROI 수정: ID={roi_id}")
        return roi
    
    def delete_roi(self, roi_id: int) -> bool:
        """ROI 삭제
        
        Args:
            roi_id: 삭제할 ROI ID
            
        Returns:
            삭제 성공 여부
        """
        success = self.db.delete_template_roi(roi_id)
        if success:
            logger.info(f"ROI 삭제: ID={roi_id}")
        return success
    
    # ========================================
    # 템플릿 활용
    # ========================================
    
    def load_template_as_detection_rois(self, template_id: int) -> list:
        """템플릿을 detection.ROI 객체 리스트로 로드
        
        병렬 처리 등에서 사용할 수 있도록 TemplateROI를
        detection.roi_types.ROI 객체로 변환합니다.
        
        Args:
            template_id: 템플릿 ID
            
        Returns:
            detection.roi_types.ROI 리스트
        """
        from ..detection.roi_types import ROI, BoundingBox, ROIType as DetectionROIType
        
        template_rois = self.get_template_rois(template_id)
        result = []
        
        for tr in template_rois:
            # DB ROIType을 detection ROIType으로 매핑
            detection_type = DetectionROIType(tr.roi_type.value)
            
            bbox = BoundingBox(
                x=tr.x,
                y=tr.y,
                width=tr.width,
                height=tr.height,
            )
            
            roi = ROI(
                id=f"template_{template_id}_roi_{tr.id}",
                bbox=bbox,
                roi_type=detection_type,
                confidence=1.0,  # 사전 정의된 ROI는 신뢰도 100%
                label=tr.name,
                metadata={
                    "template_id": template_id,
                    "template_roi_id": tr.id,
                    "threshold": tr.threshold,
                    "original_metadata": tr.metadata,
                },
            )
            result.append(roi)
        
        logger.info(
            f"템플릿 로드: ID={template_id}, ROI 개수={len(result)}"
        )
        return result
    
    def copy_template_to_session(
        self,
        template_id: int,
        session_id: int,
    ) -> list:
        """템플릿 ROI를 세션에 복사
        
        템플릿의 ROI들을 세션 전용 roi_definitions 테이블에 복사합니다.
        기존 세션 기반 워크플로우와의 호환성을 위해 제공됩니다.
        
        Args:
            template_id: 소스 템플릿 ID
            session_id: 대상 세션 ID
            
        Returns:
            생성된 ROIDefinition 리스트
        """
        from .database import ROICreate
        
        template_rois = self.get_template_rois(template_id)
        created = []
        
        for tr in template_rois:
            roi = self.db.create_roi(
                ROICreate(
                    session_id=session_id,
                    name=tr.name,
                    roi_type=tr.roi_type,
                    x=tr.x,
                    y=tr.y,
                    width=tr.width,
                    height=tr.height,
                    threshold=tr.threshold,
                    metadata=tr.metadata,
                )
            )
            created.append(roi)
        
        logger.info(
            f"템플릿 복사: 템플릿={template_id} → 세션={session_id}, "
            f"ROI 개수={len(created)}"
        )
        return created


    def load_session_rois_as_detection_rois(self, session_id: int) -> list:
        """세션 ROI를 detection.ROI 객체 리스트로 로드
        
        copy_template_to_session()으로 생성된 세션 ROI를
        detection.roi_types.ROI 객체로 변환합니다.
        metadata에 db_roi_id가 포함되어 change_event 저장 시 사용됩니다.
        
        Args:
            session_id: 세션 ID
            
        Returns:
            detection.roi_types.ROI 리스트 (metadata에 db_roi_id 포함)
        """
        import json
        from ..detection.roi_types import ROI, BoundingBox, ROIType as DetectionROIType
        
        session_rois = self.db.get_rois_by_session(session_id)
        result = []
        
        for sr in session_rois:
            # DB ROIType을 detection ROIType으로 매핑
            try:
                detection_type = DetectionROIType(sr.roi_type.value)
            except ValueError:
                # 매핑 실패 시 NUMERIC으로 기본값
                detection_type = DetectionROIType.NUMERIC
            
            bbox = BoundingBox(
                x=sr.x,
                y=sr.y,
                width=sr.width,
                height=sr.height,
            )
            
            # 기존 메타데이터 파싱 (JSON 문자열 → dict)
            original_metadata = {}
            if sr.metadata:
                try:
                    original_metadata = json.loads(sr.metadata)
                except (json.JSONDecodeError, TypeError):
                    original_metadata = {}
            
            # is_trigger 플래그 추출
            is_trigger = original_metadata.get("is_trigger", False)
            
            roi = ROI(
                id=f"session_roi_{sr.id}",  # 문자열 ID (내부 식별용)
                bbox=bbox,
                roi_type=detection_type,
                confidence=1.0,  # 사전 정의된 ROI는 신뢰도 100%
                label=sr.name,
                metadata={
                    "db_roi_id": sr.id,  # DB 외래 키용 정수 ID
                    "session_id": session_id,
                    "threshold": sr.threshold,
                    "is_trigger": is_trigger,  # 트리거 ROI 플래그
                    "original_metadata": sr.metadata,
                },
            )
            result.append(roi)
        
        logger.info(
            f"세션 ROI 로드: session_id={session_id}, ROI 개수={len(result)}"
        )
        return result
