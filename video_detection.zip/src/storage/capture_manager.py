"""
캡처 관리자 - 산업용 비디오 모니터링 시스템용

이 모듈은 변화 감지 시스템에서 캡처한 이미지 파일의 저장 및 관리를 담당합니다.
타임스탬프 기반 파일명 생성, 자동 디렉토리 생성, 이미지 압축 지원을 제공합니다.

주요 기능:
    - 타임스탬프 기반 체계적인 파일명 생성
    - 날짜별 자동 하위 디렉토리 구조 생성
    - JPEG, PNG, WebP, BMP 다양한 이미지 포맷 지원
    - 품질 조절 가능한 이미지 압축
    - 동기/비동기 저장 모드 지원
    - 배치 저장 및 병렬 처리
    - 오래된 캡처 자동 정리 기능

설계 패턴:
    - 전략 패턴 (Strategy Pattern): ImageSaver 프로토콜로 저장 구현 교체 가능
    - 컨텍스트 매니저 패턴: 리소스 자동 정리 지원
    - 비동기 패턴: ThreadPoolExecutor 기반 비동기 처리

디렉토리 구조 예시:
    captures/
    └── 2025/
        └── 01/
            └── 21/
                ├── 1_display1_20250121_143052_123456.jpg
                └── 1_display2_20250121_143053_789012.jpg

사용 예시:
    >>> config = CaptureConfig(base_directory=Path("./captures"))
    >>> manager = CaptureManager(config)
    >>> result = manager.save_capture(image, session_id=1, roi_name="display")
    >>> print(result.file_path)
"""

from __future__ import annotations

import asyncio
import io
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional, Protocol, Union

# ========================================
# 선택적 의존성 임포트
# ========================================
# numpy와 PIL은 선택적 의존성으로, 없어도 기본 동작은 가능하지만
# 이미지 처리 기능을 사용하려면 설치가 필요합니다.

try:
    import numpy as np
    from numpy.typing import NDArray

    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    NDArray = Any  # type: ignore

try:
    from PIL import Image

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


logger = logging.getLogger(__name__)


# ========================================
# 이미지 포맷 열거형
# ========================================
class ImageFormat(Enum):
    """캡처 저장용 지원 이미지 포맷

    각 포맷의 특성:
        JPEG: 손실 압축, 사진/복잡한 이미지에 적합, 가장 작은 파일 크기
        PNG: 무손실 압축, 텍스트/그래픽에 적합, 투명도 지원
        WEBP: 손실/무손실 모두 지원, 현대적 포맷, 우수한 압축률
        BMP: 무압축, 빠른 읽기/쓰기, 가장 큰 파일 크기

    산업용 디스플레이 모니터링에서 권장:
        - 일반 모니터링: JPEG (파일 크기 우선)
        - 정밀 분석 필요: PNG (화질 우선)
    """

    JPEG = "jpg"
    PNG = "png"
    WEBP = "webp"
    BMP = "bmp"

    @property
    def extension(self) -> str:
        """파일 확장자 반환

        Returns:
            점(.)을 포함한 확장자 문자열 (예: ".jpg")
        """
        return f".{self.value}"

    @property
    def mime_type(self) -> str:
        """MIME 타입 반환

        웹 서비스나 HTTP 응답에서 Content-Type 헤더에 사용됩니다.

        Returns:
            MIME 타입 문자열 (예: "image/jpeg")
        """
        mime_types = {
            ImageFormat.JPEG: "image/jpeg",
            ImageFormat.PNG: "image/png",
            ImageFormat.WEBP: "image/webp",
            ImageFormat.BMP: "image/bmp",
        }
        return mime_types[self]


# ========================================
# 압축 수준 열거형
# ========================================
class CompressionLevel(Enum):
    """미리 정의된 압축 수준

    수치가 높을수록 품질은 낮지만 파일 크기가 작아집니다.

    Attributes:
        NONE: 압축 없음 (품질 100%)
        LOW: 낮은 압축 (품질 75%)
        MEDIUM: 중간 압축 (품질 50%)
        HIGH: 높은 압축 (품질 25%)
        MAXIMUM: 최대 압축 (품질 5%)

    참고:
        CaptureConfig의 compression_quality는 품질 값(0-100)을 사용하므로
        이 열거형 값을 직접 사용할 때는 100에서 빼야 합니다.
        예: quality = 100 - CompressionLevel.MEDIUM.value
    """

    NONE = 0
    LOW = 25
    MEDIUM = 50
    HIGH = 75
    MAXIMUM = 95


# ========================================
# 설정 데이터클래스
# ========================================
@dataclass
class CaptureConfig:
    """캡처 관리자 설정

    캡처된 이미지의 저장 위치, 포맷, 품질, 파일명 규칙 등을 정의합니다.

    Attributes:
        base_directory: 캡처 파일 저장 기본 디렉토리
        default_format: 기본 이미지 포맷 (기본값: JPEG)
        compression_quality: 압축 품질 0-100 (100이 최고 품질)
        create_subdirectories: 날짜별 하위 디렉토리 생성 여부
        subdirectory_pattern: 하위 디렉토리 이름 패턴 (strftime 형식)
        filename_pattern: 파일명 생성 패턴
        timestamp_format: 타임스탬프 문자열 형식
        max_workers: 비동기 처리용 스레드 풀 크기
        enable_async: 비동기 저장 활성화 여부

    파일명 패턴 변수:
        {session}: 세션 ID
        {roi}: ROI 이름
        {timestamp}: 타임스탬프 문자열

    Example:
        >>> config = CaptureConfig(
        ...     base_directory=Path("./captures"),
        ...     default_format=ImageFormat.PNG,
        ...     compression_quality=90,
        ...     subdirectory_pattern="%Y-%m-%d",
        ... )
    """

    base_directory: Path
    default_format: ImageFormat = ImageFormat.JPEG
    compression_quality: int = 85
    create_subdirectories: bool = True
    subdirectory_pattern: str = "%Y/%m/%d"
    filename_pattern: str = "{session}_{roi}_{timestamp}"
    timestamp_format: str = "%Y%m%d_%H%M%S_%f"
    max_workers: int = 4
    enable_async: bool = True

    def __post_init__(self) -> None:
        """초기화 후 설정 유효성 검증

        문자열로 전달된 base_directory를 Path 객체로 변환하고
        각 설정값의 유효 범위를 확인합니다.

        Raises:
            ValueError: compression_quality가 0-100 범위 밖이거나
                       max_workers가 1 미만인 경우
        """
        # 문자열 경로를 Path 객체로 변환
        if isinstance(self.base_directory, str):
            self.base_directory = Path(self.base_directory)

        # 압축 품질 범위 검증 (0-100)
        if not 0 <= self.compression_quality <= 100:
            raise ValueError("compression_quality는 0과 100 사이여야 합니다")

        # 워커 수 최소값 검증
        if self.max_workers < 1:
            raise ValueError("max_workers는 최소 1이어야 합니다")


# ========================================
# 결과 데이터클래스
# ========================================
@dataclass(frozen=True)
class CaptureResult:
    """캡처 작업 결과

    이미지 저장 작업의 성공/실패 여부와 세부 정보를 담는 불변 객체입니다.

    Attributes:
        success: 저장 성공 여부
        file_path: 저장된 파일 경로 (실패 시 None)
        file_size: 파일 크기 (바이트)
        timestamp: 캡처 타임스탬프
        format: 저장된 이미지 포맷
        error_message: 오류 메시지 (성공 시 None)

    Note:
        frozen=True로 설정되어 생성 후 속성 변경이 불가합니다.
        이는 결과 객체의 무결성을 보장합니다.
    """

    success: bool
    file_path: Optional[Path]
    file_size: int
    timestamp: datetime
    format: ImageFormat
    error_message: Optional[str] = None

    @property
    def file_name(self) -> Optional[str]:
        """파일명만 추출

        Returns:
            디렉토리를 제외한 파일명 (실패 시 None)
        """
        return self.file_path.name if self.file_path else None


# ========================================
# 예외 클래스 정의
# ========================================
class CaptureError(Exception):
    """캡처 작업 기본 예외

    모든 캡처 관련 예외의 기본 클래스입니다.
    """

    pass


class CaptureIOError(CaptureError):
    """파일 I/O 작업 실패 예외

    디스크 쓰기, 디렉토리 생성 등 파일 시스템 작업이
    실패했을 때 발생합니다.

    일반적인 원인:
        - 디스크 공간 부족
        - 권한 부족
        - 잘못된 경로
    """

    pass


class CaptureFormatError(CaptureError):
    """이미지 포맷 오류 예외

    지원하지 않는 이미지 타입이거나 포맷 변환에
    실패했을 때 발생합니다.

    일반적인 원인:
        - 지원하지 않는 이미지 타입
        - 손상된 이미지 데이터
        - 호환되지 않는 색상 모드
    """

    pass


# ========================================
# 이미지 저장 프로토콜 (인터페이스)
# ========================================
class ImageSaver(Protocol):
    """이미지 저장 구현을 위한 프로토콜

    전략 패턴을 위한 인터페이스로, 다양한 이미지 저장 방식을
    구현할 수 있습니다.

    구현 예시:
        - PILImageSaver: PIL 라이브러리 기반 (기본)
        - OpenCVImageSaver: OpenCV 기반 (고성능)
        - CloudImageSaver: 클라우드 스토리지 직접 저장
    """

    def save(
        self,
        image: Any,
        path: Path,
        format: ImageFormat,
        quality: int,
    ) -> int:
        """이미지를 파일로 저장

        Args:
            image: 이미지 데이터 (numpy 배열 또는 PIL Image)
            path: 저장할 파일 경로
            format: 대상 이미지 포맷
            quality: 압축 품질 (0-100)

        Returns:
            저장된 파일 크기 (바이트)

        Raises:
            CaptureError: 저장 실패 시
            CaptureFormatError: 이미지 포맷 오류 시
        """
        ...


# ========================================
# PIL 기반 이미지 저장 구현
# ========================================
class PILImageSaver:
    """PIL 라이브러리 기반 이미지 저장 구현

    Pillow (PIL Fork) 라이브러리를 사용하여 이미지를 저장합니다.
    numpy 배열과 PIL Image 객체를 모두 지원합니다.

    포맷별 최적화:
        JPEG: optimize=True로 허프만 테이블 최적화
        PNG: compress_level로 zlib 압축 수준 조절
        WebP: method=4로 압축 효율과 속도 균형

    Note:
        RGBA 이미지를 JPEG로 저장할 때는 자동으로 RGB로 변환합니다.
    """

    def save(
        self,
        image: Any,
        path: Path,
        format: ImageFormat,
        quality: int,
    ) -> int:
        """PIL을 사용하여 이미지 저장

        Args:
            image: 이미지 데이터 (numpy 배열 또는 PIL Image)
            path: 저장할 파일 경로
            format: 대상 이미지 포맷
            quality: 압축 품질 (0-100, JPEG/WebP에서 사용)

        Returns:
            저장된 파일 크기 (바이트)

        Raises:
            CaptureError: PIL을 사용할 수 없는 경우
            CaptureFormatError: 지원하지 않는 이미지 타입인 경우
        """
        if not PIL_AVAILABLE:
            raise CaptureError("PIL이 설치되어 있지 않습니다")

        # ----------------------------------------
        # 이미지 타입 변환: numpy 배열 → PIL Image
        # ----------------------------------------
        pil_image: Image.Image
        if NUMPY_AVAILABLE and isinstance(image, np.ndarray):
            # OpenCV BGR 이미지의 경우 RGB로 변환 필요할 수 있음
            pil_image = Image.fromarray(image)
        elif isinstance(image, Image.Image):
            pil_image = image
        else:
            raise CaptureFormatError(f"지원하지 않는 이미지 타입: {type(image)}")

        # ----------------------------------------
        # 포맷별 저장 옵션 설정
        # ----------------------------------------
        save_kwargs: dict[str, Any] = {}

        if format == ImageFormat.JPEG:
            # JPEG 최적화 옵션
            save_kwargs["quality"] = quality
            save_kwargs["optimize"] = True  # 허프만 테이블 최적화
            # JPEG는 투명도를 지원하지 않으므로 RGBA → RGB 변환
            if pil_image.mode == "RGBA":
                pil_image = pil_image.convert("RGB")

        elif format == ImageFormat.PNG:
            # PNG는 무손실이므로 quality를 zlib 압축 수준(0-9)으로 변환
            # quality 100 → compress_level 0 (압축 없음)
            # quality 0 → compress_level 9 (최대 압축)
            compress_level = min(9, max(0, (100 - quality) // 11))
            save_kwargs["compress_level"] = compress_level

        elif format == ImageFormat.WEBP:
            # WebP 옵션
            save_kwargs["quality"] = quality
            save_kwargs["method"] = 4  # 0-6, 높을수록 압축 효율↑ 속도↓

        # PIL 포맷 이름 매핑 (확장자 → 포맷 이름)
        pil_format_names = {
            "jpg": "JPEG",
            "png": "PNG",
            "webp": "WEBP",
            "bmp": "BMP",
        }
        pil_format = pil_format_names.get(format.value, format.value.upper())

        # 이미지 저장
        pil_image.save(str(path), format=pil_format, **save_kwargs)

        # 저장된 파일 크기 반환
        return path.stat().st_size


# ========================================
# 캡처 관리자 클래스
# ========================================
class CaptureManager:
    """캡처 이미지 저장 관리자

    변화 감지 시스템에서 캡처한 이미지를 파일로 저장하고 관리합니다.
    자동 디렉토리 생성, 타임스탬프 기반 파일명, 이미지 압축을 지원합니다.

    주요 기능:
        - 동기/비동기 이미지 저장
        - 배치 저장 (여러 이미지 한번에)
        - 오래된 파일 자동 정리
        - 저장소 통계 조회

    스레드 안전성:
        - 내부적으로 RLock을 사용하여 동시 저장 작업 보호
        - 비동기 저장은 ThreadPoolExecutor를 통해 처리

    사용 예시:
        >>> config = CaptureConfig(base_directory=Path("./captures"))
        >>> manager = CaptureManager(config)
        >>>
        >>> # 동기 저장
        >>> result = manager.save_capture(image, session_id=1, roi_name="display")
        >>>
        >>> # 비동기 저장
        >>> result = await manager.save_capture_async(image, session_id=1, roi_name="display")
        >>>
        >>> # 정리
        >>> manager.cleanup_old_captures(days=30)
    """

    def __init__(
        self,
        config: CaptureConfig,
        image_saver: Optional[ImageSaver] = None,
    ) -> None:
        """캡처 관리자 초기화

        Args:
            config: 캡처 설정 객체
            image_saver: 커스텀 이미지 저장 구현 (선택적)
                        None이면 기본 PILImageSaver 사용
        """
        self._config = config
        self._saver = image_saver or PILImageSaver()

        # ----------------------------------------
        # 스레드 안전성을 위한 재진입 가능 락
        # RLock을 사용하여 같은 스레드에서 중첩 호출 허용
        # ----------------------------------------
        self._lock = threading.RLock()

        # ----------------------------------------
        # 비동기 처리를 위한 스레드 풀
        # 지연 초기화: 비동기 저장 시 첫 사용할 때 생성
        # ----------------------------------------
        self._executor: Optional[ThreadPoolExecutor] = None

        # 기본 디렉토리 생성
        self._ensure_base_directory()

    @property
    def config(self) -> CaptureConfig:
        """현재 설정 반환"""
        return self._config

    @property
    def base_directory(self) -> Path:
        """기본 디렉토리 경로 반환"""
        return self._config.base_directory

    def _ensure_base_directory(self) -> None:
        """기본 디렉토리가 없으면 생성

        parents=True: 중간 디렉토리도 함께 생성
        exist_ok=True: 이미 존재해도 오류 발생하지 않음
        """
        self._config.base_directory.mkdir(parents=True, exist_ok=True)

    def _get_executor(self) -> ThreadPoolExecutor:
        """스레드 풀 실행기 반환 (지연 초기화)

        비동기 저장 기능을 사용할 때만 스레드 풀을 생성합니다.
        이는 불필요한 리소스 할당을 방지합니다.

        Returns:
            비동기 작업용 ThreadPoolExecutor
        """
        if self._executor is None:
            self._executor = ThreadPoolExecutor(
                max_workers=self._config.max_workers,
                thread_name_prefix="capture_",  # 디버깅을 위한 스레드 이름 접두사
            )
        return self._executor

    # ========================================
    # 경로 및 파일명 생성 메서드
    # ========================================
    def _generate_subdirectory(self, timestamp: datetime) -> Path:
        """타임스탬프 기반 하위 디렉토리 경로 생성

        설정된 subdirectory_pattern에 따라 날짜별 디렉토리 경로를 생성합니다.
        예: "%Y/%m/%d" 패턴 → "2025/01/21"

        Args:
            timestamp: 캡처 타임스탬프

        Returns:
            하위 디렉토리 경로 (create_subdirectories가 False면 기본 디렉토리)
        """
        if not self._config.create_subdirectories:
            return self._config.base_directory

        subdir_name = timestamp.strftime(self._config.subdirectory_pattern)
        return self._config.base_directory / subdir_name

    def _generate_filename(
        self,
        timestamp: datetime,
        session_id: int,
        roi_name: str,
        format: ImageFormat,
        suffix: Optional[str] = None,
    ) -> str:
        """파일명 생성

        설정된 filename_pattern과 파라미터를 사용하여 파일명을 생성합니다.
        ROI 이름에서 공백과 슬래시는 안전한 문자로 변환됩니다.

        Args:
            timestamp: 캡처 타임스탬프
            session_id: 세션 식별자
            roi_name: ROI 이름
            format: 이미지 포맷
            suffix: 선택적 파일명 접미사 (배치 저장 시 인덱스 등)

        Returns:
            생성된 파일명 (예: "1_display_20250121_143052_123456.jpg")
        """
        # 타임스탬프 문자열 생성
        ts_str = timestamp.strftime(self._config.timestamp_format)

        # ROI 이름 안전화: 공백 → 언더스코어, 슬래시 → 대시
        safe_roi_name = roi_name.replace(" ", "_").replace("/", "-")

        # 패턴에 값 대입
        filename = self._config.filename_pattern.format(
            session=session_id,
            roi=safe_roi_name,
            timestamp=ts_str,
        )

        # 접미사가 있으면 추가
        if suffix:
            filename = f"{filename}_{suffix}"

        # 확장자 추가하여 반환
        return f"{filename}{format.extension}"

    def _generate_filepath(
        self,
        timestamp: datetime,
        session_id: int,
        roi_name: str,
        format: ImageFormat,
        suffix: Optional[str] = None,
    ) -> Path:
        """전체 파일 경로 생성

        디렉토리 경로와 파일명을 결합하여 전체 경로를 생성합니다.

        Args:
            timestamp: 캡처 타임스탬프
            session_id: 세션 식별자
            roi_name: ROI 이름
            format: 이미지 포맷
            suffix: 선택적 파일명 접미사

        Returns:
            전체 파일 경로
        """
        directory = self._generate_subdirectory(timestamp)
        filename = self._generate_filename(
            timestamp, session_id, roi_name, format, suffix
        )
        return directory / filename

    # ========================================
    # 이미지 저장 메서드
    # ========================================
    def save_capture(
        self,
        image: Any,
        session_id: int,
        roi_name: str,
        *,
        format: Optional[ImageFormat] = None,
        quality: Optional[int] = None,
        timestamp: Optional[datetime] = None,
        suffix: Optional[str] = None,
    ) -> CaptureResult:
        """캡처 이미지를 파일로 저장 (동기)

        Args:
            image: 이미지 데이터 (numpy 배열 또는 PIL Image)
            session_id: 세션 식별자
            roi_name: 파일명에 사용할 ROI 이름
            format: 이미지 포맷 (기본값: 설정에서 지정)
            quality: 압축 품질 (기본값: 설정에서 지정)
            timestamp: 캡처 타임스탬프 (기본값: 현재 시간)
            suffix: 선택적 파일명 접미사

        Returns:
            저장 작업 결과를 담은 CaptureResult

        Raises:
            CaptureIOError: 파일 쓰기 실패 시
            CaptureFormatError: 이미지 포맷이 잘못된 경우
        """
        # 기본값 설정
        capture_time = timestamp or datetime.now()
        img_format = format or self._config.default_format
        img_quality = quality if quality is not None else self._config.compression_quality

        # 파일 경로 생성
        file_path = self._generate_filepath(
            capture_time, session_id, roi_name, img_format, suffix
        )

        try:
            # ----------------------------------------
            # 스레드 안전한 파일 저장
            # 락을 사용하여 동시 저장으로 인한 충돌 방지
            # ----------------------------------------
            with self._lock:
                # 디렉토리가 없으면 생성
                file_path.parent.mkdir(parents=True, exist_ok=True)
                # 이미지 저장 및 파일 크기 반환
                file_size = self._saver.save(image, file_path, img_format, img_quality)

            logger.debug(
                "캡처 저장 완료: %s (크기: %d 바이트)", file_path.name, file_size
            )

            return CaptureResult(
                success=True,
                file_path=file_path,
                file_size=file_size,
                timestamp=capture_time,
                format=img_format,
            )

        except CaptureError:
            # CaptureError 계열 예외는 그대로 전파
            raise
        except OSError as e:
            # 파일 시스템 오류는 CaptureIOError로 변환
            logger.error("캡처 저장 실패: %s", e)
            raise CaptureIOError(f"파일 쓰기 실패: {e}") from e
        except Exception as e:
            # 기타 예외는 실패 결과로 반환
            logger.error("캡처 저장 중 예상치 못한 오류: %s", e)
            return CaptureResult(
                success=False,
                file_path=None,
                file_size=0,
                timestamp=capture_time,
                format=img_format,
                error_message=str(e),
            )

    async def save_capture_async(
        self,
        image: Any,
        session_id: int,
        roi_name: str,
        *,
        format: Optional[ImageFormat] = None,
        quality: Optional[int] = None,
        timestamp: Optional[datetime] = None,
        suffix: Optional[str] = None,
    ) -> CaptureResult:
        """캡처 이미지를 파일로 비동기 저장

        ThreadPoolExecutor를 사용하여 파일 I/O를 별도 스레드에서 실행합니다.
        이를 통해 메인 이벤트 루프가 블로킹되지 않습니다.

        Args:
            image: 이미지 데이터 (numpy 배열 또는 PIL Image)
            session_id: 세션 식별자
            roi_name: 파일명에 사용할 ROI 이름
            format: 이미지 포맷 (기본값: 설정에서 지정)
            quality: 압축 품질 (기본값: 설정에서 지정)
            timestamp: 캡처 타임스탬프 (기본값: 현재 시간)
            suffix: 선택적 파일명 접미사

        Returns:
            저장 작업 결과를 담은 CaptureResult

        Note:
            enable_async가 False이면 동기 저장으로 폴백합니다.
        """
        # 비동기 비활성화 시 동기 저장 사용
        if not self._config.enable_async:
            return self.save_capture(
                image,
                session_id,
                roi_name,
                format=format,
                quality=quality,
                timestamp=timestamp,
                suffix=suffix,
            )

        # ----------------------------------------
        # 비동기 실행: run_in_executor 사용
        # ----------------------------------------
        # 이벤트 루프 가져오기
        loop = asyncio.get_event_loop()

        # 스레드 풀에서 동기 함수 실행
        return await loop.run_in_executor(
            self._get_executor(),
            lambda: self.save_capture(
                image,
                session_id,
                roi_name,
                format=format,
                quality=quality,
                timestamp=timestamp,
                suffix=suffix,
            ),
        )

    def save_captures_batch(
        self,
        captures: list[tuple[Any, int, str]],
        *,
        format: Optional[ImageFormat] = None,
        quality: Optional[int] = None,
    ) -> list[CaptureResult]:
        """여러 캡처를 배치로 저장 (동기)

        동일한 타임스탬프를 사용하여 여러 이미지를 순차적으로 저장합니다.
        여러 ROI의 스냅샷을 동시에 저장할 때 유용합니다.

        Args:
            captures: (이미지, 세션ID, ROI이름) 튜플 리스트
            format: 모든 캡처에 적용할 이미지 포맷
            quality: 모든 캡처에 적용할 압축 품질

        Returns:
            각 캡처별 CaptureResult 리스트
        """
        results: list[CaptureResult] = []

        # 모든 캡처에 동일한 타임스탬프 사용
        timestamp = datetime.now()

        for i, (image, session_id, roi_name) in enumerate(captures):
            result = self.save_capture(
                image,
                session_id,
                roi_name,
                format=format,
                quality=quality,
                timestamp=timestamp,
                # 여러 개일 때만 인덱스 접미사 추가
                suffix=f"{i:04d}" if len(captures) > 1 else None,
            )
            results.append(result)

        return results

    async def save_captures_batch_async(
        self,
        captures: list[tuple[Any, int, str]],
        *,
        format: Optional[ImageFormat] = None,
        quality: Optional[int] = None,
    ) -> list[CaptureResult]:
        """여러 캡처를 병렬로 비동기 저장

        asyncio.gather를 사용하여 여러 이미지를 동시에 저장합니다.
        배치 저장보다 빠르지만 디스크 I/O 부하가 높아질 수 있습니다.

        Args:
            captures: (이미지, 세션ID, ROI이름) 튜플 리스트
            format: 모든 캡처에 적용할 이미지 포맷
            quality: 모든 캡처에 적용할 압축 품질

        Returns:
            각 캡처별 CaptureResult 리스트 (입력 순서와 동일)
        """
        # 모든 캡처에 동일한 타임스탬프 사용
        timestamp = datetime.now()

        async def save_one(
            idx: int, image: Any, session_id: int, roi_name: str
        ) -> CaptureResult:
            """단일 캡처 비동기 저장 헬퍼 함수"""
            return await self.save_capture_async(
                image,
                session_id,
                roi_name,
                format=format,
                quality=quality,
                timestamp=timestamp,
                suffix=f"{idx:04d}" if len(captures) > 1 else None,
            )

        # 모든 저장 작업을 병렬로 시작
        tasks = [
            save_one(i, image, session_id, roi_name)
            for i, (image, session_id, roi_name) in enumerate(captures)
        ]

        # 모든 작업 완료 대기
        return await asyncio.gather(*tasks)

    # ========================================
    # 캡처 조회 및 관리 메서드
    # ========================================
    def get_capture_path(
        self,
        session_id: int,
        roi_name: str,
        timestamp: datetime,
        format: Optional[ImageFormat] = None,
    ) -> Path:
        """캡처 파일의 예상 경로 반환

        실제 파일이 존재하지 않아도 경로를 계산합니다.

        Args:
            session_id: 세션 식별자
            roi_name: ROI 이름
            timestamp: 캡처 타임스탬프
            format: 이미지 포맷 (기본값: 설정에서 지정)

        Returns:
            예상 파일 경로
        """
        img_format = format or self._config.default_format
        return self._generate_filepath(timestamp, session_id, roi_name, img_format)

    def capture_exists(
        self,
        session_id: int,
        roi_name: str,
        timestamp: datetime,
        format: Optional[ImageFormat] = None,
    ) -> bool:
        """캡처 파일 존재 여부 확인

        Args:
            session_id: 세션 식별자
            roi_name: ROI 이름
            timestamp: 캡처 타임스탬프
            format: 이미지 포맷 (기본값: 설정에서 지정)

        Returns:
            파일이 존재하면 True
        """
        path = self.get_capture_path(session_id, roi_name, timestamp, format)
        return path.exists()

    def list_captures(
        self,
        session_id: Optional[int] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        format: Optional[ImageFormat] = None,
    ) -> list[Path]:
        """캡처 파일 목록 조회

        다양한 필터를 적용하여 캡처 파일을 검색합니다.

        Args:
            session_id: 세션 ID로 필터링 (선택적)
            start_date: 이 날짜 이후의 파일만 (선택적)
            end_date: 이 날짜 이전의 파일만 (선택적)
            format: 이미지 포맷으로 필터링 (선택적)

        Returns:
            매칭되는 파일 경로 리스트 (최신순 정렬)
        """
        # 검색할 파일 패턴 결정
        patterns = []
        if format:
            patterns.append(f"*{format.extension}")
        else:
            # 모든 지원 포맷 검색
            for fmt in ImageFormat:
                patterns.append(f"*{fmt.extension}")

        # 모든 패턴에 대해 재귀 검색
        captures: list[Path] = []
        for pattern in patterns:
            captures.extend(self._config.base_directory.rglob(pattern))

        # 필터링 적용
        filtered: list[Path] = []
        for path in captures:
            # 세션 ID 필터
            if session_id is not None:
                # 파일명에서 세션 ID 확인
                if f"_{session_id}_" not in path.name and not path.name.startswith(
                    f"{session_id}_"
                ):
                    continue

            # 날짜 범위 필터
            if start_date or end_date:
                try:
                    # 파일 수정 시간 사용
                    mtime = datetime.fromtimestamp(path.stat().st_mtime)
                    if start_date and mtime < start_date:
                        continue
                    if end_date and mtime > end_date:
                        continue
                except OSError:
                    continue

            filtered.append(path)

        # 최신순 정렬 (수정 시간 기준)
        return sorted(filtered, key=lambda p: p.stat().st_mtime, reverse=True)

    def delete_capture(self, file_path: Path) -> bool:
        """캡처 파일 삭제

        Args:
            file_path: 삭제할 파일 경로

        Returns:
            삭제 성공 시 True, 파일이 없으면 False
        """
        if not file_path.exists():
            return False

        try:
            file_path.unlink()
            logger.debug("캡처 삭제 완료: %s", file_path.name)
            return True
        except OSError as e:
            logger.error("캡처 삭제 실패 %s: %s", file_path, e)
            return False

    def cleanup_old_captures(
        self,
        days: int,
        session_id: Optional[int] = None,
        dry_run: bool = False,
    ) -> tuple[int, int]:
        """오래된 캡처 파일 정리

        지정된 일수보다 오래된 캡처 파일을 삭제합니다.
        디스크 공간 관리에 유용합니다.

        Args:
            days: 이 일수보다 오래된 파일 삭제
            session_id: 특정 세션의 파일만 대상 (선택적)
            dry_run: True이면 실제 삭제 없이 대상 파일만 카운트

        Returns:
            (삭제된 파일 수, 해제된 바이트 수) 튜플
        """
        from datetime import timedelta

        # 기준 날짜 계산
        cutoff = datetime.now() - timedelta(days=days)

        # 대상 파일 조회
        captures = self.list_captures(session_id=session_id, end_date=cutoff)

        deleted_count = 0
        bytes_freed = 0

        for path in captures:
            try:
                file_size = path.stat().st_size
                if not dry_run:
                    if self.delete_capture(path):
                        deleted_count += 1
                        bytes_freed += file_size
                else:
                    # dry_run 모드: 삭제하지 않고 카운트만
                    deleted_count += 1
                    bytes_freed += file_size
            except OSError:
                continue

        logger.info(
            "정리 %s: %d개 파일, %d 바이트",
            "예정" if dry_run else "완료",
            deleted_count,
            bytes_freed,
        )

        return deleted_count, bytes_freed

    def get_storage_stats(self) -> dict[str, Any]:
        """저장소 통계 조회

        전체 파일 수, 총 용량, 포맷별 분포, 세션별 파일 수 등의
        통계 정보를 반환합니다.

        Returns:
            통계 정보를 담은 딕셔너리:
                - total_files: 전체 파일 수
                - total_size_bytes: 총 용량 (바이트)
                - total_size_mb: 총 용량 (MB)
                - format_distribution: 포맷별 파일 수
                - session_file_counts: 세션별 파일 수
                - base_directory: 기본 디렉토리 경로
        """
        total_files = 0
        total_size = 0
        format_counts: dict[str, int] = {}
        session_counts: dict[int, int] = {}

        # 모든 이미지 포맷에 대해 검색
        for fmt in ImageFormat:
            for path in self._config.base_directory.rglob(f"*{fmt.extension}"):
                try:
                    stat = path.stat()
                    total_files += 1
                    total_size += stat.st_size

                    # 포맷별 카운트
                    format_counts[fmt.value] = format_counts.get(fmt.value, 0) + 1

                    # 파일명에서 세션 ID 추출 시도
                    parts = path.name.split("_")
                    if parts:
                        try:
                            session_id = int(parts[0])
                            session_counts[session_id] = (
                                session_counts.get(session_id, 0) + 1
                            )
                        except ValueError:
                            pass
                except OSError:
                    continue

        return {
            "total_files": total_files,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "format_distribution": format_counts,
            "session_file_counts": session_counts,
            "base_directory": str(self._config.base_directory),
        }

    # ========================================
    # 리소스 관리 메서드
    # ========================================
    def close(self) -> None:
        """리소스 정리

        스레드 풀을 정리하고 모든 작업 완료를 대기합니다.
        컨텍스트 매니저를 사용하지 않을 때 명시적으로 호출하세요.
        """
        if self._executor is not None:
            self._executor.shutdown(wait=True)
            self._executor = None

    def __enter__(self) -> "CaptureManager":
        """컨텍스트 매니저 진입

        with 문과 함께 사용하여 자동 리소스 정리를 보장합니다.

        Example:
            >>> with CaptureManager(config) as manager:
            ...     manager.save_capture(image, 1, "roi")
            >>> # 자동으로 close() 호출됨
        """
        return self

    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[Exception],
        exc_tb: Optional[Any],
    ) -> None:
        """컨텍스트 매니저 종료 및 정리

        예외 발생 여부와 관계없이 리소스를 정리합니다.
        """
        self.close()
