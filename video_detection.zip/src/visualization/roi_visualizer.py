"""ROI 시각화 모듈 - 산업용 비디오 모니터링 시스템용

이 모듈은 ROI(Region of Interest) 영역을 이미지에 시각화하는 기능을 제공합니다.
점선 스타일 사각형을 지원하여 원본 이미지 내용의 가시성을 유지하면서
ROI 영역을 명확하게 표시합니다.

주요 기능:
    - 점선 스타일 사각형 그리기 (cv2에서 기본 지원하지 않음)
    - ROI 타입별 색상 구분
    - 라벨 및 신뢰도 표시
    - 다중 ROI 동시 시각화
    - CaptureManager와의 통합 헬퍼 함수

설계 패턴:
    - Strategy 패턴: VisualizationConfig를 통한 시각화 스타일 조정
    - Factory 패턴: ROIColorScheme을 통한 색상 생성

사용 예시:
    >>> from visualization.roi_visualizer import ROIVisualizer, VisualizationConfig
    >>> config = VisualizationConfig(show_label=True, show_confidence=True)
    >>> visualizer = ROIVisualizer(config)
    >>> result_image = visualizer.draw_rois(image, rois)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

import cv2
import numpy as np
from numpy.typing import NDArray

from ..detection.roi_types import ROI, BoundingBox, ROIType

if TYPE_CHECKING:
    from ..storage.capture_manager import CaptureManager

logger = logging.getLogger(__name__)


# ========================================
# 시각화 스타일 열거형
# ========================================
class VisualizationStyle(Enum):
    """시각화 선 스타일

    ROI 영역을 표시할 때 사용할 선의 스타일을 정의합니다.

    Attributes:
        SOLID: 실선 스타일 (기본 cv2.rectangle)
        DASHED: 점선 스타일 (커스텀 구현)
    """

    SOLID = "solid"
    DASHED = "dashed"


# ========================================
# ROI 타입별 색상 스키마
# ========================================
class ROIColorScheme:
    """ROI 타입별 색상 정의

    각 ROI 타입에 대해 시각적으로 구분 가능한 색상을 제공합니다.
    색상은 BGR 형식으로 정의됩니다 (OpenCV 표준).

    색상 설계 원칙:
        - NUMERIC (녹색): 숫자 데이터 - 안정적, 정상 상태 연상
        - TEXT (주황색): 텍스트 정보 - 주의 필요, 읽기 강조
        - CHART (파란색): 차트/그래프 - 분석, 시각화 연상
        - UNKNOWN (회색): 분류되지 않음 - 중립적 표시

    Example:
        >>> color = ROIColorScheme.get_color(ROIType.NUMERIC)
        >>> print(color)  # (0, 255, 0) - BGR 녹색
    """

    # BGR 색상 정의 (OpenCV 표준)
    _COLORS: dict[ROIType, tuple[int, int, int]] = {
        ROIType.NUMERIC: (0, 255, 0),      # 녹색 - 숫자 영역
        ROIType.TEXT: (0, 165, 255),       # 주황색 - 텍스트 영역
        ROIType.CHART: (255, 0, 0),        # 파란색 - 차트 영역
        ROIType.UNKNOWN: (128, 128, 128),  # 회색 - 분류되지 않은 영역
    }

    @classmethod
    def get_color(cls, roi_type: ROIType) -> tuple[int, int, int]:
        """ROI 타입에 해당하는 색상 반환

        Args:
            roi_type: ROI 타입 열거형

        Returns:
            BGR 색상 튜플 (blue, green, red)
        """
        return cls._COLORS.get(roi_type, cls._COLORS[ROIType.UNKNOWN])

    @classmethod
    def get_all_colors(cls) -> dict[ROIType, tuple[int, int, int]]:
        """모든 ROI 타입의 색상 매핑 반환

        Returns:
            ROI 타입별 색상 딕셔너리
        """
        return cls._COLORS.copy()


# ========================================
# 시각화 설정 데이터클래스
# ========================================
@dataclass
class VisualizationConfig:
    """시각화 설정

    ROI 시각화의 모든 스타일 옵션을 정의합니다.
    점선 스타일, 라벨 표시, 폰트 크기 등을 조절할 수 있습니다.

    Attributes:
        line_thickness: 선 두께 (픽셀 단위)
        show_label: ROI 라벨 표시 여부
        show_confidence: 신뢰도 점수 표시 여부
        font_scale: 라벨 폰트 크기 배율
        style: 선 스타일 (SOLID 또는 DASHED)
        dash_length: 점선의 대시 길이 (픽셀)
        gap_length: 점선의 간격 길이 (픽셀)
        label_background_alpha: 라벨 배경 투명도 (0.0 ~ 1.0)
        label_padding: 라벨 텍스트 패딩 (픽셀)

    Example:
        >>> config = VisualizationConfig(
        ...     line_thickness=3,
        ...     show_confidence=True,
        ...     style=VisualizationStyle.DASHED,
        ... )
    """

    line_thickness: int = 2
    show_label: bool = True
    show_confidence: bool = False
    font_scale: float = 0.5
    style: VisualizationStyle = VisualizationStyle.DASHED
    dash_length: int = 10
    gap_length: int = 5
    label_background_alpha: float = 0.7
    label_padding: int = 3

    def __post_init__(self) -> None:
        """초기화 후 설정 유효성 검증

        Raises:
            ValueError: 설정값이 유효 범위를 벗어난 경우
        """
        if self.line_thickness < 1:
            raise ValueError("line_thickness는 최소 1이어야 합니다")
        if self.dash_length < 1:
            raise ValueError("dash_length는 최소 1이어야 합니다")
        if self.gap_length < 1:
            raise ValueError("gap_length는 최소 1이어야 합니다")
        if not 0.0 <= self.label_background_alpha <= 1.0:
            raise ValueError("label_background_alpha는 0.0과 1.0 사이여야 합니다")
        if self.font_scale <= 0:
            raise ValueError("font_scale은 0보다 커야 합니다")


# ========================================
# ROI 시각화 클래스
# ========================================
class ROIVisualizer:
    """ROI 영역 시각화 클래스

    이미지에 ROI 영역을 점선 사각형으로 표시하고 라벨을 추가합니다.
    cv2에서 기본 지원하지 않는 점선 사각형을 커스텀으로 구현합니다.

    주요 기능:
        - 점선 스타일 사각형 그리기
        - ROI 타입별 자동 색상 지정
        - 라벨 및 신뢰도 표시
        - 단일/다중 ROI 시각화

    ========================================
    점선 사각형 그리기 알고리즘
    ========================================

    cv2.rectangle은 점선을 지원하지 않으므로 직접 구현:

    1. 사각형의 4개 변을 분리
       ┌─────────────────┐
       │  상단 수평선     │
       │                 │
       │좌  측           우측│
       │수  직           수직│
       │선  선           선│
       │                 │
       │  하단 수평선     │
       └─────────────────┘

    2. 각 변을 dash_length와 gap_length로 분할
       ━━━  ━━━  ━━━  ━━━  (dash=10, gap=5)

    3. dash 부분만 cv2.line으로 그리기

    ========================================

    Example:
        >>> visualizer = ROIVisualizer()
        >>> # 단일 ROI 시각화
        >>> result = visualizer.draw_roi(image, roi)
        >>> # 다중 ROI 시각화
        >>> result = visualizer.draw_rois(image, [roi1, roi2, roi3])
    """

    def __init__(self, config: VisualizationConfig | None = None) -> None:
        """시각화기 초기화

        Args:
            config: 시각화 설정. None이면 기본값 사용
        """
        self.config = config or VisualizationConfig()

    def draw_roi(
        self,
        image: NDArray[np.uint8],
        roi: ROI,
        *,
        color: tuple[int, int, int] | None = None,
        in_place: bool = False,
    ) -> NDArray[np.uint8]:
        """단일 ROI를 이미지에 시각화

        Args:
            image: 입력 이미지 (BGR)
            roi: 시각화할 ROI 객체
            color: 커스텀 색상 (BGR). None이면 ROI 타입에 따른 기본 색상 사용
            in_place: True이면 원본 이미지 수정, False이면 복사본 생성

        Returns:
            ROI가 시각화된 이미지
        """
        result = image if in_place else image.copy()

        # 색상 결정
        draw_color = color if color is not None else ROIColorScheme.get_color(roi.roi_type)

        # 바운딩 박스 좌표 추출
        pt1 = (roi.bbox.x, roi.bbox.y)
        pt2 = (roi.bbox.x2, roi.bbox.y2)

        # 스타일에 따른 사각형 그리기
        if self.config.style == VisualizationStyle.DASHED:
            self._draw_dashed_rectangle(
                result,
                pt1,
                pt2,
                draw_color,
                self.config.line_thickness,
            )
        else:
            cv2.rectangle(
                result,
                pt1,
                pt2,
                draw_color,
                self.config.line_thickness,
            )

        # 라벨 표시
        if self.config.show_label or self.config.show_confidence:
            label_text = self._format_label(roi)
            if label_text:
                self._draw_label(result, label_text, pt1, draw_color)

        return result

    def draw_rois(
        self,
        image: NDArray[np.uint8],
        rois: list[ROI],
        *,
        in_place: bool = False,
    ) -> NDArray[np.uint8]:
        """다중 ROI를 이미지에 시각화

        Args:
            image: 입력 이미지 (BGR)
            rois: 시각화할 ROI 객체 리스트
            in_place: True이면 원본 이미지 수정, False이면 복사본 생성

        Returns:
            모든 ROI가 시각화된 이미지
        """
        result = image if in_place else image.copy()

        for roi in rois:
            # 각 ROI에 대해 in_place=True로 호출하여 result에 누적
            self.draw_roi(result, roi, in_place=True)

        return result

    def draw_bounding_box(
        self,
        image: NDArray[np.uint8],
        bbox: BoundingBox,
        color: tuple[int, int, int],
        *,
        label: str | None = None,
        in_place: bool = False,
    ) -> NDArray[np.uint8]:
        """바운딩 박스를 이미지에 시각화

        ROI 객체 없이 BoundingBox만으로 시각화할 때 사용합니다.

        Args:
            image: 입력 이미지 (BGR)
            bbox: 바운딩 박스 좌표
            color: 선 색상 (BGR)
            label: 표시할 라벨 텍스트 (선택적)
            in_place: True이면 원본 이미지 수정, False이면 복사본 생성

        Returns:
            바운딩 박스가 시각화된 이미지
        """
        result = image if in_place else image.copy()

        pt1 = (bbox.x, bbox.y)
        pt2 = (bbox.x2, bbox.y2)

        # 스타일에 따른 사각형 그리기
        if self.config.style == VisualizationStyle.DASHED:
            self._draw_dashed_rectangle(
                result,
                pt1,
                pt2,
                color,
                self.config.line_thickness,
            )
        else:
            cv2.rectangle(
                result,
                pt1,
                pt2,
                color,
                self.config.line_thickness,
            )

        # 라벨 표시
        if label:
            self._draw_label(result, label, pt1, color)

        return result

    def _draw_dashed_rectangle(
        self,
        image: NDArray[np.uint8],
        pt1: tuple[int, int],
        pt2: tuple[int, int],
        color: tuple[int, int, int],
        thickness: int,
    ) -> None:
        """점선 사각형 그리기

        cv2에서 점선 사각형을 기본 지원하지 않으므로 직접 구현합니다.
        사각형의 4개 변을 각각 점선으로 그립니다.

        Args:
            image: 대상 이미지 (in-place 수정)
            pt1: 좌상단 좌표 (x1, y1)
            pt2: 우하단 좌표 (x2, y2)
            color: 선 색상 (BGR)
            thickness: 선 두께
        """
        x1, y1 = pt1
        x2, y2 = pt2

        # 4개 변에 대해 점선 그리기
        # 상단 수평선: (x1, y1) → (x2, y1)
        self._draw_dashed_line(image, (x1, y1), (x2, y1), color, thickness)

        # 하단 수평선: (x1, y2) → (x2, y2)
        self._draw_dashed_line(image, (x1, y2), (x2, y2), color, thickness)

        # 좌측 수직선: (x1, y1) → (x1, y2)
        self._draw_dashed_line(image, (x1, y1), (x1, y2), color, thickness)

        # 우측 수직선: (x2, y1) → (x2, y2)
        self._draw_dashed_line(image, (x2, y1), (x2, y2), color, thickness)

    def _draw_dashed_line(
        self,
        image: NDArray[np.uint8],
        pt1: tuple[int, int],
        pt2: tuple[int, int],
        color: tuple[int, int, int],
        thickness: int,
    ) -> None:
        """점선 그리기

        선분을 dash_length와 gap_length로 분할하여 점선을 그립니다.

        ========================================
        점선 그리기 알고리즘
        ========================================

        1. 선의 총 길이 계산 (유클리드 거리)
        2. 단위 방향 벡터 계산
        3. 시작점부터 끝점까지 순회하며:
           - dash_length 만큼 선 그리기
           - gap_length 만큼 건너뛰기
           - 반복

        예시 (dash=10, gap=5, 총 길이=45):
            ━━━━━━━━━━     ━━━━━━━━━━     ━━━━━━━━━━
            [dash:10] [gap:5] [dash:10] [gap:5] [dash:10]

        ========================================

        Args:
            image: 대상 이미지 (in-place 수정)
            pt1: 시작점 좌표
            pt2: 끝점 좌표
            color: 선 색상 (BGR)
            thickness: 선 두께
        """
        x1, y1 = pt1
        x2, y2 = pt2

        # 선의 총 길이 계산
        dx = x2 - x1
        dy = y2 - y1
        total_length = np.sqrt(dx * dx + dy * dy)

        if total_length < 1:
            return  # 너무 짧은 선은 무시

        # 단위 방향 벡터
        unit_x = dx / total_length
        unit_y = dy / total_length

        # 점선 패턴 길이
        dash = self.config.dash_length
        gap = self.config.gap_length
        pattern_length = dash + gap

        # 현재 위치
        current_pos = 0.0

        while current_pos < total_length:
            # dash 시작점
            start_x = int(x1 + unit_x * current_pos)
            start_y = int(y1 + unit_y * current_pos)

            # dash 끝점 (총 길이를 넘지 않도록)
            end_pos = min(current_pos + dash, total_length)
            end_x = int(x1 + unit_x * end_pos)
            end_y = int(y1 + unit_y * end_pos)

            # dash 그리기
            cv2.line(image, (start_x, start_y), (end_x, end_y), color, thickness)

            # 다음 dash 위치로 이동 (dash + gap)
            current_pos += pattern_length

    def _draw_label(
        self,
        image: NDArray[np.uint8],
        text: str,
        position: tuple[int, int],
        color: tuple[int, int, int],
    ) -> None:
        """라벨 텍스트 그리기

        배경이 있는 라벨을 그려서 가독성을 높입니다.

        Args:
            image: 대상 이미지 (in-place 수정)
            text: 라벨 텍스트
            position: 라벨 위치 (ROI 좌상단 좌표)
            color: 라벨 색상 (BGR)
        """
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = self.config.font_scale
        thickness = 1
        padding = self.config.label_padding

        # 텍스트 크기 측정
        (text_width, text_height), baseline = cv2.getTextSize(
            text, font, font_scale, thickness
        )

        # 라벨 위치 계산 (ROI 위쪽에 배치)
        x, y = position
        label_y = y - text_height - baseline - padding * 2

        # 이미지 경계를 벗어나면 ROI 내부에 배치
        if label_y < 0:
            label_y = y + padding

        # 배경 사각형 좌표
        bg_pt1 = (x, label_y)
        bg_pt2 = (x + text_width + padding * 2, label_y + text_height + baseline + padding * 2)

        # 반투명 배경 그리기
        if self.config.label_background_alpha > 0:
            # 배경 영역 추출 및 블렌딩
            bg_x1 = max(0, bg_pt1[0])
            bg_y1 = max(0, bg_pt1[1])
            bg_x2 = min(image.shape[1], bg_pt2[0])
            bg_y2 = min(image.shape[0], bg_pt2[1])

            if bg_x2 > bg_x1 and bg_y2 > bg_y1:
                # 배경 색상 (어두운 색)
                bg_color = (
                    int(color[0] * 0.3),
                    int(color[1] * 0.3),
                    int(color[2] * 0.3),
                )

                # 알파 블렌딩을 위한 오버레이
                overlay = image.copy()
                cv2.rectangle(overlay, bg_pt1, bg_pt2, bg_color, -1)
                alpha = self.config.label_background_alpha
                cv2.addWeighted(overlay, alpha, image, 1 - alpha, 0, image)

        # 텍스트 그리기
        text_x = x + padding
        text_y = label_y + text_height + padding
        cv2.putText(
            image,
            text,
            (text_x, text_y),
            font,
            font_scale,
            (255, 255, 255),  # 흰색 텍스트
            thickness,
            cv2.LINE_AA,
        )

    def _format_label(self, roi: ROI) -> str:
        """ROI 라벨 텍스트 포맷팅

        설정에 따라 라벨과 신뢰도를 조합한 문자열을 생성합니다.

        Args:
            roi: ROI 객체

        Returns:
            포맷된 라벨 문자열
        """
        parts: list[str] = []

        # 라벨 추가
        if self.config.show_label:
            if roi.label:
                parts.append(roi.label)
            else:
                # 라벨이 없으면 ID 또는 타입 사용
                parts.append(roi.id or roi.roi_type.value)

        # 신뢰도 추가
        if self.config.show_confidence and roi.confidence > 0:
            parts.append(f"{roi.confidence:.1%}")

        return " ".join(parts)


# ========================================
# 헬퍼 함수
# ========================================
def save_capture_with_visualization(
    capture_manager: CaptureManager,
    visualizer: ROIVisualizer,
    image: NDArray[np.uint8],
    rois: list[ROI],
    session_id: int,
    roi_name: str,
    *,
    save_original: bool = True,
    save_visualized: bool = True,
) -> tuple[Any | None, Any | None]:
    """ROI 시각화된 이미지와 원본을 함께 저장

    CaptureManager와 ROIVisualizer를 통합하여
    원본 이미지와 시각화된 이미지를 모두 저장하는 편의 함수입니다.

    Args:
        capture_manager: 캡처 관리자 인스턴스
        visualizer: ROI 시각화기 인스턴스
        image: 원본 이미지 (BGR)
        rois: 시각화할 ROI 리스트
        session_id: 세션 식별자
        roi_name: 파일명에 사용할 ROI 이름
        save_original: 원본 이미지 저장 여부
        save_visualized: 시각화된 이미지 저장 여부

    Returns:
        (원본 저장 결과, 시각화 저장 결과) 튜플
        저장하지 않은 경우 해당 위치는 None

    Example:
        >>> from storage.capture_manager import CaptureManager, CaptureConfig
        >>> from visualization.roi_visualizer import ROIVisualizer, save_capture_with_visualization
        >>>
        >>> config = CaptureConfig(base_directory=Path("./captures"))
        >>> manager = CaptureManager(config)
        >>> visualizer = ROIVisualizer()
        >>>
        >>> original_result, vis_result = save_capture_with_visualization(
        ...     manager, visualizer, frame, rois, session_id=1, roi_name="panel"
        ... )
    """
    original_result = None
    visualized_result = None

    # 원본 이미지 저장
    if save_original:
        original_result = capture_manager.save_capture(
            image,
            session_id,
            roi_name,
            suffix="original",
        )
        logger.debug(
            "원본 이미지 저장: %s",
            original_result.file_path if original_result.success else "실패",
        )

    # 시각화된 이미지 저장
    if save_visualized:
        visualized_image = visualizer.draw_rois(image, rois)
        visualized_result = capture_manager.save_capture(
            visualized_image,
            session_id,
            roi_name,
            suffix="visualized",
        )
        logger.debug(
            "시각화 이미지 저장: %s",
            visualized_result.file_path if visualized_result.success else "실패",
        )

    return original_result, visualized_result
