"""시각화 모듈 - 산업용 비디오 모니터링 시스템용

이 패키지는 ROI(Region of Interest) 영역 및 감지 결과를 시각화하는 기능을 제공합니다.

주요 컴포넌트:
    - ROIVisualizer: ROI 영역을 점선 스타일로 이미지에 표시
    - VisualizationConfig: 시각화 스타일 설정 (선 두께, 점선 패턴 등)
    - ROIColorScheme: ROI 타입별 색상 스키마
    - VisualizationStyle: 시각화 선 스타일 (실선/점선)
    - save_capture_with_visualization: CaptureManager 통합 헬퍼 함수

사용 예시:
    >>> from visualization import ROIVisualizer, VisualizationConfig, VisualizationStyle
    >>> from detection.roi_types import ROI, BoundingBox, ROIType
    >>>
    >>> # 시각화 설정
    >>> config = VisualizationConfig(
    ...     line_thickness=2,
    ...     show_label=True,
    ...     show_confidence=True,
    ...     style=VisualizationStyle.DASHED,
    ... )
    >>>
    >>> # 시각화기 생성
    >>> visualizer = ROIVisualizer(config)
    >>>
    >>> # ROI 시각화
    >>> roi = ROI(
    ...     id="roi_1",
    ...     bbox=BoundingBox(x=100, y=100, width=200, height=150),
    ...     roi_type=ROIType.NUMERIC,
    ...     confidence=0.95,
    ...     label="Temperature",
    ... )
    >>> result_image = visualizer.draw_roi(image, roi)
"""

from .roi_visualizer import (
    ROIColorScheme,
    ROIVisualizer,
    VisualizationConfig,
    VisualizationStyle,
    save_capture_with_visualization,
)

__all__ = [
    "ROIVisualizer",
    "VisualizationConfig",
    "ROIColorScheme",
    "VisualizationStyle",
    "save_capture_with_visualization",
]
