"""
Detection module for video monitoring.

This module provides components for:
- ROI (Region of Interest) type definitions and utilities
- Numeric value change detection with hybrid SSIM/OCR approach
- Line chart pattern detection
- Dynamic ROI auto-detection (text + waveform)

Typical usage:
    from detection import ROI, BoundingBox, ROIType
    from detection import ChangeDetector, ChartDetector

    # 사전 정의된 ROI 사용
    bbox = BoundingBox(x=100, y=200, width=50, height=30)
    roi = ROI(id="roi_1", bbox=bbox, roi_type=ROIType.NUMERIC)

    # 동적 ROI 자동 탐지
    from detection import DynamicROIDetector
    detector = DynamicROIDetector()
    rois = detector.detect(first_frame)
"""

from .roi_types import ROI, BoundingBox, ROIType, save_rois, load_rois
from .change_detector import ChangeDetector, ChangeEvent, ChangeDetectorConfig
from .chart_detector import ChartDetector, ChartDetectorConfig, ChartDetectionResult
from .text_roi_detector import (
    TextROIDetector,
    TextROIDetectorConfig,
    TextPattern,
    PatternCategory,
)
from .waveform_detector import WaveformDetector, WaveformDetectorConfig
from .dynamic_roi_detector import DynamicROIDetector, DynamicROIConfig, WindowDetectionStrategy
from .window_boundary_detector import WindowBoundaryDetector, WindowBoundaryConfig
from .color_template_detector import ColorTemplateDetector, ColorTemplateConfig, ColorROIMapping

__all__ = [
    # ROI Types (from roi_types.py)
    "ROI",
    "BoundingBox",
    "ROIType",
    "save_rois",
    "load_rois",
    # Change Detection
    "ChangeDetector",
    "ChangeEvent",
    "ChangeDetectorConfig",
    # Chart Detection
    "ChartDetector",
    "ChartDetectorConfig",
    "ChartDetectionResult",
    # Dynamic ROI Detection
    "DynamicROIDetector",
    "DynamicROIConfig",
    "TextROIDetector",
    "TextROIDetectorConfig",
    "TextPattern",
    "PatternCategory",
    "WaveformDetector",
    "WaveformDetectorConfig",
    # Window Boundary Detection
    "WindowBoundaryDetector",
    "WindowBoundaryConfig",
    "WindowDetectionStrategy",
    # Color Template Detection
    "ColorTemplateDetector",
    "ColorTemplateConfig",
    "ColorROIMapping",
]

__version__ = "0.3.0"
