"""
차트 감지기 - 산업용 비디오 모니터링 시스템용

이 모듈은 이미지에서 라인 차트를 감지하기 위한 컴퓨터 비전 기반 알고리즘을 구현합니다.
산업 환경에서 계기판이나 모니터에 표시된 그래프/차트 영역을 자동으로 식별합니다.

주요 기능:
    - Canny 엣지 감지를 통한 경계선 추출
    - Hough 선 변환을 통한 직선 감지
    - 패턴 인식을 통한 차트 구조 검증

감지 파이프라인:
    ========================================
    차트 감지 알고리즘 흐름도
    ========================================

    [입력 이미지]
         │
         ▼
    ┌─────────────────┐
    │   전처리        │
    │ (그레이스케일,   │
    │  가우시안 블러,  │
    │  형태학적 연산)  │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  Canny 엣지     │
    │   감지          │◄─── 경계선 추출
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  확률적 Hough   │
    │  선 변환        │◄─── 직선 감지
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  선 방향 분류    │
    │ (수평/수직/대각) │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  축 감지        │
    │ (X축: 하단 수평  │
    │  Y축: 좌측 수직) │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  데이터 선 식별  │
    │ (차트 영역 내    │
    │  대각선)        │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────┐
    │  신뢰도 계산    │
    │  + 차트 타입    │
    │  분류           │
    └────────┬────────┘
             │
             ▼
    [ChartDetectionResult]

    ========================================

설계 패턴:
    - Template Method 패턴: 감지 파이프라인의 각 단계를 별도 메서드로 분리
    - Strategy 패턴: 설정을 통한 알고리즘 파라미터 조정

알고리즘 기반:
    - Canny 엣지 감지: 그레이디언트 기반 경계선 검출
    - 확률적 Hough 변환: 선분 검출에 최적화된 Hough 변환

사용 예시:
    >>> from detection.chart_detector import ChartDetector, ChartDetectorConfig
    >>> config = ChartDetectorConfig(hough_threshold=50)
    >>> detector = ChartDetector(config)
    >>> result = detector.analyze(image)
    >>> if result.is_chart:
    ...     print(f"차트 타입: {result.chart_type.value}")
    ...     print(f"신뢰도: {result.confidence:.2f}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import cv2
import numpy as np
from numpy.typing import NDArray

logger = logging.getLogger(__name__)


class ChartType(Enum):
    """
    감지된 차트 타입 분류

    산업용 디스플레이에서 흔히 볼 수 있는 차트 유형을 정의합니다.
    감지된 선의 패턴과 구조를 기반으로 분류됩니다.

    Attributes:
        LINE_CHART: 라인 차트 (대각선이 많음, 시계열 데이터)
        BAR_CHART: 막대 차트 (수직선이 많음)
        SCATTER_PLOT: 산점도 (점 분포 패턴)
        AREA_CHART: 영역 차트 (채워진 라인 차트)
        UNKNOWN: 차트로 판단되나 타입 불명
        NOT_A_CHART: 차트가 아닌 것으로 판단됨
    """

    LINE_CHART = "line_chart"       # 라인 차트
    BAR_CHART = "bar_chart"         # 막대 차트
    SCATTER_PLOT = "scatter_plot"   # 산점도
    AREA_CHART = "area_chart"       # 영역 차트
    UNKNOWN = "unknown"             # 알 수 없는 차트
    NOT_A_CHART = "not_a_chart"     # 차트 아님


class LineOrientation(Enum):
    """
    선 방향 분류

    Hough 변환으로 감지된 선의 방향을 분류합니다.
    각도에 따라 수평, 수직, 대각선으로 구분됩니다.

    분류 기준:
        - HORIZONTAL: 각도 < 15° (거의 수평)
        - VERTICAL: 각도 > 75° (거의 수직)
        - DIAGONAL: 15° ≤ 각도 ≤ 75° (대각선)

    Attributes:
        HORIZONTAL: 수평선 (X축 후보)
        VERTICAL: 수직선 (Y축 후보)
        DIAGONAL: 대각선 (데이터 선 후보)
    """

    HORIZONTAL = "horizontal"   # 수평선
    VERTICAL = "vertical"       # 수직선
    DIAGONAL = "diagonal"       # 대각선


@dataclass
class DetectedLine:
    """
    감지된 선분을 나타내는 데이터 클래스

    Hough 변환으로 감지된 개별 선분의 기하학적 정보를 저장합니다.

    ========================================
    좌표계 설명
    ========================================

    이미지 좌표계:
        - 원점 (0,0): 이미지 좌상단
        - X축: 오른쪽으로 증가
        - Y축: 아래쪽으로 증가

        (0,0) ─────────────▶ X
          │
          │
          │    (x1,y1)────────(x2,y2)
          │        선분
          ▼
          Y

    각도 계산:
        - 0°: 완전 수평선
        - 90°: 완전 수직선
        - arctan2(|Δy|, |Δx|)로 계산

    ========================================

    Attributes:
        x1, y1: 선분 시작점 좌표
        x2, y2: 선분 끝점 좌표
        length: 선분 길이 (픽셀 단위)
        angle_degrees: 수평선과의 각도 (도 단위)
        orientation: 방향 분류 (수평/수직/대각선)
    """

    x1: int                         # 시작점 X
    y1: int                         # 시작점 Y
    x2: int                         # 끝점 X
    y2: int                         # 끝점 Y
    length: float                   # 선분 길이
    angle_degrees: float            # 각도 (도)
    orientation: LineOrientation    # 방향 분류

    @classmethod
    def from_hough_line(cls, line: NDArray[np.int32]) -> DetectedLine:
        """
        Hough 변환 출력에서 DetectedLine 생성

        OpenCV의 HoughLinesP 출력 형식을 파싱하여
        DetectedLine 객체를 생성합니다.

        Args:
            line: Hough 변환 결과 [[x1, y1, x2, y2]] 형식

        Returns:
            생성된 DetectedLine 객체
        """
        x1, y1, x2, y2 = line[0]

        # 선분 길이 계산 (유클리드 거리)
        length = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

        # 각도 계산 (라디안 → 도)
        # 0° = 수평, 90° = 수직
        angle_rad = np.arctan2(abs(y2 - y1), abs(x2 - x1))
        angle_deg = np.degrees(angle_rad)

        # ========================================
        # 방향 분류 기준
        # ========================================
        #   0° ─────┬───── 15°: 수평
        #          │
        #  15° ────┴─────75°: 대각선
        #          │
        #  75° ────┴───── 90°: 수직
        # ========================================
        if angle_deg < 15:
            orientation = LineOrientation.HORIZONTAL
        elif angle_deg > 75:
            orientation = LineOrientation.VERTICAL
        else:
            orientation = LineOrientation.DIAGONAL

        return cls(
            x1=x1,
            y1=y1,
            x2=x2,
            y2=y2,
            length=length,
            angle_degrees=angle_deg,
            orientation=orientation,
        )

    @property
    def midpoint(self) -> tuple[float, float]:
        """
        선분 중점 계산

        Returns:
            (x, y) 중점 좌표 튜플
        """
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)

    @property
    def slope(self) -> float | None:
        """
        선분 기울기 계산

        수직선(dx ≈ 0)의 경우 None 반환

        Returns:
            기울기 값 또는 None (수직선의 경우)
        """
        dx = self.x2 - self.x1
        if abs(dx) < 1e-6:
            return None  # 수직선
        return (self.y2 - self.y1) / dx


@dataclass
class AxisDetection:
    """
    감지된 차트 축 정보

    X축 또는 Y축으로 식별된 선에 대한 정보를 저장합니다.

    Attributes:
        is_detected: 축 감지 여부
        line: 감지된 축 선분 객체
        position: 축 원점 (x, y) 좌표
        length: 축 길이 (픽셀)
        is_x_axis: X축 여부
        is_y_axis: Y축 여부
    """

    is_detected: bool                               # 감지 여부
    line: DetectedLine | None = None                # 축 선분
    position: tuple[int, int] | None = None         # 축 원점 좌표
    length: float = 0.0                             # 축 길이
    is_x_axis: bool = False                         # X축 여부
    is_y_axis: bool = False                         # Y축 여부


@dataclass
class ChartDetectionResult:
    """
    차트 감지 분석 결과

    차트 감지 알고리즘의 전체 결과를 담는 데이터 클래스입니다.

    Attributes:
        is_chart: 차트 감지 여부
        chart_type: 감지된 차트 타입
        confidence: 신뢰도 점수 (0.0~1.0)
        x_axis: X축 감지 정보
        y_axis: Y축 감지 정보
        data_lines_count: 데이터 선 개수
        total_lines_detected: 감지된 총 선 개수
        horizontal_lines: 수평선 개수
        vertical_lines: 수직선 개수
        diagonal_lines: 대각선 개수
        metadata: 추가 메타데이터

    Example:
        >>> result = detector.analyze(image)
        >>> if result.is_chart:
        ...     print(f"차트 타입: {result.chart_type.value}")
        ...     print(f"축 감지: X={result.x_axis.is_detected}, Y={result.y_axis.is_detected}")
    """

    is_chart: bool                                  # 차트 여부
    chart_type: ChartType                           # 차트 타입
    confidence: float                               # 신뢰도
    x_axis: AxisDetection | None = None             # X축 정보
    y_axis: AxisDetection | None = None             # Y축 정보
    data_lines_count: int = 0                       # 데이터 선 수
    total_lines_detected: int = 0                   # 총 선 수
    horizontal_lines: int = 0                       # 수평선 수
    vertical_lines: int = 0                         # 수직선 수
    diagonal_lines: int = 0                         # 대각선 수
    metadata: dict[str, Any] = field(default_factory=dict)  # 메타데이터

    def to_dict(self) -> dict[str, Any]:
        """
        결과를 딕셔너리로 직렬화

        Returns:
            모든 필드를 포함하는 딕셔너리
        """
        return {
            "is_chart": self.is_chart,
            "chart_type": self.chart_type.value,
            "confidence": self.confidence,
            "has_x_axis": self.x_axis.is_detected if self.x_axis else False,
            "has_y_axis": self.y_axis.is_detected if self.y_axis else False,
            "data_lines_count": self.data_lines_count,
            "total_lines_detected": self.total_lines_detected,
            "horizontal_lines": self.horizontal_lines,
            "vertical_lines": self.vertical_lines,
            "diagonal_lines": self.diagonal_lines,
            "metadata": self.metadata,
        }


@dataclass
class ChartDetectorConfig:
    """
    차트 감지기 설정 클래스

    ========================================
    Canny 엣지 감지 알고리즘 개요
    ========================================

    Canny 엣지 감지는 5단계 알고리즘입니다:

    1. 노이즈 감소 (Gaussian Blur)
       - 5x5 가우시안 커널로 이미지 평활화
       - 노이즈로 인한 거짓 엣지 방지

    2. 그레이디언트 계산 (Sobel)
       - X, Y 방향 미분으로 그레이디언트 계산
       - 크기(magnitude)와 방향(direction) 획득

    3. 비최대 억제 (Non-Maximum Suppression)
       - 엣지 방향을 따라 로컬 최대값만 유지
       - 얇은 1픽셀 엣지 생성

    4. 이중 임계값 적용 (Double Threshold)
       - threshold1 (저): 약한 엣지 기준
       - threshold2 (고): 강한 엣지 기준
       - 강한 엣지: 확실한 엣지
       - 약한 엣지: 조건부 엣지

    5. 히스테리시스 엣지 추적
       - 강한 엣지와 연결된 약한 엣지만 최종 엣지로 채택
       - 연결되지 않은 약한 엣지는 제거

    ========================================

    ========================================
    Hough 선 변환 알고리즘 개요
    ========================================

    Hough 변환은 이미지 공간의 점을 파라미터 공간으로 매핑합니다.

    표준 Hough 변환:
        직선 방정식: x·cos(θ) + y·sin(θ) = ρ

        이미지 공간         파라미터 (ρ,θ) 공간
        ┌─────────┐        ┌─────────────────┐
        │  . . .  │        │                 │
        │ . . .   │  ──▶   │    투표 누적     │
        │. . .    │        │    ★ (최대점)   │
        └─────────┘        └─────────────────┘
        직선 위의 점들       한 점에서 교차

    확률적 Hough 변환 (HoughLinesP):
        - 모든 점이 아닌 무작위 샘플링
        - 선분의 시작점과 끝점 직접 반환
        - 최소 선분 길이, 최대 간격 설정 가능
        - 더 빠르고 실용적

    파라미터:
        - rho: ρ 해상도 (픽셀 단위)
        - theta: θ 해상도 (라디안 단위)
        - threshold: 최소 투표 수
        - minLineLength: 최소 선분 길이
        - maxLineGap: 선분 연결 최대 간격

    ========================================

    Attributes:
        canny_threshold1: Canny 저임계값
        canny_threshold2: Canny 고임계값
        canny_aperture_size: Sobel 연산자 크기
        hough_rho: Hough ρ 해상도 (픽셀)
        hough_theta: Hough θ 해상도 (라디안)
        hough_threshold: Hough 최소 투표 수
        hough_min_line_length: 최소 선분 길이
        hough_max_line_gap: 선분 연결 최대 간격
        min_axis_length_ratio: 축 최소 길이 비율
        axis_angle_tolerance: 축 각도 허용 오차
        axis_position_margin: 축 위치 여백
        min_data_lines: 차트 분류 최소 데이터 선 수
        min_diagonal_ratio: 대각선 최소 비율
        apply_gaussian_blur: 가우시안 블러 적용 여부
        gaussian_kernel_size: 가우시안 커널 크기
        apply_morphology: 형태학적 연산 적용 여부
        morph_kernel_size: 형태학적 커널 크기
        chart_confidence_threshold: 차트 판정 신뢰도 임계값
        axis_confidence_boost: 축 감지 시 신뢰도 가산
        data_line_confidence_boost: 데이터 선 당 신뢰도 가산
    """

    # ========================================
    # Canny 엣지 감지 파라미터
    # ========================================
    # 히스테리시스를 위한 이중 임계값
    # threshold1 < threshold2 관계 유지
    canny_threshold1: int = 50      # 저임계값 (약한 엣지 기준)
    canny_threshold2: int = 150     # 고임계값 (강한 엣지 기준)
    canny_aperture_size: int = 3    # Sobel 연산자 커널 크기 (3, 5, 7)

    # ========================================
    # 확률적 Hough 선 변환 파라미터
    # ========================================
    hough_rho: float = 1.0              # ρ 해상도 (픽셀 단위)
    hough_theta: float = np.pi / 180    # θ 해상도 (1도 = π/180 라디안)
    hough_threshold: int = 50           # 최소 투표 수 (선으로 인정하기 위한 기준)
    hough_min_line_length: int = 30     # 최소 선분 길이 (픽셀)
    hough_max_line_gap: int = 10        # 동일 선으로 연결할 최대 간격 (픽셀)

    # ========================================
    # 축 감지 파라미터
    # ========================================
    min_axis_length_ratio: float = 0.3  # 이미지 크기 대비 최소 축 길이 비율
    axis_angle_tolerance: float = 10.0  # 수평/수직에서의 허용 각도 (도)
    axis_position_margin: float = 0.2   # 엣지에서의 축 위치 여백 비율

    # ========================================
    # 데이터 선 감지 파라미터
    # ========================================
    min_data_lines: int = 1             # 차트 분류를 위한 최소 대각선 수
    min_diagonal_ratio: float = 0.1     # 전체 선 대비 대각선 최소 비율

    # ========================================
    # 전처리 설정
    # ========================================
    apply_gaussian_blur: bool = True                # 가우시안 블러 적용 여부
    gaussian_kernel_size: tuple[int, int] = (5, 5)  # 가우시안 커널 크기
    apply_morphology: bool = True                   # 형태학적 연산 적용 여부
    morph_kernel_size: tuple[int, int] = (3, 3)     # 형태학적 커널 크기

    # ========================================
    # 신뢰도 계산 파라미터
    # ========================================
    chart_confidence_threshold: float = 0.5   # 차트로 판정하기 위한 최소 신뢰도
    axis_confidence_boost: float = 0.2        # 축 감지 시 신뢰도 가산값
    data_line_confidence_boost: float = 0.1   # 데이터 선 당 신뢰도 가산값

    # ========================================
    # 적응형 Canny 설정
    # ========================================
    # 이미지 통계 기반 동적 임계값 계산 활성화
    use_adaptive_canny: bool = True
    # 적응형 임계값 계산 방법: "median" 또는 "otsu"
    # - median: 이미지 중앙값 기반 (기본, 일반적인 이미지에 안정적)
    # - otsu: Otsu 임계값 기반 (이중모드 히스토그램에 효과적)
    adaptive_canny_method: str = "median"
    # 적응형 임계값 안전 범위
    min_canny_threshold1: int = 30   # 저임계값 최소값
    max_canny_threshold2: int = 200  # 고임계값 최대값

    # ========================================
    # 적응형 Hough 설정
    # ========================================
    # 이미지 크기 기반 동적 파라미터 계산 활성화
    use_adaptive_hough: bool = True
    # 기준 이미지 대각선 길이 (이 크기를 기준으로 스케일링)
    hough_scale_reference: int = 500


class ChartDetector:
    """
    엣지 감지와 Hough 변환을 사용한 라인 차트 감지기

    이 클래스는 이미지에서 라인 차트를 감지하기 위한 완전한 파이프라인을 제공합니다.
    산업용 디스플레이의 그래프 영역을 자동으로 식별하는 데 최적화되어 있습니다.

    ========================================
    감지 전략 (Detection Strategy)
    ========================================

    1단계: 이미지 전처리
        - 가우시안 블러로 노이즈 감소
        - 형태학적 닫힘 연산으로 근접 엣지 연결

    2단계: Canny 엣지 감지
        - 이미지의 경계선 추출
        - 히스테리시스 기반 연속 엣지 검출

    3단계: Hough 선 변환
        - 엣지 이미지에서 직선 검출
        - 선분의 시작/끝점 좌표 획득

    4단계: 선 방향 분류
        - 각 선분을 수평/수직/대각선으로 분류
        - 각도 기반 분류 (15° 미만: 수평, 75° 초과: 수직)

    5단계: 축 감지
        - X축: 이미지 하단의 긴 수평선
        - Y축: 이미지 좌측의 긴 수직선

    6단계: 데이터 선 식별
        - 차트 영역 내의 대각선
        - 축으로 정의된 영역 또는 기본 내부 영역

    7단계: 신뢰도 계산
        - 축 존재, 데이터 선 수 등을 종합
        - 임계값 이상이면 차트로 판정

    ========================================
    신뢰도 계산 공식
    ========================================

    기본 신뢰도:
        + 0.20: 수평선 또는 수직선 존재
        + 0.20: X축 감지됨
        + 0.20: Y축 감지됨
        + 0.10 × min(데이터선 수, 5): 데이터 선 보너스
        + 0.15: 대각선 비율이 임계값 이상
        + 0.10: 라인 차트 패턴 (대각선 우세)

    최종 신뢰도 = min(1.0, max(0.0, 누적 점수))

    ========================================

    Attributes:
        config: 감지기 설정 객체

    Example:
        >>> detector = ChartDetector()
        >>> result = detector.analyze(image)
        >>> if result.is_chart:
        ...     print(f"라인 차트 감지됨! 신뢰도: {result.confidence:.2f}")
    """

    def __init__(self, config: ChartDetectorConfig | None = None) -> None:
        """
        차트 감지기 초기화

        Args:
            config: 감지 설정. None이면 기본값 사용
        """
        self.config = config or ChartDetectorConfig()

    def detect_chart(
        self,
        image: NDArray[np.uint8],
    ) -> bool:
        """
        차트 존재 여부 간단 확인

        상세 분석이 필요 없고 차트 여부만 빠르게 확인할 때 사용합니다.

        Args:
            image: 입력 이미지 (BGR 또는 그레이스케일)

        Returns:
            True: 차트가 감지됨
            False: 차트가 감지되지 않음
        """
        result = self.analyze(image)
        return result.is_chart

    def analyze(
        self,
        image: NDArray[np.uint8],
    ) -> ChartDetectionResult:
        """
        상세 차트 분석 수행

        이미지에서 차트를 감지하고 구조를 분석합니다.
        축 감지, 데이터 선 식별, 차트 타입 분류를 모두 수행합니다.

        Args:
            image: 입력 이미지 (BGR 또는 그레이스케일)

        Returns:
            상세한 차트 감지 결과
        """
        # 빈 이미지 처리
        if image is None or image.size == 0:
            return ChartDetectionResult(
                is_chart=False,
                chart_type=ChartType.NOT_A_CHART,
                confidence=0.0,
            )

        # 그레이스케일 변환 (필요 시)
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()

        height, width = gray.shape[:2]

        # ========================================
        # 감지 파이프라인 실행
        # ========================================

        # 1. 전처리
        preprocessed = self._preprocess(gray)

        # 2. 엣지 감지
        edges = self._detect_edges(preprocessed)

        # 3. 선 감지
        lines = self._detect_lines(edges)

        # 선이 없으면 차트 아님
        if lines is None or len(lines) == 0:
            return ChartDetectionResult(
                is_chart=False,
                chart_type=ChartType.NOT_A_CHART,
                confidence=0.0,
                total_lines_detected=0,
            )

        # 4. 선 분류
        detected_lines = [DetectedLine.from_hough_line(line) for line in lines]
        classified = self._classify_lines(detected_lines)

        # 5. 축 감지
        x_axis = self._detect_x_axis(classified["horizontal"], width, height)
        y_axis = self._detect_y_axis(classified["vertical"], width, height)

        # 6. 데이터 선 식별
        data_lines = self._identify_data_lines(
            classified["diagonal"],
            x_axis,
            y_axis,
            width,
            height,
        )

        # 7. 신뢰도 계산 및 차트 타입 결정
        confidence, chart_type = self._evaluate_chart_structure(
            x_axis=x_axis,
            y_axis=y_axis,
            data_lines_count=len(data_lines),
            total_lines=len(detected_lines),
            horizontal_count=len(classified["horizontal"]),
            vertical_count=len(classified["vertical"]),
            diagonal_count=len(classified["diagonal"]),
        )

        # 임계값 이상이면 차트로 판정
        is_chart = confidence >= self.config.chart_confidence_threshold

        return ChartDetectionResult(
            is_chart=is_chart,
            chart_type=chart_type if is_chart else ChartType.NOT_A_CHART,
            confidence=confidence,
            x_axis=x_axis,
            y_axis=y_axis,
            data_lines_count=len(data_lines),
            total_lines_detected=len(detected_lines),
            horizontal_lines=len(classified["horizontal"]),
            vertical_lines=len(classified["vertical"]),
            diagonal_lines=len(classified["diagonal"]),
            metadata={
                "image_size": (width, height),
                "edge_density": float(np.sum(edges > 0) / edges.size),
            },
        )

    def _preprocess(self, gray: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """
        엣지 감지를 위한 이미지 전처리

        Args:
            gray: 그레이스케일 이미지

        Returns:
            전처리된 이미지
        """
        processed = gray.copy()

        # 가우시안 블러 적용 (노이즈 감소)
        if self.config.apply_gaussian_blur:
            processed = cv2.GaussianBlur(
                processed,
                self.config.gaussian_kernel_size,
                0,
            )

        # 형태학적 연산 적용 (근접 엣지 연결)
        if self.config.apply_morphology:
            kernel = cv2.getStructuringElement(
                cv2.MORPH_RECT,
                self.config.morph_kernel_size,
            )
            # 닫힘 연산: 작은 구멍 채우기, 근접 엣지 연결
            processed = cv2.morphologyEx(processed, cv2.MORPH_CLOSE, kernel)

        return processed


    def _compute_adaptive_thresholds(
        self,
        gray: NDArray[np.uint8],
    ) -> tuple[int, int]:
        """
        이미지 통계 기반 동적 Canny 임계값 계산

        ========================================
        적응형 Canny 임계값 알고리즘
        ========================================

        이미지의 밝기 분포를 분석하여 최적의 Canny 임계값을 자동 계산합니다.

        방법 1: Median 기반 (기본)
            - 이미지 픽셀 중앙값(v)을 기준으로 임계값 설정
            - sigma = 0.33 (경험적 파라미터)
            - threshold1 = max(0, (1 - sigma) * v)
            - threshold2 = min(255, (1 + sigma) * v)
            - 일반적인 이미지에서 안정적인 결과

        방법 2: Otsu 기반
            - Otsu의 이진화 임계값을 기준으로 설정
            - 이중모드 히스토그램(bimodal)에 효과적
            - threshold1 = 0.5 * otsu_val
            - threshold2 = otsu_val

        안전 범위 적용:
            - threshold1 >= config.min_canny_threshold1
            - threshold2 <= config.max_canny_threshold2
            - threshold2 >= threshold1 + 50 (최소 차이 보장)

        ========================================

        Args:
            gray: 그레이스케일 이미지

        Returns:
            (threshold1, threshold2) 튜플 - Canny 저임계값과 고임계값
        """
        if self.config.adaptive_canny_method == "otsu":
            # Otsu 기반 임계값 계산
            otsu_val, _ = cv2.threshold(
                gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
            threshold1 = int(0.5 * otsu_val)
            threshold2 = int(otsu_val)
        else:
            # Median 기반 임계값 계산 (기본)
            v = np.median(gray)
            sigma = 0.33
            threshold1 = int(max(0, (1.0 - sigma) * v))
            threshold2 = int(min(255, (1.0 + sigma) * v))

        # 안전 범위 적용
        threshold1 = max(threshold1, self.config.min_canny_threshold1)
        threshold2 = min(threshold2, self.config.max_canny_threshold2)
        # 최소 차이 보장 (threshold2가 threshold1보다 충분히 커야 함)
        threshold2 = max(threshold2, threshold1 + 50)

        logger.debug(
            "적응형 Canny 임계값 계산 (방법=%s): threshold1=%d, threshold2=%d",
            self.config.adaptive_canny_method,
            threshold1,
            threshold2,
        )

        return threshold1, threshold2


    def _compute_adaptive_hough_params(
        self,
        image_size: tuple[int, int],
    ) -> dict[str, int]:
        """
        이미지 크기 기반 동적 Hough 파라미터 계산

        ========================================
        적응형 Hough 파라미터 알고리즘
        ========================================

        이미지 크기에 비례하여 Hough 변환 파라미터를 자동 조정합니다.

        스케일 계산:
            diagonal = sqrt(width² + height²)
            scale = diagonal / hough_scale_reference

        파라미터 스케일링:
            - min_line_length: 작은 이미지에서 짧은 선도 감지
            - max_line_gap: 작은 이미지에서 가까운 간격 허용
            - threshold: 작은 이미지에서 낮은 투표 수 허용

        최소값 보장:
            - min_line_length >= 20 픽셀
            - max_line_gap >= 5 픽셀
            - threshold >= 30 투표

        ========================================

        Args:
            image_size: (width, height) 튜플 - 이미지 크기

        Returns:
            Hough 파라미터 딕셔너리:
                - min_line_length: 최소 선분 길이
                - max_line_gap: 선분 연결 최대 간격
                - threshold: 최소 투표 수
        """
        import math

        width, height = image_size
        diagonal = math.sqrt(width**2 + height**2)
        scale = diagonal / self.config.hough_scale_reference

        # 스케일에 따른 파라미터 계산 (최소값 보장)
        min_line_length = int(max(20, 30 * scale))
        max_line_gap = int(max(5, 10 * scale))
        threshold = int(max(30, 50 * scale))

        logger.debug(
            "적응형 Hough 파라미터 계산: "
            "image_size=(%d, %d), diagonal=%.1f, scale=%.2f, "
            "min_line_length=%d, max_line_gap=%d, threshold=%d",
            width,
            height,
            diagonal,
            scale,
            min_line_length,
            max_line_gap,
            threshold,
        )

        return {
            "min_line_length": min_line_length,
            "max_line_gap": max_line_gap,
            "threshold": threshold,
        }

    def _detect_edges(self, image: NDArray[np.uint8]) -> NDArray[np.uint8]:
        """
        Canny 알고리즘을 사용한 엣지 감지

        ========================================
        Canny 엣지 감지 단계
        ========================================

        입력: 전처리된 그레이스케일 이미지

        1. Sobel 그레이디언트 계산
           Gx = Sobel(I, dx=1, dy=0)
           Gy = Sobel(I, dx=0, dy=1)
           G = √(Gx² + Gy²)
           θ = atan2(Gy, Gx)

        2. 비최대 억제
           그레이디언트 방향을 따라 국소 최대값만 유지

        3. 이중 임계값
           - G > threshold2 → 강한 엣지
           - threshold1 < G < threshold2 → 약한 엣지
           - G < threshold1 → 비엣지

        4. 히스테리시스 추적
           강한 엣지와 연결된 약한 엣지만 최종 엣지

        출력: 이진 엣지 이미지

        ========================================

        Args:
            image: 전처리된 이미지

        Returns:
            엣지 이미지 (이진 마스크)
        """
        # 적응형 또는 고정 임계값 선택
        if self.config.use_adaptive_canny:
            threshold1, threshold2 = self._compute_adaptive_thresholds(image)
        else:
            threshold1 = self.config.canny_threshold1
            threshold2 = self.config.canny_threshold2

        edges = cv2.Canny(
            image,
            threshold1,
            threshold2,
            apertureSize=self.config.canny_aperture_size,
        )
        return edges

    def _detect_lines(
        self,
        edges: NDArray[np.uint8],
    ) -> NDArray[np.int32] | None:
        """
        확률적 Hough 변환을 사용한 선 감지

        ========================================
        확률적 Hough 변환 (HoughLinesP)
        ========================================

        표준 Hough 변환과의 차이점:
            - 무작위 점 샘플링으로 더 빠름
            - 선분의 실제 끝점 반환
            - 최소 길이, 최대 간격 설정 가능

        출력 형식:
            lines[i] = [[x1, y1, x2, y2]]
            여기서 (x1,y1), (x2,y2)는 선분의 양 끝점

        ========================================

        Args:
            edges: 엣지 이미지

        Returns:
            감지된 선분 배열 또는 None
        """
        # 적응형 또는 고정 파라미터 선택
        if self.config.use_adaptive_hough:
            # 이미지 크기: (width, height) = (edges.shape[1], edges.shape[0])
            image_size = (edges.shape[1], edges.shape[0])
            params = self._compute_adaptive_hough_params(image_size)
            min_line_length = params["min_line_length"]
            max_line_gap = params["max_line_gap"]
            threshold = params["threshold"]
        else:
            min_line_length = self.config.hough_min_line_length
            max_line_gap = self.config.hough_max_line_gap
            threshold = self.config.hough_threshold

        lines = cv2.HoughLinesP(
            edges,
            rho=self.config.hough_rho,
            theta=self.config.hough_theta,
            threshold=threshold,
            minLineLength=min_line_length,
            maxLineGap=max_line_gap,
        )
        return lines

    def _classify_lines(
        self,
        lines: list[DetectedLine],
    ) -> dict[str, list[DetectedLine]]:
        """
        선분을 방향별로 분류

        Args:
            lines: 감지된 선분 목록

        Returns:
            방향별로 분류된 선분 딕셔너리
            {"horizontal": [...], "vertical": [...], "diagonal": [...]}
        """
        classified: dict[str, list[DetectedLine]] = {
            "horizontal": [],   # 수평선
            "vertical": [],     # 수직선
            "diagonal": [],     # 대각선
        }

        for line in lines:
            if line.orientation == LineOrientation.HORIZONTAL:
                classified["horizontal"].append(line)
            elif line.orientation == LineOrientation.VERTICAL:
                classified["vertical"].append(line)
            else:
                classified["diagonal"].append(line)

        return classified

    def _detect_x_axis(
        self,
        horizontal_lines: list[DetectedLine],
        width: int,
        height: int,
    ) -> AxisDetection:
        """
        수평선에서 X축 감지

        X축의 특성:
            - 이미지 하단에 위치
            - 충분히 긴 길이 (이미지 너비의 일정 비율 이상)
            - 거의 수평 (작은 각도)

        Args:
            horizontal_lines: 수평선 목록
            width: 이미지 너비
            height: 이미지 높이

        Returns:
            X축 감지 결과
        """
        if not horizontal_lines:
            return AxisDetection(is_detected=False)

        # 최소 축 길이 계산
        min_length = width * self.config.min_axis_length_ratio
        # 하단 여백 계산
        margin = height * self.config.axis_position_margin

        # X축 후보 선택 (하단의 긴 수평선)
        candidates: list[DetectedLine] = []

        for line in horizontal_lines:
            # 길이 확인
            if line.length < min_length:
                continue

            # 위치 확인 (이미지 하단에 있어야 함)
            avg_y = (line.y1 + line.y2) / 2
            if avg_y < height - margin:
                continue

            candidates.append(line)

        if not candidates:
            return AxisDetection(is_detected=False)

        # 가장 긴 후보를 X축으로 선택
        best_axis = max(candidates, key=lambda l: l.length)

        return AxisDetection(
            is_detected=True,
            line=best_axis,
            position=(min(best_axis.x1, best_axis.x2), best_axis.y1),
            length=best_axis.length,
            is_x_axis=True,
            is_y_axis=False,
        )

    def _detect_y_axis(
        self,
        vertical_lines: list[DetectedLine],
        width: int,
        height: int,
    ) -> AxisDetection:
        """
        수직선에서 Y축 감지

        Y축의 특성:
            - 이미지 좌측에 위치
            - 충분히 긴 길이 (이미지 높이의 일정 비율 이상)
            - 거의 수직 (큰 각도)

        Args:
            vertical_lines: 수직선 목록
            width: 이미지 너비
            height: 이미지 높이

        Returns:
            Y축 감지 결과
        """
        if not vertical_lines:
            return AxisDetection(is_detected=False)

        # 최소 축 길이 계산
        min_length = height * self.config.min_axis_length_ratio
        # 좌측 여백 계산
        margin = width * self.config.axis_position_margin

        # Y축 후보 선택 (좌측의 긴 수직선)
        candidates: list[DetectedLine] = []

        for line in vertical_lines:
            # 길이 확인
            if line.length < min_length:
                continue

            # 위치 확인 (이미지 좌측에 있어야 함)
            avg_x = (line.x1 + line.x2) / 2
            if avg_x > margin:
                continue

            candidates.append(line)

        if not candidates:
            return AxisDetection(is_detected=False)

        # 가장 긴 후보를 Y축으로 선택
        best_axis = max(candidates, key=lambda l: l.length)

        return AxisDetection(
            is_detected=True,
            line=best_axis,
            position=(best_axis.x1, max(best_axis.y1, best_axis.y2)),
            length=best_axis.length,
            is_x_axis=False,
            is_y_axis=True,
        )

    def _identify_data_lines(
        self,
        diagonal_lines: list[DetectedLine],
        x_axis: AxisDetection,
        y_axis: AxisDetection,
        width: int,
        height: int,
    ) -> list[DetectedLine]:
        """
        차트 데이터를 나타내는 선 식별

        차트 영역 내에 있는 대각선을 데이터 선으로 식별합니다.
        축이 감지되면 축으로 정의된 영역을, 그렇지 않으면 기본 내부 영역을 사용합니다.

        Args:
            diagonal_lines: 대각선 목록
            x_axis: X축 감지 정보
            y_axis: Y축 감지 정보
            width: 이미지 너비
            height: 이미지 높이

        Returns:
            데이터 선 목록
        """
        if not diagonal_lines:
            return []

        # ========================================
        # 차트 영역 정의
        # ========================================
        if x_axis.is_detected and y_axis.is_detected:
            # 축이 감지된 경우: 축으로 정의된 영역
            chart_left = y_axis.line.x1 if y_axis.line else 0
            chart_bottom = x_axis.line.y1 if x_axis.line else height
            chart_right = width
            chart_top = 0
        else:
            # 축이 없는 경우: 기본 내부 영역 (15% 여백)
            margin_x = int(width * 0.15)
            margin_y = int(height * 0.15)
            chart_left = margin_x
            chart_right = width - margin_x
            chart_top = margin_y
            chart_bottom = height - margin_y

        # 차트 영역 내의 대각선 필터링
        data_lines: list[DetectedLine] = []

        for line in diagonal_lines:
            # 선분 중점이 차트 영역 내에 있는지 확인
            mid_x, mid_y = line.midpoint
            if (
                chart_left <= mid_x <= chart_right
                and chart_top <= mid_y <= chart_bottom
            ):
                data_lines.append(line)

        return data_lines

    def _evaluate_chart_structure(
        self,
        x_axis: AxisDetection,
        y_axis: AxisDetection,
        data_lines_count: int,
        total_lines: int,
        horizontal_count: int,
        vertical_count: int,
        diagonal_count: int,
    ) -> tuple[float, ChartType]:
        """
        차트 구조 평가 및 신뢰도 점수 계산

        ========================================
        신뢰도 계산 알고리즘
        ========================================

        기본 점수:
            - 수평/수직선 존재: +0.20
            - X축 감지: +0.20
            - Y축 감지: +0.20
            - 데이터 선 (최대 5개): +0.10 × 개수
            - 대각선 비율 충분: +0.15
            - 라인 차트 패턴: +0.10

        차트 타입 결정:
            - 대각선 > 수평선 & 대각선 > 수직선 → LINE_CHART
            - 수직선 > 대각선 & 수직선 > 2×수평선 → BAR_CHART
            - 그 외 대각선 있으면 → LINE_CHART

        ========================================

        Args:
            x_axis: X축 감지 정보
            y_axis: Y축 감지 정보
            data_lines_count: 데이터 선 개수
            total_lines: 총 선 개수
            horizontal_count: 수평선 개수
            vertical_count: 수직선 개수
            diagonal_count: 대각선 개수

        Returns:
            (신뢰도, 차트 타입) 튜플
        """
        confidence = 0.0
        chart_type = ChartType.UNKNOWN

        # 선이 없으면 차트 아님
        if total_lines == 0:
            return 0.0, ChartType.NOT_A_CHART

        # 기본 점수: 수평/수직선 존재
        if horizontal_count > 0 or vertical_count > 0:
            confidence += 0.2

        # 축 감지 보너스
        if x_axis.is_detected:
            confidence += self.config.axis_confidence_boost
        if y_axis.is_detected:
            confidence += self.config.axis_confidence_boost

        # 데이터 선 보너스 (최대 5개까지 가산)
        if data_lines_count >= self.config.min_data_lines:
            confidence += self.config.data_line_confidence_boost * min(
                data_lines_count, 5
            )

        # 대각선 비율 보너스
        if total_lines > 0:
            diagonal_ratio = diagonal_count / total_lines
            if diagonal_ratio >= self.config.min_diagonal_ratio:
                confidence += 0.15

        # ========================================
        # 차트 타입 결정
        # ========================================
        if diagonal_count > horizontal_count and diagonal_count > vertical_count:
            # 대각선 우세 → 라인 차트
            chart_type = ChartType.LINE_CHART
            confidence += 0.1
        elif vertical_count > diagonal_count and vertical_count > horizontal_count * 2:
            # 수직선 우세 → 막대 차트
            chart_type = ChartType.BAR_CHART
        elif (
            diagonal_count >= self.config.min_data_lines
            and (x_axis.is_detected or y_axis.is_detected)
        ):
            # 축이 있고 대각선이 있으면 → 라인 차트
            chart_type = ChartType.LINE_CHART

        # 신뢰도 정규화 (0.0 ~ 1.0)
        confidence = min(1.0, max(0.0, confidence))

        return confidence, chart_type

    def visualize_detection(
        self,
        image: NDArray[np.uint8],
        result: ChartDetectionResult,
    ) -> NDArray[np.uint8]:
        """
        차트 감지 결과 시각화 이미지 생성

        감지된 축과 정보를 원본 이미지 위에 오버레이합니다.
        디버깅이나 결과 확인에 유용합니다.

        Args:
            image: 원본 이미지
            result: 감지 결과

        Returns:
            시각화 오버레이가 적용된 이미지
        """
        # 컬러 이미지로 변환
        if len(image.shape) == 2:
            vis = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        else:
            vis = image.copy()

        # X축 그리기 (빨간색)
        if result.x_axis and result.x_axis.is_detected and result.x_axis.line:
            line = result.x_axis.line
            cv2.line(vis, (line.x1, line.y1), (line.x2, line.y2), (0, 0, 255), 2)
            cv2.putText(
                vis,
                "X축",
                (line.x1, line.y1 - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 0, 255),
                1,
            )

        # Y축 그리기 (녹색)
        if result.y_axis and result.y_axis.is_detected and result.y_axis.line:
            line = result.y_axis.line
            cv2.line(vis, (line.x1, line.y1), (line.x2, line.y2), (0, 255, 0), 2)
            cv2.putText(
                vis,
                "Y축",
                (line.x1 + 5, line.y1),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 255, 0),
                1,
            )

        # 감지 정보 텍스트 추가
        info_y = 20
        cv2.putText(
            vis,
            f"차트: {result.is_chart} ({result.chart_type.value})",
            (10, info_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1,
        )
        cv2.putText(
            vis,
            f"신뢰도: {result.confidence:.2f}",
            (10, info_y + 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1,
        )
        cv2.putText(
            vis,
            f"선: {result.total_lines_detected} (수평:{result.horizontal_lines}, 수직:{result.vertical_lines}, 대각:{result.diagonal_lines})",
            (10, info_y + 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1,
        )

        return vis

    def detect_multiple_charts(
        self,
        image: NDArray[np.uint8],
        grid_divisions: int = 2,
    ) -> list[tuple[tuple[int, int, int, int], ChartDetectionResult]]:
        """
        이미지를 그리드로 분할하여 여러 차트 감지

        하나의 이미지에 여러 차트가 있을 수 있는 대시보드 형태의
        디스플레이를 분석할 때 유용합니다.

        Args:
            image: 입력 이미지
            grid_divisions: 축당 분할 수 (2 = 2x2 = 4 영역)

        Returns:
            (바운딩박스, 감지결과) 튜플 리스트
            바운딩박스: (x, y, width, height)
        """
        height, width = image.shape[:2]
        cell_height = height // grid_divisions
        cell_width = width // grid_divisions

        results: list[tuple[tuple[int, int, int, int], ChartDetectionResult]] = []

        # 그리드 셀 순회
        for row in range(grid_divisions):
            for col in range(grid_divisions):
                # 셀 좌표 계산
                x1 = col * cell_width
                y1 = row * cell_height
                x2 = (col + 1) * cell_width if col < grid_divisions - 1 else width
                y2 = (row + 1) * cell_height if row < grid_divisions - 1 else height

                # 셀 영역 추출 및 분석
                cell = image[y1:y2, x1:x2]
                result = self.analyze(cell)

                # 차트가 감지되면 결과 추가
                if result.is_chart:
                    results.append(((x1, y1, x2 - x1, y2 - y1), result))

        return results
