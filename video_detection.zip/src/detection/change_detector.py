"""
변화 감지기 - 산업용 비디오 모니터링 시스템용

이 모듈은 비디오 프레임 간의 변화를 감지하기 위한 하이브리드 전략을 구현합니다.
산업 환경에서 디스플레이의 숫자/텍스트 변화를 실시간으로 모니터링하는 것이 주요 목적입니다.

주요 기능:
    - SSIM (구조적 유사도 지수) 기반 빠른 픽셀 수준 비교
    - OCR 검증을 통한 정밀한 숫자/텍스트 변화 감지
    - 디바운싱을 통한 노이즈 필터링

하이브리드 감지 전략:
    ========================================
    감지 파이프라인 흐름도
    ========================================

    [현재 프레임] ─────────────────────────────────────┐
         │                                            │
         ▼                                            │
    ┌─────────────────┐                               │
    │  ROI 영역 추출   │                               │
    └────────┬────────┘                               │
             │                                        │
             ▼                                        │
    ┌─────────────────┐    ┌─────────────────┐       │
    │  이미지 전처리   │    │   이전 프레임    │◄──────┘
    │ (그레이스케일,   │    │   (캐시된 상태)  │
    │  블러, 평활화)   │    └────────┬────────┘
    └────────┬────────┘             │
             │                      │
             └──────────┬───────────┘
                        │
                        ▼
             ┌─────────────────┐
             │   SSIM 계산     │ ◄─── 빠른 1차 필터
             └────────┬────────┘
                      │
           ┌──────────┴──────────┐
           │                     │
     SSIM ≥ 임계값          SSIM < 임계값
     (변화 없음)            (잠재적 변화)
           │                     │
           ▼                     ▼
    ┌──────────────┐    ┌──────────────────┐
    │ NO_CHANGE    │    │ ROI 타입 확인    │
    │ 이벤트 반환   │    └────────┬─────────┘
    └──────────────┘             │
                      ┌──────────┴──────────┐
                      │                     │
                NUMERIC/TEXT             CHART/REGION
                      │                     │
                      ▼                     ▼
             ┌─────────────────┐    ┌──────────────┐
             │   OCR 검증      │    │ VISUAL_CHANGE│
             └────────┬────────┘    │ 이벤트 반환   │
                      │             └──────────────┘
                      ▼
             ┌─────────────────┐
             │   디바운싱      │ ◄─── 시간적 노이즈 필터
             │  (연속성 검증)   │
             └────────┬────────┘
                      │
           ┌──────────┴──────────┐
           │                     │
       확인됨                 미확인
           │                  (노이즈)
           ▼                     │
    ┌──────────────────┐         ▼
    │ 변화 타입 분류    │   ┌──────────────┐
    │ (증가/감소/텍스트)│   │ NO_CHANGE    │
    └────────┬─────────┘   │ 이벤트 반환   │
             │             └──────────────┘
             ▼
    ┌──────────────────┐
    │ ChangeEvent 생성 │
    │ + 콜백 알림      │
    └──────────────────┘

    ========================================

설계 패턴:
    - Observer 패턴: 콜백 기반 이벤트 알림 시스템
    - Strategy 패턴: ROI 타입별 다른 검증 전략 적용
    - State 패턴: ROI별 상태 추적 및 관리

사용 예시:
    >>> from detection.change_detector import ChangeDetector, ChangeDetectorConfig
    >>> config = ChangeDetectorConfig(ssim_threshold=0.95)
    >>> detector = ChangeDetector(config=config, ocr_engine=ocr)
    >>> detector.register_callback(lambda event: print(f"변화 감지: {event}"))
    >>> events = detector.detect_changes(current_frame, rois)
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Protocol, runtime_checkable

import cv2
import numpy as np
from numpy.typing import NDArray
from skimage.metrics import structural_similarity

from .roi_types import ROI, BoundingBox, ROIType

logger = logging.getLogger(__name__)


class ChangeType(Enum):
    """
    감지된 변화의 분류 타입

    산업용 디스플레이에서 발생할 수 있는 다양한 변화 유형을 정의합니다.
    각 타입은 후속 처리 로직에서 다르게 취급될 수 있습니다.

    Attributes:
        NUMERIC_INCREASE: 숫자 값이 증가한 경우 (예: 온도 상승, 압력 증가)
        NUMERIC_DECREASE: 숫자 값이 감소한 경우 (예: 재고 감소, 수위 하락)
        TEXT_CHANGE: 숫자가 아닌 텍스트가 변경된 경우 (예: 상태 메시지)
        VISUAL_CHANGE: OCR 없이 시각적 변화만 감지된 경우 (차트 영역 등)
        NO_CHANGE: 의미 있는 변화가 없는 경우 (노이즈 또는 안정 상태)
    """

    NUMERIC_INCREASE = "numeric_increase"  # 숫자 증가
    NUMERIC_DECREASE = "numeric_decrease"  # 숫자 감소
    TEXT_CHANGE = "text_change"            # 텍스트 변경
    VISUAL_CHANGE = "visual_change"        # 시각적 변화
    NO_CHANGE = "no_change"                # 변화 없음


@dataclass
class ChangeEvent:
    """
    모니터링 영역에서 감지된 변화를 나타내는 데이터 클래스

    하나의 ROI에서 감지된 단일 변화 이벤트의 모든 정보를 캡슐화합니다.
    이벤트 기반 아키텍처에서 콜백 함수나 이벤트 핸들러로 전달됩니다.

    Attributes:
        roi_id: 변화가 감지된 ROI의 고유 식별자
        roi_type: ROI의 타입 (NUMERIC, TEXT, CHART 등)
        change_type: 감지된 변화의 분류
        timestamp: 변화가 감지된 시점 (Unix 타임스탬프)
        ssim_score: SSIM 점수 (0.0~1.0, 1.0이 완전 동일)
        previous_value: 변화 전 OCR로 인식된 값
        current_value: 변화 후 OCR로 인식된 값
        numeric_delta: 숫자 값의 변화량 (증가: 양수, 감소: 음수)
        confidence: OCR 인식 신뢰도 (0.0~1.0)
        bbox: 변화가 발생한 영역의 바운딩 박스
        metadata: 추가 메타데이터 (디버깅 정보 등)

    Example:
        >>> event = ChangeEvent(
        ...     roi_id="temp_display",
        ...     roi_type=ROIType.NUMERIC,
        ...     change_type=ChangeType.NUMERIC_INCREASE,
        ...     timestamp=time.time(),
        ...     ssim_score=0.85,
        ...     previous_value="25.5",
        ...     current_value="26.0",
        ...     numeric_delta=0.5,
        ...     confidence=0.95
        ... )
        >>> print(f"온도 변화: {event.numeric_delta}°C")
    """

    roi_id: str                                    # ROI 식별자
    roi_type: ROIType                              # ROI 타입
    change_type: ChangeType                        # 변화 타입
    timestamp: float                               # 감지 시간
    ssim_score: float                              # SSIM 점수
    previous_value: str | None = None              # 이전 값
    current_value: str | None = None               # 현재 값
    numeric_delta: float | None = None             # 숫자 변화량
    confidence: float = 0.0                        # OCR 신뢰도
    bbox: BoundingBox | None = None                # 바운딩 박스
    metadata: dict[str, Any] = field(default_factory=dict)  # 추가 메타데이터

    @property
    def is_significant(self) -> bool:
        """
        변화가 유의미한지 (노이즈가 아닌지) 확인

        NO_CHANGE가 아닌 모든 변화를 유의미한 것으로 간주합니다.

        Returns:
            True: 유의미한 변화 (알림 필요)
            False: 노이즈 또는 변화 없음
        """
        return self.change_type != ChangeType.NO_CHANGE

    def to_dict(self) -> dict[str, Any]:
        """
        이벤트를 딕셔너리로 직렬화

        JSON 저장, 로깅, API 응답 등에 사용됩니다.

        Returns:
            모든 필드를 포함하는 딕셔너리
        """
        return {
            "roi_id": self.roi_id,
            "roi_type": self.roi_type.value,
            "change_type": self.change_type.value,
            "timestamp": self.timestamp,
            "ssim_score": self.ssim_score,
            "previous_value": self.previous_value,
            "current_value": self.current_value,
            "numeric_delta": self.numeric_delta,
            "confidence": self.confidence,
            "bbox": self.bbox.to_tuple() if self.bbox else None,
            "metadata": self.metadata,
        }


@dataclass
class ChangeDetectorConfig:
    """
    변화 감지기 설정 클래스

    감지 알고리즘의 동작을 제어하는 모든 파라미터를 포함합니다.
    기본값은 일반적인 산업용 디스플레이 모니터링에 최적화되어 있습니다.

    SSIM 관련 파라미터:
        ========================================
        SSIM (Structural Similarity Index) 개요
        ========================================

        SSIM은 두 이미지 간의 구조적 유사도를 측정하는 지표입니다.
        단순한 픽셀 차이(MSE)보다 인간의 시각적 인식에 더 가깝습니다.

        계산 공식:
            SSIM(x, y) = [l(x,y)]^α · [c(x,y)]^β · [s(x,y)]^γ

            여기서:
            - l(x,y) = 밝기(luminance) 비교
            - c(x,y) = 대비(contrast) 비교
            - s(x,y) = 구조(structure) 비교

        값의 범위:
            - 1.0: 완전히 동일한 이미지
            - 0.0: 완전히 다른 이미지
            - 음수: 역상관 (일반적이지 않음)

        임계값 선택 가이드:
            - 0.99 이상: 매우 엄격, 미세한 변화도 감지
            - 0.95 (기본값): 일반적인 변화 감지
            - 0.90 이하: 관대함, 큰 변화만 감지
        ========================================

    디바운싱 파라미터:
        ========================================
        디바운싱 (Debouncing) 알고리즘
        ========================================

        시간적 노이즈를 필터링하여 거짓 양성을 줄입니다.

        원리:
            1. 연속된 N개 프레임의 감지 결과를 버퍼에 저장
            2. 버퍼의 과반수(60%)가 변화를 나타낼 때만 확인
            3. 마지막 확인된 변화 이후 최소 시간 간격 유지

        시간 다이어그램:

            프레임: ─────[1]────[2]────[3]────[4]────[5]────
            감지:       변화    변화   노이즈   변화    변화
            버퍼:       [T]    [T,T]  [T,T,F] [T,T,F,T] [확인!]
                                              │
                                              └─ 60% 이상이므로 확인

        파라미터:
            - debounce_time_ms: 확인 간 최소 시간 간격 (100ms 기본)
            - debounce_buffer_size: 버퍼 크기 (5 프레임 기본)
        ========================================

    Attributes:
        ssim_threshold: SSIM 임계값 (이 값 미만이면 OCR 검증 트리거)
        ssim_window_size: SSIM 계산용 윈도우 크기 (홀수)
        debounce_time_ms: 변화 간 최소 시간 간격 (밀리초)
        debounce_buffer_size: 시간적 평활화용 프레임 버퍼 크기
        numeric_change_threshold: 숫자 변화 최소 임계값 (0.0 = 모든 변화)
        numeric_tolerance: 부동소수점 비교 허용 오차
        ocr_confidence_threshold: OCR 결과 채택을 위한 최소 신뢰도
        max_ocr_retries: OCR 실패 시 재시도 횟수
        apply_gaussian_blur: 가우시안 블러 적용 여부
        gaussian_kernel_size: 가우시안 커널 크기
        apply_histogram_equalization: 히스토그램 평활화 적용 여부
        use_grayscale_ssim: SSIM 계산을 그레이스케일로 수행할지
        downscale_factor: 성능 향상을 위한 다운스케일 비율
    """

    # ========================================
    # SSIM 임계값 설정
    # ========================================
    # ssim_threshold: 이 값 미만이면 "잠재적 변화"로 판단
    # ssim_window_size: SSIM 계산에 사용되는 슬라이딩 윈도우 크기
    ssim_threshold: float = 0.95  # 이 값 미만이면 OCR 검증 트리거
    ssim_window_size: int = 7     # SSIM 계산용 윈도우 크기 (홀수여야 함)

    # ========================================
    # 디바운싱 파라미터
    # ========================================
    # 빠른 연속 변화나 깜빡임을 필터링하기 위한 설정
    debounce_time_ms: float = 100.0   # 변화 간 최소 시간 간격 (밀리초)
    debounce_buffer_size: int = 5     # 시간적 평활화를 위한 프레임 버퍼 크기

    # ========================================
    # 숫자 변화 감지 설정
    # ========================================
    # 작은 숫자 변화도 감지할지 결정하는 설정
    numeric_change_threshold: float = 0.0   # 최소 변화량 (0.0 = 모든 변화 감지)
    numeric_tolerance: float = 1e-6         # 부동소수점 비교 허용 오차

    # ========================================
    # OCR 검증 설정
    # ========================================
    ocr_confidence_threshold: float = 0.6   # OCR 결과 채택을 위한 최소 신뢰도
    max_ocr_retries: int = 2                # OCR 실패 시 재시도 횟수

    # ========================================
    # 전처리 설정
    # ========================================
    # SSIM 계산 전 이미지 전처리 옵션
    apply_gaussian_blur: bool = True                    # 가우시안 블러 적용 여부
    gaussian_kernel_size: tuple[int, int] = (3, 3)      # 가우시안 커널 크기
    apply_histogram_equalization: bool = True           # 히스토그램 평활화 적용 여부

    # ========================================
    # 성능 최적화 설정
    # ========================================
    use_grayscale_ssim: bool = True   # 그레이스케일 SSIM 사용 (더 빠름)
    downscale_factor: float = 1.0     # 다운스케일 비율 (1.0 = 다운스케일 안 함)


@runtime_checkable
class OCREngine(Protocol):
    """
    변화 검증에 사용되는 OCR 엔진 프로토콜 인터페이스

    이 프로토콜을 구현하는 모든 OCR 엔진을 ChangeDetector에서 사용할 수 있습니다.
    덕 타이핑(duck typing)을 지원하여 유연한 OCR 엔진 교체가 가능합니다.

    Example:
        >>> class MyOCREngine:
        ...     def recognize(self, image: NDArray[np.uint8]) -> tuple[str, float]:
        ...         # OCR 수행 로직
        ...         return ("인식된 텍스트", 0.95)
        >>>
        >>> # 프로토콜 검증
        >>> assert isinstance(MyOCREngine(), OCREngine)
    """

    def recognize(self, image: NDArray[np.uint8]) -> tuple[str, float]:
        """
        이미지에서 텍스트 인식

        Args:
            image: 입력 이미지 (BGR 또는 그레이스케일)

        Returns:
            (인식된_텍스트, 신뢰도_점수) 튜플
            - 인식된_텍스트: OCR로 추출된 문자열
            - 신뢰도_점수: 0.0~1.0 범위의 신뢰도
        """
        ...


class DebounceBuffer:
    """
    변화 감지 디바운싱을 위한 시간적 버퍼

    연속된 여러 프레임에서 일관된 변화 감지를 요구함으로써
    순간적인 노이즈나 깜빡임을 필터링합니다.

    ========================================
    디바운싱 알고리즘 상세
    ========================================

    목적:
        - 조명 변화로 인한 거짓 양성 방지
        - 디스플레이 깜빡임 필터링
        - 프레임 간 일시적 노이즈 제거

    알고리즘:
        1. 각 감지 결과를 (타임스탬프, 변화여부, 값) 형태로 버퍼에 추가
        2. 버퍼가 가득 차면 가장 오래된 항목 제거 (FIFO)
        3. 변화 확인 조건:
           a) 마지막 확인 이후 최소 시간 간격 경과
           b) 버퍼의 60% 이상이 변화를 나타냄
           c) 현재 값이 마지막 확인된 값과 다름

    상태 다이어그램:

        ┌──────────┐  변화 감지  ┌───────────────┐
        │  대기    │───────────▶│  버퍼에 추가   │
        └──────────┘            └───────┬───────┘
              ▲                         │
              │                         ▼
              │                 ┌───────────────┐
              │    미확인      │  과반수 검사   │
              │◀───────────────│  + 시간 검사   │
              │                 └───────┬───────┘
              │                         │ 확인됨
              │                         ▼
              │                 ┌───────────────┐
              └─────────────────│  상태 업데이트 │
                    리셋       └───────────────┘

    ========================================

    Attributes:
        buffer_size: 버퍼에 저장할 최대 프레임 수
        time_window_ms: 디바운싱 시간 윈도우 (밀리초)

    Example:
        >>> buffer = DebounceBuffer(buffer_size=5, time_window_ms=100.0)
        >>> # 첫 번째 변화 - 아직 확인 안 됨
        >>> buffer.add_detection(0.0, True, "100")
        False
        >>> # 연속 변화 감지 후 확인
        >>> for i in range(1, 4):
        ...     result = buffer.add_detection(i * 0.05, True, "100")
        >>> result  # 마지막은 True (확인됨)
    """

    def __init__(
        self,
        buffer_size: int = 5,
        time_window_ms: float = 100.0,
    ) -> None:
        """
        디바운스 버퍼 초기화

        Args:
            buffer_size: 버퍼에 저장할 프레임 수 (기본값: 5)
            time_window_ms: 디바운싱 시간 윈도우 (밀리초, 기본값: 100.0)
        """
        self.buffer_size = buffer_size
        self.time_window_ms = time_window_ms

        # 버퍼: (타임스탬프, 변화여부, 인식값) 튜플의 덱
        self._buffer: deque[tuple[float, bool, str | None]] = deque(
            maxlen=buffer_size
        )

        # 마지막으로 확인된 변화의 시간과 값
        self._last_confirmed_time: float = 0.0
        self._last_confirmed_value: str | None = None

    def add_detection(
        self,
        timestamp: float,
        has_change: bool,
        value: str | None = None,
    ) -> bool:
        """
        감지 결과를 버퍼에 추가하고 변화 확인 여부 반환

        디바운싱 로직을 적용하여 노이즈를 필터링합니다.
        변화가 확인되면 내부 상태를 업데이트합니다.

        Args:
            timestamp: 감지 타임스탬프 (초 단위)
            has_change: 변화 감지 여부
            value: 선택적 인식 값 (OCR 결과)

        Returns:
            True: 디바운싱 후 변화가 확인됨 (알림 필요)
            False: 변화 없음 또는 아직 확인 전 (노이즈 가능성)
        """
        # 버퍼에 현재 감지 결과 추가
        self._buffer.append((timestamp, has_change, value))

        # 변화 없음이면 즉시 False 반환
        if not has_change:
            return False

        # 마지막 확인 이후 경과 시간 계산 (밀리초)
        time_since_last_ms = (timestamp - self._last_confirmed_time) * 1000

        # 최소 시간 간격이 경과하지 않았으면 확인하지 않음
        if time_since_last_ms < self.time_window_ms:
            return False

        # ========================================
        # 과반수 검사
        # ========================================
        # 버퍼 내 최근 감지들 중 변화를 나타내는 비율 계산
        recent_changes = [entry[1] for entry in self._buffer]
        change_ratio = sum(recent_changes) / len(recent_changes)

        # 60% 이상이 변화를 나타내면 확인
        if change_ratio >= 0.6:
            # 값 일관성 검사 - 값이 있고 이전과 다르면 확인
            if value is not None and value != self._last_confirmed_value:
                self._last_confirmed_time = timestamp
                self._last_confirmed_value = value
                return True

            # 값 없는 시각적 변화
            if value is None:
                self._last_confirmed_time = timestamp
                return True

        return False

    def reset(self) -> None:
        """
        버퍼 상태 초기화

        새로운 ROI 추적 시작 시 또는 오류 복구 시 호출됩니다.
        """
        self._buffer.clear()
        self._last_confirmed_time = 0.0
        self._last_confirmed_value = None


class ChangeDetector:
    """
    SSIM과 OCR 검증을 결합한 하이브리드 변화 감지기

    이 클래스는 산업용 디스플레이 모니터링을 위한 핵심 변화 감지 로직을 구현합니다.
    빠른 SSIM 비교로 변화 후보를 필터링하고, OCR로 정밀하게 검증합니다.

    ========================================
    감지 전략 (Detection Strategy)
    ========================================

    1단계: SSIM 기반 빠른 필터링
        - 모든 프레임에 대해 SSIM 계산 수행
        - SSIM ≥ 임계값: 변화 없음으로 즉시 반환
        - SSIM < 임계값: 2단계로 진행

    2단계: ROI 타입별 분기 처리
        - NUMERIC/TEXT ROI: OCR 검증 수행
        - CHART/REGION ROI: 시각적 변화로 직접 반환

    3단계: OCR 검증 (숫자/텍스트 ROI만)
        - 현재 프레임에서 텍스트 인식
        - 이전 값과 비교하여 실제 변화 여부 판단

    4단계: 디바운싱
        - 연속된 프레임에서 일관된 변화만 확인
        - 순간적인 노이즈 필터링

    5단계: 변화 타입 분류
        - 숫자 ROI: 증가/감소 판별 및 델타 계산
        - 텍스트 ROI: TEXT_CHANGE로 분류

    ========================================
    상태 관리
    ========================================

    각 ROI에 대해 다음 상태를 추적합니다:
        - _previous_frames: 이전 프레임 이미지 (SSIM 비교용)
        - _previous_values: 이전 OCR 인식 값 (변화 비교용)
        - _debounce_buffers: ROI별 디바운스 버퍼

    메모리 레이아웃:

        _previous_frames: dict[roi_id] → NDArray
        ┌────────────────────────────────────────┐
        │ "roi_1" → [이전 프레임 이미지 데이터]    │
        │ "roi_2" → [이전 프레임 이미지 데이터]    │
        │ ...                                    │
        └────────────────────────────────────────┘

        _previous_values: dict[roi_id] → str
        ┌────────────────────────────────────────┐
        │ "roi_1" → "25.5"                       │
        │ "roi_2" → "정상"                        │
        │ ...                                    │
        └────────────────────────────────────────┘

    ========================================

    Attributes:
        config: 감지기 설정 객체
        ocr_engine: OCR 엔진 인스턴스 (선택적)

    Example:
        >>> # 기본 사용법
        >>> detector = ChangeDetector()
        >>> events = detector.detect_changes(frame, rois)
        >>>
        >>> # 콜백과 함께 사용
        >>> def on_change(event: ChangeEvent):
        ...     print(f"변화 감지: {event.roi_id} - {event.change_type}")
        >>>
        >>> detector.register_callback(on_change)
        >>> detector.detect_changes(frame, rois)  # 변화 시 콜백 호출됨
    """

    def __init__(
        self,
        config: ChangeDetectorConfig | None = None,
        ocr_engine: OCREngine | None = None,
    ) -> None:
        """
        변화 감지기 초기화

        Args:
            config: 감지 설정. None이면 기본값 사용
            ocr_engine: 텍스트 검증용 OCR 엔진
        """
        self.config = config or ChangeDetectorConfig()
        self.ocr_engine = ocr_engine

        # ========================================
        # ROI별 상태 추적 저장소
        # ========================================
        self._previous_frames: dict[str, NDArray[np.uint8]] = {}    # 이전 프레임 캐시
        self._previous_values: dict[str, str] = {}                   # 이전 OCR 값 캐시
        self._debounce_buffers: dict[str, DebounceBuffer] = {}       # 디바운스 버퍼

        # ========================================
        # Observer 패턴 - 변화 이벤트 콜백
        # ========================================
        self._callbacks: list[Callable[[ChangeEvent], None]] = []

    def register_callback(
        self,
        callback: Callable[[ChangeEvent], None],
    ) -> None:
        """
        변화 이벤트 콜백 함수 등록

        유의미한 변화가 감지될 때마다 등록된 콜백이 호출됩니다.
        여러 콜백을 등록할 수 있으며, 등록 순서대로 호출됩니다.

        Args:
            callback: ChangeEvent를 받는 콜백 함수
        """
        self._callbacks.append(callback)

    def unregister_callback(
        self,
        callback: Callable[[ChangeEvent], None],
    ) -> None:
        """
        콜백 함수 등록 해제

        Args:
            callback: 등록 해제할 콜백 함수
        """
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    def detect_changes(
        self,
        current_frame: NDArray[np.uint8],
        rois: list[ROI],
        timestamp: float | None = None,
    ) -> list[ChangeEvent]:
        """
        현재 프레임과 이전 상태 간의 모든 ROI 변화 감지

        이전 프레임은 내부적으로 캐시되므로 현재 프레임만 전달하면 됩니다.
        첫 번째 호출에서는 각 ROI의 초기 상태가 저장되고 변화 없음이 반환됩니다.

        Args:
            current_frame: 현재 비디오 프레임 (BGR 또는 그레이스케일)
            rois: 모니터링할 ROI 목록
            timestamp: 프레임 타임스탬프. None이면 현재 시간 사용

        Returns:
            유의미한 변화가 감지된 ChangeEvent 목록
            (NO_CHANGE 이벤트는 제외됨)
        """
        if timestamp is None:
            timestamp = time.time()

        events: list[ChangeEvent] = []

        # 각 ROI에 대해 변화 감지 수행
        for roi in rois:
            event = self._detect_roi_change(current_frame, roi, timestamp)
            if event is not None and event.is_significant:
                events.append(event)
                self._notify_callbacks(event)

        return events

    def detect_changes_between_frames(
        self,
        previous_frame: NDArray[np.uint8],
        current_frame: NDArray[np.uint8],
        rois: list[ROI],
        timestamp: float | None = None,
    ) -> list[ChangeEvent]:
        """
        두 명시적 프레임 간의 변화 감지

        내부 상태를 사용하지 않고 두 프레임을 직접 비교합니다.
        배치 처리나 과거 프레임 분석에 유용합니다.

        Args:
            previous_frame: 이전 비디오 프레임
            current_frame: 현재 비디오 프레임
            rois: 모니터링할 ROI 목록
            timestamp: 프레임 타임스탬프

        Returns:
            감지된 변화 이벤트 목록
        """
        if timestamp is None:
            timestamp = time.time()

        events: list[ChangeEvent] = []

        for roi in rois:
            # 각 프레임에서 ROI 영역 추출
            prev_region = roi.extract_region(previous_frame)
            curr_region = roi.extract_region(current_frame)

            # 영역 비교 및 변화 감지
            event = self._compare_regions(
                roi=roi,
                prev_region=prev_region,
                curr_region=curr_region,
                timestamp=timestamp,
            )

            if event is not None and event.is_significant:
                events.append(event)
                self._notify_callbacks(event)

        return events

    def _detect_roi_change(
        self,
        current_frame: NDArray[np.uint8],
        roi: ROI,
        timestamp: float,
    ) -> ChangeEvent | None:
        """
        단일 ROI에서 변화 감지 (내부 메서드)

        이전 프레임 캐시를 사용하여 현재 프레임과 비교합니다.

        Args:
            current_frame: 현재 프레임
            roi: 검사할 ROI
            timestamp: 감지 타임스탬프

        Returns:
            ChangeEvent 또는 None (추출 실패 시)
        """
        # 현재 프레임에서 ROI 영역 추출
        try:
            curr_region = roi.extract_region(current_frame)
        except Exception as e:
            logger.warning(f"ROI {roi.id} 추출 실패: {e}")
            return None

        # 이전 프레임 가져오기
        prev_region = self._previous_frames.get(roi.id)

        if prev_region is None:
            # 이 ROI의 첫 프레임 - 저장하고 변화 없음 반환
            self._previous_frames[roi.id] = curr_region.copy()
            self._initialize_debounce_buffer(roi.id)
            return None

        # 영역 비교
        event = self._compare_regions(roi, prev_region, curr_region, timestamp)

        # 상태 업데이트
        self._previous_frames[roi.id] = curr_region.copy()

        return event

    def _compare_regions(
        self,
        roi: ROI,
        prev_region: NDArray[np.uint8],
        curr_region: NDArray[np.uint8],
        timestamp: float,
    ) -> ChangeEvent | None:
        """
        두 영역을 비교하여 변화 감지 (내부 메서드)

        ========================================
        비교 파이프라인
        ========================================

        1. 크기 정규화 (필요 시)
        2. 전처리 (그레이스케일, 블러, 평활화)
        3. SSIM 계산
        4. 임계값 기반 분기:
           - SSIM ≥ 임계값 → NO_CHANGE
           - SSIM < 임계값 → OCR 검증 또는 VISUAL_CHANGE

        ========================================

        Args:
            roi: 대상 ROI
            prev_region: 이전 영역 이미지
            curr_region: 현재 영역 이미지
            timestamp: 감지 타임스탬프

        Returns:
            변화 이벤트 또는 None
        """
        # 크기가 다르면 현재 영역을 이전 영역 크기로 리사이즈
        if prev_region.shape != curr_region.shape:
            curr_region = cv2.resize(
                curr_region,
                (prev_region.shape[1], prev_region.shape[0]),
            )

        # 영역 전처리 (노이즈 감소, 정규화)
        prev_processed = self._preprocess_region(prev_region)
        curr_processed = self._preprocess_region(curr_region)

        # SSIM 계산
        ssim_score = self._calculate_ssim(prev_processed, curr_processed)

        # ========================================
        # SSIM 기반 1차 판단
        # ========================================
        # SSIM이 임계값 이상이면 변화 없음으로 즉시 반환
        if ssim_score >= self.config.ssim_threshold:
            return ChangeEvent(
                roi_id=roi.id,
                roi_type=roi.roi_type,
                change_type=ChangeType.NO_CHANGE,
                timestamp=timestamp,
                ssim_score=ssim_score,
                confidence=1.0 - ssim_score,  # SSIM이 높을수록 변화 신뢰도 낮음
                bbox=roi.bbox,
            )

        # ========================================
        # 잠재적 변화 - OCR 검증 분기
        # ========================================
        # SSIM이 임계값 미만 = 잠재적 변화 감지
        # NUMERIC 또는 TEXT ROI이고 OCR 엔진이 있으면 OCR로 검증
        if roi.roi_type in (ROIType.NUMERIC, ROIType.TEXT) and self.ocr_engine:
            return self._verify_with_ocr(
                roi=roi,
                prev_region=prev_region,
                curr_region=curr_region,
                ssim_score=ssim_score,
                timestamp=timestamp,
            )

        # OCR 검증 없이 시각적 변화로 반환 (차트 영역 등)
        return self._create_visual_change_event(
            roi=roi,
            ssim_score=ssim_score,
            timestamp=timestamp,
        )

    def _preprocess_region(
        self,
        region: NDArray[np.uint8],
    ) -> NDArray[np.uint8]:
        """
        SSIM 비교를 위한 영역 전처리

        일관된 비교를 위해 이미지를 정규화합니다.

        전처리 단계:
            1. 그레이스케일 변환 (컬러 이미지인 경우)
            2. 가우시안 블러 (노이즈 감소)
            3. 히스토그램 평활화 (대비 정규화)
            4. 다운스케일 (성능 최적화, 선택적)

        Args:
            region: 입력 영역 이미지

        Returns:
            전처리된 그레이스케일 이미지
        """
        # 그레이스케일 변환 (필요 시)
        if len(region.shape) == 3:
            processed = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
        else:
            processed = region.copy()

        # 가우시안 블러 적용 (노이즈 감소)
        if self.config.apply_gaussian_blur:
            processed = cv2.GaussianBlur(
                processed,
                self.config.gaussian_kernel_size,
                0,  # sigmaX (0이면 커널 크기에서 자동 계산)
            )

        # 히스토그램 평활화 (대비 정규화)
        if self.config.apply_histogram_equalization:
            processed = cv2.equalizeHist(processed)

        # 다운스케일 (설정된 경우)
        if self.config.downscale_factor < 1.0:
            new_size = (
                int(processed.shape[1] * self.config.downscale_factor),
                int(processed.shape[0] * self.config.downscale_factor),
            )
            processed = cv2.resize(processed, new_size)

        return processed

    def _calculate_ssim(
        self,
        img1: NDArray[np.uint8],
        img2: NDArray[np.uint8],
    ) -> float:
        """
        두 이미지 간 SSIM 계산

        ========================================
        SSIM (Structural Similarity Index) 알고리즘
        ========================================

        SSIM은 두 이미지의 구조적 유사성을 측정합니다.
        단순한 픽셀 차이(MSE)보다 인간의 시각적 인식에 더 가깝습니다.

        SSIM 공식:
            SSIM(x, y) = (2μxμy + C1)(2σxy + C2)
                         ────────────────────────────
                         (μx² + μy² + C1)(σx² + σy² + C2)

        구성 요소:
            - μx, μy: 각 이미지의 평균 밝기
            - σx², σy²: 각 이미지의 분산 (대비)
            - σxy: 공분산 (구조적 유사성)
            - C1, C2: 안정화 상수

        윈도우 기반 계산:
            - 이미지를 작은 윈도우로 나눔
            - 각 윈도우에서 로컬 SSIM 계산
            - 전체 SSIM은 모든 윈도우의 평균

        주의사항:
            - 이미지가 윈도우 크기보다 작으면 대체 알고리즘 사용
            - 빈 이미지는 1.0 (동일) 반환

        ========================================

        Args:
            img1: 첫 번째 이미지 (그레이스케일)
            img2: 두 번째 이미지 (그레이스케일)

        Returns:
            SSIM 점수 (0.0 ~ 1.0, 1.0이 완전 동일)
        """
        # 빈 이미지 처리
        if img1.size == 0 or img2.size == 0:
            return 1.0  # 빈 이미지는 변화 없음으로 처리

        # SSIM 윈도우 크기 최소 요구사항 확인
        min_size = self.config.ssim_window_size
        if img1.shape[0] < min_size or img1.shape[1] < min_size:
            # 이미지가 너무 작으면 간단한 유사도 계산으로 대체
            return self._calculate_simple_similarity(img1, img2)

        try:
            # scikit-image의 structural_similarity 사용
            score, _ = structural_similarity(
                img1,
                img2,
                win_size=min(self.config.ssim_window_size, min(img1.shape[:2])),
                full=True,  # 전체 SSIM 맵도 반환 (여기서는 사용 안 함)
            )
            return float(score)
        except Exception as e:
            logger.warning(f"SSIM 계산 실패: {e}")
            return self._calculate_simple_similarity(img1, img2)

    def _calculate_simple_similarity(
        self,
        img1: NDArray[np.uint8],
        img2: NDArray[np.uint8],
    ) -> float:
        """
        정규화 상관관계를 사용한 간단한 유사도 계산

        SSIM을 사용할 수 없는 작은 이미지에 대한 대체 알고리즘입니다.

        ========================================
        정규화 교차 상관 (NCC) 알고리즘
        ========================================

        공식:
                     Σ(I1 - μ1)(I2 - μ2)
            NCC = ─────────────────────────────
                   √[Σ(I1 - μ1)²] · √[Σ(I2 - μ2)²]

        범위: [-1, 1] → [0, 1]로 스케일링
            - 1.0: 완전 동일
            - 0.0: 완전 다름
            - 0.5: 무상관

        ========================================

        Args:
            img1: 첫 번째 이미지
            img2: 두 번째 이미지

        Returns:
            유사도 점수 (0.0 ~ 1.0)
        """
        # 크기가 다르면 비교 불가
        if img1.shape != img2.shape:
            return 0.0

        # 0~1 범위로 정규화
        img1_norm = img1.astype(np.float64) / 255.0
        img2_norm = img2.astype(np.float64) / 255.0

        # 정규화 교차 상관 계산
        numerator = np.sum(
            (img1_norm - img1_norm.mean()) * (img2_norm - img2_norm.mean())
        )
        denominator = np.sqrt(
            np.sum((img1_norm - img1_norm.mean()) ** 2)
            * np.sum((img2_norm - img2_norm.mean()) ** 2)
        )

        # 분모가 0에 가까우면 (균일한 이미지)
        if denominator < 1e-10:
            return 1.0 if np.allclose(img1_norm, img2_norm) else 0.0

        # [-1, 1] 범위를 [0, 1] 범위로 변환
        return float((numerator / denominator + 1) / 2)

    def _verify_with_ocr(
        self,
        roi: ROI,
        prev_region: NDArray[np.uint8],
        curr_region: NDArray[np.uint8],
        ssim_score: float,
        timestamp: float,
    ) -> ChangeEvent:
        """
        OCR 인식을 통한 변화 검증

        SSIM에서 잠재적 변화가 감지된 후, OCR로 실제 텍스트/숫자 변화를
        확인합니다. 디바운싱을 적용하여 노이즈를 필터링합니다.

        ========================================
        OCR 검증 워크플로우
        ========================================

        1. 이전 값 조회 (캐시 또는 OCR)
        2. 현재 값 OCR 인식
        3. 값 비교
        4. 디바운싱 적용
        5. 변화 타입 분류

        재시도 전략:
            - 1차 시도: 원본 이미지
            - 2차 시도: 대비 증가 (alpha=1.5)
            - 3차 시도: Otsu 이진화

        ========================================

        Args:
            roi: 대상 ROI
            prev_region: 이전 영역 이미지
            curr_region: 현재 영역 이미지
            ssim_score: SSIM 점수
            timestamp: 감지 타임스탬프

        Returns:
            검증 결과를 담은 ChangeEvent
        """
        # OCR 엔진이 없으면 시각적 변화로 처리
        if self.ocr_engine is None:
            return self._create_visual_change_event(roi, ssim_score, timestamp)

        # ========================================
        # 이전 값 가져오기 (캐시 또는 OCR)
        # ========================================
        prev_value = self._previous_values.get(roi.id)
        if prev_value is None:
            prev_value, prev_conf = self._perform_ocr(prev_region)
            if prev_conf >= self.config.ocr_confidence_threshold:
                self._previous_values[roi.id] = prev_value

        # 현재 값 OCR 인식
        curr_value, curr_conf = self._perform_ocr(curr_region)

        # 캐시 업데이트 (신뢰도 충분 시)
        if curr_conf >= self.config.ocr_confidence_threshold:
            self._previous_values[roi.id] = curr_value

        # ========================================
        # 디바운싱 적용
        # ========================================
        debounce_buffer = self._get_debounce_buffer(roi.id)
        has_change = prev_value != curr_value
        is_confirmed = debounce_buffer.add_detection(timestamp, has_change, curr_value)

        # 디바운싱에서 확인되지 않으면 NO_CHANGE 반환
        if not is_confirmed:
            return ChangeEvent(
                roi_id=roi.id,
                roi_type=roi.roi_type,
                change_type=ChangeType.NO_CHANGE,
                timestamp=timestamp,
                ssim_score=ssim_score,
                previous_value=prev_value,
                current_value=curr_value,
                confidence=curr_conf,
                bbox=roi.bbox,
                metadata={"debounced": True},  # 디바운싱됨 표시
            )

        # ========================================
        # 변화 타입 분류 및 델타 계산
        # ========================================
        change_type, numeric_delta = self._classify_change(
            roi.roi_type,
            prev_value,
            curr_value,
        )

        return ChangeEvent(
            roi_id=roi.id,
            roi_type=roi.roi_type,
            change_type=change_type,
            timestamp=timestamp,
            ssim_score=ssim_score,
            previous_value=prev_value,
            current_value=curr_value,
            numeric_delta=numeric_delta,
            confidence=curr_conf,
            bbox=roi.bbox,
        )

    def _perform_ocr(
        self,
        region: NDArray[np.uint8],
    ) -> tuple[str, float]:
        """
        재시도 로직을 포함한 OCR 수행

        OCR 정확도를 높이기 위해 실패 시 다른 전처리를 적용하여 재시도합니다.

        ========================================
        재시도 전략
        ========================================

        시도 0: 원본 이미지 그대로
            - 대부분의 경우에 적합

        시도 1: 대비 증가 (alpha=1.5)
            - 저대비 이미지에 효과적
            - 흐린 디스플레이에 유용

        시도 2: Otsu 이진화
            - 복잡한 배경에 효과적
            - 노이즈가 많은 환경에 유용

        ========================================

        Args:
            region: OCR을 수행할 영역 이미지

        Returns:
            (인식된_텍스트, 신뢰도) 튜플
        """
        if self.ocr_engine is None:
            return "", 0.0

        best_result = ("", 0.0)

        for attempt in range(self.config.max_ocr_retries + 1):
            try:
                # 시도별 다른 전처리 적용
                if attempt == 0:
                    # 첫 시도: 원본 이미지
                    processed = region
                elif attempt == 1:
                    # 두 번째 시도: 대비 증가
                    processed = cv2.convertScaleAbs(region, alpha=1.5, beta=0)
                else:
                    # 세 번째 시도: 이진화
                    gray = (
                        cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
                        if len(region.shape) == 3
                        else region
                    )
                    _, processed = cv2.threshold(
                        gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
                    )
                    processed = cv2.cvtColor(processed, cv2.COLOR_GRAY2BGR)

                # OCR 수행
                text, confidence = self.ocr_engine.recognize(processed)

                # 더 좋은 결과면 저장
                if confidence > best_result[1]:
                    best_result = (text.strip(), confidence)

                # 임계값 이상이면 즉시 반환
                if confidence >= self.config.ocr_confidence_threshold:
                    break

            except Exception as e:
                logger.warning(f"OCR 시도 {attempt + 1} 실패: {e}")

        return best_result

    def _classify_change(
        self,
        roi_type: ROIType,
        prev_value: str | None,
        curr_value: str | None,
    ) -> tuple[ChangeType, float | None]:
        """
        변화 타입 분류 및 숫자 델타 계산

        ========================================
        숫자 변화 판별 로직
        ========================================

        입력: 이전값 "25.5", 현재값 "26.0"

        1. 숫자 파싱: 25.5, 26.0
        2. 델타 계산: 26.0 - 25.5 = 0.5
        3. 허용 오차 검사: |0.5| > 1e-6 → 유의미한 변화
        4. 부호 판단: 0.5 > 0 → NUMERIC_INCREASE

        결과: (NUMERIC_INCREASE, 0.5)

        ========================================

        Args:
            roi_type: ROI 타입
            prev_value: 이전 인식 값
            curr_value: 현재 인식 값

        Returns:
            (변화_타입, 숫자_델타) 튜플
            숫자 변화가 아니면 델타는 None
        """
        # 값이 없으면 시각적 변화로 분류
        if prev_value is None or curr_value is None:
            return ChangeType.VISUAL_CHANGE, None

        # 값이 같으면 변화 없음
        if prev_value == curr_value:
            return ChangeType.NO_CHANGE, None

        # 숫자 ROI인 경우 숫자 파싱 시도
        if roi_type == ROIType.NUMERIC:
            try:
                # 숫자 값 파싱
                prev_num = self._parse_numeric(prev_value)
                curr_num = self._parse_numeric(curr_value)

                if prev_num is not None and curr_num is not None:
                    delta = curr_num - prev_num

                    # 허용 오차 이내면 변화 없음
                    if abs(delta) <= self.config.numeric_tolerance:
                        return ChangeType.NO_CHANGE, 0.0

                    # 증가/감소 판별
                    if delta > 0:
                        return ChangeType.NUMERIC_INCREASE, delta
                    else:
                        return ChangeType.NUMERIC_DECREASE, delta

            except (ValueError, TypeError):
                pass

        # 숫자 파싱 실패 또는 TEXT ROI → 텍스트 변화
        return ChangeType.TEXT_CHANGE, None

    def _parse_numeric(self, value: str) -> float | None:
        """
        문자열에서 숫자 값 파싱

        산업용 디스플레이에서 흔히 볼 수 있는 다양한 숫자 형식을 처리합니다.

        지원 형식:
            - 정수: "123", "1,234"
            - 소수: "12.34", "12,34" (유럽식)
            - 단위 포함: "25.5°C", "100kg", "1.5V"

        Args:
            value: 파싱할 문자열

        Returns:
            파싱된 숫자 또는 None (파싱 실패 시)
        """
        if not value:
            return None

        # 문자열 정리
        cleaned = value.strip()
        cleaned = cleaned.replace(",", ".")  # 쉼표를 소수점으로 (유럽식)
        cleaned = cleaned.replace(" ", "")   # 공백 제거

        # 일반적인 비숫자 접미사 제거
        for suffix in ["%", "kg", "lb", "m", "ft", "C", "F", "Hz", "V", "A"]:
            if cleaned.endswith(suffix):
                cleaned = cleaned[: -len(suffix)]

        try:
            return float(cleaned)
        except ValueError:
            return None

    def _create_visual_change_event(
        self,
        roi: ROI,
        ssim_score: float,
        timestamp: float,
    ) -> ChangeEvent:
        """
        OCR 검증 없이 시각적 변화 이벤트 생성

        차트 영역이나 OCR을 사용할 수 없는 경우에 사용됩니다.

        Args:
            roi: 대상 ROI
            ssim_score: SSIM 점수
            timestamp: 감지 타임스탬프

        Returns:
            VISUAL_CHANGE 타입의 ChangeEvent
        """
        return ChangeEvent(
            roi_id=roi.id,
            roi_type=roi.roi_type,
            change_type=ChangeType.VISUAL_CHANGE,
            timestamp=timestamp,
            ssim_score=ssim_score,
            confidence=1.0 - ssim_score,  # SSIM이 낮을수록 변화 신뢰도 높음
            bbox=roi.bbox,
        )

    def _initialize_debounce_buffer(self, roi_id: str) -> None:
        """
        새 ROI에 대한 디바운스 버퍼 초기화

        Args:
            roi_id: ROI 식별자
        """
        if roi_id not in self._debounce_buffers:
            self._debounce_buffers[roi_id] = DebounceBuffer(
                buffer_size=self.config.debounce_buffer_size,
                time_window_ms=self.config.debounce_time_ms,
            )

    def _get_debounce_buffer(self, roi_id: str) -> DebounceBuffer:
        """
        ROI의 디바운스 버퍼 가져오기 (없으면 생성)

        Args:
            roi_id: ROI 식별자

        Returns:
            해당 ROI의 DebounceBuffer 인스턴스
        """
        self._initialize_debounce_buffer(roi_id)
        return self._debounce_buffers[roi_id]

    def _notify_callbacks(self, event: ChangeEvent) -> None:
        """
        등록된 모든 콜백에 변화 이벤트 알림

        콜백 실행 중 발생하는 예외는 로그만 기록하고 계속 진행합니다.
        이를 통해 하나의 콜백 오류가 다른 콜백에 영향을 주지 않습니다.

        Args:
            event: 알릴 변화 이벤트
        """
        for callback in self._callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"콜백 오류: {e}")

    def reset_state(self, roi_id: str | None = None) -> None:
        """
        감지기 상태 초기화

        새로운 모니터링 세션 시작 시 또는 오류 복구 시 호출합니다.

        Args:
            roi_id: 특정 ROI만 초기화. None이면 모든 ROI 초기화
        """
        if roi_id is not None:
            # 특정 ROI만 초기화
            self._previous_frames.pop(roi_id, None)
            self._previous_values.pop(roi_id, None)
            if roi_id in self._debounce_buffers:
                self._debounce_buffers[roi_id].reset()
        else:
            # 모든 ROI 초기화
            self._previous_frames.clear()
            self._previous_values.clear()
            for buffer in self._debounce_buffers.values():
                buffer.reset()

    def get_state_summary(self) -> dict[str, Any]:
        """
        현재 감지기 상태 요약 반환

        디버깅, 모니터링, 상태 확인에 유용합니다.

        Returns:
            현재 상태 정보를 담은 딕셔너리:
            - tracked_rois: 추적 중인 ROI ID 목록
            - cached_values: 캐시된 OCR 값들
            - debounce_buffers: 디바운스 버퍼 수
            - registered_callbacks: 등록된 콜백 수
        """
        return {
            "tracked_rois": list(self._previous_frames.keys()),
            "cached_values": dict(self._previous_values),
            "debounce_buffers": len(self._debounce_buffers),
            "registered_callbacks": len(self._callbacks),
        }
