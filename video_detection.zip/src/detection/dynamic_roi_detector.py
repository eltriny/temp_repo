"""동적 ROI 탐지 오케스트레이터

TextROIDetector와 WaveformDetector를 조합하여
첫 프레임에서 ROI를 자동으로 탐지합니다.

통합 파이프라인:
    [프레임] → TextROIDetector → 텍스트 ROI
            → WaveformDetector → 파형 ROI
            → 병합 + 중복 제거 → 최종 ROI 리스트

사용 예시:
    >>> from detection.dynamic_roi_detector import DynamicROIDetector
    >>> detector = DynamicROIDetector()
    >>> rois = detector.detect(first_frame)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
from numpy.typing import NDArray

from .roi_types import ROI, BoundingBox, ROIType
from .text_roi_detector import (
    TextROIDetector,
    TextROIDetectorConfig,
    TextPattern,
    PatternCategory,
)
from .waveform_detector import WaveformDetector, WaveformDetectorConfig

logger = logging.getLogger(__name__)


@dataclass
class DynamicROIConfig:
    """동적 ROI 탐지 통합 설정

    Attributes:
        enable_text_detection: 텍스트 ROI 탐지 활성화
        enable_waveform_detection: 파형 ROI 탐지 활성화
        text_config: 텍스트 탐지기 설정
        waveform_config: 파형 탐지기 설정
        roi_padding: 최종 ROI bbox 추가 여백 (px)
        iou_merge_threshold: 텍스트/파형 간 중복 병합 IoU 임계값
        default_threshold: 자동 생성 ROI의 기본 변화 감지 임계값
    """

    enable_text_detection: bool = True
    enable_waveform_detection: bool = True
    text_config: TextROIDetectorConfig = field(
        default_factory=TextROIDetectorConfig
    )
    waveform_config: WaveformDetectorConfig = field(
        default_factory=WaveformDetectorConfig
    )
    roi_padding: int = 5
    iou_merge_threshold: float = 0.5
    default_threshold: float = 0.1


class DynamicROIDetector:
    """동적 ROI 탐지 오케스트레이터

    TextROIDetector와 WaveformDetector를 조합하여
    첫 프레임에서 ROI를 자동 탐지합니다.

    결과는 기존 detection.roi_types.ROI 객체와 완전히 호환되어,
    ParallelProcessor, ChangeDetector 등 다운스트림 파이프라인에서
    템플릿 기반 ROI와 동일하게 사용됩니다.

    Example:
        >>> from ocr.ocr_engine import OCREngine
        >>> detector = DynamicROIDetector(ocr_engine=OCREngine())
        >>> rois = detector.detect(first_frame)
        >>> print(f"{len(rois)}개 ROI 자동 탐지")
    """

    def __init__(
        self,
        config: DynamicROIConfig | None = None,
        ocr_engine: object | None = None,
    ) -> None:
        self.config = config or DynamicROIConfig()
        self._ocr_engine = ocr_engine

        # 서브 탐지기 초기화
        self._text_detector: TextROIDetector | None = None
        self._waveform_detector: WaveformDetector | None = None

        if self.config.enable_text_detection:
            self._text_detector = TextROIDetector(
                config=self.config.text_config,
                ocr_engine=self._ocr_engine,
            )

        if self.config.enable_waveform_detection:
            self._waveform_detector = WaveformDetector(
                config=self.config.waveform_config,
            )

    def detect(self, frame: NDArray[np.uint8]) -> list[ROI]:
        """프레임에서 동적 ROI 탐지

        텍스트와 파형 탐지를 순차적으로 실행하고,
        결과를 병합하여 고유 ID가 부여된 ROI 리스트를 반환합니다.

        Args:
            frame: 입력 프레임 (BGR 형식)

        Returns:
            탐지된 ROI 리스트 (고유 ID 부여, 중복 제거)
        """
        if frame is None or frame.size == 0:
            logger.warning("빈 프레임이 입력됨")
            return []

        all_rois: list[ROI] = []

        # Phase 1: 텍스트 ROI 탐지
        if self._text_detector is not None:
            try:
                text_rois = self._text_detector.detect(frame)
                all_rois.extend(text_rois)
                logger.info("텍스트 ROI %d개 탐지", len(text_rois))
            except Exception as e:
                logger.error("텍스트 ROI 탐지 실패: %s", e)

        # Phase 2: 파형 ROI 탐지
        if self._waveform_detector is not None:
            try:
                waveform_rois = self._waveform_detector.detect(frame)
                all_rois.extend(waveform_rois)
                logger.info("파형 ROI %d개 탐지", len(waveform_rois))
            except Exception as e:
                logger.error("파형 ROI 탐지 실패: %s", e)

        if not all_rois:
            logger.warning("동적 ROI 탐지 결과 없음")
            return []

        # Phase 3: 텍스트-파형 간 중복 제거
        merged = self._merge_overlapping_rois(all_rois)

        # Phase 4: 고유 ID 재할당
        final = self._assign_ids(merged)

        logger.info(
            "동적 ROI 탐지 완료: 총 %d개 (텍스트+파형 병합 전 %d개)",
            len(final),
            len(all_rois),
        )

        return final

    def _merge_overlapping_rois(self, rois: list[ROI]) -> list[ROI]:
        """IoU 기반 중복 ROI 병합

        텍스트 ROI와 파형 ROI가 겹치는 경우,
        텍스트 ROI를 우선합니다 (더 구체적인 정보 보유).

        Args:
            rois: 병합 전 ROI 리스트

        Returns:
            병합된 ROI 리스트
        """
        if len(rois) <= 1:
            return rois

        # 텍스트 ROI 우선 (detection_method=text가 먼저)
        sorted_rois = sorted(
            rois,
            key=lambda r: (
                0 if r.metadata.get("detection_method") == "text" else 1,
                -r.confidence,
            ),
        )

        merged: list[ROI] = []
        used = [False] * len(sorted_rois)

        for i, roi_i in enumerate(sorted_rois):
            if used[i]:
                continue

            used[i] = True
            # 겹치는 ROI 확인 (낮은 우선순위 ROI 흡수)
            for j in range(i + 1, len(sorted_rois)):
                if used[j]:
                    continue
                iou = roi_i.bbox.iou(sorted_rois[j].bbox)
                if iou >= self.config.iou_merge_threshold:
                    used[j] = True
                    logger.debug(
                        "ROI 중복 병합: %s (IoU=%.2f) → %s 흡수",
                        sorted_rois[j].id,
                        iou,
                        roi_i.id,
                    )

            merged.append(roi_i)

        return merged

    @staticmethod
    def _assign_ids(rois: list[ROI]) -> list[ROI]:
        """ROI에 고유 ID를 순차적으로 할당

        Args:
            rois: ID 재할당 대상 ROI 리스트

        Returns:
            새 ID가 부여된 ROI 리스트
        """
        result: list[ROI] = []
        text_idx = 0
        waveform_idx = 0

        for roi in rois:
            method = roi.metadata.get("detection_method", "unknown")
            if method == "text":
                new_id = f"auto_text_{text_idx}"
                text_idx += 1
            elif method == "waveform":
                new_id = f"auto_waveform_{waveform_idx}"
                waveform_idx += 1
            else:
                new_id = f"auto_unknown_{text_idx + waveform_idx}"

            result.append(ROI(
                id=new_id,
                bbox=roi.bbox,
                roi_type=roi.roi_type,
                confidence=roi.confidence,
                label=roi.label,
                metadata=roi.metadata,
            ))

        return result
