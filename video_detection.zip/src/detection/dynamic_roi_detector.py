"""동적 ROI 탐지 오케스트레이터

TextROIDetector와 WaveformDetector를 조합하여
첫 프레임에서 ROI를 자동으로 탐지합니다.

통합 파이프라인 (윈도우 경계 탐지 포함):
    [프레임] → WindowBoundaryDetector → 크롭 (또는 전체 프레임)
            → TextROIDetector → 텍스트 ROI
            → WaveformDetector → 파형 ROI
            → 병합 + 중복 제거 → 좌표 복원 → 최종 ROI 리스트

사용 예시:
    >>> from detection.dynamic_roi_detector import DynamicROIDetector
    >>> detector = DynamicROIDetector()
    >>> rois = detector.detect(first_frame)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum

import numpy as np
from numpy.typing import NDArray

from .roi_types import ROI, BoundingBox, ROIType
from .text_roi_detector import (
    PatternCategory,
    TextPattern,
    TextROIDetector,
    TextROIDetectorConfig,
)
from .waveform_detector import WaveformDetector, WaveformDetectorConfig
from .window_boundary_detector import WindowBoundaryConfig, WindowBoundaryDetector

logger = logging.getLogger(__name__)


class WindowDetectionStrategy(Enum):
    """윈도우 경계 탐지 전략

    Attributes:
        NONE: 윈도우 경계 탐지 비활성화 (전체 프레임 사용)
        CONTOUR: OpenCV 컨투어 기반 탐지 (기본, 추가 의존성 없음)
    """

    NONE = "none"
    CONTOUR = "contour"


@dataclass
class DynamicROIConfig:
    """동적 ROI 탐지 통합 설정

    Attributes:
        enable_text_detection: 텍스트 ROI 탐지 활성화
        enable_waveform_detection: 파형 ROI 탐지 활성화
        text_config: 텍스트 탐지기 설정
        waveform_config: 파형 탐지기 설정
        roi_padding: 최종 ROI bbox 추가 여백 (px)
        iou_merge_threshold: 텍스트/파형 간 중복 병합 IoU 임계값
        default_threshold: 자동 생성 ROI의 기본 변화 감지 임계값
        window_detection_strategy: 윈도우 경계 탐지 전략
        window_boundary_config: 윈도우 경계 탐지기 설정
    """

    enable_text_detection: bool = True
    enable_waveform_detection: bool = True
    text_config: TextROIDetectorConfig = field(default_factory=TextROIDetectorConfig)
    waveform_config: WaveformDetectorConfig = field(
        default_factory=WaveformDetectorConfig
    )
    roi_padding: int = 5
    iou_merge_threshold: float = 0.5
    default_threshold: float = 0.1
    # 윈도우 경계 탐지 설정 (기본: NONE — 하위 호환성 보장)
    window_detection_strategy: WindowDetectionStrategy = WindowDetectionStrategy.NONE
    window_boundary_config: WindowBoundaryConfig = field(
        default_factory=WindowBoundaryConfig
    )


class DynamicROIDetector:
    """동적 ROI 탐지 오케스트레이터

    TextROIDetector와 WaveformDetector를 조합하여
    첫 프레임에서 ROI를 자동 탐지합니다.

    결과는 기존 detection.roi_types.ROI 객체와 완전히 호환되어,
    ParallelProcessor, ChangeDetector 등 다운스트림 파이프라인에서
    템플릿 기반 ROI와 동일하게 사용됩니다.

    Example:
        >>> from ocr.ocr_engine import OCREngine
        >>> detector = DynamicROIDetector(ocr_engine=OCREngine())
        >>> rois = detector.detect(first_frame)
        >>> print(f"{len(rois)}개 ROI 자동 탐지")
    """

    def __init__(
        self,
        config: DynamicROIConfig | None = None,
        ocr_engine: object | None = None,
    ) -> None:
        self.config = config or DynamicROIConfig()
        self._ocr_engine = ocr_engine

        # 서브 탐지기 초기화
        self._text_detector: TextROIDetector | None = None
        self._waveform_detector: WaveformDetector | None = None

        if self.config.enable_text_detection:
            self._text_detector = TextROIDetector(
                config=self.config.text_config,
                ocr_engine=self._ocr_engine,
            )

        if self.config.enable_waveform_detection:
            self._waveform_detector = WaveformDetector(
                config=self.config.waveform_config,
            )

        # 윈도우 경계 탐지기 초기화
        self._window_detector: WindowBoundaryDetector | None = None
        self._window_bbox: BoundingBox | None = None

        strategy = self.config.window_detection_strategy
        if strategy == WindowDetectionStrategy.CONTOUR:
            self._window_detector = WindowBoundaryDetector(
                config=self.config.window_boundary_config,
            )

    @property
    def last_window_bbox(self) -> BoundingBox | None:
        """마지막 detect() 호출에서 탐지된 윈도우 경계

        메타데이터 저장이나 시각화에 사용할 수 있습니다.

        Returns:
            탐지된 윈도우 경계 BoundingBox, 또는 None
        """
        return self._window_bbox

    def detect(self, frame: NDArray[np.uint8]) -> list[ROI]:
        """프레임에서 동적 ROI 탐지

        윈도우 경계 탐지 → 텍스트/파형 탐지 → 병합 → 좌표 복원 순으로
        실행하여, 고유 ID가 부여된 ROI 리스트를 반환합니다.

        Args:
            frame: 입력 프레임 (BGR 형식)

        Returns:
            탐지된 ROI 리스트 (고유 ID 부여, 중복 제거, 원본 좌표)
        """
        if frame is None or frame.size == 0:
            logger.warning("빈 프레임이 입력됨")
            return []

        # === Phase 0: 윈도우 경계 탐지 ===
        working_frame = frame
        self._window_bbox = None

        if self._window_detector is not None:
            try:
                self._window_bbox = self._window_detector.detect(frame)
                if self._window_bbox is not None:
                    logger.info(
                        "윈도우 경계 탐지: (%d,%d) %dx%d",
                        self._window_bbox.x,
                        self._window_bbox.y,
                        self._window_bbox.width,
                        self._window_bbox.height,
                    )
                    y_sl, x_sl = self._window_bbox.to_slice()
                    working_frame = frame[y_sl, x_sl].copy()
                else:
                    logger.info("윈도우 경계 미탐지 — 전체 프레임 사용")
            except Exception as e:
                logger.warning(
                    "윈도우 경계 탐지 예외: %s — 전체 프레임 사용",
                    e,
                )

        all_rois: list[ROI] = []

        # Phase 1: 텍스트 ROI 탐지
        if self._text_detector is not None:
            try:
                text_rois = self._text_detector.detect(working_frame)
                all_rois.extend(text_rois)
                logger.info("텍스트 ROI %d개 탐지", len(text_rois))
            except Exception as e:
                logger.error("텍스트 ROI 탐지 실패: %s", e)

        # Phase 2: 파형 ROI 탐지
        if self._waveform_detector is not None:
            try:
                waveform_rois = self._waveform_detector.detect(working_frame)
                all_rois.extend(waveform_rois)
                logger.info("파형 ROI %d개 탐지", len(waveform_rois))
            except Exception as e:
                logger.error("파형 ROI 탐지 실패: %s", e)

        if not all_rois:
            logger.warning("동적 ROI 탐지 결과 없음")
            return []

        # Phase 3: 텍스트-파형 간 중복 제거
        merged = self._merge_overlapping_rois(all_rois)

        # === Phase 3.5: 좌표 복원 (크롭 오프셋 적용) ===
        if self._window_bbox is not None:
            merged = WindowBoundaryDetector.remap_rois(
                merged,
                self._window_bbox,
            )
            logger.info(
                "좌표 복원: offset (%d,%d)",
                self._window_bbox.x,
                self._window_bbox.y,
            )

        # Phase 4: 고유 ID 재할당
        final = self._assign_ids(merged)

        logger.info(
            "동적 ROI 탐지 완료: 총 %d개 (텍스트+파형 병합 전 %d개)",
            len(final),
            len(all_rois),
        )

        return final

    def _merge_overlapping_rois(self, rois: list[ROI]) -> list[ROI]:
        """IoU 기반 중복 ROI 병합

        텍스트 ROI와 파형 ROI가 겹치는 경우,
        텍스트 ROI를 우선합니다 (더 구체적인 정보 보유).

        Args:
            rois: 병합 전 ROI 리스트

        Returns:
            병합된 ROI 리스트
        """
        if len(rois) <= 1:
            return rois

        # 텍스트 ROI 우선 (detection_method=text가 먼저)
        sorted_rois = sorted(
            rois,
            key=lambda r: (
                0 if r.metadata.get("detection_method") == "text" else 1,
                -r.confidence,
            ),
        )

        merged: list[ROI] = []
        used = [False] * len(sorted_rois)

        for i, roi_i in enumerate(sorted_rois):
            if used[i]:
                continue

            used[i] = True
            # 겹치는 ROI 확인 (낮은 우선순위 ROI 흡수)
            for j in range(i + 1, len(sorted_rois)):
                if used[j]:
                    continue
                iou = roi_i.bbox.iou(sorted_rois[j].bbox)
                if iou >= self.config.iou_merge_threshold:
                    used[j] = True
                    logger.debug(
                        "ROI 중복 병합: %s (IoU=%.2f) → %s 흡수",
                        sorted_rois[j].id,
                        iou,
                        roi_i.id,
                    )

            merged.append(roi_i)

        return merged

    @staticmethod
    def _assign_ids(rois: list[ROI]) -> list[ROI]:
        """ROI에 고유 ID를 순차적으로 할당

        Args:
            rois: ID 재할당 대상 ROI 리스트

        Returns:
            새 ID가 부여된 ROI 리스트
        """
        result: list[ROI] = []
        text_idx = 0
        waveform_idx = 0

        for roi in rois:
            method = roi.metadata.get("detection_method", "unknown")
            if method == "text":
                new_id = f"auto_text_{text_idx}"
                text_idx += 1
            elif method == "waveform":
                new_id = f"auto_waveform_{waveform_idx}"
                waveform_idx += 1
            else:
                new_id = f"auto_unknown_{text_idx + waveform_idx}"

            result.append(
                ROI(
                    id=new_id,
                    bbox=roi.bbox,
                    roi_type=roi.roi_type,
                    confidence=roi.confidence,
                    label=roi.label,
                    metadata=roi.metadata,
                )
            )

        return result
