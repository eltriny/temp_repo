"""이미지 기반 윈도우 경계 탐지기

비디오 프레임에서 가장 큰 사각형 윈도우 경계를 OpenCV 기법으로 탐지합니다.

탐지 전략:
    전략 1: Canny Edge + findContours + approxPolyDP (빠름, ~5ms)
    전략 2: HoughLinesP 기반 직선 교차점 분석 (견고, ~10ms)
    폴백: None 반환 → 전체 프레임 사용

사용 예시:
    >>> from detection.window_boundary_detector import WindowBoundaryDetector
    >>> detector = WindowBoundaryDetector()
    >>> bbox = detector.detect(frame)
    >>> if bbox is not None:
    ...     cropped = frame[bbox.y:bbox.y2, bbox.x:bbox.x2]
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

import cv2
import numpy as np
from numpy.typing import NDArray

from .roi_types import ROI, BoundingBox

logger = logging.getLogger(__name__)


@dataclass
class WindowBoundaryConfig:
    """윈도우 경계 탐지 설정

    Attributes:
        canny_threshold1: Canny 에지 저임계값
        canny_threshold2: Canny 에지 고임계값
        blur_kernel_size: 가우시안 블러 커널 크기
        approx_epsilon_factor: approxPolyDP epsilon 계수 (둘레 대비 비율)
        min_area_ratio: 프레임 면적 대비 최소 윈도우 면적 비율
        max_area_ratio: 프레임 면적 대비 최대 윈도우 면적 비율
        min_aspect_ratio: 최소 종횡비 (width/height)
        max_aspect_ratio: 최대 종횡비 (width/height)
        center_bias_max_ratio: 프레임 대각선 대비 중앙 편향 최대 비율
        hough_threshold: HoughLinesP 투표 임계값
        hough_min_line_length: HoughLinesP 최소 직선 길이
        hough_max_line_gap: HoughLinesP 최대 직선 갭
        morph_kernel_size: 에지 정리용 형태학적 커널 크기
        inner_padding: 창 테두리 제거용 내부 패딩 (px)
    """

    canny_threshold1: int = 30
    canny_threshold2: int = 100
    blur_kernel_size: tuple[int, int] = (5, 5)
    approx_epsilon_factor: float = 0.02
    min_area_ratio: float = 0.20
    max_area_ratio: float = 0.95
    min_aspect_ratio: float = 0.75
    max_aspect_ratio: float = 2.5
    center_bias_max_ratio: float = 0.3
    hough_threshold: int = 80
    hough_min_line_length: int = 100
    hough_max_line_gap: int = 10
    morph_kernel_size: tuple[int, int] = (3, 3)
    inner_padding: int = 2


class WindowBoundaryDetector:
    """이미지 기반 윈도우 경계 탐지기

    비디오 프레임에서 가장 큰 사각형 윈도우 경계를 탐지합니다.
    두 가지 전략을 순차적으로 시도하며, 모두 실패하면
    None을 반환하여 전체 프레임 사용으로 폴백합니다.

    전략 1 (컨투어 분석):
        Canny 에지 이미지에서 외곽선을 찾고,
        가장 큰 4꼭짓점 다각형을 윈도우 경계로 판정합니다.

    전략 2 (직선 교차 분석):
        HoughLinesP로 수평/수직 직선을 탐지하고,
        직선들의 경계에서 윈도우 사각형을 복원합니다.

    Example:
        >>> detector = WindowBoundaryDetector()
        >>> bbox = detector.detect(frame)
        >>> if bbox is not None:
        ...     print(f"윈도우: ({bbox.x},{bbox.y}) {bbox.width}x{bbox.height}")
    """

    def __init__(self, config: WindowBoundaryConfig | None = None) -> None:
        self.config = config or WindowBoundaryConfig()

    def detect(self, frame: NDArray[np.uint8]) -> BoundingBox | None:
        """프레임에서 윈도우 경계 탐지

        두 전략을 순차적으로 시도합니다:
        1. Canny + findContours + approxPolyDP
        2. HoughLinesP 기반 직선 교차점 분석

        Args:
            frame: 입력 프레임 (BGR 형식)

        Returns:
            탐지된 윈도우 경계 BoundingBox, 또는 None (탐지 실패 시)
        """
        if frame is None or frame.size == 0:
            logger.warning("빈 프레임이 입력됨")
            return None

        h, w = frame.shape[:2]

        # 전처리
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, self.config.blur_kernel_size, 0)

        # 에지 탐지
        edges = cv2.Canny(
            blurred,
            self.config.canny_threshold1,
            self.config.canny_threshold2,
        )

        # 형태학적 닫힘으로 에지 갭 연결
        kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, self.config.morph_kernel_size,
        )
        edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

        # 전략 1: 컨투어 분석
        result = self._detect_by_contour(edges, h, w)
        if result is not None:
            logger.debug("전략 1 (컨투어) 성공: %s", result.to_tuple())
            return result

        # 전략 2: HoughLines 직선 교차
        result = self._detect_by_hough_lines(edges, h, w)
        if result is not None:
            logger.debug("전략 2 (HoughLines) 성공: %s", result.to_tuple())
            return result

        # 모든 전략 실패
        logger.debug("윈도우 경계 탐지 실패 — 전체 프레임 사용")
        return None

    def _detect_by_contour(
        self,
        edges: NDArray[np.uint8],
        frame_h: int,
        frame_w: int,
    ) -> BoundingBox | None:
        """전략 1: Canny + findContours + approxPolyDP

        외곽선 중 가장 큰 4꼭짓점 다각형을 윈도우 경계로 판정합니다.

        Args:
            edges: Canny 에지 이미지
            frame_h: 프레임 높이
            frame_w: 프레임 너비

        Returns:
            탐지된 BoundingBox 또는 None
        """
        contours, _ = cv2.findContours(
            edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE,
        )

        if not contours:
            return None

        # 면적 내림차순 정렬
        sorted_contours = sorted(
            contours, key=cv2.contourArea, reverse=True,
        )

        frame_area = frame_h * frame_w

        for contour in sorted_contours:
            area = cv2.contourArea(contour)

            # 면적 비율 사전 필터링
            area_ratio = area / frame_area
            if area_ratio < self.config.min_area_ratio:
                break  # 정렬됨 → 이후 더 작음
            if area_ratio > self.config.max_area_ratio:
                continue

            # 다각형 근사
            perimeter = cv2.arcLength(contour, True)
            epsilon = self.config.approx_epsilon_factor * perimeter
            approx = cv2.approxPolyDP(contour, epsilon, True)

            # 4꼭짓점 여부 확인
            if len(approx) != 4:
                continue

            # 바운딩 렉트 추출
            bx, by, bw, bh = cv2.boundingRect(approx)

            # 내부 패딩 적용 (창 테두리 제거)
            pad = self.config.inner_padding
            bbox = BoundingBox(
                x=max(0, bx + pad),
                y=max(0, by + pad),
                width=max(1, bw - 2 * pad),
                height=max(1, bh - 2 * pad),
            )

            if self._validate_boundary(bbox, frame_h, frame_w):
                return bbox

        return None

    def _detect_by_hough_lines(
        self,
        edges: NDArray[np.uint8],
        frame_h: int,
        frame_w: int,
    ) -> BoundingBox | None:
        """전략 2: HoughLinesP → 수평/수직 직선 → 교차 사각형 추출

        직선들의 경계 위치에서 가장 큰 직사각형 영역을 복원합니다.

        Args:
            edges: Canny 에지 이미지
            frame_h: 프레임 높이
            frame_w: 프레임 너비

        Returns:
            탐지된 BoundingBox 또는 None
        """
        lines = cv2.HoughLinesP(
            edges,
            rho=1,
            theta=np.pi / 180,
            threshold=self.config.hough_threshold,
            minLineLength=self.config.hough_min_line_length,
            maxLineGap=self.config.hough_max_line_gap,
        )

        if lines is None or len(lines) == 0:
            return None

        # 수평 / 수직 직선 분류 (각도 허용 오차: 10도)
        horizontal_ys: list[int] = []
        vertical_xs: list[int] = []
        angle_tolerance = 10  # degrees

        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = abs(math.degrees(math.atan2(y2 - y1, x2 - x1)))

            if angle < angle_tolerance or angle > (180 - angle_tolerance):
                # 수평 직선: Y 좌표 수집
                horizontal_ys.append(y1)
                horizontal_ys.append(y2)
            elif abs(angle - 90) < angle_tolerance:
                # 수직 직선: X 좌표 수집
                vertical_xs.append(x1)
                vertical_xs.append(x2)

        # 최소 수평 2개 + 수직 2개 필요
        if len(horizontal_ys) < 2 or len(vertical_xs) < 2:
            return None

        # 직선 경계에서 사각형 복원
        # 클러스터링 대신 min/max 사용 (단순하지만 효과적)
        horizontal_ys.sort()
        vertical_xs.sort()

        # 상단/하단 경계: 전체 범위의 상/하 25% 지점 근처
        top_ys = [y for y in horizontal_ys if y < frame_h * 0.4]
        bottom_ys = [y for y in horizontal_ys if y > frame_h * 0.6]
        left_xs = [x for x in vertical_xs if x < frame_w * 0.4]
        right_xs = [x for x in vertical_xs if x > frame_w * 0.6]

        if not top_ys or not bottom_ys or not left_xs or not right_xs:
            return None

        # 가장 안쪽 경계 선택 (중앙에 가까운)
        top = max(top_ys)
        bottom = min(bottom_ys)
        left = max(left_xs)
        right = min(right_xs)

        if top >= bottom or left >= right:
            return None

        pad = self.config.inner_padding
        bbox = BoundingBox(
            x=max(0, left + pad),
            y=max(0, top + pad),
            width=max(1, right - left - 2 * pad),
            height=max(1, bottom - top - 2 * pad),
        )

        if self._validate_boundary(bbox, frame_h, frame_w):
            return bbox

        return None

    def _validate_boundary(
        self,
        bbox: BoundingBox,
        frame_h: int,
        frame_w: int,
    ) -> bool:
        """탐지된 경계의 유효성 검증

        면적 비율, 종횡비, 중앙 위치 가중치를 확인합니다.

        Args:
            bbox: 검증할 BoundingBox
            frame_h: 프레임 높이
            frame_w: 프레임 너비

        Returns:
            유효하면 True
        """
        frame_area = frame_h * frame_w
        if frame_area == 0:
            return False

        # 면적 비율 검증
        area_ratio = bbox.area / frame_area
        if area_ratio < self.config.min_area_ratio:
            logger.debug("면적 비율 부족: %.2f < %.2f", area_ratio, self.config.min_area_ratio)
            return False
        if area_ratio > self.config.max_area_ratio:
            logger.debug("면적 비율 초과: %.2f > %.2f", area_ratio, self.config.max_area_ratio)
            return False

        # 종횡비 검증
        if bbox.height == 0:
            return False
        aspect_ratio = bbox.width / bbox.height
        if aspect_ratio < self.config.min_aspect_ratio:
            logger.debug("종횡비 부족: %.2f < %.2f", aspect_ratio, self.config.min_aspect_ratio)
            return False
        if aspect_ratio > self.config.max_aspect_ratio:
            logger.debug("종횡비 초과: %.2f > %.2f", aspect_ratio, self.config.max_aspect_ratio)
            return False

        # 중앙 편향 검증
        bbox_cx, bbox_cy = bbox.center
        frame_cx = frame_w / 2
        frame_cy = frame_h / 2
        diagonal = math.sqrt(frame_w**2 + frame_h**2)
        distance = math.sqrt((bbox_cx - frame_cx)**2 + (bbox_cy - frame_cy)**2)
        center_ratio = distance / diagonal

        if center_ratio > self.config.center_bias_max_ratio:
            logger.debug(
                "중앙 편향 초과: %.2f > %.2f",
                center_ratio, self.config.center_bias_max_ratio,
            )
            return False

        return True

    @staticmethod
    def remap_rois(
        rois: list[ROI],
        window_bbox: BoundingBox,
    ) -> list[ROI]:
        """크롭된 좌표를 원본 프레임 좌표로 복원

        크롭된 프레임에서 탐지된 ROI의 좌표를
        원본 프레임의 좌표계로 변환합니다.

        Args:
            rois: 크롭된 프레임 좌표 기준 ROI 리스트
            window_bbox: 원본 프레임에서의 윈도우 경계

        Returns:
            원본 프레임 좌표로 변환된 ROI 리스트
        """
        if not rois:
            return rois

        result: list[ROI] = []
        for roi in rois:
            new_bbox = BoundingBox(
                x=roi.bbox.x + window_bbox.x,
                y=roi.bbox.y + window_bbox.y,
                width=roi.bbox.width,
                height=roi.bbox.height,
            )
            result.append(ROI(
                id=roi.id,
                bbox=new_bbox,
                roi_type=roi.roi_type,
                confidence=roi.confidence,
                label=roi.label,
                metadata={
                    **roi.metadata,
                    "window_offset": (window_bbox.x, window_bbox.y),
                },
            ))

        return result
