"""텍스트 기반 동적 ROI 탐지기

전체 프레임에 PaddleOCR을 실행한 후 정규식 패턴 매칭으로
관심 텍스트 영역을 ROI로 변환합니다.

주요 기능:
    - PaddleOCR 전체 파이프라인 (det+rec) 실행
    - 패턴 카테고리별 텍스트 분류 (온도, 퍼센트, 시간 등)
    - 매칭된 텍스트의 bbox를 detection.roi_types.ROI로 변환
    - 같은 줄의 인접 ROI 병합

사용 예시:
    >>> from detection.text_roi_detector import TextROIDetector
    >>> detector = TextROIDetector(ocr_engine=engine)
    >>> rois = detector.detect(frame)
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import ClassVar

import numpy as np
from numpy.typing import NDArray

from .roi_types import ROI, BoundingBox, ROIType

logger = logging.getLogger(__name__)


class PatternCategory(Enum):
    """탐지된 텍스트의 분류 카테고리"""

    TEMPERATURE = "temperature"
    PERCENTAGE = "percentage"
    TIMESTAMP = "timestamp"
    PRESSURE = "pressure"
    FREQUENCY = "frequency"
    LABELED_VALUE = "labeled_value"
    NUMERIC_VALUE = "numeric_value"
    STATUS_TEXT = "status_text"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class TextPattern:
    """텍스트 매칭용 정규식 패턴 정의

    Attributes:
        category: 패턴 카테고리
        pattern: 정규식 패턴 문자열
        roi_type: 매칭 시 할당할 ROI 타입
        priority: 우선순위 (높을수록 먼저 매칭)
    """

    category: PatternCategory
    pattern: str
    roi_type: ROIType
    priority: int = 0

    def __post_init__(self) -> None:
        # 정규식 컴파일 유효성 검증
        re.compile(self.pattern)


@dataclass
class TextROIDetectorConfig:
    """텍스트 ROI 탐지기 설정

    Attributes:
        confidence_threshold: OCR 최소 신뢰도 (이하 결과 무시)
        patterns: 사용할 패턴 목록 (비어있으면 DEFAULT_PATTERNS)
        merge_same_line_threshold_px: 같은 줄 병합 시 최대 수평 간격 (px)
        merge_vertical_tolerance_px: 같은 줄 판정 최대 Y 차이 (px)
        min_text_area: 최소 bbox 면적 (이하 필터링)
        padding: ROI bbox 주변 여백 (px)
    """

    confidence_threshold: float = 0.6
    patterns: tuple[TextPattern, ...] = ()
    merge_same_line_threshold_px: int = 30
    merge_vertical_tolerance_px: int = 15
    min_text_area: int = 100
    padding: int = 5


class TextROIDetector:
    """전체 OCR + 패턴 필터링 기반 텍스트 ROI 탐지기

    첫 프레임에서 PaddleOCR 전체 파이프라인을 실행하고,
    결과에 정규식 패턴 매칭을 적용하여 관심 텍스트의
    바운딩 박스를 ROI로 변환합니다.

    Example:
        >>> from ocr.ocr_engine import OCREngine
        >>> engine = OCREngine()
        >>> detector = TextROIDetector(ocr_engine=engine)
        >>> rois = detector.detect(frame)
        >>> for roi in rois:
        ...     print(f"{roi.label}: {roi.roi_type.value}")
    """

    DEFAULT_PATTERNS: ClassVar[tuple[TextPattern, ...]] = (
        TextPattern(
            category=PatternCategory.TEMPERATURE,
            pattern=r"(?i)(?:temp(?:erature)?[:\s]*)?"
                    r"-?\d+\.?\d*\s*[°℃℉]?[CcFf]",
            roi_type=ROIType.NUMERIC,
            priority=10,
        ),
        TextPattern(
            category=PatternCategory.PERCENTAGE,
            pattern=r"-?\d+\.?\d*\s*%",
            roi_type=ROIType.NUMERIC,
            priority=9,
        ),
        TextPattern(
            category=PatternCategory.TIMESTAMP,
            pattern=r"\d{1,2}:\d{2}(?::\d{2})?",
            roi_type=ROIType.TEXT,
            priority=8,
        ),
        TextPattern(
            category=PatternCategory.PRESSURE,
            pattern=r"-?\d+\.?\d*\s*(?:bar|kPa|psi|Pa|MPa|atm)",
            roi_type=ROIType.NUMERIC,
            priority=7,
        ),
        TextPattern(
            category=PatternCategory.FREQUENCY,
            pattern=r"-?\d+\.?\d*\s*(?:Hz|kHz|MHz|GHz)",
            roi_type=ROIType.NUMERIC,
            priority=7,
        ),
        TextPattern(
            category=PatternCategory.LABELED_VALUE,
            pattern=r"[A-Za-z\u3131-\u318E\uAC00-\uD7A3]+"
                    r"\s*[:=]\s*-?\d+\.?\d*",
            roi_type=ROIType.NUMERIC,
            priority=5,
        ),
        TextPattern(
            category=PatternCategory.STATUS_TEXT,
            pattern=r"(?i)\b(?:RUNNING|STOPPED|OK|ERROR|ALARM"
                    r"|ON|OFF|STANDBY|READY|NORMAL|WARNING)\b",
            roi_type=ROIType.TEXT,
            priority=4,
        ),
        TextPattern(
            category=PatternCategory.NUMERIC_VALUE,
            pattern=r"^-?\d+\.\d+$",
            roi_type=ROIType.NUMERIC,
            priority=3,
        ),
    )

    def __init__(
        self,
        config: TextROIDetectorConfig | None = None,
        ocr_engine: object | None = None,
    ) -> None:
        self.config = config or TextROIDetectorConfig()
        self._ocr_engine = ocr_engine
        self._compiled_patterns: list[tuple[TextPattern, re.Pattern]] = []
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        """패턴을 우선순위 내림차순으로 정렬하고 컴파일"""
        patterns = self.config.patterns or self.DEFAULT_PATTERNS
        sorted_patterns = sorted(patterns, key=lambda p: p.priority, reverse=True)
        self._compiled_patterns = [
            (p, re.compile(p.pattern)) for p in sorted_patterns
        ]

    def _get_ocr_engine(self) -> object:
        """OCR 엔진 반환 (없으면 생성)"""
        if self._ocr_engine is None:
            from ..ocr.ocr_engine import OCREngine, OCRConfig

            self._ocr_engine = OCREngine(OCRConfig(
                confidence_threshold=0.3,  # 낮게 설정 (패턴 매칭에서 필터링)
                use_space_char=True,
            ))
        return self._ocr_engine

    def detect(self, frame: NDArray[np.uint8]) -> list[ROI]:
        """프레임에서 패턴 매칭 기반 텍스트 ROI 탐지

        Args:
            frame: 입력 프레임 (BGR 형식)

        Returns:
            탐지된 ROI 리스트
        """
        if frame is None or frame.size == 0:
            return []

        engine = self._get_ocr_engine()
        ocr_results = engine.recognize(frame)

        if not ocr_results:
            logger.debug("프레임에서 텍스트가 감지되지 않음")
            return []

        logger.info("OCR 결과 %d개에서 패턴 매칭 시작", len(ocr_results))

        # 패턴 매칭으로 관심 텍스트 필터링
        matched_rois: list[ROI] = []
        for i, result in enumerate(ocr_results):
            if result.confidence < self.config.confidence_threshold:
                continue

            category, roi_type = self._classify_text(result.text)
            if category == PatternCategory.UNKNOWN:
                continue

            # OCR BoundingBox → detection BoundingBox 변환
            bbox = self._convert_ocr_bbox(result.bounding_box, frame.shape)

            if bbox.area < self.config.min_text_area:
                continue

            roi = ROI(
                id=f"auto_text_{i}",
                bbox=bbox,
                roi_type=roi_type,
                confidence=result.confidence,
                label=f"{category.value}: {result.text}",
                metadata={
                    "source": "auto_detected",
                    "detection_method": "text",
                    "pattern_category": category.value,
                    "original_text": result.text,
                },
            )
            matched_rois.append(roi)

        logger.info("패턴 매칭 결과: %d개 ROI 탐지", len(matched_rois))

        # 같은 줄의 인접 ROI 병합
        merged = self._merge_adjacent_on_same_line(matched_rois)
        if len(merged) != len(matched_rois):
            logger.info(
                "인접 ROI 병합: %d개 → %d개",
                len(matched_rois),
                len(merged),
            )

        return merged

    def _classify_text(
        self, text: str
    ) -> tuple[PatternCategory, ROIType]:
        """텍스트를 패턴에 매칭하여 분류

        Args:
            text: OCR 인식 텍스트

        Returns:
            (카테고리, ROI 타입) 튜플. 매칭 없으면 (UNKNOWN, UNKNOWN)
        """
        text = text.strip()
        if not text:
            return PatternCategory.UNKNOWN, ROIType.UNKNOWN

        for pattern, compiled in self._compiled_patterns:
            if compiled.search(text):
                return pattern.category, pattern.roi_type

        return PatternCategory.UNKNOWN, ROIType.UNKNOWN

    def _convert_ocr_bbox(
        self,
        ocr_bbox: object,
        frame_shape: tuple[int, ...],
    ) -> BoundingBox:
        """OCR BoundingBox를 detection BoundingBox로 변환

        OCR 엔진의 BoundingBox(x_min, y_min, x_max, y_max)를
        detection의 BoundingBox(x, y, width, height)로 변환합니다.
        패딩 적용 및 프레임 경계 클리핑도 수행합니다.

        Args:
            ocr_bbox: OCR 엔진의 BoundingBox 객체
            frame_shape: 프레임 shape (height, width, ...)

        Returns:
            변환된 detection BoundingBox
        """
        h, w = frame_shape[:2]
        pad = self.config.padding

        x = max(0, ocr_bbox.x_min - pad)
        y = max(0, ocr_bbox.y_min - pad)
        x2 = min(w, ocr_bbox.x_max + pad)
        y2 = min(h, ocr_bbox.y_max + pad)

        return BoundingBox(
            x=x,
            y=y,
            width=x2 - x,
            height=y2 - y,
        )

    def _merge_adjacent_on_same_line(
        self, rois: list[ROI]
    ) -> list[ROI]:
        """같은 줄에서 수평으로 인접한 ROI를 병합

        PaddleOCR이 "Temperature:" 와 "25.5°C"를 별개로 인식할 때
        하나의 ROI로 합칩니다.

        Args:
            rois: 병합 전 ROI 리스트

        Returns:
            병합된 ROI 리스트
        """
        if len(rois) <= 1:
            return rois

        # X 좌표 기준 정렬
        sorted_rois = sorted(rois, key=lambda r: (r.bbox.y, r.bbox.x))

        merged: list[ROI] = []
        current_group: list[ROI] = [sorted_rois[0]]

        for roi in sorted_rois[1:]:
            last = current_group[-1]

            # 같은 줄 판정 (Y 중심점 차이)
            last_cy = last.bbox.y + last.bbox.height // 2
            roi_cy = roi.bbox.y + roi.bbox.height // 2
            y_diff = abs(roi_cy - last_cy)

            # 수평 간격 계산
            x_gap = roi.bbox.x - (last.bbox.x + last.bbox.width)

            if (
                y_diff <= self.config.merge_vertical_tolerance_px
                and 0 <= x_gap <= self.config.merge_same_line_threshold_px
            ):
                current_group.append(roi)
            else:
                merged.append(self._merge_group(current_group))
                current_group = [roi]

        merged.append(self._merge_group(current_group))
        return merged

    @staticmethod
    def _merge_group(group: list[ROI]) -> ROI:
        """ROI 그룹을 하나의 ROI로 병합

        Args:
            group: 병합할 ROI 리스트

        Returns:
            병합된 단일 ROI
        """
        if len(group) == 1:
            return group[0]

        # 전체를 감싸는 bbox 계산
        x_min = min(r.bbox.x for r in group)
        y_min = min(r.bbox.y for r in group)
        x_max = max(r.bbox.x + r.bbox.width for r in group)
        y_max = max(r.bbox.y + r.bbox.height for r in group)

        # 가장 높은 우선순위의 ROI 정보를 기준으로 사용
        primary = group[0]
        texts = [r.metadata.get("original_text", "") for r in group]
        combined_text = " ".join(t for t in texts if t)

        return ROI(
            id=primary.id,
            bbox=BoundingBox(
                x=x_min,
                y=y_min,
                width=x_max - x_min,
                height=y_max - y_min,
            ),
            roi_type=primary.roi_type,
            confidence=max(r.confidence for r in group),
            label=f"{primary.metadata.get('pattern_category', 'merged')}: {combined_text}",
            metadata={
                "source": "auto_detected",
                "detection_method": "text",
                "pattern_category": primary.metadata.get(
                    "pattern_category", "merged"
                ),
                "original_text": combined_text,
                "merged_count": len(group),
            },
        )
