"""파형 기반 동적 ROI 탐지기

축이나 범례 없이 노이즈 배경에 존재하는 단순 선형 파형을
탐지하여 ROI로 변환합니다.

탐지 전략:
    1. 수평 프로젝션 프로파일: 에지 이미지의 행별 밀도 분석
    2. 연결 성분 분석: 수평 형태학적 연결 후 종횡비 필터링

두 전략의 결과를 합산하고 IoU 기반 중복 제거를 수행합니다.

사용 예시:
    >>> from detection.waveform_detector import WaveformDetector
    >>> detector = WaveformDetector()
    >>> rois = detector.detect(frame)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import cv2
import numpy as np
from numpy.typing import NDArray

from .roi_types import ROI, BoundingBox, ROIType

logger = logging.getLogger(__name__)


@dataclass
class WaveformDetectorConfig:
    """파형 탐지기 설정

    Attributes:
        blur_kernel_size: 전처리 가우시안 블러 커널 크기
        canny_threshold1: Canny 에지 저임계값
        canny_threshold2: Canny 에지 고임계값
        morph_kernel_width: 수평 형태학적 커널 너비
        morph_kernel_height: 수평 형태학적 커널 높이
        min_component_aspect_ratio: 파형 판정 최소 종횡비 (width/height)
        min_component_width_ratio: 프레임 너비 대비 최소 파형 너비 비율
        max_waveform_height_ratio: 프레임 높이 대비 최대 파형 높이 비율
        min_active_row_ratio: 파형 밴드의 최소 활성 행 비율
        projection_threshold_ratio: 프로젝션 피크 대비 활성 임계 비율
        min_band_height_px: 최소 밴드 높이 (px)
        min_area: 최소 영역 면적 (px^2)
        padding: ROI bbox 주변 여백 (px)
        iou_merge_threshold: 두 패스 결과 병합 시 IoU 임계값
    """

    blur_kernel_size: tuple[int, int] = (5, 5)
    canny_threshold1: int = 50
    canny_threshold2: int = 150
    morph_kernel_width: int = 15
    morph_kernel_height: int = 3
    min_component_aspect_ratio: float = 2.0
    min_component_width_ratio: float = 0.1
    max_waveform_height_ratio: float = 0.3
    min_active_row_ratio: float = 0.05
    projection_threshold_ratio: float = 0.3
    min_band_height_px: int = 5
    min_area: int = 500
    padding: int = 10
    iou_merge_threshold: float = 0.3


class WaveformDetector:
    """노이즈 환경의 단순 선형 파형 탐지기

    축/범례 없는 파형(오실로스코프 스타일, 트렌드 라인 등)을
    두 가지 상호 보완적 분석 기법으로 탐지합니다.

    Pass 1 (프로젝션 프로파일):
        에지 이미지의 각 행별 에지 밀도를 측정하여
        파형이 지나가는 수평 밴드를 탐지합니다.

    Pass 2 (연결 성분 분석):
        수평 형태학적 커널로 에지를 연결한 후
        가로로 긴 연결 성분을 파형으로 식별합니다.

    Example:
        >>> detector = WaveformDetector()
        >>> rois = detector.detect(frame)
        >>> for roi in rois:
        ...     print(f"파형 ROI: {roi.bbox.to_tuple()}")
    """

    def __init__(self, config: WaveformDetectorConfig | None = None) -> None:
        self.config = config or WaveformDetectorConfig()

    def detect(self, frame: NDArray[np.uint8]) -> list[ROI]:
        """프레임에서 파형 영역 탐지

        Args:
            frame: 입력 프레임 (BGR 형식)

        Returns:
            탐지된 파형 ROI 리스트
        """
        if frame is None or frame.size == 0:
            return []

        h, w = frame.shape[:2]

        # 전처리
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, self.config.blur_kernel_size, 0)

        # 에지 추출
        edges = cv2.Canny(
            blurred,
            self.config.canny_threshold1,
            self.config.canny_threshold2,
        )

        # 적응형 이진화 (연결 성분 분석용)
        binary = cv2.adaptiveThreshold(
            blurred, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV,
            11, 2,
        )

        # Pass 1: 수평 프로젝션 프로파일 분석
        projection_bboxes = self._detect_by_projection(edges, w, h)

        # Pass 2: 연결 성분 분석
        component_bboxes = self._detect_by_connected_components(binary, w, h)

        # 두 패스 결과 합산 + 중복 제거
        all_bboxes = projection_bboxes + component_bboxes
        merged_bboxes = self._merge_overlapping_bboxes(all_bboxes)

        # BoundingBox → ROI 변환
        rois: list[ROI] = []
        for i, bbox in enumerate(merged_bboxes):
            roi = ROI(
                id=f"auto_waveform_{i}",
                bbox=bbox,
                roi_type=ROIType.CHART,
                confidence=0.7,
                label=f"waveform_{i}",
                metadata={
                    "source": "auto_detected",
                    "detection_method": "waveform",
                    "pattern_category": "waveform",
                },
            )
            rois.append(roi)

        if rois:
            logger.info("파형 ROI %d개 탐지", len(rois))

        return rois

    def _detect_by_projection(
        self,
        edges: NDArray[np.uint8],
        width: int,
        height: int,
    ) -> list[BoundingBox]:
        """수평 프로젝션 프로파일로 파형 밴드 탐지

        각 행의 에지 픽셀 밀도를 측정하여
        파형이 지나가는 수평 밴드를 찾습니다.

        Args:
            edges: Canny 에지 이미지
            width: 프레임 너비
            height: 프레임 높이

        Returns:
            탐지된 파형 영역의 BoundingBox 리스트
        """
        # 행별 에지 밀도 계산 (0.0 ~ 1.0)
        projection = np.sum(edges > 0, axis=1).astype(np.float64)
        if width > 0:
            projection /= width

        if projection.max() < 1e-6:
            return []

        # 프로젝션 프로파일 스무딩
        kernel_size = max(3, height // 50)
        if kernel_size % 2 == 0:
            kernel_size += 1
        kernel = np.ones(kernel_size) / kernel_size
        smoothed = np.convolve(projection, kernel, mode="same")

        # 활성 임계값
        threshold = smoothed.max() * self.config.projection_threshold_ratio

        # 활성 밴드 탐지 (연속적으로 임계값을 초과하는 행 범위)
        bands = self._find_active_bands(smoothed, threshold)

        # 각 밴드에서 수평 범위 결정 및 필터링
        bboxes: list[BoundingBox] = []
        for band_start, band_end in bands:
            band_height = band_end - band_start

            if band_height < self.config.min_band_height_px:
                continue
            if band_height > height * self.config.max_waveform_height_ratio:
                continue

            # 밴드 내 에지의 수평 범위 결정
            band_edges = edges[band_start:band_end, :]
            col_projection = np.sum(band_edges > 0, axis=0)
            active_cols = np.where(col_projection > 0)[0]

            if len(active_cols) < 2:
                continue

            x_start = int(active_cols[0])
            x_end = int(active_cols[-1])
            span = x_end - x_start

            if span < width * self.config.min_component_width_ratio:
                continue

            # 패딩 적용 + 경계 클리핑
            pad = self.config.padding
            bbox = BoundingBox(
                x=max(0, x_start - pad),
                y=max(0, band_start - pad),
                width=min(width, span + 2 * pad),
                height=min(height - max(0, band_start - pad), band_height + 2 * pad),
            )

            if bbox.area >= self.config.min_area:
                bboxes.append(bbox)

        return bboxes

    @staticmethod
    def _find_active_bands(
        projection: NDArray[np.float64],
        threshold: float,
    ) -> list[tuple[int, int]]:
        """프로젝션 프로파일에서 활성 밴드 범위 추출

        Args:
            projection: 스무딩된 프로젝션 프로파일
            threshold: 활성 판정 임계값

        Returns:
            (시작행, 끝행) 튜플 리스트
        """
        active = projection > threshold
        bands: list[tuple[int, int]] = []
        in_band = False
        start = 0

        for i, is_active in enumerate(active):
            if is_active and not in_band:
                start = i
                in_band = True
            elif not is_active and in_band:
                bands.append((start, i))
                in_band = False

        if in_band:
            bands.append((start, len(projection)))

        return bands

    def _detect_by_connected_components(
        self,
        binary: NDArray[np.uint8],
        width: int,
        height: int,
    ) -> list[BoundingBox]:
        """수평 형태학적 연결 + 연결 성분 분석으로 파형 탐지

        수평 형태학적 커널로 에지를 수평 연결하여
        가로로 긴 연결 성분을 파형으로 식별합니다.

        Args:
            binary: 적응형 이진화 이미지
            width: 프레임 너비
            height: 프레임 높이

        Returns:
            탐지된 파형 영역의 BoundingBox 리스트
        """
        # 수평 형태학적 닫힘 연산 (수평 갭 연결)
        h_kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (self.config.morph_kernel_width, self.config.morph_kernel_height),
        )
        closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, h_kernel)

        # 연결 성분 분석
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            closed, connectivity=8,
        )

        bboxes: list[BoundingBox] = []

        for i in range(1, num_labels):  # 0은 배경
            comp_x = stats[i, cv2.CC_STAT_LEFT]
            comp_y = stats[i, cv2.CC_STAT_TOP]
            comp_w = stats[i, cv2.CC_STAT_WIDTH]
            comp_h = stats[i, cv2.CC_STAT_HEIGHT]
            comp_area = stats[i, cv2.CC_STAT_AREA]

            if comp_h == 0 or comp_w == 0:
                continue

            aspect_ratio = comp_w / comp_h
            width_ratio = comp_w / width

            # 파형 특성 필터링
            if aspect_ratio < self.config.min_component_aspect_ratio:
                continue
            if width_ratio < self.config.min_component_width_ratio:
                continue
            if comp_h > height * self.config.max_waveform_height_ratio:
                continue
            if comp_area < self.config.min_area:
                continue

            # 패딩 적용 + 경계 클리핑
            pad = self.config.padding
            bbox = BoundingBox(
                x=max(0, comp_x - pad),
                y=max(0, comp_y - pad),
                width=min(width - max(0, comp_x - pad), comp_w + 2 * pad),
                height=min(height - max(0, comp_y - pad), comp_h + 2 * pad),
            )
            bboxes.append(bbox)

        return bboxes

    def _merge_overlapping_bboxes(
        self, bboxes: list[BoundingBox]
    ) -> list[BoundingBox]:
        """IoU 기반 중복 BoundingBox 병합

        Args:
            bboxes: 병합 전 BoundingBox 리스트

        Returns:
            병합된 BoundingBox 리스트
        """
        if len(bboxes) <= 1:
            return bboxes

        # 면적 내림차순 정렬
        sorted_boxes = sorted(bboxes, key=lambda b: b.area, reverse=True)
        merged: list[BoundingBox] = []
        used = [False] * len(sorted_boxes)

        for i, box_i in enumerate(sorted_boxes):
            if used[i]:
                continue

            # 현재 박스와 겹치는 모든 박스 수집
            group = [box_i]
            used[i] = True

            for j in range(i + 1, len(sorted_boxes)):
                if used[j]:
                    continue
                if box_i.iou(sorted_boxes[j]) >= self.config.iou_merge_threshold:
                    group.append(sorted_boxes[j])
                    used[j] = True

            # 그룹을 감싸는 bbox 생성
            x_min = min(b.x for b in group)
            y_min = min(b.y for b in group)
            x_max = max(b.x + b.width for b in group)
            y_max = max(b.y + b.height for b in group)

            merged.append(BoundingBox(
                x=x_min, y=y_min,
                width=x_max - x_min, height=y_max - y_min,
            ))

        return merged
