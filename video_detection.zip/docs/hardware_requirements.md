# 산업용 비디오 모니터링 시스템 - 하드웨어 성능 검토 보고서

**작성일:** 2026-01-19
**프로젝트:** video_detection
**버전:** 0.1.0

---

## 1. 프로젝트 개요

**video_detection** 프로젝트는 산업용 비디오에서 숫자 변화를 감지하고 OCR로 텍스트를 추출하는 시스템입니다.

### 핵심 기술 스택
| 구성요소 | 기술 | 역할 |
|---------|------|------|
| 비디오 처리 | OpenCV 4.8+ | 프레임 추출, 리사이징 |
| OCR 엔진 | PaddleOCR PP-OCRv4 | 텍스트/숫자 인식 |
| 변화 감지 | scikit-image (SSIM) | 구조적 유사도 비교 |
| 데이터 저장 | SQLite | 분석 결과 저장 |
| 이미지 처리 | Pillow, NumPy | 전처리 |

---

## 2. 하드웨어 요구사항

### 2.1 CPU 요구사항

**주요 CPU 부하 요소:**
- 비디오 디코딩 (H.264/H.265)
- SSIM 계산 (매 프레임 × ROI 수)
- 이미지 전처리 (그레이스케일, 블러, 히스토그램 균등화)
- PaddleOCR CPU 모드 연산

| 등급 | CPU 사양 | 코어/스레드 | 권장 클럭 |
|------|----------|------------|----------|
| 최소 | Intel i5-8세대 / Ryzen 5 2세대 | 4C/8T | 2.8GHz+ |
| 권장 | Intel i5-12세대 / Ryzen 5 5세대 | 6C/12T | 3.0GHz+ |
| 최적 | Intel i7-12세대 / Ryzen 7 5세대 | 8C/16T | 3.5GHz+ |

---

### 2.2 GPU 요구사항 (선택사항)

**GPU 활용 대상:**
- PaddleOCR 가속 (Detection + Recognition + Classification)
- 설정: `--gpu` 플래그로 활성화

| 등급 | GPU 사양 | VRAM | CUDA 버전 |
|------|----------|------|-----------|
| 최소 | GTX 1050 Ti | 4GB | CUDA 10.2+ |
| 권장 | RTX 2060 | 6GB | CUDA 11.0+ |
| 최적 | RTX 3060 | 12GB | CUDA 11.8+ |

**참고:** 코드에서 GPU 메모리 제한이 500MB로 설정되어 있어 저사양 GPU도 사용 가능

```python
# ocr_engine.py
gpu_mem: int = 500  # GPU 메모리 제한 (MB)
```

---

### 2.3 메모리(RAM) 요구사항

**메모리 사용 구성:**
| 항목 | 예상 사용량 |
|------|------------|
| PaddleOCR 모델 | 800MB - 1GB |
| 프레임 버퍼 (1080p) | ~50MB |
| Python/라이브러리 오버헤드 | ~500MB |
| 배치 처리 (batch_size=32) | ~200MB |
| **총 필요량** | **~2.5GB** |

| 등급 | RAM | 적용 시나리오 |
|------|-----|--------------|
| 최소 | 4GB | 1080p, CPU 모드 |
| 권장 | 8GB | 1080p, GPU 모드 |
| 최적 | 16GB | 4K 또는 장시간 분석 |

---

### 2.4 저장소 요구사항

**저장소 사용 패턴:**
| 항목 | 예상 크기 |
|------|----------|
| PaddleOCR 모델 캐시 | 500MB - 1GB |
| 1시간 분석 캡처 이미지 | 100 - 400MB |
| SQLite 데이터베이스 | 10 - 100MB |
| 로그 파일 | 수십 MB |

| 등급 | 저장소 | 비고 |
|------|--------|------|
| 최소 | HDD 50GB | 여유 공간 |
| 권장 | SSD 256GB | 캡처 이미지 빈번한 저장 |
| 최적 | NVMe SSD 512GB | 읽기 3000MB/s+ |

**SSD 권장 이유:** 캡처 이미지 저장 및 비디오 스트리밍에서 I/O 병목 방지

---

## 3. 운영 시나리오별 성능 예측

### 시나리오 A: 경량 분석
```
설정: 1080p, 1fps, CPU 모드, ROI 3-5개
리소스: CPU 30-50%, RAM 2-3GB
처리 속도: 2-3x (실시간 충분)
```

### 시나리오 B: 표준 분석 (권장)
```
설정: 1080p, 6fps, GPU 모드, ROI 5-10개
리소스: CPU 50-70%, GPU 30-50%, RAM 4-6GB
처리 속도: 2-4x (실시간 가능)
```

### 시나리오 C: 고성능 분석
```
설정: 4K, 1fps, GPU 모드, ROI 10개+
리소스: CPU 80-100%, GPU 60-80%, RAM 8-12GB
처리 속도: 1-2x (경계선)
```

---

## 4. 성능 병목 지점 및 최적화

### 주요 병목 지점
1. **PaddleOCR 초기화**: 최초 10-30초 소요 → `warmup()` 호출로 해결
2. **SSIM 계산**: 매 프레임 연산 → `downscale_factor` 조정 가능
3. **H.265 디코딩**: CPU 집약적 → H.264 코덱 권장

### 최적화 명령어 예시
```bash
# GPU 모드 + 프레임 간격 0.5초 + SSIM 임계값 0.90
python main.py --video input.mp4 --output ./data --gpu --interval 0.5 --ssim-threshold 0.90
```

---

## 5. 종합 권장 사양

### 최소 사양 (CPU 모드)
- CPU: 4코어 8스레드 (i5-8세대급)
- RAM: 4GB
- GPU: 불필요
- 저장소: HDD 50GB
- OS: Ubuntu 20.04+ / Windows 10

### 권장 사양 (GPU 모드)
- CPU: 6코어 12스레드 (i5-12세대급)
- RAM: 8GB
- GPU: NVIDIA RTX 2060 6GB (CUDA 11.0+)
- 저장소: SSD 256GB
- OS: Ubuntu 22.04 / Windows 11

### 최적 사양 (4K/장시간)
- CPU: 8코어 16스레드 (i7-12세대급)
- RAM: 16GB+
- GPU: NVIDIA RTX 3060 12GB (CUDA 11.8+)
- 저장소: NVMe SSD 512GB
- OS: Ubuntu 22.04 LTS

---

## 6. 결론

이 프로젝트는 **Generator 패턴**과 **지연 로딩**을 활용하여 메모리 효율적으로 설계되어 있습니다.

- **CPU 모드**: 최소 4GB RAM, 4코어 CPU로 실시간 분석 가능 (프레임 간격 조정 시)
- **GPU 모드**: RTX 2060급 GPU 활성화 시 4배 이상 성능 향상
- **장시간 분석**: 16GB RAM과 NVMe SSD 권장

---

## 7. 사용자 요구사항 기반 맞춤 권장 사양

### 확인된 운영 조건
| 항목 | 값 |
|------|-----|
| 비디오 해상도 | **1080p (30fps)** |
| GPU 사용 | **검토 중** |
| 분석 시간 | **장시간 (1시간 이상)** |
| ROI 개수 | **4-7개** |

---

### 맞춤 권장 사양 (1080p, 장시간, 4-7 ROI)

#### CPU 모드 운영 시
```
CPU: 6코어 12스레드 (i5-12400급)
RAM: 8GB
저장소: SSD 256GB (캡처 이미지 저장 위해 필수)
예상 처리 속도: 1.5-2x (실시간 가능)
```

**장점:**
- 초기 비용 절감
- 전력 소비 낮음
- 설정 간단

**단점:**
- GPU 대비 OCR 속도 느림
- CPU 부하 높음 (70-90%)

---

#### GPU 모드 운영 시 (권장)
```
CPU: 6코어 12스레드 (i5-12400급)
RAM: 8GB
GPU: RTX 2060 6GB (CUDA 11.0+)
저장소: SSD 256GB
예상 처리 속도: 3-4x (실시간 여유)
```

**장점:**
- OCR 속도 3-4배 향상
- CPU 부하 분산 (50-60%)
- 장시간 분석 안정성 향상

**단점:**
- GPU 추가 비용
- CUDA 설정 필요

---

### 장시간 분석 특별 고려사항

1. **메모리 안정성**
   - Generator 패턴으로 메모리 누수 최소화됨
   - 8GB RAM 권장 (4GB는 경계선)

2. **저장소 공간**
   - 1시간 분석 시 캡처 이미지: 100-400MB
   - 장시간 분석 시 누적 데이터 고려 필요
   - **SSD 필수** (HDD 병목 발생)

3. **로그 파일 관리**
   - `video_analyzer.log` 로테이션 고려
   - 장시간 시 수십~수백 MB 가능

4. **프레임 간격 조정**
   - 1시간 이상 분석 시 `--interval 0.5` 권장
   - 불필요한 OCR 호출 감소

---

### 최종 권장 구성 (귀하의 조건 기준)

| 구성요소 | 권장 사양 | 비고 |
|---------|----------|------|
| CPU | Intel i5-12400 또는 Ryzen 5 5600 | 6코어 12스레드 |
| RAM | **8GB DDR4** | 장시간 분석 안정성 |
| GPU | **RTX 2060 6GB** (선택) | GPU 모드 시 3-4배 성능 |
| 저장소 | **SSD 256GB** | NVMe 권장 |
| OS | Ubuntu 22.04 LTS | 또는 Windows 10/11 |

### 실행 명령어 예시
```bash
# CPU 모드 (기본)
python main.py --video input.mp4 --output ./data --interval 0.5

# GPU 모드 (권장)
python main.py --video input.mp4 --output ./data --gpu --interval 0.5
```

---

## 부록: 성능 벤치마킹 방법

### OCR 성능 테스트
```python
from src.ocr.ocr_engine import OCREngine, OCRConfig
import time

engine = OCREngine(OCRConfig(use_gpu=True))
engine.warmup()

# 10회 반복 측정
times = []
for _ in range(10):
    start = time.time()
    engine.recognize(test_image)
    times.append(time.time() - start)

print(f"평균 OCR 시간: {sum(times)/len(times):.3f}초")
```

### 메모리 모니터링 (Linux)
```bash
# 실시간 메모리 사용량 확인
top -p $(pgrep -f "python main.py")

# 또는 memory_profiler 사용
pip install memory_profiler
python -m memory_profiler main.py --video test.mp4
```

### GPU 사용량 모니터링
```bash
nvidia-smi -l 1
```
