# 설정 가이드

video_detection 프로젝트의 설정 시스템에 대한 종합 가이드입니다. 이 문서에서는 명령행 인자, 설정 클래스, YAML 파일, 환경변수를 사용한 애플리케이션 구성 방법을 설명합니다.

## 목차

1. [설정 개요](#설정-개요)
2. [명령행 인자](#명령행-인자)
3. [Config 클래스 상세](#config-클래스-상세)
4. [YAML 설정 파일](#yaml-설정-파일)
5. [환경변수](#환경변수)
6. [시나리오별 최적 설정](#시나리오별-최적-설정)

---

## 설정 개요

### 설정 시스템 구조

video_detection은 계층적 설정 시스템을 사용하여 유연한 구성을 지원합니다.

```
┌─────────────────────────────────────────────────────────┐
│                    런타임 오버라이드                      │  ← 최고 우선순위
│               (config.with_overrides())                  │
├─────────────────────────────────────────────────────────┤
│                      명령행 인자                          │
│                  (--video, --gpu 등)                     │
├─────────────────────────────────────────────────────────┤
│                       환경변수                           │
│              (VIDEO_PATH, DB_PATH 등)                    │
├─────────────────────────────────────────────────────────┤
│                      YAML 파일                           │  ← 최저 우선순위
│                    (config.yaml)                         │
└─────────────────────────────────────────────────────────┘
```

### 우선순위 규칙

설정 값은 다음 우선순위에 따라 적용됩니다 (높은 순서대로).

| 순위 | 설정 소스 | 사용 시점 |
|------|-----------|-----------|
| 1 | 런타임 오버라이드 | 프로그래밍 방식으로 특정 값만 변경할 때 |
| 2 | 명령행 인자 | 실행 시점에 설정을 지정할 때 |
| 3 | 환경변수 | 배포 환경별 설정을 관리할 때 |
| 4 | YAML 파일 | 기본 설정을 파일로 관리할 때 |
| 5 | 기본값 | 별도 지정이 없을 때 |

### 설정 로드 예시

```python
from pathlib import Path
from config import Config

# YAML 파일에서 로드
config = Config.from_yaml("config.yaml")

# 환경변수에서 로드
config = Config.from_env()

# 런타임 오버라이드 적용
config = config.with_overrides(
    debug=True,
    **{"processing.batch_size": 64}
)
```

---

## 명령행 인자

### 기본 사용법

```bash
python main.py --video input.mp4 --output ./data [옵션들]
```

### 필수 인자

| 인자 | 단축형 | 설명 |
|------|--------|------|
| `--video` | `-v` | 분석할 비디오 파일 경로 (필수) |

### 선택 인자

#### 경로 설정

| 인자 | 기본값 | 설명 |
|------|--------|------|
| `--output` | `./data` | 결과 저장 디렉토리 |
| `--db` | `<output>/analysis.db` | SQLite 데이터베이스 파일 경로 |

#### 처리 옵션

| 인자 | 기본값 | 설명 |
|------|--------|------|
| `--gpu` | `false` | GPU 가속 사용 (PaddleOCR) |
| `--interval` | `1.0` | 프레임 분석 간격 (초) |
| `--ssim-threshold` | `0.95` | SSIM 변화 감지 임계값 (0.0-1.0) |
| `--confidence` | `0.7` | OCR 신뢰도 임계값 (0.0-1.0) |

#### 디버그 옵션

| 인자 | 설명 |
|------|------|
| `--debug` | 디버그 모드 활성화 (상세 로깅) |

### 사용 예시

```bash
# 기본 분석
python main.py --video input.mp4 --output ./results

# GPU 사용 및 빠른 분석 간격
python main.py --video input.mp4 --output ./results --gpu --interval 0.5

# 높은 정밀도 설정
python main.py --video input.mp4 --output ./results \
    --ssim-threshold 0.98 \
    --confidence 0.85

# 디버그 모드
python main.py --video input.mp4 --output ./results --debug
```

---

## Config 클래스 상세

### ProcessingConfig

비디오 프레임 추출 및 분석 관련 설정입니다.

```python
@dataclass
class ProcessingConfig:
    frame_skip_mode: FrameSkipMode = FrameSkipMode.ADAPTIVE
    default_interval_sec: float = 1.0
    change_detection_interval_sec: float = 0.17  # ~6fps
    change_threshold: float = 0.05
    batch_size: int = 32
    max_workers: int = 0  # 0 = 자동 (CPU 코어 수)
    resize_width: int = 0  # 0 = 원본 유지
    resize_height: int = 0  # 0 = 원본 유지
```

#### 속성 설명

| 속성 | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `frame_skip_mode` | `FrameSkipMode` | `ADAPTIVE` | 프레임 스킵 모드 |
| `default_interval_sec` | `float` | `1.0` | 기본 프레임 추출 간격 (초) |
| `change_detection_interval_sec` | `float` | `0.17` | 변화 감지 시 프레임 추출 간격 (약 6fps) |
| `change_threshold` | `float` | `0.05` | 프레임 변화 감지 임계값 (0.0-1.0) |
| `batch_size` | `int` | `32` | 배치 처리 시 프레임 수 |
| `max_workers` | `int` | `0` | 병렬 처리 워커 수 (0=자동) |
| `resize_width` | `int` | `0` | 처리용 리사이즈 너비 (0=원본) |
| `resize_height` | `int` | `0` | 처리용 리사이즈 높이 (0=원본) |

#### FrameSkipMode 옵션

| 모드 | 값 | 설명 |
|------|-----|------|
| `FIXED` | `"fixed"` | 고정 간격으로 프레임 추출 |
| `ADAPTIVE` | `"adaptive"` | 변화 감지 기반 적응형 추출 |

**ADAPTIVE 모드 동작 방식:**
- 평상시: `default_interval_sec` 간격으로 프레임 추출
- 변화 감지 시: `change_detection_interval_sec` 간격으로 전환하여 정밀 분석

### StorageConfig

분석 결과 저장 관련 설정입니다.

```python
@dataclass
class StorageConfig:
    db_path: Path = Path("data/results.db")
    output_dir: Path = Path("data/output")
    save_frames: bool = False
    frame_format: str = "jpg"
    frame_quality: int = 85
```

#### 속성 설명

| 속성 | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `db_path` | `Path` | `data/results.db` | SQLite 데이터베이스 파일 경로 |
| `output_dir` | `Path` | `data/output` | 결과 출력 디렉토리 |
| `save_frames` | `bool` | `False` | 분석된 프레임 이미지 저장 여부 |
| `frame_format` | `str` | `"jpg"` | 저장 프레임 이미지 형식 |
| `frame_quality` | `int` | `85` | JPEG 품질 (1-100) |

#### 지원 이미지 형식

| 형식 | 확장자 | 특징 |
|------|--------|------|
| JPEG | `jpg`, `jpeg` | 압축률 높음, 파일 크기 작음 |
| PNG | `png` | 무손실, 투명도 지원 |
| WebP | `webp` | 높은 압축률, 웹 최적화 |

### OCRConfig

PaddleOCR 엔진 설정입니다.

```python
@dataclass(frozen=True)
class OCRConfig:
    use_gpu: bool = False
    gpu_mem: int = 500
    numeric_only: bool = True
    confidence_threshold: float = 0.7
    det_db_thresh: float = 0.3
    det_db_box_thresh: float = 0.5
    det_db_unclip_ratio: float = 1.6
    rec_batch_num: int = 6
    max_text_length: int = 25
    use_angle_cls: bool = True
    enable_mkldnn: bool = True
    cpu_threads: int = 4
```

#### 속성 설명

| 속성 | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `use_gpu` | `bool` | `False` | GPU 가속 사용 여부 |
| `gpu_mem` | `int` | `500` | GPU 메모리 한도 (MB) |
| `numeric_only` | `bool` | `True` | 숫자만 인식 모드 (0-9, ., -, +) |
| `confidence_threshold` | `float` | `0.7` | 최소 신뢰도 점수 (0.0-1.0) |
| `det_db_thresh` | `float` | `0.3` | 텍스트 감지 DB 임계값 |
| `det_db_box_thresh` | `float` | `0.5` | 텍스트 박스 감지 임계값 |
| `det_db_unclip_ratio` | `float` | `1.6` | 감지 언클립 비율 |
| `rec_batch_num` | `int` | `6` | 인식 배치 크기 |
| `max_text_length` | `int` | `25` | 최대 인식 텍스트 길이 |
| `use_angle_cls` | `bool` | `True` | 텍스트 각도 분류 사용 |
| `enable_mkldnn` | `bool` | `True` | MKL-DNN 가속 사용 (CPU) |
| `cpu_threads` | `int` | `4` | CPU 스레드 수 |

#### GPU 메모리 가이드라인

| GPU VRAM | 권장 `gpu_mem` 설정 |
|----------|---------------------|
| 4GB | 300-400 MB |
| 6GB | 400-500 MB |
| 8GB+ | 500-1000 MB |

### ChangeDetectorConfig

변화 감지 알고리즘 설정입니다.

```python
@dataclass
class ChangeDetectorConfig:
    ssim_threshold: float = 0.95
    ssim_window_size: int = 7
    debounce_time_ms: float = 100.0
    debounce_buffer_size: int = 5
    numeric_change_threshold: float = 0.0
    numeric_tolerance: float = 1e-6
    ocr_confidence_threshold: float = 0.6
    max_ocr_retries: int = 2
    apply_gaussian_blur: bool = True
    gaussian_kernel_size: tuple[int, int] = (3, 3)
    apply_histogram_equalization: bool = True
    use_grayscale_ssim: bool = True
    downscale_factor: float = 1.0
```

#### 속성 설명

| 속성 | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `ssim_threshold` | `float` | `0.95` | SSIM 변화 감지 임계값 (이 값 미만이면 변화로 판단) |
| `ssim_window_size` | `int` | `7` | SSIM 계산 윈도우 크기 |
| `debounce_time_ms` | `float` | `100.0` | 변화 간 최소 간격 (밀리초) |
| `debounce_buffer_size` | `int` | `5` | 시간적 스무딩을 위한 프레임 버퍼 크기 |
| `numeric_change_threshold` | `float` | `0.0` | 숫자 변화 감지 임계값 (0.0=모든 변화 감지) |
| `numeric_tolerance` | `float` | `1e-6` | 부동소수점 비교 허용 오차 |
| `ocr_confidence_threshold` | `float` | `0.6` | OCR 검증 시 최소 신뢰도 |
| `max_ocr_retries` | `int` | `2` | OCR 재시도 횟수 |

#### SSIM 임계값 가이드라인

| 임계값 | 민감도 | 권장 용도 |
|--------|--------|-----------|
| 0.99 | 매우 높음 | 미세한 변화 감지 (노이즈 주의) |
| 0.95 | 높음 | 일반적인 숫자 변화 감지 (기본값) |
| 0.90 | 중간 | 뚜렷한 변화만 감지 |
| 0.85 | 낮음 | 대규모 변화만 감지 |

### ROIConfig

관심 영역(Region of Interest) 설정입니다.

```python
@dataclass(frozen=True)
class ROIConfig:
    name: str
    x: float
    y: float
    width: float
    height: float
    normalized: bool = True
```

#### 속성 설명

| 속성 | 타입 | 기본값 | 설명 |
|------|------|--------|------|
| `name` | `str` | - | ROI 식별 이름 |
| `x` | `float` | - | 좌상단 X 좌표 |
| `y` | `float` | - | 좌상단 Y 좌표 |
| `width` | `float` | - | ROI 너비 |
| `height` | `float` | - | ROI 높이 |
| `normalized` | `bool` | `True` | 정규화 좌표 사용 여부 |

#### 좌표 시스템

**정규화 좌표 (normalized=True)**
- 범위: 0.0 ~ 1.0
- 해상도 독립적
- 다양한 비디오에 동일 ROI 적용 가능

**픽셀 좌표 (normalized=False)**
- 범위: 0 ~ 이미지 크기
- 특정 해상도에 종속
- 정확한 위치 지정 필요 시 사용

```python
# 정규화 좌표 예시 (화면 중앙 25% 영역)
roi = ROIConfig(
    name="center_display",
    x=0.375,
    y=0.375,
    width=0.25,
    height=0.25,
    normalized=True
)

# 픽셀 좌표 예시 (1920x1080 기준)
roi = ROIConfig(
    name="fixed_display",
    x=100,
    y=200,
    width=300,
    height=150,
    normalized=False
)
```

---

## YAML 설정 파일

### 기본 설정 예시

프로젝트 루트에 `config.yaml` 파일을 생성하여 기본 설정을 관리할 수 있습니다.

```yaml
# config.yaml - video_detection 설정 파일

# 비디오 경로 (선택사항, 명령행에서 지정 가능)
video_path: null

# 비디오 처리 설정
processing:
  frame_skip_mode: adaptive  # fixed 또는 adaptive
  default_interval_sec: 1.0  # 기본 프레임 추출 간격 (초)
  change_detection_interval_sec: 0.17  # 변화 감지 시 간격 (~6fps)
  change_threshold: 0.05  # 프레임 변화 감지 임계값
  batch_size: 32  # 배치 처리 크기
  max_workers: 0  # 병렬 워커 수 (0=자동)
  resize_width: 0  # 리사이즈 너비 (0=원본)
  resize_height: 0  # 리사이즈 높이 (0=원본)

# 저장소 설정
storage:
  db_path: data/results.db
  output_dir: data/output
  save_frames: false
  frame_format: jpg  # jpg, png, webp
  frame_quality: 85  # 1-100

# 관심 영역 (ROI) 설정
rois:
  - name: main_display
    x: 0.1
    y: 0.2
    width: 0.3
    height: 0.15
    normalized: true

  - name: secondary_display
    x: 0.6
    y: 0.2
    width: 0.25
    height: 0.1
    normalized: true

# 디버그 및 로깅
debug: false
log_level: INFO  # DEBUG, INFO, WARNING, ERROR, CRITICAL
```

### 전체 설정 예시

```yaml
# config-full.yaml - 전체 옵션이 포함된 설정 파일

video_path: /path/to/video.mp4

processing:
  frame_skip_mode: adaptive
  default_interval_sec: 1.0
  change_detection_interval_sec: 0.17
  change_threshold: 0.05
  batch_size: 32
  max_workers: 4
  resize_width: 1280
  resize_height: 720

storage:
  db_path: data/analysis.db
  output_dir: data/captures
  save_frames: true
  frame_format: jpg
  frame_quality: 90

rois:
  # 산업용 디스플레이 영역
  - name: pressure_gauge
    x: 0.05
    y: 0.1
    width: 0.15
    height: 0.08
    normalized: true

  - name: temperature_display
    x: 0.25
    y: 0.1
    width: 0.15
    height: 0.08
    normalized: true

  - name: flow_meter
    x: 0.45
    y: 0.1
    width: 0.15
    height: 0.08
    normalized: true

debug: false
log_level: INFO
```

### YAML 파일 로드

```python
from config import Config

# 파일에서 설정 로드
config = Config.from_yaml("config.yaml")

# 설정 확인
print(f"프레임 간격: {config.processing.default_interval_sec}초")
print(f"배치 크기: {config.processing.batch_size}")
print(f"ROI 개수: {len(config.rois)}")
```

### YAML 파일 저장

```python
# 현재 설정을 YAML 파일로 저장
config.save_yaml("config-backup.yaml")
```

---

## 환경변수

### 지원 환경변수

애플리케이션은 다음 환경변수를 인식합니다.

| 환경변수 | 대응 설정 | 설명 |
|----------|-----------|------|
| `VIDEO_PATH` | `video_path` | 비디오 파일 경로 |
| `DB_PATH` | `storage.db_path` | 데이터베이스 경로 |
| `OUTPUT_DIR` | `storage.output_dir` | 출력 디렉토리 |
| `FRAME_INTERVAL` | `processing.default_interval_sec` | 프레임 추출 간격 |
| `DEBUG` | `debug` | 디버그 모드 (`true`/`false`) |
| `LOG_LEVEL` | `log_level` | 로깅 레벨 |

### 환경변수 설정 예시

**Linux/macOS (Bash)**
```bash
export VIDEO_PATH=/data/videos/monitoring.mp4
export DB_PATH=/data/results/analysis.db
export OUTPUT_DIR=/data/output
export FRAME_INTERVAL=0.5
export DEBUG=false
export LOG_LEVEL=INFO

python main.py
```

**Windows (PowerShell)**
```powershell
$env:VIDEO_PATH = "C:\data\videos\monitoring.mp4"
$env:DB_PATH = "C:\data\results\analysis.db"
$env:OUTPUT_DIR = "C:\data\output"
$env:FRAME_INTERVAL = "0.5"
$env:DEBUG = "false"
$env:LOG_LEVEL = "INFO"

python main.py
```

**Docker 환경**
```dockerfile
ENV VIDEO_PATH=/app/data/input.mp4
ENV DB_PATH=/app/data/results.db
ENV OUTPUT_DIR=/app/data/output
ENV DEBUG=false
ENV LOG_LEVEL=INFO
```

```bash
docker run -e VIDEO_PATH=/data/video.mp4 \
           -e DB_PATH=/data/results.db \
           -e OUTPUT_DIR=/data/output \
           -e FRAME_INTERVAL=0.5 \
           video_detection
```

### .env 파일 사용

`.env` 파일을 사용하여 환경변수를 관리할 수 있습니다.

```env
# .env 파일 예시
VIDEO_PATH=/data/videos/monitoring.mp4
DB_PATH=/data/results/analysis.db
OUTPUT_DIR=/data/output
FRAME_INTERVAL=0.5
DEBUG=false
LOG_LEVEL=INFO
```

```python
# python-dotenv 사용 시
from dotenv import load_dotenv
from config import Config

load_dotenv()
config = Config.from_env()
```

### 환경변수 우선순위

환경변수는 YAML 파일보다 높은 우선순위를 갖지만, 명령행 인자보다는 낮습니다.

```bash
# YAML: interval=1.0, 환경변수: interval=0.5, 명령행: interval=0.25
# 최종 적용 값: 0.25 (명령행 우선)
export FRAME_INTERVAL=0.5
python main.py --video input.mp4 --interval 0.25
```

---

## 시나리오별 최적 설정

### 경량 분석 (1080p, CPU 전용)

리소스가 제한된 환경에서 기본적인 분석을 수행할 때 권장되는 설정입니다.

**특징:**
- CPU만 사용
- 메모리 사용량 최소화
- 분석 속도보다 안정성 우선

```yaml
# config-lightweight.yaml
processing:
  frame_skip_mode: fixed
  default_interval_sec: 2.0  # 낮은 샘플링 레이트
  batch_size: 16  # 작은 배치 크기
  max_workers: 2  # 제한된 워커
  resize_width: 854  # 480p로 리사이즈
  resize_height: 480

storage:
  save_frames: false  # 프레임 저장 비활성화
  frame_quality: 70  # 낮은 품질

debug: false
log_level: WARNING
```

**명령행 사용:**
```bash
python main.py --video input.mp4 --output ./results \
    --interval 2.0 \
    --confidence 0.6 \
    --ssim-threshold 0.90
```

**예상 성능:**
- 메모리: ~500MB
- 처리 속도: 실시간의 2-3배

### 표준 분석 (1080p, GPU 사용)

일반적인 분석 작업에 권장되는 설정입니다.

**특징:**
- GPU 가속 사용
- 균형 잡힌 정확도와 속도
- 적응형 프레임 추출

```yaml
# config-standard.yaml
processing:
  frame_skip_mode: adaptive
  default_interval_sec: 1.0
  change_detection_interval_sec: 0.17
  batch_size: 32
  max_workers: 4
  resize_width: 0  # 원본 유지
  resize_height: 0

storage:
  save_frames: true
  frame_format: jpg
  frame_quality: 85

debug: false
log_level: INFO
```

**명령행 사용:**
```bash
python main.py --video input.mp4 --output ./results \
    --gpu \
    --interval 1.0 \
    --confidence 0.7 \
    --ssim-threshold 0.95
```

**예상 성능:**
- GPU 메모리: ~500MB
- 시스템 메모리: ~1.5GB
- 처리 속도: 실시간의 5-10배

### 고성능 분석 (4K 비디오)

4K 해상도 비디오나 높은 정밀도가 필요한 분석 작업용 설정입니다.

**특징:**
- 최대 GPU 활용
- 높은 정밀도 설정
- 대용량 배치 처리

```yaml
# config-highperformance.yaml
processing:
  frame_skip_mode: adaptive
  default_interval_sec: 0.5  # 높은 샘플링 레이트
  change_detection_interval_sec: 0.1  # 10fps 정밀 분석
  batch_size: 64  # 큰 배치 크기
  max_workers: 8  # 많은 워커
  resize_width: 1920  # 처리용 다운스케일
  resize_height: 1080

storage:
  save_frames: true
  frame_format: png  # 무손실 저장
  frame_quality: 100

debug: false
log_level: INFO
```

**명령행 사용:**
```bash
python main.py --video input_4k.mp4 --output ./results \
    --gpu \
    --interval 0.5 \
    --confidence 0.8 \
    --ssim-threshold 0.98
```

**예상 성능:**
- GPU 메모리: ~1GB
- 시스템 메모리: ~4GB
- 처리 속도: 실시간의 3-5배

### 설정 비교 요약

| 설정 항목 | 경량 | 표준 | 고성능 |
|-----------|------|------|--------|
| `frame_skip_mode` | fixed | adaptive | adaptive |
| `default_interval_sec` | 2.0 | 1.0 | 0.5 |
| `batch_size` | 16 | 32 | 64 |
| `max_workers` | 2 | 4 | 8 |
| `gpu` | No | Yes | Yes |
| `ssim_threshold` | 0.90 | 0.95 | 0.98 |
| `confidence` | 0.6 | 0.7 | 0.8 |
| 예상 메모리 | ~500MB | ~1.5GB | ~4GB |

### 시나리오별 권장 사항

**실시간 모니터링**
```yaml
processing:
  frame_skip_mode: adaptive
  default_interval_sec: 0.5
  batch_size: 8  # 낮은 지연시간
```

**배치 분석 (대량 비디오)**
```yaml
processing:
  frame_skip_mode: fixed
  default_interval_sec: 1.0
  batch_size: 64  # 높은 처리량
  max_workers: 8
```

**정밀 분석 (품질 중심)**
```yaml
processing:
  frame_skip_mode: adaptive
  change_detection_interval_sec: 0.05  # 20fps
storage:
  frame_format: png
  frame_quality: 100
```

---

## 참고 사항

### 설정 검증

Config 클래스는 자동으로 설정 값을 검증합니다.

```python
# 잘못된 설정 시 ValueError 발생
try:
    config = ProcessingConfig(default_interval_sec=-1)
except ValueError as e:
    print(f"설정 오류: {e}")
    # 출력: "default_interval_sec는 양수여야 합니다: -1"
```

### 설정 덤프

현재 설정을 딕셔너리로 변환하여 확인할 수 있습니다.

```python
import json

config = Config.from_yaml("config.yaml")
print(json.dumps(config.to_dict(), indent=2, ensure_ascii=False))
```

### 관련 문서

- [README.md](/home/eltriny/Workspace/projects/video_detection/README.md) - 프로젝트 개요
- [hardware_requirements.md](/home/eltriny/Workspace/projects/video_detection/docs/hardware_requirements.md) - 하드웨어 요구사항
