# 비디오 탐지 시스템 아키텍처

## 목차
1. [시스템 개요](#시스템-개요)
2. [아키텍처 다이어그램](#아키텍처-다이어그램)
3. [모듈 구조](#모듈-구조)
4. [핵심 컴포넌트](#핵심-컴포넌트)
5. [디자인 패턴](#디자인-패턴)
6. [데이터 흐름](#데이터-흐름)
7. [설정 관리](#설정-관리)
8. [저장소 계층](#저장소-계층)

---

## 시스템 개요

### 목적 및 핵심 기능

비디오 탐지 시스템은 다음을 위해 설계된 산업용 비디오 모니터링 애플리케이션입니다:

- 산업 장비 디스플레이의 비디오 프레임에서 **숫자 변화 감지**
- OCR 기술을 사용하여 캡처된 이미지에서 **텍스트 추출**
- 모니터링 영역에서 **차트/그래프 감지** (추세 차트, 선 그래프)
- 분석 결과를 구조화된 SQLite 데이터베이스에 **저장**

### 주요 사용 사례

1. 산업 디스플레이의 값 변화 모니터링
2. 변화 감지 시 자동 스크린샷 캡처
3. 캡처된 프레임에서 숫자/텍스트 데이터 추출 및 기록
4. 비디오 스트림에서 차트 영역 식별 및 추적

### 기술 스택

| 계층 | 기술 | 용도 |
|------|------|------|
| 런타임 | Python 3.10+ | 핵심 애플리케이션 언어 |
| 비디오 처리 | OpenCV (cv2) | 프레임 추출 및 이미지 조작 |
| OCR 엔진 | PaddleOCR PP-OCRv4 | 산업 디스플레이 숫자 인식 |
| 이미지 유사도 | scikit-image (SSIM) | 프레임 간 변화 감지 |
| 데이터 저장 | SQLite | 경량 영구 저장소 |
| 이미지 처리 | NumPy, PIL | 배열 연산 및 이미지 I/O |
| 설정 | PyYAML | 설정 파일 파싱 |

---

## 아키텍처 다이어그램

### 고수준 컴포넌트 아키텍처

```mermaid
graph TB
    subgraph Input["입력 계층"]
        VIDEO[비디오 파일]
        CONFIG[설정]
    end

    subgraph Core["핵심 처리"]
        VP[VideoProcessor]
        FA[FrameAnalyzer]
    end

    subgraph Detection["탐지 계층"]
        ROI[ROIDetector]
        CD[ChangeDetector]
        CHART[ChartDetector]
    end

    subgraph Processing["처리 계층"]
        OCR[OCREngine]
        IE[ImageEnhancer]
    end

    subgraph Storage["저장소 계층"]
        DB[(데이터베이스)]
        CM[CaptureManager]
        FS[파일 시스템]
    end

    VIDEO --> VP
    CONFIG --> VP
    CONFIG --> FA

    VP --> FA
    FA --> ROI
    FA --> CD
    FA --> CHART

    CD --> OCR
    CD --> IE
    ROI --> OCR

    IE --> OCR

    FA --> DB
    FA --> CM
    CM --> FS
```

### 데이터 흐름 다이어그램

```mermaid
flowchart LR
    subgraph Input["입력"]
        A[비디오 입력]
    end

    subgraph Extraction["추출"]
        B[프레임 추출<br/>Generator 패턴]
    end

    subgraph Detection["탐지"]
        C[ROI 탐지]
        D[변화 탐지<br/>SSIM + OCR]
        E[차트 탐지<br/>허프 변환]
    end

    subgraph Processing["처리"]
        F[이미지 향상<br/>CLAHE + 이진화]
        G[OCR 인식<br/>PaddleOCR]
    end

    subgraph Output["출력"]
        H[(SQLite DB)]
        I[캡처된 이미지]
    end

    A --> B
    B --> C
    C --> D
    D --> E
    D --> F
    F --> G
    G --> H
    D --> I
```

### 컴포넌트 상호작용 시퀀스

```mermaid
sequenceDiagram
    participant Main
    participant VP as VideoProcessor
    participant FA as FrameAnalyzer
    participant CD as ChangeDetector
    participant OCR as OCREngine
    participant DB as DatabaseManager

    Main->>VP: extract_frames()
    loop 각 프레임에 대해
        VP->>FA: FrameData
        FA->>CD: detect_changes()

        alt 변화 감지됨
            CD->>OCR: recognize()
            OCR-->>CD: OCRResult
            CD-->>FA: ChangeEvent
            FA->>DB: save_result()
        end
    end
    FA-->>Main: AnalysisResult
```

---

## 모듈 구조

```
src/
├── __init__.py
├── main.py                         # 애플리케이션 진입점 및 CLI
├── config.py                       # 설정 관리
│
├── core/                           # 핵심 처리 모듈
│   ├── __init__.py
│   ├── video_processor.py          # 비디오 프레임 추출
│   └── frame_analyzer.py           # 분석 오케스트레이션
│
├── detection/                      # 탐지 모듈
│   ├── __init__.py
│   ├── roi_detector.py             # 관심 영역(ROI) 탐지
│   ├── change_detector.py          # 값 변화 탐지
│   └── chart_detector.py           # 차트/그래프 탐지
│
├── ocr/                            # OCR 모듈
│   ├── __init__.py
│   └── ocr_engine.py               # PaddleOCR 래퍼
│
├── preprocessing/                  # 이미지 전처리
│   ├── __init__.py
│   └── image_enhancer.py           # 이미지 향상 파이프라인
│
└── storage/                        # 데이터 영속성
    ├── __init__.py
    ├── database.py                 # SQLite 데이터베이스 관리자
    └── capture_manager.py          # 이미지 파일 저장소
```

---

## 핵심 컴포넌트

### VideoProcessor (`src/core/video_processor.py`)

**책임**: Generator 패턴을 사용한 메모리 효율적인 비디오 프레임 추출

**주요 기능**:
- 메모리 효율성을 위한 Generator 기반 프레임 추출
- 감지된 변화에 따른 적응형 프레임 스킵
- 장시간 비디오(1시간 이상) 지원
- 프레임 리사이징 및 전처리

**인터페이스**:

```python
class VideoProcessor:
    def __init__(self, config: Config) -> None
    def extract_frames(self, start_ms: float = 0, end_ms: float | None = None) -> Generator[FrameData, None, None]
    def extract_frame_at(self, timestamp_ms: float) -> FrameData | None
    def iterate_all_frames(self) -> Iterator[FrameData]

@dataclass
class FrameData:
    frame: NDArray[np.uint8]        # BGR 이미지 데이터
    frame_number: int               # 원본 프레임 번호
    timestamp_ms: float             # 밀리초 단위 타임스탬프
    is_change_detected: bool        # 변화 감지 플래그
    change_score: float             # 변화 크기 (0.0-1.0)
```

---

### FrameAnalyzer (`src/core/frame_analyzer.py`)

**책임**: 탐지, OCR 및 저장소 모듈의 오케스트레이션

**주요 기능**:
- 다중 분석 모듈 조정
- 배치 및 병렬 처리 지원
- 콜백 기반 이벤트 알림
- 통계 추적 및 보고

**인터페이스**:

```python
class FrameAnalyzer:
    def set_detector(self, detector: DetectorProtocol) -> FrameAnalyzer
    def set_ocr_engine(self, ocr_engine: OCREngineProtocol) -> FrameAnalyzer
    def set_storage(self, storage: StorageProtocol) -> FrameAnalyzer
    def add_callback(self, callback: AnalysisCallback) -> FrameAnalyzer
    def analyze_video(self, start_ms: float = 0, end_ms: float | None = None) -> Generator[AnalysisResult, None, None]
    def analyze_video_parallel(self, start_ms: float = 0, end_ms: float | None = None) -> Generator[AnalysisResult, None, None]

class DetectorProtocol(Protocol):
    def detect(self, frame: NDArray[np.uint8], confidence_threshold: float = 0.5) -> DetectionResult

class OCREngineProtocol(Protocol):
    def recognize(self, frame: NDArray[np.uint8], confidence_threshold: float = 0.5) -> OCRResult
```

---

### ROIDetector (`src/detection/roi_detector.py`)

**책임**: 비디오 프레임에서 관심 영역(ROI) 자동 탐지

**주요 기능**:
- 윤곽선 기반 영역 탐지
- OCR 지원 텍스트/숫자 영역 식별
- 에지 기반 차트 영역 탐지
- 안정적인 탐지를 위한 다중 프레임 합의
- 중첩 처리를 위한 NMS (Non-Maximum Suppression)

**탐지 방법**:

| 방법 | 기술 | 사용 사례 |
|------|------|----------|
| 윤곽선 탐지 | 적응형 임계값 + 형태학 | 일반 영역 발견 |
| OCR 기반 | PaddleOCR 텍스트 탐지 | 텍스트/숫자 영역 |
| 에지 기반 | Canny + 허프 변환 | 차트/그래프 영역 |

**인터페이스**:

```python
class ROIDetector:
    def detect_from_frame(self, frame: NDArray[np.uint8], use_ocr: bool = True) -> list[ROI]
    def detect_from_multiple_frames(self, frames: list[NDArray[np.uint8]], consensus_threshold: float = 0.5) -> list[ROI]
    def save_rois(self, rois: list[ROI], filepath: Path | str) -> None
    def load_rois(self, filepath: Path | str) -> list[ROI]

@dataclass
class ROI:
    id: str
    bbox: BoundingBox
    roi_type: ROIType          # NUMERIC, TEXT, CHART, UNKNOWN
    confidence: float
    label: str
```

---

### ChangeDetector (`src/detection/change_detector.py`)

**책임**: SSIM과 OCR 검증을 결합한 하이브리드 변화 탐지

**주요 기능**:
- SSIM 기반 빠른 픽셀 비교
- 숫자/텍스트 영역에 대한 OCR 검증
- 노이즈 필터링을 위한 디바운싱
- ROI별 상태 추적
- 이벤트를 위한 콜백 등록

**탐지 전략**:

```
1. 현재 프레임과 이전 프레임 간 SSIM 계산
2. SSIM < 임계값(0.95)이면 잠재적 변화 감지
3. NUMERIC/TEXT ROI의 경우: OCR로 검증
4. 디바운싱 적용 (시간적 스무딩)
5. 확인되면 ChangeEvent 발생
```

**인터페이스**:

```python
class ChangeDetector:
    def detect_changes(self, current_frame: NDArray[np.uint8], rois: list[ROI], timestamp: float | None = None) -> list[ChangeEvent]
    def detect_changes_between_frames(self, previous_frame: NDArray[np.uint8], current_frame: NDArray[np.uint8], rois: list[ROI], timestamp: float | None = None) -> list[ChangeEvent]
    def register_callback(self, callback: Callable[[ChangeEvent], None]) -> None
    def reset_state(self, roi_id: str | None = None) -> None

@dataclass
class ChangeEvent:
    roi_id: str
    roi_type: ROIType
    change_type: ChangeType    # NUMERIC_INCREASE, NUMERIC_DECREASE, TEXT_CHANGE, VISUAL_CHANGE
    timestamp: float
    ssim_score: float
    previous_value: str | None
    current_value: str | None
    numeric_delta: float | None
    confidence: float
```

---

### ChartDetector (`src/detection/chart_detector.py`)

**책임**: 이미지 영역에서 선 차트 및 그래프 탐지

**주요 기능**:
- 라인 식별을 위한 Canny 에지 탐지
- 축 및 데이터 라인 탐지를 위한 허프 라인 변환
- 차트 유형 분류 (선형, 막대, 산점도)
- 축 탐지 (X축 및 Y축)
- 신뢰도 점수 산출

**탐지 파이프라인**:

```
1. 전처리 (가우시안 블러, 형태학적 연산)
2. Canny 에지 탐지
3. 확률적 허프 라인 변환
4. 라인 분류 (수평, 수직, 대각선)
5. 수평/수직 라인에서 축 탐지
6. 차트 영역에서 데이터 라인(대각선) 식별
7. 신뢰도 점수 계산
```

**인터페이스**:

```python
class ChartDetector:
    def detect_chart(self, image: NDArray[np.uint8]) -> bool
    def analyze(self, image: NDArray[np.uint8]) -> ChartDetectionResult
    def visualize_detection(self, image: NDArray[np.uint8], result: ChartDetectionResult) -> NDArray[np.uint8]

@dataclass
class ChartDetectionResult:
    is_chart: bool
    chart_type: ChartType      # LINE_CHART, BAR_CHART, SCATTER_PLOT, AREA_CHART
    confidence: float
    x_axis: AxisDetection | None
    y_axis: AxisDetection | None
    data_lines_count: int
```

---

### OCREngine (`src/ocr/ocr_engine.py`)

**책임**: 산업 디스플레이 인식에 최적화된 PaddleOCR 래퍼

**주요 기능**:
- PP-OCRv4 모델 통합
- 설정 가능한 메모리 제한으로 GPU/CPU 지원
- 숫자 전용 인식 모드
- 신뢰도 기반 필터링
- 메모리 관리와 함께 배치 처리
- 스레드 안전 싱글톤 패턴

**인터페이스**:

```python
class OCREngine:
    def recognize(self, image: NDArray[np.uint8] | str | Path) -> tuple[OCRResult, ...]
    def recognize_batch(self, images: Sequence[NDArray[np.uint8] | str | Path], chunk_size: int = 10) -> OCRBatchResult
    def recognize_region(self, image: NDArray[np.uint8], region: tuple[int, int, int, int]) -> tuple[OCRResult, ...]
    def warmup(self, dummy_size: tuple[int, int] = (100, 100)) -> None

@dataclass
class OCRResult:
    text: str
    confidence: float
    bounding_box: BoundingBox
    raw_text: str
```

---

### ImageEnhancer (`src/preprocessing/image_enhancer.py`)

**책임**: OCR 최적화를 위한 설정 가능한 이미지 전처리 파이프라인

**주요 기능**:
- CLAHE 대비 향상
- 가우시안 블러 및 양방향 필터링
- 적응형 이진화 (Otsu, 가우시안, 평균)
- 형태학적 연산
- 사용자 정의 가능한 파이프라인 순서
- 다양한 시나리오를 위한 프리셋 설정

**파이프라인 단계**:

| 단계 | 용도 | 기본값 |
|------|------|--------|
| 그레이스케일 | 색공간 변환 | 활성화 |
| CLAHE | 적응형 대비 향상 | 활성화 |
| 가우시안 블러 | 노이즈 감소 | 활성화 |
| 양방향 필터 | 에지 보존 스무딩 | 비활성화 |
| 이진화 | 텍스트/배경 분리 | 활성화 |
| 형태학적 | 노이즈 제거 | 활성화 |
| 샤프닝 | 에지 향상 | 비활성화 |
| 노이즈 제거 | 고급 노이즈 감소 | 비활성화 |

**인터페이스**:

```python
class ImageEnhancer:
    def enhance(self, image: NDArray[np.uint8]) -> ProcessingResult
    def enhance_region(self, image: NDArray[np.uint8], region: tuple[int, int, int, int]) -> ProcessingResult
    def enhance_batch(self, images: Sequence[NDArray[np.uint8]]) -> list[ProcessingResult]
    def apply_single_step(self, image: NDArray[np.uint8], step: PreprocessingStep) -> NDArray[np.uint8]

# 프리셋 설정
def create_industrial_display_config() -> PreprocessingConfig
def create_low_contrast_config() -> PreprocessingConfig
def create_noisy_image_config() -> PreprocessingConfig
```

---

## 디자인 패턴

### Generator 패턴 (메모리 효율성)

**위치**: `VideoProcessor.extract_frames()`

**목적**: 모든 프레임을 메모리에 로드하지 않고 장시간 비디오 처리

**구현**:
```python
def extract_frames(self, start_ms: float = 0, end_ms: float | None = None) -> Generator[FrameData, None, None]:
    with self._open_video() as cap:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            # 단일 프레임 처리 및 yield
            yield FrameData(frame=processed_frame, ...)
```

**장점**:
- 비디오 길이와 무관한 일정한 메모리 사용
- 스트리밍 처리 지원
- 리소스 낭비 없는 조기 종료

---

### Protocol 패턴 (인터페이스 추상화)

**위치**: `FrameAnalyzer` 모듈

**목적**: 상속 없이 플러그인 가능한 컴포넌트의 계약 정의

**구현**:
```python
class DetectorProtocol(Protocol):
    def detect(self, frame: NDArray[np.uint8], confidence_threshold: float = 0.5) -> DetectionResult: ...

class OCREngineProtocol(Protocol):
    def recognize(self, frame: NDArray[np.uint8], confidence_threshold: float = 0.5) -> OCRResult: ...

class StorageProtocol(Protocol):
    def save_result(self, result: AnalysisResult) -> None: ...
```

**장점**:
- 정적 타입 검사와 함께 덕 타이핑
- 테스트를 위한 쉬운 컴포넌트 교체
- 상속 결합 없음

---

### Factory 패턴 (설정 기반 생성)

**위치**: `ImageEnhancer`, `Config` 모듈

**목적**: 일반적인 시나리오를 위한 사전 설정된 객체 생성

**구현**:
```python
def create_industrial_display_config() -> PreprocessingConfig:
    return PreprocessingConfig(
        enable_clahe=True,
        clahe_clip_limit=3.0,
        enable_binarization=True,
        binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
        # ... 추가 설정
    )

# 사용법
enhancer = ImageEnhancer(create_industrial_display_config())
```

**장점**:
- 복잡한 설정 로직 캡슐화
- 테스트되고 최적화된 프리셋 제공
- 설정 오류 감소

---

### Callback 패턴 (이벤트 처리)

**위치**: `FrameAnalyzer`, `ChangeDetector`

**목적**: 이벤트 생산자와 소비자의 분리

**구현**:
```python
class AnalysisCallback(ABC):
    @abstractmethod
    def on_frame_analyzed(self, result: AnalysisResult) -> None: ...

    @abstractmethod
    def on_batch_complete(self, results: list[AnalysisResult]) -> None: ...

    @abstractmethod
    def on_progress(self, progress: float, message: str) -> None: ...

    @abstractmethod
    def on_error(self, error: Exception, frame_data: FrameData | None) -> None: ...

# 등록
analyzer.add_callback(LoggingCallback(log_every_n=100))
analyzer.add_callback(ProgressBarCallback())
```

**장점**:
- 이벤트당 다중 옵저버
- 컴포넌트 간 느슨한 결합
- 새로운 동작을 위한 쉬운 확장

---

### Context Manager 패턴 (리소스 안전성)

**위치**: `VideoProcessor`, `DatabaseManager`, `CaptureManager`

**목적**: 적절한 리소스 정리 보장

**구현**:
```python
@contextmanager
def _open_video(self) -> Generator[VideoCapture, None, None]:
    cap = cv2.VideoCapture(str(self._video_path))
    try:
        if not cap.isOpened():
            raise RuntimeError(f"비디오를 열 수 없음: {self._video_path}")
        yield cap
    finally:
        cap.release()

# 사용법
with self._open_video() as cap:
    # 비디오 처리
    pass  # cap.release()가 자동으로 호출됨
```

**장점**:
- 보장된 리소스 정리
- 예외 안전한 리소스 처리
- 명시적 정리 없이 깔끔한 코드

---

### Builder 패턴 (Fluent 설정)

**위치**: `FrameAnalyzer`

**목적**: 읽기 쉽고 체이닝 가능한 설정 제공

**구현**:
```python
analyzer = FrameAnalyzer(config) \
    .set_detector(my_detector) \
    .set_ocr_engine(my_ocr) \
    .set_storage(my_storage) \
    .add_callback(LoggingCallback()) \
    .set_analysis_type(AnalysisType.BOTH) \
    .set_confidence_thresholds(detection=0.5, ocr=0.7)
```

**장점**:
- 읽기 쉬운 설정 코드
- 생성자 폭발 없이 선택적 매개변수
- 자체 문서화 API

---

## 데이터 흐름

### 완전한 처리 파이프라인

```
비디오 입력
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ VideoProcessor.extract_frames()                             │
│ - 적응형 간격으로 프레임 추출                                   │
│ - 성능을 위한 선택적 리사이즈                                   │
│ - 메모리 효율성을 위한 Generator 패턴                          │
└─────────────────────────────────────────────────────────────┘
    │
    │ FrameData (프레임, 타임스탬프, 프레임 번호)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ ROIDetector.detect_from_frame()                             │
│ - 윤곽선 탐지                                                │
│ - OCR 기반 영역 탐지                                         │
│ - 에지 기반 차트 탐지                                         │
│ - 중첩 제거를 위한 NMS                                        │
└─────────────────────────────────────────────────────────────┘
    │
    │ list[ROI] (bbox, 유형, 신뢰도)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ ChangeDetector.detect_changes()                             │
│ - ROI별 SSIM 계산                                           │
│ - 텍스트/숫자에 대한 OCR 검증                                  │
│ - 노이즈 필터링을 위한 디바운싱                                 │
└─────────────────────────────────────────────────────────────┘
    │
    │ list[ChangeEvent] (변화 유형, 값, 신뢰도)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ ImageEnhancer.enhance()                                     │
│ - CLAHE 대비 향상                                            │
│ - 적응형 이진화                                               │
│ - 형태학적 정리                                               │
└─────────────────────────────────────────────────────────────┘
    │
    │ ProcessingResult (향상된 이미지)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ OCREngine.recognize()                                       │
│ - PaddleOCR PP-OCRv4 추론                                   │
│ - 숫자 필터링 (선택 사항)                                      │
│ - 신뢰도 필터링                                               │
└─────────────────────────────────────────────────────────────┘
    │
    │ OCRResult (텍스트, 신뢰도, bbox)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ ChartDetector.analyze()                                     │
│ - 에지 탐지                                                  │
│ - 축 식별                                                    │
│ - 데이터 라인 탐지                                            │
└─────────────────────────────────────────────────────────────┘
    │
    │ ChartDetectionResult (is_chart, 유형, 신뢰도)
    ▼
┌─────────────────────────────────────────────────────────────┐
│ 저장소 계층                                                  │
│ - DatabaseManager: SQLite 영속성                            │
│ - CaptureManager: 이미지 파일 저장                            │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
출력 (데이터베이스 레코드 + 캡처된 이미지)
```

### 적응형 프레임 스킵 로직

```
                    ┌─────────────────┐
                    │  프레임 처리    │
                    │     시작        │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ 이전 프레임과   │
                    │ SSIM 계산       │
                    └────────┬────────┘
                             │
                ┌────────────┴────────────┐
                ▼                         ▼
        ┌──────────────┐         ┌──────────────┐
        │ SSIM >= 0.95 │         │ SSIM < 0.95  │
        │ (변화 없음)   │         │ (변화 감지!) │
        └──────┬───────┘         └──────┬───────┘
               │                        │
               ▼                        ▼
        ┌──────────────┐         ┌──────────────┐
        │ 기본 간격    │         │ 간격 감소    │
        │ 유지         │         │              │
        │ (1.0 초)     │         │ (0.17 초)    │
        └──────┬───────┘         └──────┬───────┘
               │                        │
               │                        ▼
               │                 ┌──────────────┐
               │                 │ 변화 없이    │
               │                 │ N 프레임 후  │
               │                 └──────┬───────┘
               │                        │
               │                        ▼
               │                 ┌──────────────┐
               │                 │ 기본 간격    │
               │                 │ 복원         │
               └────────────────►└──────────────┘
```

---

## 설정 관리

### 설정 계층 구조

```python
@dataclass
class Config:
    video_path: Path | None                    # 입력 비디오 파일
    processing: ProcessingConfig               # 프레임 처리 설정
    storage: StorageConfig                     # 출력 저장소 설정
    rois: list[ROIConfig]                      # 관심 영역 정의
    debug: bool                                # 디버그 모드 플래그
    log_level: str                             # 로깅 상세도

@dataclass
class ProcessingConfig:
    frame_skip_mode: FrameSkipMode             # FIXED 또는 ADAPTIVE
    default_interval_sec: float                # 기본 프레임 간격 (1.0초)
    change_detection_interval_sec: float       # 변화 시 간격 (0.17초)
    change_threshold: float                    # SSIM 변화 임계값 (0.05)
    batch_size: int                            # 배치 처리 크기 (32)
    max_workers: int                           # 병렬 워커 수 (0=자동)
    resize_width: int                          # 처리 리사이즈 너비
    resize_height: int                         # 처리 리사이즈 높이

@dataclass
class StorageConfig:
    db_path: Path                              # SQLite 데이터베이스 경로
    output_dir: Path                           # 출력 디렉토리
    save_frames: bool                          # 분석된 프레임 저장
    frame_format: str                          # 이미지 형식 (jpg, png)
    frame_quality: int                         # JPEG 품질 (1-100)

@dataclass
class ROIConfig:
    name: str                                  # ROI 식별자
    x: float                                   # 좌상단 X 좌표
    y: float                                   # 좌상단 Y 좌표
    width: float                               # ROI 너비
    height: float                              # ROI 높이
    normalized: bool                           # 정규화 좌표 사용 (0.0-1.0)
```

### 설정 소스

1. **YAML 파일**:
   ```yaml
   video_path: /path/to/video.mp4
   processing:
     frame_skip_mode: adaptive
     default_interval_sec: 1.0
   storage:
     db_path: data/results.db
     output_dir: data/output
   rois:
     - name: display_1
       x: 0.1
       y: 0.2
       width: 0.3
       height: 0.1
       normalized: true
   ```

2. **환경 변수**:
   ```bash
   VIDEO_PATH=/path/to/video.mp4
   DB_PATH=/path/to/db.sqlite
   OUTPUT_DIR=/path/to/output
   FRAME_INTERVAL=1.0
   DEBUG=true
   LOG_LEVEL=DEBUG
   ```

3. **런타임 오버라이드**:
   ```python
   config = Config.from_yaml("config.yaml")
   config = config.with_overrides(
       debug=True,
       **{"processing.batch_size": 64}
   )
   ```

---

## 저장소 계층

### 데이터베이스 스키마

```mermaid
erDiagram
    sessions ||--o{ roi_definitions : 포함
    sessions ||--o{ change_events : 기록
    roi_definitions ||--o{ change_events : 트리거

    sessions {
        int id PK
        text name
        text source_path
        timestamp created_at
        timestamp updated_at
        int is_active
        text metadata
    }

    roi_definitions {
        int id PK
        int session_id FK
        text name
        text roi_type
        int x
        int y
        int width
        int height
        real threshold
        timestamp created_at
        text metadata
    }

    change_events {
        int id PK
        int roi_id FK
        int session_id FK
        timestamp timestamp
        text previous_value
        text current_value
        text frame_path
        text extracted_text
        int is_chart
        real confidence
        text metadata
    }
```

### 파일 저장소 구조

```
{output_dir}/
├── captures/                           # 캡처된 이미지
│   └── {year}/
│       └── {month}/
│           └── {day}/
│               └── {session}_{roi}_{timestamp}.jpg
├── analysis.db                         # SQLite 데이터베이스
└── video_analyzer.log                  # 애플리케이션 로그
```

### CaptureManager 기능

| 기능 | 설명 |
|------|------|
| 타임스탬프 기반 명명 | `{session}_{roi}_{YYYYMMDD_HHMMSS_ffffff}.jpg` |
| 자동 디렉토리 생성 | 날짜 기반 하위 디렉토리 자동 생성 |
| 다중 형식 | JPEG, PNG, WebP, BMP 지원 |
| 압축 제어 | 품질 설정 0-100 |
| 비동기 지원 | ThreadPoolExecutor를 사용한 논블로킹 I/O |
| 배치 작업 | 단일 호출로 다중 캡처 저장 |
| 정리 유틸리티 | N일 이상된 캡처 삭제 |

---

## 성능 특성

### 메모리 효율성

| 컴포넌트 | 전략 | 메모리 영향 |
|----------|------|-------------|
| VideoProcessor | Generator 패턴 | 일정 (단일 프레임) |
| ROIDetector | 프레임별 처리 | O(영역 수) |
| ChangeDetector | ROI별 상태 | O(ROI 수) |
| OCREngine | 지연 모델 로딩 | ~500MB GPU / ~200MB CPU |
| DatabaseManager | 연결 풀링 | 최소 |

### 예상 성능

| 메트릭 | 값 | 참고 |
|--------|-----|------|
| 처리 속도 | 5-10 FPS | 분석 처리량 |
| 메모리 사용량 | < 1GB | 1시간 비디오 기준 |
| 비디오 길이 | 무제한 | Generator 기반 |
| 시작 시간 | 2-5 초 | 모델 로딩 |

### 최적화 팁

1. **GPU 가속**: CUDA 사용 가능 시 OCR에 `use_gpu=True` 활성화
2. **프레임 리사이즈**: 처리 부하 감소를 위해 `resize_width/height` 설정
3. **배치 크기**: 더 나은 처리량을 위해 `batch_size` 증가
4. **병렬 워커**: 병렬 분석을 위해 `max_workers > 1` 설정
5. **JPEG 품질**: I/O 시간 감소를 위해 낮은 품질 (70-85) 사용

---

## 확장 포인트

### 새로운 탐지기 추가

`DetectorProtocol` 구현:

```python
class CustomDetector:
    def detect(
        self,
        frame: NDArray[np.uint8],
        confidence_threshold: float = 0.5,
    ) -> DetectionResult:
        # 사용자 정의 탐지 로직
        return DetectionResult(boxes=[...])

# 통합
analyzer.set_detector(CustomDetector())
```

### 새로운 OCR 엔진 추가

`OCREngineProtocol` 구현:

```python
class TesseractOCR:
    def recognize(
        self,
        frame: NDArray[np.uint8],
        confidence_threshold: float = 0.5,
    ) -> OCRResult:
        # Tesseract 통합
        return OCRResult(text="...", words=[...])
```

### 새로운 저장소 백엔드 추가

`StorageProtocol` 구현:

```python
class CloudStorage:
    def save_result(self, result: AnalysisResult) -> None:
        # 클라우드에 업로드
        pass

    def save_batch(self, results: list[AnalysisResult]) -> None:
        # 배치 업로드
        pass
```

---

## 부록

### 버전 이력

| 버전 | 날짜 | 변경 사항 |
|------|------|----------|
| 0.1.0 | 2024 | 초기 릴리스 |

### 라이선스

MIT License

### 참고 자료

- [PaddleOCR 문서](https://github.com/PaddlePaddle/PaddleOCR)
- [OpenCV Python 문서](https://docs.opencv.org/4.x/d6/d00/tutorial_py_root.html)
- [scikit-image SSIM](https://scikit-image.org/docs/stable/api/skimage.metrics.html)
