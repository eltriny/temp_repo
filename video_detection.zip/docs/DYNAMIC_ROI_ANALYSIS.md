# Dynamic ROI Detection - 분석 결과 문서

## 1. 배경 및 목표

v2.0 시스템은 사전 정의된 ROI 템플릿 기반으로 동작하며, 영상마다 동일한 좌표의 ROI를 적용합니다.
그러나 영상별로 해상도/크롭 차이와 완전히 다른 장비/레이아웃이 존재하여, 매번 새 템플릿을 수동 생성해야 하는 문제가 있습니다.

**목표**: 영상 분석 시작 시 첫 프레임에서 ROI를 자동으로 탐지하여, 템플릿 없이도 분석이 가능하도록 합니다.

**분석 대상 환경**: 일반 모니터 캡처 영상 (산업용 디스플레이가 아님)

---

## 2. 텍스트 ROI 동적 탐지

### 2.1 접근법: 전체 OCR 후 패턴 필터링

PaddleOCR PP-OCRv4의 det+rec 전체 파이프라인을 첫 프레임에 실행한 후,
결과에 정규식 패턴 매칭을 적용하여 관심 텍스트의 바운딩 박스를 ROI로 변환합니다.

**파이프라인**:
```
[첫 프레임] → PaddleOCR(det+rec) → OCR 결과 리스트
    → 패턴 매칭 (정규식) → 카테고리 분류
    → BoundingBox 변환 + 패딩
    → 같은 줄 인접 ROI 병합
    → 최종 텍스트 ROI 리스트
```

### 2.2 패턴 카테고리

| 카테고리 | 패턴 예시 | ROI 타입 | 우선순위 |
|---------|----------|---------|---------|
| TEMPERATURE | `25.5°C`, `Temperature: 72.3°C` | NUMERIC | 10 |
| PERCENTAGE | `85.3%`, `-2.5%` | NUMERIC | 9 |
| TIMESTAMP | `14:30`, `14:30:05` | TEXT | 8 |
| PRESSURE | `2.5 bar`, `101.3 kPa` | NUMERIC | 7 |
| FREQUENCY | `60 Hz`, `2.4 GHz` | NUMERIC | 7 |
| LABELED_VALUE | `Speed: 1500`, `RPM=3200` | NUMERIC | 5 |
| STATUS_TEXT | `RUNNING`, `ERROR`, `STANDBY` | TEXT | 4 |
| NUMERIC_VALUE | `123.456` | NUMERIC | 3 |

### 2.3 인접 ROI 병합

PaddleOCR이 "Temperature:" 와 "25.5C"를 별도로 인식할 수 있습니다.
같은 줄(Y 중심점 차이 <= 15px)에서 수평 간격이 30px 이하인 ROI를 하나로 병합합니다.

### 2.4 성능 예상

- 전체 OCR: ~550ms (GPU) / ~1.3s (CPU) - 1920x1080 기준
- 패턴 매칭: ~1ms (무시 가능)
- 첫 프레임에서만 1회 실행, 이후 재사용

### 2.5 한계

- 일반 모니터 캡처는 텍스트가 매우 많아 관심 없는 UI 요소도 탐지될 수 있음
- OCR 품질에 의존 (블러/저해상도 시 정확도 저하)
- 패턴에 포함되지 않은 새로운 형식의 값은 탐지 불가

---

## 3. 파형 ROI 동적 탐지

### 3.1 대상

축(axis)이나 범례(legend) 없이, 노이즈 배경에 존재하는 단순 선형 파형을 탐지합니다.
오실로스코프 스타일 파형, 트렌드 라인 등이 해당됩니다.

### 3.2 접근법: 2-Pass 분석

**Pass 1 - 수평 프로젝션 프로파일**:
- Canny 에지 이미지의 각 행별 에지 밀도를 측정
- 파형이 지나는 행에서 수평 연속성이 높은 밴드를 탐지
- 밴드 내 에지의 수평 범위로 BoundingBox 생성

**Pass 2 - 연결 성분 분석**:
- 적응형 이진화 후 수평 형태학적 커널(15x3)로 에지를 연결
- connectedComponentsWithStats로 연결 성분 추출
- 종횡비(width/height >= 2.0)와 너비 비율로 필터링

```
[프레임] → 전처리 (Grayscale + GaussianBlur)
    ├─ Canny Edge → 행별 프로젝션 → 활성 밴드 → BBox (Pass 1)
    └─ AdaptiveThreshold → 수평 Morph Close → CC 분석 → BBox (Pass 2)
    → 두 패스 결과 합산 → IoU 기반 중복 제거 → 최종 파형 ROI
```

### 3.3 기존 ChartDetector와의 차이

| 항목 | ChartDetector (기존) | WaveformDetector (신규) |
|------|---------------------|----------------------|
| 축 의존성 | Hough 기반 축 감지 필수 | 축 불필요 |
| 대상 | 구조화된 차트 | 단순 선형 파형 |
| 노이즈 내성 | 낮음 | 높음 |
| 성능 | ~20ms | ~15ms |

### 3.4 설정 파라미터

| 파라미터 | 기본값 | 설명 |
|---------|-------|------|
| `min_component_aspect_ratio` | 2.0 | 파형 판정 최소 종횡비 |
| `min_component_width_ratio` | 0.1 | 프레임 너비 대비 최소 파형 너비 |
| `max_waveform_height_ratio` | 0.3 | 프레임 높이 대비 최대 파형 높이 |
| `min_area` | 500 | 최소 영역 면적 (px^2) |
| `iou_merge_threshold` | 0.3 | 두 패스 결과 병합 IoU 임계값 |

---

## 4. 통합 아키텍처

### 4.1 DynamicROIDetector 오케스트레이터

```
DynamicROIDetector.detect(frame)
    ├─ TextROIDetector.detect(frame) → 텍스트 ROI 리스트
    ├─ WaveformDetector.detect(frame) → 파형 ROI 리스트
    ├─ 텍스트-파형 간 IoU 기반 중복 제거 (텍스트 ROI 우선)
    └─ 고유 ID 재할당 (auto_text_0, auto_waveform_0, ...)
```

### 4.2 시스템 통합 흐름

```
CLI: python -m src.main --video capture.mp4 --output ./results --auto-detect

VideoAnalyzerApp.run()
    ├─[auto_detect=True]─→ _detect_rois_from_first_frame()
    │   ├── VideoProcessor로 첫 프레임 추출
    │   ├── DynamicROIDetector.detect(frame)
    │   ├── DB roi_definitions에 저장
    │   └── load_session_rois_as_detection_rois()로 재로드
    │
    ├─[auto_detect=False]─→ 기존 템플릿 경로 (변경 없음)
    │
    └─→ _analyze_frames_parallel(session_id, rois)  (변경 없음)
```

### 4.3 DB 저장 방식

기존 `roi_definitions` 테이블에 저장 (스키마 변경 없음):

```sql
INSERT INTO roi_definitions
    (session_id, name, roi_type, x, y, width, height, threshold, metadata)
VALUES
    (?, 'auto_text_0', 'numeric', 100, 200, 80, 40, 0.1,
     '{"source":"auto_detected","pattern_category":"temperature","original_text":"25.5C"}');
```

---

## 5. 파일 구조

```
src/detection/
    text_roi_detector.py       # TextROIDetector, PatternCategory, TextPattern
    waveform_detector.py       # WaveformDetector, WaveformDetectorConfig
    dynamic_roi_detector.py    # DynamicROIDetector (오케스트레이터)

tests/
    test_text_roi_detector.py  # 43 tests (패턴 분류, bbox 변환, 병합, detect)
    test_waveform_detector.py  # 22 tests (탐지, 프로젝션, 병합, 노이즈)
    test_dynamic_roi_detector.py # 22 tests (조합, 중복 제거, ID 할당, 에러)
```

---

## 6. 사용 방법

### 자동 ROI 탐지 모드

```bash
python -m src.main --video capture.mp4 --output ./results --auto-detect
```

### 기존 템플릿 모드 (변경 없음)

```bash
python -m src.main --video capture.mp4 --output ./results --template "모니터링 레이아웃 A"
```

### Python API

```python
from src.detection import DynamicROIDetector, DynamicROIConfig

detector = DynamicROIDetector(
    config=DynamicROIConfig(
        enable_text_detection=True,
        enable_waveform_detection=True,
    ),
    ocr_engine=ocr_engine,
)
rois = detector.detect(first_frame)
```
