# Video Detection API 레퍼런스

이 문서는 Video Detection 시스템의 종합적인 API 문서를 제공합니다. 이 시스템은 숫자 디스플레이, 텍스트, 차트의 변화를 감지하기 위한 산업용 비디오 모니터링 프레임워크입니다.

## 목차

- [config 모듈](#config-모듈)
- [core 모듈](#core-모듈)
- [detection 모듈](#detection-모듈)
- [ocr 모듈](#ocr-모듈)
- [preprocessing 모듈](#preprocessing-모듈)
- [storage 모듈](#storage-모듈)

---

## config 모듈

설정 모듈은 환경 변수, YAML 파일, 런타임 오버라이드를 지원하는 데이터클래스 기반의 타입 안전 설정 관리를 제공합니다.

### FrameSkipMode

```python
class FrameSkipMode(Enum)
```

비디오 처리 중 프레임 스킵 동작을 정의하는 열거형입니다.

**멤버:**

| 멤버 | 값 | 설명 |
|--------|-------|-------------|
| `FIXED` | `"fixed"` | 고정 간격으로 프레임 추출 |
| `ADAPTIVE` | `"adaptive"` | 감지된 변화에 따라 추출 속도 조정 |

**예제:**

```python
from src.config import FrameSkipMode

mode = FrameSkipMode.ADAPTIVE
print(mode.value)  # "adaptive"
```

---

### ROIConfig

```python
@dataclass(frozen=True)
class ROIConfig
```

관심 영역(ROI, Region of Interest)을 위한 불변 설정입니다. 좌표는 정규화된 값(0.0-1.0) 또는 픽셀 값으로 지정할 수 있습니다.

**속성:**

| 속성 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `name` | `str` | 필수 | ROI의 고유 식별자 |
| `x` | `float` | 필수 | 왼쪽 가장자리 X 좌표 |
| `y` | `float` | 필수 | 상단 가장자리 Y 좌표 |
| `width` | `float` | 필수 | ROI 너비 |
| `height` | `float` | 필수 | ROI 높이 |
| `normalized` | `bool` | `True` | `True`이면 좌표는 0.0-1.0 정규화된 값 |

**메서드:**

#### to_pixel_coords

```python
def to_pixel_coords(
    self,
    frame_width: int,
    frame_height: int
) -> tuple[int, int, int, int]
```

정규화된 좌표를 픽셀 좌표로 변환합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `frame_width` | `int` | 프레임 너비(픽셀) |
| `frame_height` | `int` | 프레임 높이(픽셀) |

**반환값:** `tuple[int, int, int, int]` - (x, y, width, height) 픽셀 단위

**예제:**

```python
from src.config import ROIConfig

# 프레임 중앙 50%를 차지하는 ROI 정의
roi = ROIConfig(
    name="display",
    x=0.25,
    y=0.25,
    width=0.5,
    height=0.5,
    normalized=True
)

# 1920x1080 프레임에 대한 픽셀 좌표로 변환
x, y, w, h = roi.to_pixel_coords(1920, 1080)
print(f"픽셀 좌표: ({x}, {y}, {w}, {h})")
# 출력: 픽셀 좌표: (480, 270, 960, 540)
```

---

### ProcessingConfig

```python
@dataclass
class ProcessingConfig
```

비디오 처리 매개변수 설정입니다.

**속성:**

| 속성 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `frame_skip_mode` | `FrameSkipMode` | `ADAPTIVE` | 프레임 추출 전략 |
| `default_interval_sec` | `float` | `1.0` | 기본 프레임 추출 간격(초) |
| `change_detection_interval_sec` | `float` | `0.17` | 변화 감지 시 간격(약 6fps) |
| `change_threshold` | `float` | `0.05` | 프레임 차이 임계값(0.0-1.0) |
| `batch_size` | `int` | `32` | 처리 배치당 프레임 수 |
| `max_workers` | `int` | `0` | 병렬 워커 수(0 = CPU 코어 자동 감지) |
| `resize_width` | `int` | `0` | 처리용 목표 너비(0 = 원본) |
| `resize_height` | `int` | `0` | 처리용 목표 높이(0 = 원본) |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `effective_max_workers` | `int` | 실제 워커 수(0을 CPU 수로 해석) |

**예제:**

```python
from src.config import ProcessingConfig, FrameSkipMode

config = ProcessingConfig(
    frame_skip_mode=FrameSkipMode.ADAPTIVE,
    default_interval_sec=0.5,
    change_threshold=0.03,
    batch_size=64
)

print(f"워커 수: {config.effective_max_workers}")
```

---

### StorageConfig

```python
@dataclass
class StorageConfig
```

분석 결과 저장을 위한 설정입니다.

**속성:**

| 속성 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `db_path` | `Path` | `data/results.db` | SQLite 데이터베이스 파일 경로 |
| `output_dir` | `Path` | `data/output` | 결과 출력 디렉토리 |
| `save_frames` | `bool` | `False` | 분석된 프레임 이미지 저장 여부 |
| `frame_format` | `str` | `"jpg"` | 이미지 형식(jpg, png, webp) |
| `frame_quality` | `int` | `85` | JPEG 품질(1-100) |

**메서드:**

#### ensure_directories

```python
def ensure_directories(self) -> None
```

필요한 디렉토리가 없으면 생성합니다.

**예제:**

```python
from src.config import StorageConfig
from pathlib import Path

storage = StorageConfig(
    db_path=Path("./data/analysis.db"),
    output_dir=Path("./output"),
    save_frames=True,
    frame_format="png"
)
storage.ensure_directories()
```

---

### Config

```python
@dataclass
class Config
```

모든 설정 섹션을 집계하는 루트 설정 객체입니다.

**속성:**

| 속성 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `video_path` | `Path \| None` | `None` | 입력 비디오 파일 경로 |
| `processing` | `ProcessingConfig` | 기본 인스턴스 | 처리 설정 |
| `storage` | `StorageConfig` | 기본 인스턴스 | 저장 설정 |
| `rois` | `list[ROIConfig]` | `[]` | 관심 영역 정의 목록 |
| `debug` | `bool` | `False` | 디버그 모드 활성화 |
| `log_level` | `str` | `"INFO"` | 로깅 레벨 |

**클래스 메서드:**

#### from_yaml

```python
@classmethod
def from_yaml(cls, config_path: Path | str) -> Config
```

YAML 파일에서 설정을 로드합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `config_path` | `Path \| str` | YAML 설정 파일 경로 |

**반환값:** `Config` - 로드된 설정 인스턴스

**예외:**

- `FileNotFoundError` - 설정 파일이 존재하지 않음
- `yaml.YAMLError` - 잘못된 YAML 구문

**예제:**

```python
from src.config import Config

config = Config.from_yaml("config/production.yaml")
```

#### from_env

```python
@classmethod
def from_env(cls) -> Config
```

환경 변수에서 설정을 로드합니다.

**환경 변수:**

| 변수 | 설명 |
|----------|-------------|
| `VIDEO_PATH` | 입력 비디오 파일 경로 |
| `DB_PATH` | 데이터베이스 파일 경로 |
| `OUTPUT_DIR` | 출력 디렉토리 |
| `FRAME_INTERVAL` | 기본 프레임 간격(초) |
| `DEBUG` | 디버그 모드 활성화(`true`/`false`) |
| `LOG_LEVEL` | 로깅 레벨 |

**반환값:** `Config` - 환경에서 로드된 설정

**예제:**

```python
import os
from src.config import Config

os.environ["VIDEO_PATH"] = "/path/to/video.mp4"
os.environ["DEBUG"] = "true"

config = Config.from_env()
```

#### with_overrides

```python
def with_overrides(self, **kwargs: Any) -> Config
```

지정된 값이 오버라이드된 새 Config를 생성합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `**kwargs` | `Any` | 오버라이드할 키-값 쌍(점 표기법 지원) |

**반환값:** `Config` - 오버라이드가 적용된 새 인스턴스

**예제:**

```python
from src.config import Config

base_config = Config.from_yaml("config.yaml")

# 점 표기법으로 중첩된 값 오버라이드
modified = base_config.with_overrides(
    debug=True,
    **{"processing.batch_size": 64}
)
```

---

## core 모듈

코어 모듈은 비디오 처리 및 프레임 분석 오케스트레이션을 제공합니다.

### VideoProcessor

```python
class VideoProcessor
```

제너레이터 패턴을 사용하는 메모리 효율적인 비디오 프레임 추출기입니다. 변화 감지에 기반한 적응형 프레임 스킵을 지원합니다.

**생성자:**

```python
def __init__(self, config: Config) -> None
```

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `config` | `Config` | `video_path`가 설정된 설정 |

**예외:**

- `ValueError` - `video_path`가 설정되지 않음
- `FileNotFoundError` - 비디오 파일이 존재하지 않음

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `metadata` | `VideoMetadata` | 비디오 메타데이터(지연 로드) |

**메서드:**

#### extract_frames

```python
def extract_frames(
    self,
    start_ms: float = 0,
    end_ms: float | None = None
) -> Generator[FrameData, None, None]
```

설정된 스킵 모드를 사용하여 비디오에서 프레임을 추출합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `start_ms` | `float` | `0` | 시작 위치(밀리초) |
| `end_ms` | `float \| None` | `None` | 종료 위치(None = 비디오 끝) |

**반환값(Yields):** `FrameData` - 메타데이터가 포함된 추출된 프레임

**예제:**

```python
from src.config import Config
from src.core import VideoProcessor
from pathlib import Path

config = Config(video_path=Path("video.mp4"))
processor = VideoProcessor(config)

for frame_data in processor.extract_frames():
    print(f"프레임 {frame_data.frame_number}: {frame_data.timestamp_str}")
    if frame_data.is_change_detected:
        print(f"  변화 감지됨 (점수: {frame_data.change_score:.3f})")
```

#### get_metadata

`metadata` 프로퍼티를 통해 비디오 메타데이터에 접근합니다.

**반환값:** `VideoMetadata` - 비디오 파일 메타데이터

#### get_progress

```python
def get_progress(self, current_frame: int) -> tuple[float, str]
```

처리 진행률을 계산합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `current_frame` | `int` | 현재 프레임 번호 |

**반환값:** `tuple[float, str]` - (진행률 0.0-1.0, "HH:MM:SS / HH:MM:SS" 문자열)

**예제:**

```python
progress, time_str = processor.get_progress(frame_data.frame_number)
print(f"진행률: {progress:.1%} ({time_str})")
```

---

### FrameData

```python
@dataclass
class FrameData
```

추출된 프레임 데이터와 메타데이터를 위한 컨테이너입니다.

**속성:**

| 속성 | 타입 | 설명 |
|-----------|------|-------------|
| `frame` | `NDArray[np.uint8]` | BGR 이미지 배열 |
| `frame_number` | `int` | 비디오 내 프레임 인덱스 |
| `timestamp_ms` | `float` | 위치(밀리초) |
| `is_change_detected` | `bool` | 이전 프레임 대비 변화 감지 여부 |
| `change_score` | `float` | 변화의 크기(0.0-1.0) |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `timestamp` | `timedelta` | timedelta로서의 타임스탬프 |
| `timestamp_str` | `str` | 포맷된 "HH:MM:SS.mmm" |
| `shape` | `tuple[int, int, int]` | 프레임 치수(H, W, C) |
| `height` | `int` | 프레임 높이(픽셀) |
| `width` | `int` | 프레임 너비(픽셀) |

---

### VideoMetadata

```python
@dataclass
class VideoMetadata
```

비디오 파일 메타데이터입니다.

**속성:**

| 속성 | 타입 | 설명 |
|-----------|------|-------------|
| `path` | `Path` | 비디오 파일 경로 |
| `width` | `int` | 프레임 너비 |
| `height` | `int` | 프레임 높이 |
| `fps` | `float` | 초당 프레임 수 |
| `total_frames` | `int` | 총 프레임 수 |
| `duration_ms` | `float` | 재생 시간(밀리초) |
| `codec` | `str` | 비디오 코덱 FourCC |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `duration` | `timedelta` | timedelta로서의 재생 시간 |
| `duration_str` | `str` | 포맷된 "HH:MM:SS" |

---

### FrameAnalyzer

```python
class FrameAnalyzer
```

감지, OCR, 저장 모듈을 결합하는 프레임 분석 오케스트레이터입니다.

**생성자:**

```python
def __init__(self, config: Config) -> None
```

**메서드:**

#### analyze_video

```python
def analyze_video(
    self,
    start_ms: float = 0,
    end_ms: float | None = None
) -> Generator[AnalysisResult, None, None]
```

비디오 프레임을 순차적으로 분석합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `start_ms` | `float` | `0` | 시작 위치(밀리초) |
| `end_ms` | `float \| None` | `None` | 종료 위치(None = 전체 비디오) |

**반환값(Yields):** `AnalysisResult` - 각 프레임에 대한 분석 결과

**예제:**

```python
from src.config import Config
from src.core import FrameAnalyzer
from pathlib import Path

config = Config(video_path=Path("video.mp4"))
analyzer = FrameAnalyzer(config)

# 분석 모듈 설정
analyzer.set_detector(my_detector)
analyzer.set_ocr_engine(my_ocr)

for result in analyzer.analyze_video():
    if result.success:
        print(f"프레임 {result.frame_data.frame_number}: "
              f"{result.total_detections}개 감지")
```

#### analyze_video_parallel

```python
def analyze_video_parallel(
    self,
    start_ms: float = 0,
    end_ms: float | None = None
) -> Generator[AnalysisResult, None, None]
```

병렬 처리를 사용하여 프레임을 분석합니다. 결과는 순서가 보장되지 않을 수 있습니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `start_ms` | `float` | `0` | 시작 위치 |
| `end_ms` | `float \| None` | `None` | 종료 위치 |

**반환값(Yields):** `AnalysisResult` - 결과(순서 보장 안 됨)

**예제:**

```python
results = list(analyzer.analyze_video_parallel())
# 순서가 중요한 경우 프레임 번호로 정렬
results.sort(key=lambda r: r.frame_data.frame_number)
```

---

### AnalysisResult

```python
@dataclass
class AnalysisResult
```

프레임 분석의 종합 결과입니다.

**속성:**

| 속성 | 타입 | 설명 |
|-----------|------|-------------|
| `frame_data` | `FrameData` | 소스 프레임 정보 |
| `detections` | `list[DetectionResult]` | ROI별 감지 결과 |
| `ocr_results` | `list[OCRResult]` | ROI별 OCR 결과 |
| `total_time_ms` | `float` | 분석 소요 시간 |
| `error` | `str \| None` | 실패 시 오류 메시지 |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `success` | `bool` | 오류가 없으면 True |
| `total_detections` | `int` | 모든 감지된 객체의 합계 |
| `has_text` | `bool` | 텍스트가 인식되었으면 True |

---

## detection 모듈

감지 모듈은 ROI 감지, 변화 감지, 차트 감지 기능을 제공합니다.

### ROIDetector

```python
class ROIDetector
```

윤곽 분석, OCR, 엣지 감지를 사용하는 자동 관심 영역 감지기입니다.

**생성자:**

```python
def __init__(
    self,
    config: ROIConfig | None = None,
    ocr_provider: OCRProvider | None = None
) -> None
```

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `config` | `ROIConfig \| None` | `None` | 감지 설정 |
| `ocr_provider` | `OCRProvider \| None` | `None` | 텍스트 기반 감지용 OCR 제공자 |

**메서드:**

#### detect_from_frame

```python
def detect_from_frame(
    self,
    frame: NDArray[np.uint8],
    use_ocr: bool = True
) -> list[ROI]
```

단일 프레임에서 ROI를 감지합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `frame` | `NDArray[np.uint8]` | 필수 | 입력 프레임(BGR 또는 그레이스케일) |
| `use_ocr` | `bool` | `True` | OCR 기반 감지 활성화 |

**반환값:** `list[ROI]` - 감지된 영역

**예제:**

```python
from src.detection import ROIDetector
import cv2

detector = ROIDetector()
frame = cv2.imread("display.jpg")

rois = detector.detect_from_frame(frame)
for roi in rois:
    print(f"ROI {roi.id}: {roi.roi_type.value} at {roi.bbox}")
```

#### detect_from_multiple_frames

```python
def detect_from_multiple_frames(
    self,
    frames: list[NDArray[np.uint8]],
    consensus_threshold: float = 0.5
) -> list[ROI]
```

여러 프레임에서 일관되게 나타나는 안정적인 ROI를 감지합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `frames` | `list[NDArray[np.uint8]]` | 필수 | 프레임 목록 |
| `consensus_threshold` | `float` | `0.5` | 최소 출현 비율 |

**반환값:** `list[ROI]` - 합의 임계값을 충족하는 안정적인 ROI

**예제:**

```python
# 비디오에서 샘플 프레임 추출
sample_frames = [processor.extract_frame_at(t * 1000).frame
                 for t in [0, 30, 60, 90, 120]]

# 안정적인 ROI 찾기
stable_rois = detector.detect_from_multiple_frames(
    sample_frames,
    consensus_threshold=0.6
)
print(f"{len(stable_rois)}개의 안정적인 ROI 발견")
```

---

### ChangeDetector

```python
class ChangeDetector
```

SSIM 비교와 OCR 검증을 결합한 하이브리드 변화 감지기입니다.

**생성자:**

```python
def __init__(
    self,
    config: ChangeDetectorConfig | None = None,
    ocr_engine: OCREngine | None = None
) -> None
```

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `config` | `ChangeDetectorConfig \| None` | `None` | 감지 설정 |
| `ocr_engine` | `OCREngine \| None` | `None` | 검증용 OCR 엔진 |

**메서드:**

#### detect_changes

```python
def detect_changes(
    self,
    current_frame: NDArray[np.uint8],
    rois: list[ROI],
    timestamp: float | None = None
) -> list[ChangeEvent]
```

현재 프레임과 저장된 이전 상태 간의 ROI 변화를 감지합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `current_frame` | `NDArray[np.uint8]` | 필수 | 현재 비디오 프레임 |
| `rois` | `list[ROI]` | 필수 | 모니터링할 ROI |
| `timestamp` | `float \| None` | `None` | 프레임 타임스탬프(None이면 자동) |

**반환값:** `list[ChangeEvent]` - 감지된 변화 이벤트

**예제:**

```python
from src.detection import ChangeDetector, ChangeDetectorConfig

config = ChangeDetectorConfig(
    ssim_threshold=0.95,
    debounce_time_ms=100
)
detector = ChangeDetector(config)

for frame_data in processor.extract_frames():
    events = detector.detect_changes(
        frame_data.frame,
        rois,
        timestamp=frame_data.timestamp_ms / 1000
    )
    for event in events:
        if event.is_significant:
            print(f"{event.roi_id}에서 변화: "
                  f"{event.previous_value} -> {event.current_value}")
```

#### register_callback

```python
def register_callback(
    self,
    callback: Callable[[ChangeEvent], None]
) -> None
```

변화 이벤트에 대한 콜백 함수를 등록합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `callback` | `Callable[[ChangeEvent], None]` | 변화 감지 시 호출할 함수 |

**예제:**

```python
def on_change(event: ChangeEvent):
    if event.change_type == ChangeType.NUMERIC_INCREASE:
        print(f"값이 {event.numeric_delta}만큼 증가")

detector.register_callback(on_change)
```

---

### ChartDetector

```python
class ChartDetector
```

엣지 감지와 허프 변환을 사용하는 선형 차트 감지기입니다.

**생성자:**

```python
def __init__(self, config: ChartDetectorConfig | None = None) -> None
```

**메서드:**

#### analyze

```python
def analyze(self, image: NDArray[np.uint8]) -> ChartDetectionResult
```

상세 차트 분석을 수행합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `image` | `NDArray[np.uint8]` | 입력 이미지(BGR 또는 그레이스케일) |

**반환값:** `ChartDetectionResult` - 상세 분석 결과

**예제:**

```python
from src.detection import ChartDetector

detector = ChartDetector()
result = detector.analyze(roi_image)

if result.is_chart:
    print(f"차트 유형: {result.chart_type.value}")
    print(f"신뢰도: {result.confidence:.2f}")
    print(f"데이터 라인 수: {result.data_lines_count}")
```

#### detect_chart

```python
def detect_chart(self, image: NDArray[np.uint8]) -> bool
```

차트 존재 여부에 대한 간단한 불리언 검사입니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `image` | `NDArray[np.uint8]` | 입력 이미지 |

**반환값:** `bool` - 차트가 감지되면 True

---

## ocr 모듈

OCR 모듈은 산업용 디스플레이 인식에 최적화된 PaddleOCR 통합을 제공합니다.

### OCREngine

```python
class OCREngine
```

산업용 디스플레이 숫자 인식에 최적화된 PaddleOCR 래퍼입니다.

**생성자:**

```python
def __init__(self, config: OCRConfig | None = None) -> None
```

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `config` | `OCRConfig \| None` | `None` | OCR 설정 |

**메서드:**

#### recognize

```python
def recognize(
    self,
    image: NDArray[np.uint8] | str | Path
) -> tuple[OCRResult, ...]
```

단일 이미지에서 텍스트를 인식합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `image` | `NDArray[np.uint8] \| str \| Path` | 이미지 배열 또는 파일 경로 |

**반환값:** `tuple[OCRResult, ...]` - 인식 결과

**예외:**

- `RuntimeError` - OCR 초기화 또는 인식 실패
- `ValueError` - 잘못된 이미지 형식

**예제:**

```python
from src.ocr import OCREngine, OCRConfig

config = OCRConfig(
    numeric_only=True,
    confidence_threshold=0.8
)
engine = OCREngine(config)

results = engine.recognize(frame)
for r in results:
    print(f"텍스트: {r.text}, 신뢰도: {r.confidence:.2f}")
    if r.numeric_value is not None:
        print(f"  숫자 값: {r.numeric_value}")
```

#### recognize_batch

```python
def recognize_batch(
    self,
    images: Sequence[NDArray[np.uint8] | str | Path],
    chunk_size: int = 10
) -> OCRBatchResult
```

메모리 효율적인 배치 처리로 여러 이미지에서 텍스트를 인식합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `images` | `Sequence[...]` | 필수 | 이미지 시퀀스 |
| `chunk_size` | `int` | `10` | 배치당 이미지 수 |

**반환값:** `OCRBatchResult` - 배치 처리 결과

**예제:**

```python
frames = [frame_data.frame for frame_data in processor.extract_frames()]
batch_result = engine.recognize_batch(frames, chunk_size=20)

print(f"성공률: {batch_result.success_rate:.1%}")
for image_results in batch_result.results:
    for r in image_results:
        print(r.text)
```

#### warmup

```python
def warmup(self, dummy_size: tuple[int, int] = (100, 100)) -> None
```

첫 추론 지연을 줄이기 위해 OCR 모델을 미리 로드합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `dummy_size` | `tuple[int, int]` | `(100, 100)` | 더미 이미지 크기 |

**예제:**

```python
engine = OCREngine(config)
engine.warmup()  # 처리 전 모델 초기화
```

---

### OCRConfig

```python
@dataclass(frozen=True, slots=True)
class OCRConfig
```

OCR 엔진의 불변 설정입니다.

**주요 속성:**

| 속성 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `use_gpu` | `bool` | `False` | GPU 가속 활성화 |
| `gpu_mem` | `int` | `500` | GPU 메모리 제한(MB) |
| `language` | `OCRLanguage` | `ENGLISH` | 인식 언어 |
| `numeric_only` | `bool` | `True` | 숫자만 필터링 |
| `confidence_threshold` | `float` | `0.7` | 최소 신뢰도 |
| `use_angle_cls` | `bool` | `True` | 텍스트 각도 감지 활성화 |
| `cpu_threads` | `int` | `4` | CPU 스레드 수 |

---

### OCRResult

```python
@dataclass(frozen=True, slots=True)
class OCRResult
```

단일 OCR 인식 결과입니다.

**속성:**

| 속성 | 타입 | 설명 |
|-----------|------|-------------|
| `text` | `str` | 인식된 텍스트(numeric_only인 경우 필터링됨) |
| `confidence` | `float` | 인식 신뢰도(0.0-1.0) |
| `bounding_box` | `BoundingBox` | 텍스트 영역 위치 |
| `raw_text` | `str` | 필터링 전 원본 텍스트 |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `is_valid` | `bool` | 텍스트가 비어있지 않으면 True |
| `numeric_value` | `float \| None` | 파싱된 숫자 값 |

---

### OCRBatchResult

```python
@dataclass(frozen=True, slots=True)
class OCRBatchResult
```

배치 OCR 처리 결과입니다.

**속성:**

| 속성 | 타입 | 설명 |
|-----------|------|-------------|
| `results` | `tuple[tuple[OCRResult, ...], ...]` | 이미지별 결과 |
| `total_images` | `int` | 처리된 총 이미지 수 |
| `successful_count` | `int` | 유효한 결과가 있는 이미지 수 |
| `failed_indices` | `tuple[int, ...]` | 실패한 이미지의 인덱스 |

**프로퍼티:**

| 프로퍼티 | 타입 | 설명 |
|----------|------|-------------|
| `success_rate` | `float` | 성공적인 인식 비율 |

---

## preprocessing 모듈

전처리 모듈은 OCR에 최적화된 이미지 향상 파이프라인을 제공합니다.

### ImageEnhancer

```python
class ImageEnhancer
```

산업용 디스플레이 향상을 위한 설정 가능한 이미지 전처리 파이프라인입니다.

**생성자:**

```python
def __init__(self, config: PreprocessingConfig | None = None) -> None
```

**메서드:**

#### enhance

```python
def enhance(self, image: NDArray[np.uint8]) -> ProcessingResult
```

전체 전처리 파이프라인을 적용합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `image` | `NDArray[np.uint8]` | 입력 이미지 |

**반환값:** `ProcessingResult` - 메타데이터가 포함된 향상된 이미지

**예외:**

- `ValueError` - 비어있거나 None인 이미지
- `RuntimeError` - 처리 단계 실패

**예제:**

```python
from src.preprocessing import ImageEnhancer, PreprocessingConfig

config = PreprocessingConfig(
    enable_clahe=True,
    clahe_clip_limit=3.0,
    enable_binarization=True
)
enhancer = ImageEnhancer(config)

result = enhancer.enhance(frame)
print(f"적용된 단계: {[s.name for s in result.applied_steps]}")
print(f"처리 시간: {result.processing_time_ms:.2f}ms")

# 향상된 이미지 사용
enhanced_frame = result.image
```

#### enhance_batch

```python
def enhance_batch(
    self,
    images: Sequence[NDArray[np.uint8]]
) -> list[ProcessingResult]
```

여러 이미지에 전처리를 적용합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `images` | `Sequence[NDArray[np.uint8]]` | 입력 이미지 |

**반환값:** `list[ProcessingResult]` - 각 이미지에 대한 결과

**예제:**

```python
roi_images = [roi.extract_region(frame) for roi in detected_rois]
results = enhancer.enhance_batch(roi_images)
```

---

### 팩토리 함수

#### create_industrial_display_config

```python
def create_industrial_display_config() -> PreprocessingConfig
```

산업용 7세그먼트 및 LCD 디스플레이에 최적화된 설정을 생성합니다.

**반환값:** `PreprocessingConfig` - 최적화된 설정

**예제:**

```python
from src.preprocessing import ImageEnhancer, create_industrial_display_config

config = create_industrial_display_config()
enhancer = ImageEnhancer(config)
```

---

## storage 모듈

저장 모듈은 분석 결과를 위한 데이터베이스 관리 및 파일 저장을 제공합니다.

### DatabaseManager

```python
class DatabaseManager
```

세션, ROI, 변화 이벤트를 위한 스레드 안전 SQLite 데이터베이스 관리자입니다.

**생성자:**

```python
def __init__(
    self,
    db_path: str | Path,
    *,
    check_same_thread: bool = False,
    timeout: float = 30.0
) -> None
```

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `db_path` | `str \| Path` | 필수 | 데이터베이스 파일 경로 |
| `check_same_thread` | `bool` | `False` | SQLite 스레드 검사 |
| `timeout` | `float` | `30.0` | 연결 타임아웃 |

**메서드:**

#### create_session

```python
def create_session(self, data: SessionCreate) -> Session
```

새 분석 세션을 생성합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `data` | `SessionCreate` | 세션 생성 데이터 |

**반환값:** `Session` - 생성된 세션

**예제:**

```python
from src.storage import DatabaseManager, SessionCreate

with DatabaseManager("data/results.db") as db:
    session = db.create_session(SessionCreate(
        name="생산라인 A",
        source_path="/videos/line_a.mp4"
    ))
    print(f"세션 {session.id} 생성됨")
```

#### create_change_event

```python
def create_change_event(self, data: ChangeEventCreate) -> ChangeEvent
```

변화 감지 이벤트를 기록합니다.

**매개변수:**

| 매개변수 | 타입 | 설명 |
|-----------|------|-------------|
| `data` | `ChangeEventCreate` | 이벤트 생성 데이터 |

**반환값:** `ChangeEvent` - 생성된 이벤트 레코드

**예제:**

```python
from src.storage import ChangeEventCreate

event = db.create_change_event(ChangeEventCreate(
    roi_id=1,
    session_id=session.id,
    previous_value="123.4",
    current_value="125.7",
    confidence=0.95
))
```

---

### CaptureManager

```python
class CaptureManager
```

압축 및 비동기 지원이 포함된 이미지 파일 저장 관리자입니다.

**생성자:**

```python
def __init__(
    self,
    config: CaptureConfig,
    image_saver: ImageSaver | None = None
) -> None
```

**메서드:**

#### save_capture

```python
def save_capture(
    self,
    image: Any,
    session_id: int,
    roi_name: str,
    *,
    format: ImageFormat | None = None,
    quality: int | None = None,
    timestamp: datetime | None = None,
    suffix: str | None = None
) -> CaptureResult
```

캡처된 이미지를 파일로 저장합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `image` | `Any` | 필수 | 이미지(numpy 배열 또는 PIL) |
| `session_id` | `int` | 필수 | 세션 식별자 |
| `roi_name` | `str` | 필수 | 파일명용 ROI 이름 |
| `format` | `ImageFormat \| None` | 설정 기본값 | 이미지 형식 |
| `quality` | `int \| None` | 설정 기본값 | 압축 품질 |
| `timestamp` | `datetime \| None` | 현재 시간 | 캡처 타임스탬프 |
| `suffix` | `str \| None` | `None` | 파일명 접미사 |

**반환값:** `CaptureResult` - 파일 경로가 포함된 작업 결과

**예제:**

```python
from src.storage import CaptureManager, CaptureConfig, ImageFormat
from pathlib import Path

config = CaptureConfig(
    base_directory=Path("./captures"),
    default_format=ImageFormat.JPEG,
    compression_quality=90
)

with CaptureManager(config) as manager:
    result = manager.save_capture(
        frame,
        session_id=1,
        roi_name="display_01"
    )
    if result.success:
        print(f"저장됨: {result.file_path}")
```

#### cleanup_old_captures

```python
def cleanup_old_captures(
    self,
    days: int,
    session_id: int | None = None,
    dry_run: bool = False
) -> tuple[int, int]
```

지정된 일수보다 오래된 캡처를 삭제합니다.

**매개변수:**

| 매개변수 | 타입 | 기본값 | 설명 |
|-----------|------|---------|-------------|
| `days` | `int` | 필수 | 기간 임계값(일) |
| `session_id` | `int \| None` | `None` | 세션별 필터링 |
| `dry_run` | `bool` | `False` | 삭제하지 않고 카운트만 수행 |

**반환값:** `tuple[int, int]` - (삭제된 파일 수, 해제된 바이트)

**예제:**

```python
# 정리 미리보기
count, size = manager.cleanup_old_captures(30, dry_run=True)
print(f"{count}개 파일 삭제 예정 ({size / 1024 / 1024:.1f} MB)")

# 정리 실행
deleted, freed = manager.cleanup_old_captures(30)
print(f"{deleted}개 파일 정리됨")
```

---

## 전체 통합 예제

```python
from pathlib import Path
from src.config import Config, ROIConfig
from src.core import VideoProcessor, FrameAnalyzer
from src.detection import ROIDetector, ChangeDetector, ChangeDetectorConfig
from src.ocr import OCREngine, OCRConfig
from src.preprocessing import ImageEnhancer, create_industrial_display_config
from src.storage import DatabaseManager, SessionCreate, CaptureManager, CaptureConfig

# 1. 설정 로드
config = Config(
    video_path=Path("monitoring_video.mp4"),
    rois=[
        ROIConfig(name="pressure", x=0.1, y=0.2, width=0.15, height=0.1),
        ROIConfig(name="temperature", x=0.3, y=0.2, width=0.15, height=0.1),
    ]
)

# 2. 컴포넌트 초기화
ocr_config = OCRConfig(numeric_only=True, confidence_threshold=0.8)
ocr_engine = OCREngine(ocr_config)
ocr_engine.warmup()

enhancer = ImageEnhancer(create_industrial_display_config())

change_config = ChangeDetectorConfig(ssim_threshold=0.95)
change_detector = ChangeDetector(change_config, ocr_engine)

# 3. 저장소 설정
db = DatabaseManager("data/results.db")
db.connect()

capture_config = CaptureConfig(base_directory=Path("./captures"))
capture_manager = CaptureManager(capture_config)

# 4. 분석 세션 생성
session = db.create_session(SessionCreate(
    name="생산 모니터링",
    source_path=str(config.video_path)
))

# 5. 비디오 처리
processor = VideoProcessor(config)

def on_change(event):
    print(f"[{event.roi_id}] {event.previous_value} -> {event.current_value}")

change_detector.register_callback(on_change)

for frame_data in processor.extract_frames():
    # OCR을 위한 프레임 향상
    enhanced = enhancer.enhance(frame_data.frame)

    # 변화 감지
    events = change_detector.detect_changes(
        enhanced.image,
        config.rois,
        frame_data.timestamp_ms / 1000
    )

    # 유의미한 변화 저장
    for event in events:
        if event.is_significant:
            # 캡처 저장
            capture_manager.save_capture(
                frame_data.frame,
                session.id,
                event.roi_id
            )

# 6. 정리
db.close()
capture_manager.close()
```

---

## 버전 정보

- **API 버전:** 1.0.0
- **Python 요구사항:** >= 3.10
- **의존성:** OpenCV, NumPy, PaddleOCR, scikit-image, PyYAML
