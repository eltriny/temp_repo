# Troubleshooting Guide

video_detection 프로젝트 사용 중 발생할 수 있는 문제들과 해결 방법을 안내합니다.

## Table of Contents

1. [설치 문제](#1-설치-문제)
2. [런타임 에러](#2-런타임-에러)
3. [성능 문제](#3-성능-문제)
4. [OCR 인식률 문제](#4-ocr-인식률-문제)
5. [변화 감지 문제](#5-변화-감지-문제)
6. [로그 분석](#6-로그-분석)
7. [FAQ](#7-faq)

---

## 1. 설치 문제

### 1.1 PaddleOCR 설치 오류

#### 증상
```
ERROR: Could not find a version that satisfies the requirement paddlepaddle
ModuleNotFoundError: No module named 'paddle'
```

#### 원인
- paddlepaddle과 paddleocr 버전 불일치
- Python 버전 호환성 문제
- CUDA 버전과 paddlepaddle-gpu 불일치

#### 해결 방법

**CPU 버전 설치 (권장 시작점)**
```bash
# 기존 설치 제거
pip uninstall paddlepaddle paddlepaddle-gpu paddleocr -y

# CPU 버전 순차 설치
pip install paddlepaddle==2.5.2
pip install paddleocr==2.7.3
```

**GPU 버전 설치 (CUDA 11.8 기준)**
```bash
# CUDA 버전 확인
nvcc --version

# GPU 버전 설치
pip install paddlepaddle-gpu==2.5.2.post118 -f https://www.paddlepaddle.org.cn/whl/linux/mkl/avx/stable.html
pip install paddleocr==2.7.3
```

**CUDA 버전별 paddlepaddle-gpu 설치**

| CUDA 버전 | 설치 명령 |
|-----------|-----------|
| CUDA 11.2 | `pip install paddlepaddle-gpu==2.5.2.post112` |
| CUDA 11.6 | `pip install paddlepaddle-gpu==2.5.2.post116` |
| CUDA 11.7 | `pip install paddlepaddle-gpu==2.5.2.post117` |
| CUDA 11.8 | `pip install paddlepaddle-gpu==2.5.2.post118` |
| CUDA 12.0 | `pip install paddlepaddle-gpu==2.5.2.post120` |

**설치 확인**
```python
import paddle
print(paddle.__version__)
print(paddle.device.is_compiled_with_cuda())

from paddleocr import PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')
print("PaddleOCR 설치 성공")
```

---

### 1.2 의존성 충돌

#### 증상
```
ERROR: pip's dependency resolver does not support...
numpy.core.multiarray failed to import
AttributeError: module 'cv2' has no attribute 'xxx'
```

#### 원인
- numpy 버전이 너무 높거나 낮음
- opencv-python과 opencv-contrib-python 충돌
- scikit-image 호환성 문제

#### 해결 방법

**깨끗한 환경에서 재설치**
```bash
# 가상환경 생성
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# 충돌 패키지 제거
pip uninstall numpy opencv-python opencv-contrib-python scikit-image -y

# 호환 버전 순차 설치
pip install numpy==1.24.3
pip install opencv-python==4.8.1.78
pip install scikit-image==0.21.0
pip install Pillow==10.1.0
pip install PyYAML==6.0.1
pip install paddlepaddle==2.5.2
pip install paddleocr==2.7.3
```

**버전 호환성 표**

| 패키지 | 최소 버전 | 권장 버전 | 최대 버전 |
|--------|-----------|-----------|-----------|
| Python | 3.10 | 3.11 | 3.12 |
| numpy | 1.24.0 | 1.24.3 | 1.26.x |
| opencv-python | 4.8.0 | 4.8.1 | 4.9.x |
| scikit-image | 0.21.0 | 0.21.0 | 0.22.x |
| paddlepaddle | 2.5.0 | 2.5.2 | 2.6.x |
| paddleocr | 2.7.0 | 2.7.3 | 2.8.x |

---

## 2. 런타임 에러

### 2.1 비디오 열기 실패

#### 증상
```
RuntimeError: 비디오를 열 수 없습니다: /path/to/video.mp4
cv2.error: OpenCV(4.8.1) error: (-215:Assertion failed)
```

#### 원인
- 비디오 코덱 미지원
- 파일 손상 또는 불완전한 다운로드
- 파일 권한 문제
- ffmpeg 미설치

#### 해결 방법

**1. ffmpeg 설치 확인 및 설치**
```bash
# Linux (Ubuntu/Debian)
sudo apt update
sudo apt install ffmpeg libavcodec-dev libavformat-dev libswscale-dev

# macOS
brew install ffmpeg

# Windows - https://ffmpeg.org/download.html 에서 다운로드 후 PATH 추가
```

**2. 비디오 파일 검증**
```bash
# ffprobe로 비디오 정보 확인
ffprobe -v error -show_format -show_streams input.mp4

# 손상된 비디오 복구 시도
ffmpeg -i input.mp4 -c copy output_fixed.mp4
```

**3. 코덱 변환**
```bash
# H.264 코덱으로 변환 (가장 호환성 높음)
ffmpeg -i input.mp4 -c:v libx264 -preset medium -crf 23 output.mp4
```

**4. 파일 권한 확인**
```bash
# 읽기 권한 확인
ls -la /path/to/video.mp4

# 권한 부여
chmod 644 /path/to/video.mp4
```

**5. Python에서 비디오 테스트**
```python
import cv2

video_path = "/path/to/video.mp4"
cap = cv2.VideoCapture(video_path)

if cap.isOpened():
    print(f"Width: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}")
    print(f"Height: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}")
    print(f"FPS: {cap.get(cv2.CAP_PROP_FPS)}")
    print(f"Frames: {cap.get(cv2.CAP_PROP_FRAME_COUNT)}")
    ret, frame = cap.read()
    print(f"First frame read: {ret}")
    cap.release()
else:
    print("비디오 열기 실패")
```

---

### 2.2 OCR 초기화 실패

#### 증상
```
RuntimeError: Failed to initialize PaddleOCR: ...
[ERROR] Download model failed...
W0101 00:00:00.000000 12345 gpu_resources.cc:119] GPU memory is not enough
```

#### 원인
- OCR 모델 다운로드 실패 (네트워크 문제)
- GPU 메모리 부족
- 캐시 디렉토리 권한 문제

#### 해결 방법

**1. 모델 수동 다운로드**
```bash
# 모델 저장 경로 확인
python -c "from paddleocr import PaddleOCR; print(PaddleOCR.__doc__)"

# 기본 모델 저장 경로: ~/.paddleocr/

# 수동 다운로드 (영어 모델)
mkdir -p ~/.paddleocr/whl/det/en/
mkdir -p ~/.paddleocr/whl/rec/en/
mkdir -p ~/.paddleocr/whl/cls/

# PaddleOCR GitHub에서 모델 다운로드
# https://github.com/PaddlePaddle/PaddleOCR/blob/release/2.7/doc/doc_en/models_list_en.md
```

**2. GPU 메모리 부족 해결**
```python
from src.ocr import OCREngine, OCRConfig

# GPU 메모리 제한 설정
config = OCRConfig(
    use_gpu=True,
    gpu_mem=300,  # 기본 500에서 300으로 낮춤
)
engine = OCREngine(config)

# 또는 CPU 모드 사용
config = OCRConfig(use_gpu=False)
```

**3. 캐시 디렉토리 권한**
```bash
# 캐시 디렉토리 권한 확인 및 수정
chmod -R 755 ~/.paddleocr/

# 또는 캐시 디렉토리 삭제 후 재시도
rm -rf ~/.paddleocr/
```

**4. 프록시/방화벽 환경**
```bash
# 환경변수로 프록시 설정
export http_proxy=http://proxy.example.com:8080
export https_proxy=http://proxy.example.com:8080

# 또는 오프라인 모델 사용 설정
```

---

### 2.3 메모리 부족

#### 증상
```
MemoryError: Unable to allocate array...
Killed (out of memory)
Process terminated by OOM killer
```

#### 원인
- 대용량/고해상도 비디오 처리
- 배치 크기가 너무 큼
- 메모리 누수

#### 해결 방법

**1. 프레임 리사이즈 설정**
```yaml
# config.yaml
processing:
  resize_width: 1280   # 4K 비디오를 HD로 다운스케일
  resize_height: 720
```

```python
from src.config import Config, ProcessingConfig

config = Config(
    processing=ProcessingConfig(
        resize_width=1280,
        resize_height=720,
    )
)
```

**2. 배치 크기 조정**
```yaml
# config.yaml
processing:
  batch_size: 16  # 기본 32에서 16으로 감소
```

**3. 프레임 추출 간격 증가**
```yaml
# config.yaml
processing:
  default_interval_sec: 2.0  # 기본 1.0에서 2.0으로 증가
```

**4. 메모리 모니터링**
```python
import psutil
import os

def check_memory():
    process = psutil.Process(os.getpid())
    mem_mb = process.memory_info().rss / 1024 / 1024
    print(f"현재 메모리 사용량: {mem_mb:.1f} MB")
    return mem_mb

# 처리 중 주기적으로 확인
for frame_data in processor.extract_frames():
    if frame_data.frame_number % 100 == 0:
        check_memory()
```

**5. Generator 패턴 활용**
```python
# 메모리 효율적인 처리 (이미 기본 동작)
for frame_data in processor.extract_frames():
    # 프레임 처리
    result = process_frame(frame_data)
    # 명시적 메모리 해제 (필요 시)
    del frame_data.frame
```

---

## 3. 성능 문제

### 3.1 처리 속도 느림

#### 증상
- 실시간보다 처리 속도가 현저히 느림
- CPU 사용률이 100%에 가깝게 유지
- GPU가 거의 사용되지 않음

#### 원인
- SSIM 계산의 높은 연산 비용
- GPU 가속 미사용
- 비효율적인 프레임 추출 간격

#### 해결 방법

**1. SSIM 계산 최적화**
```yaml
# config.yaml에서 change_detector 설정
# downscale_factor를 낮춰 SSIM 계산 이미지 크기 축소
```

```python
from src.detection import ChangeDetector, ChangeDetectorConfig

config = ChangeDetectorConfig(
    downscale_factor=0.5,  # 원본의 50% 크기로 SSIM 계산
    use_grayscale_ssim=True,  # 그레이스케일로 계산 (더 빠름)
    ssim_window_size=5,  # 기본 7에서 5로 감소
)
detector = ChangeDetector(config)
```

**2. GPU 가속 활성화**
```python
from src.ocr import OCREngine, OCRConfig

config = OCRConfig(
    use_gpu=True,
    gpu_mem=500,
    enable_mkldnn=True,  # CPU에서도 최적화
    cpu_threads=4,
)
engine = OCREngine(config)
```

**3. 프레임 추출 간격 조정**
```yaml
# config.yaml
processing:
  frame_skip_mode: fixed  # adaptive 대신 fixed 사용
  default_interval_sec: 2.0  # 간격 증가
```

**4. 병렬 처리 활성화**
```yaml
# config.yaml
processing:
  max_workers: 4  # 0(자동)이 아닌 명시적 설정
  batch_size: 32
```

**5. 프로파일링으로 병목 확인**
```python
import cProfile
import pstats

profiler = cProfile.Profile()
profiler.enable()

# 처리 코드 실행
for frame_data in processor.extract_frames():
    pass

profiler.disable()
stats = pstats.Stats(profiler)
stats.sort_stats('cumulative')
stats.print_stats(20)  # 상위 20개 함수
```

---

### 3.2 GPU 활용률 낮음

#### 증상
- `nvidia-smi`에서 GPU 사용률이 10% 미만
- GPU 메모리는 할당되지만 연산이 적음
- CPU 사용률이 여전히 높음

#### 원인
- CUDA 드라이버/라이브러리 버전 불일치
- cuDNN 미설치 또는 버전 문제
- 배치 크기가 너무 작음

#### 해결 방법

**1. CUDA 환경 확인**
```bash
# CUDA 버전 확인
nvcc --version

# 드라이버 버전 확인
nvidia-smi

# cuDNN 버전 확인
cat /usr/local/cuda/include/cudnn_version.h | grep CUDNN_MAJOR -A 2
```

**2. PaddlePaddle GPU 지원 확인**
```python
import paddle

print(f"PaddlePaddle version: {paddle.__version__}")
print(f"CUDA compiled: {paddle.device.is_compiled_with_cuda()}")
print(f"GPU available: {paddle.device.cuda.device_count()}")

# GPU 테스트
if paddle.device.is_compiled_with_cuda():
    paddle.device.set_device('gpu:0')
    x = paddle.randn([1000, 1000])
    y = paddle.matmul(x, x)
    print("GPU 연산 성공")
```

**3. gpu_mem 파라미터 조정**
```python
from src.ocr import OCREngine, OCRConfig

# GPU 메모리 할당 증가
config = OCRConfig(
    use_gpu=True,
    gpu_mem=1000,  # 기본 500에서 1000으로 증가 (1GB)
    rec_batch_num=16,  # 인식 배치 크기 증가
)
```

**4. cuDNN 설치/업데이트**
```bash
# Ubuntu/Debian
sudo apt install libcudnn8 libcudnn8-dev

# 또는 NVIDIA 공식 사이트에서 다운로드
# https://developer.nvidia.com/cudnn
```

**5. 환경변수 설정**
```bash
# cuDNN 최적화 활성화
export CUDA_VISIBLE_DEVICES=0
export TF_FORCE_GPU_ALLOW_GROWTH=true
```

---

## 4. OCR 인식률 문제

### 4.1 숫자 인식 실패

#### 증상
- 명확한 숫자가 인식되지 않음
- 빈 결과가 반환됨
- 텍스트 감지는 되지만 인식 실패

#### 원인
- confidence_threshold가 너무 높음
- 이미지 전처리 부족
- 텍스트 감지 임계값 문제

#### 해결 방법

**1. confidence_threshold 조정**
```python
from src.ocr import OCREngine, OCRConfig

config = OCRConfig(
    confidence_threshold=0.5,  # 기본 0.7에서 낮춤
    drop_score=0.3,  # 기본 0.5에서 낮춤
)
```

**2. 텍스트 감지 임계값 튜닝**
```python
config = OCRConfig(
    det_db_thresh=0.2,  # 기본 0.3에서 낮춤 (더 민감)
    det_db_box_thresh=0.4,  # 기본 0.5에서 낮춤
    det_db_unclip_ratio=1.8,  # 기본 1.6에서 증가 (박스 확대)
)
```

**3. 이미지 전처리 적용**
```python
from src.preprocessing import ImageEnhancer, create_industrial_display_config
import cv2

# 산업용 디스플레이에 최적화된 전처리
enhancer = ImageEnhancer(create_industrial_display_config())
enhanced = enhancer.enhance(frame)

# 수동 전처리 예시
def preprocess_for_ocr(image):
    # 그레이스케일 변환
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # 대비 향상 (CLAHE)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    
    # 이진화
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # BGR로 변환 (PaddleOCR 입력)
    return cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
```

---

### 4.2 잘못된 인식 (오인식)

#### 증상
- 숫자가 다른 문자로 인식됨 (8 -> B, 0 -> O)
- 특수문자나 노이즈가 포함됨
- 부분적으로만 인식됨

#### 원인
- numeric_only 모드 미사용
- 텍스트 각도 분류 문제
- 배경 노이즈

#### 해결 방법

**1. numeric_only 모드 활성화**
```python
config = OCRConfig(
    numeric_only=True,  # 숫자만 필터링
    confidence_threshold=0.7,
)
```

**2. 각도 분류 설정**
```python
config = OCRConfig(
    use_angle_cls=True,  # 텍스트 각도 자동 보정
    cls_batch_num=6,
)
```

**3. 후처리 필터 적용**
```python
import re

def clean_numeric_result(text: str) -> str:
    """숫자 결과 정제"""
    # 숫자, 소수점, 부호만 유지
    cleaned = re.sub(r'[^\d.\-+]', '', text)
    
    # 다중 소수점 제거
    parts = cleaned.split('.')
    if len(parts) > 2:
        cleaned = parts[0] + '.' + ''.join(parts[1:])
    
    return cleaned

# 사용 예
for result in ocr_results:
    clean_value = clean_numeric_result(result.text)
    print(f"원본: {result.text} -> 정제: {clean_value}")
```

**4. ROI 영역 조정**
```python
from src.config import ROIConfig

# ROI를 더 정확하게 설정하여 배경 노이즈 제외
roi = ROIConfig(
    name="display",
    x=0.15,
    y=0.22,
    width=0.12,  # 너무 넓지 않게
    height=0.08,
    normalized=True,
)
```

---

## 5. 변화 감지 문제

### 5.1 과다 감지 (False Positive)

#### 증상
- 실제 변화 없이 계속 변화 이벤트 발생
- 미세한 노이즈에 반응
- 동일한 값인데 변화로 감지

#### 원인
- ssim_threshold가 너무 높음
- 디바운스 설정 부족
- 비디오 압축 아티팩트

#### 해결 방법

**1. ssim_threshold 증가**
```python
from src.detection import ChangeDetector, ChangeDetectorConfig

config = ChangeDetectorConfig(
    ssim_threshold=0.97,  # 기본 0.95에서 증가 (덜 민감)
)
```

**2. 디바운스 설정 강화**
```python
config = ChangeDetectorConfig(
    debounce_time_ms=200.0,  # 기본 100에서 증가
    debounce_buffer_size=10,  # 기본 5에서 증가
)
```

**3. 전처리로 노이즈 제거**
```python
config = ChangeDetectorConfig(
    apply_gaussian_blur=True,
    gaussian_kernel_size=(5, 5),  # 기본 (3, 3)에서 증가
    apply_histogram_equalization=True,
)
```

**4. 숫자 변화 임계값 설정**
```python
config = ChangeDetectorConfig(
    numeric_change_threshold=0.1,  # 0.1 이하 변화 무시
    numeric_tolerance=1e-4,
)
```

---

### 5.2 미탐지 (False Negative)

#### 증상
- 실제 변화가 있는데 감지되지 않음
- 큰 변화만 감지되고 작은 변화 누락
- 변화 이벤트가 전혀 발생하지 않음

#### 원인
- ssim_threshold가 너무 낮음
- change_threshold 설정 문제
- OCR 신뢰도 임계값이 너무 높음

#### 해결 방법

**1. ssim_threshold 감소**
```python
config = ChangeDetectorConfig(
    ssim_threshold=0.90,  # 기본 0.95에서 감소 (더 민감)
)
```

**2. 변화 감지 임계값 조정**
```yaml
# config.yaml
processing:
  change_threshold: 0.03  # 기본 0.05에서 감소
```

**3. OCR 검증 임계값 조정**
```python
config = ChangeDetectorConfig(
    ocr_confidence_threshold=0.5,  # 기본 0.6에서 감소
    max_ocr_retries=3,  # 기본 2에서 증가
)
```

**4. 다운스케일 비활성화**
```python
config = ChangeDetectorConfig(
    downscale_factor=1.0,  # 원본 크기로 비교
)
```

**5. 디버그 모드로 상세 분석**
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# SSIM 점수 확인
for frame_data in processor.extract_frames():
    events = detector.detect_changes(frame_data.frame, rois)
    for event in events:
        print(f"ROI: {event.roi_id}, SSIM: {event.ssim_score:.4f}, "
              f"Type: {event.change_type.value}")
```

---

## 6. 로그 분석

### 6.1 DEBUG 모드 활성화

**명령행에서 활성화**
```bash
python main.py --video input.mp4 --output ./results --debug
```

**코드에서 활성화**
```python
import logging

# 전체 DEBUG 레벨
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('debug.log'),
        logging.StreamHandler()
    ]
)

# 특정 모듈만 DEBUG
logging.getLogger('src.ocr').setLevel(logging.DEBUG)
logging.getLogger('src.detection').setLevel(logging.DEBUG)
```

**YAML 설정**
```yaml
# config.yaml
debug: true
log_level: DEBUG
```

---

### 6.2 로그 파일 위치

| 로그 유형 | 기본 위치 | 설명 |
|-----------|-----------|------|
| 애플리케이션 로그 | `stdout` / `debug.log` | 처리 진행 상황 |
| PaddleOCR 로그 | `stdout` | 모델 로딩, 추론 정보 |
| OpenCV 로그 | `stderr` | 비디오 처리 경고 |

---

### 6.3 주요 로그 메시지 해석

**정상 동작 로그**
```
INFO - VideoProcessor 초기화: /path/to/video.mp4
INFO - 비디오 메타데이터 로드: 1920x1080, 30.00fps, 01:30:00
INFO - PaddleOCR PP-OCRv4 initialized successfully
INFO - 프레임 추출 완료: 총 5400개, 변화감지 127회
```

**경고 로그 (주의 필요)**
```
WARNING - OCR attempt 1 failed: ...  # OCR 재시도 발생
WARNING - Failed to extract ROI display: ...  # ROI 추출 실패
WARNING - SSIM calculation failed: ...  # SSIM 계산 오류
```

**에러 로그 (조치 필요)**
```
ERROR - Failed to initialize PaddleOCR: ...  # OCR 초기화 실패
ERROR - 비디오를 열 수 없습니다: ...  # 비디오 열기 실패
ERROR - OCR recognition failed: ...  # OCR 인식 실패
```

---

## 7. FAQ

### Q1: 처리 중 프로그램이 갑자기 종료됩니다.

**A:** 대부분 메모리 부족(OOM)이 원인입니다.
```yaml
# config.yaml에서 다음 설정 조정
processing:
  resize_width: 1280
  resize_height: 720
  batch_size: 16
  default_interval_sec: 2.0
```

또는 시스템 스왑 메모리를 확인하세요:
```bash
free -h
sudo swapon --show
```

---

### Q2: GPU를 사용하도록 설정했는데 CPU만 사용됩니다.

**A:** 다음 순서로 확인하세요:

1. CUDA 설치 확인:
   ```bash
   nvidia-smi
   nvcc --version
   ```

2. PaddlePaddle GPU 버전 확인:
   ```python
   import paddle
   print(paddle.device.is_compiled_with_cuda())
   ```

3. paddlepaddle-gpu 재설치:
   ```bash
   pip uninstall paddlepaddle
   pip install paddlepaddle-gpu==2.5.2.post118  # CUDA 버전에 맞게
   ```

---

### Q3: 특정 비디오 포맷이 열리지 않습니다.

**A:** ffmpeg으로 변환 후 사용하세요:
```bash
# H.264 코덱으로 변환
ffmpeg -i input.avi -c:v libx264 -c:a aac output.mp4

# 지원 포맷 확인
ffmpeg -formats
```

---

### Q4: ROI 좌표를 어떻게 찾나요?

**A:** 다음 도구를 사용하세요:

```python
import cv2

def get_roi_coordinates(video_path):
    """마우스로 ROI 선택"""
    cap = cv2.VideoCapture(video_path)
    ret, frame = cap.read()
    cap.release()
    
    if not ret:
        print("비디오 로드 실패")
        return
    
    # ROI 선택 (드래그로 영역 지정)
    roi = cv2.selectROI("Select ROI", frame, fromCenter=False)
    cv2.destroyAllWindows()
    
    x, y, w, h = roi
    height, width = frame.shape[:2]
    
    # 정규화 좌표 출력
    print(f"정규화 좌표:")
    print(f"  x: {x/width:.4f}")
    print(f"  y: {y/height:.4f}")
    print(f"  width: {w/width:.4f}")
    print(f"  height: {h/height:.4f}")
    
    return roi

get_roi_coordinates("video.mp4")
```

---

### Q5: 데이터베이스 파일이 계속 커집니다.

**A:** 주기적으로 정리하세요:

```python
from src.storage import DatabaseManager

db = DatabaseManager("data/results.db")

# 30일 이상 된 데이터 삭제
db.cleanup_old_data(days=30)

# 데이터베이스 압축 (VACUUM)
db.optimize()
```

SQLite 직접 사용:
```bash
sqlite3 data/results.db "VACUUM;"
```

---

### Q6: 여러 ROI를 동시에 모니터링할 수 있나요?

**A:** 예, YAML 설정이나 코드로 여러 ROI를 정의할 수 있습니다:

```yaml
# config.yaml
rois:
  - name: display_1
    x: 0.1
    y: 0.2
    width: 0.15
    height: 0.1
    
  - name: display_2
    x: 0.3
    y: 0.2
    width: 0.15
    height: 0.1
    
  - name: display_3
    x: 0.5
    y: 0.2
    width: 0.15
    height: 0.1
```

---

### Q7: 실시간 스트림을 처리할 수 있나요?

**A:** 현재 버전은 파일 기반 처리에 최적화되어 있습니다. RTSP 스트림의 경우:

```python
# RTSP URL 직접 사용 (실험적)
config = Config(video_path=Path("rtsp://user:pass@ip:port/stream"))

# 더 안정적인 방법: ffmpeg으로 중간 파일 생성
# ffmpeg -i rtsp://... -c copy -t 60 segment.mp4
```

---

### Q8: 분석 결과를 CSV로 내보내려면?

**A:** 데이터베이스에서 추출:

```python
import sqlite3
import pandas as pd

conn = sqlite3.connect('data/results.db')

# 변화 이벤트 추출
df = pd.read_sql_query("""
    SELECT 
        timestamp,
        roi_id,
        previous_value,
        current_value,
        confidence
    FROM change_events
    WHERE session_id = 1
    ORDER BY timestamp
""", conn)

df.to_csv('analysis_results.csv', index=False)
conn.close()
```

---

## 추가 지원

문제가 해결되지 않으면:

1. **DEBUG 로그 수집**: `--debug` 옵션으로 실행하여 상세 로그 확인
2. **환경 정보 수집**: 
   ```bash
   pip freeze > requirements_actual.txt
   python --version
   nvidia-smi
   ```
3. **최소 재현 코드 작성**: 문제를 재현할 수 있는 최소한의 코드 준비

---

## 관련 문서

- [README.md](/home/eltriny/Workspace/projects/video_detection/README.md) - 프로젝트 개요
- [CONFIGURATION.md](/home/eltriny/Workspace/projects/video_detection/docs/CONFIGURATION.md) - 설정 가이드
- [API_REFERENCE.md](/home/eltriny/Workspace/projects/video_detection/docs/API_REFERENCE.md) - API 문서
- [hardware_requirements.md](/home/eltriny/Workspace/projects/video_detection/docs/hardware_requirements.md) - 하드웨어 요구사항
