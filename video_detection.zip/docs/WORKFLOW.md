# 비디오 감지 분석 워크플로우

## 목차
1. [파이프라인 개요](#파이프라인-개요)
2. [1단계: 초기화](#1단계-초기화)
3. [2단계: ROI 감지](#2단계-roi-감지)
4. [3단계: 프레임 분석 루프](#3단계-프레임-분석-루프)
5. [4단계: 변경 이벤트 처리](#4단계-변경-이벤트-처리)
6. [5단계: 완료 및 요약](#5단계-완료-및-요약)
7. [시퀀스 다이어그램](#시퀀스-다이어그램)
8. [오류 처리 흐름](#오류-처리-흐름)
9. [최적화 팁](#최적화-팁)

---

## 파이프라인 개요

비디오 감지 시스템은 5단계 파이프라인을 통해 산업용 모니터링 비디오를 처리하며, 원시 비디오 입력을 구조화된 변경 감지 데이터로 변환합니다.

### 전체 처리 흐름

```mermaid
flowchart TB
    subgraph Phase1["1단계: 초기화"]
        A[비디오 파일 입력] --> B[VideoProcessor 생성]
        B --> C[메타데이터 로딩]
        C --> D[OCR엔진 워밍업]
        D --> E[데이터베이스 관리자 세션]
        E --> F[캡처 관리자 설정]
    end

    subgraph Phase2["2단계: ROI 감지"]
        F --> G[처음 10개 프레임 샘플링]
        G --> H[다중 프레임 합의 감지]
        H --> I{ROI 발견?}
        I -->|예| J[ROI 유형 분류]
        I -->|아니오| K[전체 프레임 모드]
        J --> L[ROI 데이터베이스 저장]
        K --> L
    end

    subgraph Phase3["3단계: 프레임 분석 루프"]
        L --> M[제너레이터 프레임 추출]
        M --> N[적응형 프레임 스킵 로직]
        N --> O[SSIM 변경 감지]
        O --> P{변경 감지?}
        P -->|예| Q[OCR 인식]
        P -->|아니오| R[다음 프레임으로 건너뛰기]
        Q --> S[결과 저장]
        R --> M
        S --> T{더 많은 프레임?}
        T -->|예| M
        T -->|아니오| U[완료]
    end

    subgraph Phase4["4단계: 이벤트 처리"]
        Q --> V[디바운싱 필터]
        V --> W[숫자 델타 계산]
        W --> X[캡처 이미지 저장]
        X --> Y[데이터베이스 이벤트 삽입]
    end

    subgraph Phase5["5단계: 완료"]
        U --> Z[세션 종료]
        Z --> AA[요약 생성]
        AA --> AB[리소스 정리]
    end

    style Phase1 fill:#e1f5fe
    style Phase2 fill:#fff3e0
    style Phase3 fill:#e8f5e9
    style Phase4 fill:#fce4ec
    style Phase5 fill:#f3e5f5
```

---

## 1단계: 초기화

### 목적
모델 로딩, 데이터베이스 연결, 디렉토리 구조 생성 등 비디오 분석을 위한 모든 시스템 구성 요소를 준비합니다.

### 처리 흐름

```mermaid
flowchart LR
    A[시작] --> B[VideoProcessor 생성]
    B --> C[비디오 메타데이터 로드]
    C --> D[프레임 간격 계산]
    D --> E[OCR엔진 초기화]
    E --> F[OCR 모델 워밍업]
    F --> G[DB 세션 생성]
    G --> H[캡처 디렉토리 설정]
    H --> I[분석 준비 완료]
```

### 구성 요소 초기화

| 단계 | 구성 요소 | 동작 | 목적 |
|------|-----------|--------|---------|
| 1 | VideoProcessor | `VideoProcessor(config)` | 비디오 파일 참조 로드 |
| 2 | VideoMetadata | `processor.metadata` | fps, 해상도, 재생시간 추출 |
| 3 | 프레임 간격 | `_calculate_frame_intervals()` | 초를 프레임 수로 변환 |
| 4 | OCREngine | `OCREngine(OCRConfig(...))` | PaddleOCR PP-OCRv4 초기화 |
| 5 | OCR 워밍업 | `ocr_engine.warmup()` | 첫 번째 추론 속도 향상을 위한 모델 사전 로드 |
| 6 | DatabaseManager | `DatabaseManager(db_path)` | SQLite 연결 열기 |
| 7 | 세션 | `db.create_session(...)` | 분석 세션 레코드 생성 |
| 8 | CaptureManager | `CaptureManager(config)` | 이미지 저장 디렉토리 준비 |

### 코드 예제

```python
# 1단계: 초기화
config = Config(video_path=Path("video.mp4"))
processor = VideoProcessor(config)

# 메타데이터 로드 시 프레임 간격 계산 트리거
metadata = processor.metadata  # 지연 로딩
logger.info(f"비디오: {metadata.width}x{metadata.height}, {metadata.fps}fps")

# 워밍업과 함께 OCR 초기화
ocr_engine = OCREngine(OCRConfig(use_gpu=True, numeric_only=True))
ocr_engine.warmup()

# 데이터베이스 세션
with DatabaseManager(db_path) as db:
    session = db.create_session(SessionCreate(
        name=f"Analysis_{datetime.now():%Y%m%d_%H%M%S}",
        source_path=str(video_path)
    ))

# 캡처 디렉토리
capture_manager = CaptureManager(CaptureConfig(
    base_directory=output_dir / "captures"
))
```

### 주요 출력
- VideoMetadata: fps, total_frames, duration_ms
- 계산된 간격: default_interval_frames, change_interval_frames
- 데이터베이스의 활성 세션 ID
- 초기화된 캡처 디렉토리 구조

---

## 2단계: ROI 감지

### 목적
안정성을 위한 다중 프레임 합의를 사용하여 초기 비디오 프레임에서 관심 영역(숫자 디스플레이, 텍스트 라벨, 차트)을 자동으로 식별합니다.

### 처리 흐름

```mermaid
flowchart TB
    A[ROI 감지 시작] --> B[처음 10개 프레임 추출]
    B --> C[각 프레임에 대해]

    subgraph Detection["감지 방법"]
        C --> D[윤곽선 감지]
        C --> E[OCR 기반 감지]
        C --> F[엣지 기반 차트 감지]
    end

    D --> G[모든 감지 결과 수집]
    E --> G
    F --> G

    G --> H[NMS 적용]
    H --> I[다중 프레임 합의]
    I --> J{50%+ 프레임에서 나타남?}

    J -->|예| K[안정적인 ROI로 유지]
    J -->|아니오| L[폐기]

    K --> M[ROI 유형 분류]
    M --> N[데이터베이스에 저장]
    L --> O[계속]

    N --> P[ROI 목록 반환]
    O --> P
```

### 다중 프레임 합의 알고리즘

```
각 공간 위치에 대해:
    1. 그리드 위치별로 감지 결과 그룹화 (20x20 픽셀 그리드)
    2. 프레임 출현 횟수 계산
    3. 출현 횟수 >= 임계값 (50%)인 경우:
        - 바운딩 박스 좌표 평균 계산
        - 가장 높은 신뢰도 점수 사용
        - 안정적인 ROI로 표시
```

### ROI 유형 분류

| 유형 | 감지 방법 | 특성 |
|------|-----------------|-----------------|
| NUMERIC | 윤곽선 + OCR | 종횡비 0.3-5.0, 높이 10-200px, 숫자 내용 70% 이상 |
| TEXT | 윤곽선 + OCR | 종횡비 2.0 초과, 너비 50px 초과, 영숫자 내용 |
| CHART | 엣지 감지 | 수평 + 수직선 보유, 대각선 데이터 라인이 있는 영역 |
| UNKNOWN | 윤곽선 | 다른 기준에 맞지 않음 |

### 코드 예제

```python
def _detect_rois_from_video(self, session_id: int) -> list:
    """다중 프레임 합의 ROI 감지."""
    sample_frames = []

    # 처음 10개 프레임 샘플링
    for i, frame_data in enumerate(self.video_processor.extract_frames()):
        if i >= 10:
            break
        sample_frames.append(frame_data.image)

    if not sample_frames:
        return []

    # 다중 프레임 합의 감지
    detected_rois = self.roi_detector.detect_from_frames_consensus(
        sample_frames,
        consensus_threshold=0.5
    )

    # 데이터베이스에 저장
    rois = []
    with self.db_manager as db:
        for i, roi in enumerate(detected_rois):
            roi_type = ROIType.NUMERIC if roi.roi_type == "numeric" else ROIType.TEXT
            db_roi = db.create_roi(ROICreate(
                session_id=session_id,
                name=f"ROI_{i+1}",
                roi_type=roi_type,
                x=roi.bounding_box.x,
                y=roi.bounding_box.y,
                width=roi.bounding_box.width,
                height=roi.bounding_box.height,
            ))
            rois.append((db_roi, roi))

    return rois
```

### 주요 출력
- 다음을 포함하는 안정적인 ROI 정의 목록:
  - 바운딩 박스 좌표 (x, y, width, height)
  - ROI 유형 분류
  - 신뢰도 점수
  - 데이터베이스 레코드 ID

---

## 3단계: 프레임 분석 루프

### 목적
메모리 효율성을 위한 제너레이터 패턴을 사용하여 비디오 프레임을 처리하고, 감지된 변경 사항에 따라 적응형 프레임 스킵을 수행합니다.

### 처리 흐름

```mermaid
flowchart TB
    A[프레임 루프 시작] --> B[제너레이터 초기화]
    B --> C{다음 프레임?}

    C -->|예| D[비디오에서 프레임 읽기]
    C -->|아니오| E[루프 종료]

    D --> F{이 프레임 건너뛰기?}
    F -->|예| G[스킵 카운터 감소]
    G --> C

    F -->|아니오| H[설정된 경우 리사이즈]
    H --> I[프레임 차이 계산]

    I --> J{변경 점수 > 임계값?}

    J -->|예| K[프레임 간격 축소]
    J -->|아니오| L[변경 없음 카운터 증가]

    K --> M[변경 감지 표시]
    L --> N{변경 없이 오랜 기간?}

    N -->|예| O[기본 간격 복원]
    N -->|아니오| P[현재 간격 유지]

    M --> Q[FrameData 반환]
    O --> Q
    P --> Q

    Q --> R[이전 프레임 업데이트]
    R --> S[스킵 카운터 설정]
    S --> C
```

### 적응형 프레임 스킵 로직

```
기본 상태:
    frame_interval = 30 프레임 (30fps에서 1.0초)

변경 감지 시 (score > 0.05):
    frame_interval = 5 프레임 (30fps에서 0.17초)
    frames_since_change = 0

변경 없음 시:
    frames_since_change += 1
    if frames_since_change > default_interval * 2:
        frame_interval = 30 프레임 (기본값 복원)
```

### 프레임 스킵 상태 다이어그램

```mermaid
stateDiagram-v2
    [*] --> NormalMode

    NormalMode: 기본 간격 (1.0초)
    HighFreqMode: 빠른 간격 (0.17초)

    NormalMode --> HighFreqMode: 변경 감지됨\n(SSIM < 임계값)
    HighFreqMode --> HighFreqMode: 변경 계속됨
    HighFreqMode --> NormalMode: 60+ 프레임 동안\n변경 없음
```

### 변경 감지를 위한 SSIM 계산

```python
def _compute_frame_difference(
    self,
    frame1: NDArray[np.uint8],
    frame2: NDArray[np.uint8],
) -> float:
    """정규화된 프레임 차이 점수를 계산합니다."""
    # 성능을 위해 축소
    small_size = (160, 90)
    small1 = cv2.resize(frame1, small_size)
    small2 = cv2.resize(frame2, small_size)

    # 그레이스케일로 변환
    gray1 = cv2.cvtColor(small1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(small2, cv2.COLOR_BGR2GRAY)

    # 0.0-1.0으로 정규화된 절대 차이
    diff = cv2.absdiff(gray1, gray2)
    score = float(np.mean(diff) / 255.0)

    return score  # 0.0 = 동일, 1.0 = 완전히 다름
```

### 제너레이터 기반 프레임 추출

```python
def extract_frames(
    self,
    start_ms: float = 0,
    end_ms: float | None = None,
) -> Generator[FrameData, None, None]:
    """메모리 효율적인 프레임 추출 제너레이터."""
    state = _ProcessingState()
    current_interval = self._default_interval_frames
    frames_until_next = 0

    with self._open_video() as cap:
        if start_ms > 0:
            cap.set(cv2.CAP_PROP_POS_MSEC, start_ms)

        while True:
            current_ms = cap.get(cv2.CAP_PROP_POS_MSEC)
            if end_ms is not None and current_ms > end_ms:
                break

            ret, frame = cap.read()
            if not ret:
                break

            frame_number = int(cap.get(cv2.CAP_PROP_POS_FRAMES)) - 1

            # 스킵 로직
            if frames_until_next > 0:
                frames_until_next -= 1
                continue

            # 프레임 처리
            processed_frame = self._resize_frame_if_needed(frame)

            # 변경 감지 (적응 모드)
            change_score = 0.0
            is_change_detected = False

            if state.last_processed_frame is not None:
                change_score = self._compute_frame_difference(
                    state.last_processed_frame,
                    processed_frame,
                )
                is_change_detected = change_score > self._change_threshold

                if is_change_detected:
                    current_interval = self._change_interval_frames
                    state.frames_since_last_change = 0
                else:
                    state.frames_since_last_change += 1
                    if state.frames_since_last_change > self._default_interval_frames * 2:
                        current_interval = self._default_interval_frames

            # 프레임 데이터 반환
            yield FrameData(
                frame=processed_frame,
                frame_number=frame_number,
                timestamp_ms=current_ms,
                is_change_detected=is_change_detected,
                change_score=change_score,
            )

            state.last_processed_frame = processed_frame.copy()
            frames_until_next = current_interval - 1
```

### 주요 출력
- FrameData 객체가 하나씩 반환됨
- 메모리 사용량: 비디오 길이에 관계없이 일정
- 콘텐츠 변경에 따른 적응형 처리 속도

---

## 4단계: 변경 이벤트 처리

### 목적
감지된 변경 사항을 디바운싱으로 처리하고, 변경 유형을 분류하며, 캡처를 저장하고, 이벤트를 데이터베이스에 유지합니다.

### 처리 흐름

```mermaid
flowchart TB
    A[변경 감지됨] --> B[ROI 영역 추출]
    B --> C[ROI에 대한 SSIM 계산]

    C --> D{SSIM < 임계값?}
    D -->|아니오| E[유의미한 변경 없음]
    D -->|예| F[디바운스 버퍼 진입]

    F --> G{버퍼의 60%+가 변경 표시?}
    G -->|아니오| H[노이즈로 필터링됨]
    G -->|예| I[마지막 변경 이후 시간?]

    I --> J{> 디바운스 윈도우?}
    J -->|아니오| K[너무 빠름 - 건너뛰기]
    J -->|예| L[확인된 변경]

    L --> M[OCR 수행]
    M --> N[숫자 값 파싱]

    N --> O{두 값 모두 유효?}
    O -->|예| P[델타 계산]
    O -->|아니오| Q[텍스트 변경으로 표시]

    P --> R{델타 > 0?}
    R -->|예| S[NUMERIC_INCREASE]
    R -->|아니오| T[NUMERIC_DECREASE]

    S --> U[캡처 이미지 저장]
    T --> U
    Q --> U

    U --> V[DB 이벤트 삽입]
    V --> W[콜백 알림]
```

### 디바운싱 알고리즘

```python
class DebounceBuffer:
    """시간적 일관성 검사를 통한 노이즈 필터링."""

    def __init__(self, buffer_size: int = 5, time_window_ms: float = 100.0):
        self.buffer_size = buffer_size
        self.time_window_ms = time_window_ms
        self._buffer: deque[tuple[float, bool, str | None]] = deque(maxlen=buffer_size)
        self._last_confirmed_time: float = 0.0
        self._last_confirmed_value: str | None = None

    def add_detection(
        self,
        timestamp: float,
        has_change: bool,
        value: str | None = None,
    ) -> bool:
        """디바운싱 후 변경이 확인되면 True를 반환합니다."""
        self._buffer.append((timestamp, has_change, value))

        if not has_change:
            return False

        # 마지막 확인된 변경 이후 시간 확인
        time_since_last_ms = (timestamp - self._last_confirmed_time) * 1000
        if time_since_last_ms < self.time_window_ms:
            return False  # 너무 빠름

        # 버퍼의 60%가 변경을 표시해야 함
        recent_changes = [entry[1] for entry in self._buffer]
        change_ratio = sum(recent_changes) / len(recent_changes)

        if change_ratio >= 0.6:
            if value != self._last_confirmed_value:
                self._last_confirmed_time = timestamp
                self._last_confirmed_value = value
                return True

        return False
```

### 변경 유형 분류

| 변경 유형 | 조건 | 설명 |
|-------------|-----------|-------------|
| NUMERIC_INCREASE | delta > 0 | 숫자 값 증가 |
| NUMERIC_DECREASE | delta < 0 | 숫자 값 감소 |
| TEXT_CHANGE | prev != curr (텍스트) | 텍스트 내용 변경 |
| VISUAL_CHANGE | SSIM 낮음, OCR 없음 | 텍스트 없는 시각적 변경 |
| NO_CHANGE | SSIM 높음 | 유의미한 변경 없음 |

### 이벤트 저장

```python
def _handle_change_event(
    self,
    session_id: int,
    roi_id: int,
    frame_data,
    frame: NDArray,
    roi,
) -> None:
    """확인된 변경 이벤트를 처리하고 저장합니다."""
    # 1. 캡처 이미지 저장
    capture_result = self.capture_manager.save_capture(
        frame,
        session_id=session_id,
        roi_name=f"roi_{roi_id}",
    )

    # 2. ROI 영역 추출 및 향상
    roi_region = roi.extract_region(frame)
    enhanced = self.image_enhancer.enhance(roi_region)

    # 3. OCR 수행
    ocr_results = self.ocr_engine.recognize(enhanced.image)
    extracted_text = " ".join([r.text for r in ocr_results]) if ocr_results else ""

    # 4. 차트 확인
    chart_detected = self.chart_detector.detect_chart(roi_region)

    # 5. 데이터베이스에 저장
    with self.db_manager as db:
        db.create_change_event(ChangeEventCreate(
            roi_id=roi_id,
            session_id=session_id,
            previous_value=self._previous_values.get(roi_id, ""),
            current_value=extracted_text,
            frame_path=str(capture_result.path),
            extracted_text=extracted_text,
            is_chart=chart_detected,
            confidence=ocr_results[0].confidence if ocr_results else 0.0,
        ))

    # 이전 값 캐시 업데이트
    self._previous_values[roi_id] = extracted_text
```

### 주요 출력
- 정리된 디렉토리 구조에 캡처된 이미지 파일
- 다음을 포함하는 데이터베이스 레코드:
  - 이전 값과 현재 값
  - 변경 분류
  - 신뢰도 점수
  - 프레임 경로 참조

---

## 5단계: 완료 및 요약

### 목적
분석 세션을 마무리하고, 요약 통계를 생성하며, 리소스를 정리합니다.

### 처리 흐름

```mermaid
flowchart LR
    A[분석 완료] --> B[DB 세션 종료]
    B --> C[최종 통계 조회]
    C --> D[요약 보고서 생성]
    D --> E[비디오 핸들 해제]
    E --> F[DB 연결 종료]
    F --> G[스레드 풀 정리]
    G --> H[요약 출력]
```

### 요약 생성

```python
def _print_summary(self, session_id: int) -> None:
    """분석 요약을 생성하고 표시합니다."""
    with self.db_manager as db:
        events = db.get_events_by_session(session_id)
        rois = db.get_rois_by_session(session_id)

    print("\n" + "=" * 60)
    print("분석 요약")
    print("=" * 60)
    print(f"비디오: {self.video_path}")
    print(f"감지된 ROI: {len(rois)}")
    print(f"변경 이벤트: {len(events)}")
    print(f"캡처 디렉토리: {self.output_dir / 'captures'}")
    print(f"데이터베이스: {self.db_path}")

    # 상세 통계
    chart_events = [e for e in events if e.is_chart]
    print(f"차트 감지: {len(chart_events)}")

    # ROI별 분류
    for roi in rois:
        roi_events = [e for e in events if e.roi_id == roi.id]
        print(f"  {roi.name} ({roi.roi_type.value}): {len(roi_events)} 이벤트")

    print("=" * 60 + "\n")
```

### 리소스 정리

| 리소스 | 정리 방법 | 타이밍 |
|----------|---------------|--------|
| 비디오 파일 핸들 | `cap.release()` | 프레임 추출 후 |
| 데이터베이스 연결 | `connection.close()` | 세션 종료 후 |
| 스레드 풀 | `executor.shutdown()` | 비동기 작업 후 |
| OCR 모델 | 가비지 컬렉션 | 스크립트 종료 시 |

---

## 시퀀스 다이어그램

### 주요 컴포넌트 상호작용

```mermaid
sequenceDiagram
    participant User as 사용자
    participant Main as VideoAnalyzerApp
    participant VP as VideoProcessor
    participant ROI as ROIDetector
    participant CD as ChangeDetector
    participant OCR as OCREngine
    participant IE as ImageEnhancer
    participant DB as DatabaseManager
    participant CM as CaptureManager

    User->>Main: run()

    rect rgb(225, 245, 254)
        Note over Main,CM: 1단계: 초기화
        Main->>VP: VideoProcessor 생성
        VP-->>Main: 준비 완료
        Main->>OCR: warmup()
        OCR-->>Main: 모델 로드됨
        Main->>DB: create_session()
        DB-->>Main: session_id
        Main->>CM: 디렉토리 준비
    end

    rect rgb(255, 243, 224)
        Note over Main,ROI: 2단계: ROI 감지
        Main->>VP: extract_frames() [처음 10개]
        VP-->>Main: sample_frames
        Main->>ROI: detect_from_frames_consensus()
        ROI-->>Main: stable_rois
        Main->>DB: create_roi() [각각에 대해]
        DB-->>Main: roi_ids
    end

    rect rgb(232, 245, 233)
        Note over Main,DB: 3-4단계: 분석 루프
        loop 각 프레임에 대해
            Main->>VP: extract_frames()
            VP-->>Main: FrameData

            Main->>CD: detect_changes()
            CD->>CD: SSIM 계산

            alt 변경 감지됨
                CD->>IE: enhance()
                IE-->>CD: enhanced_image
                CD->>OCR: recognize()
                OCR-->>CD: OCRResult
                CD-->>Main: ChangeEvent

                Main->>CM: save_capture()
                CM-->>Main: CaptureResult
                Main->>DB: create_change_event()
            else 변경 없음
                CD-->>Main: 건너뛰기
            end
        end
    end

    rect rgb(243, 229, 245)
        Note over Main,DB: 5단계: 완료
        Main->>DB: end_session()
        Main->>DB: get_events_by_session()
        DB-->>Main: events
        Main->>User: 요약 보고서
    end
```

### 변경 감지 상세

```mermaid
sequenceDiagram
    participant Frame as 현재 프레임
    participant CD as ChangeDetector
    participant Buffer as DebounceBuffer
    participant OCR as OCREngine
    participant DB as DatabaseManager

    Frame->>CD: detect_changes(frame, rois)

    loop 각 ROI에 대해
        CD->>CD: ROI 영역 추출
        CD->>CD: 이전과 SSIM 계산

        alt SSIM < 0.95
            CD->>Buffer: add_detection(has_change=true)

            alt 버퍼가 변경 확인
                CD->>OCR: recognize(roi_region)
                OCR-->>CD: text, confidence

                CD->>CD: 숫자 값 파싱
                CD->>CD: 델타 계산
                CD->>CD: 변경 유형 분류

                CD->>DB: ChangeEvent 준비
            else 디바운스로 필터링됨
                CD->>CD: 필터링된 감지 로그
            end
        else SSIM >= 0.95
            CD->>Buffer: add_detection(has_change=false)
        end
    end

    CD-->>Frame: list[ChangeEvent]
```

---

## 오류 처리 흐름

### 오류 카테고리와 복구

```mermaid
flowchart TB
    A[오류 발생] --> B{오류 유형?}

    B -->|비디오 열기 실패| C[VideoOpenError]
    B -->|OCR 초기화 실패| D[OCRInitError]
    B -->|프레임 추출| E[FrameExtractionError]
    B -->|데이터베이스 오류| F[DatabaseError]

    C --> G[오류 로그]
    G --> H[코드 1로 종료]

    D --> I[경고 로그]
    I --> J[OCR 없이 계속]

    E --> K[경고 로그]
    K --> L[프레임 건너뛰기]
    L --> M{더 많은 프레임?}
    M -->|예| N[루프 계속]
    M -->|아니오| O[분석 종료]

    F --> P[트랜잭션 롤백]
    P --> Q[오류 로그]
    Q --> R{심각한가?}
    R -->|예| H
    R -->|아니오| N
```

### 비디오 열기 실패

```python
def _load_metadata(self) -> VideoMetadata:
    """오류 처리와 함께 비디오 메타데이터를 로드합니다."""
    cap = cv2.VideoCapture(str(self._video_path))
    try:
        if not cap.isOpened():
            raise RuntimeError(f"비디오를 열 수 없습니다: {self._video_path}")

        # ... 메타데이터 로드 ...

    finally:
        cap.release()
```

**복구**: 없음 - 비디오 파일이 필수입니다. 애플리케이션이 오류 메시지와 함께 종료됩니다.

### OCR 초기화 실패

```python
def _ensure_initialized(self) -> None:
    """오류 처리와 함께 OCR을 초기화합니다."""
    try:
        from paddleocr import PaddleOCR
        self._ocr = PaddleOCR(**ocr_params)

    except ImportError as e:
        msg = "PaddleOCR이 설치되지 않았습니다. 다음으로 설치하세요: pip install paddlepaddle paddleocr"
        logger.error(msg)
        raise RuntimeError(msg) from e

    except Exception as e:
        msg = f"PaddleOCR 초기화 실패: {e}"
        logger.error(msg)
        raise RuntimeError(msg) from e
```

**복구 옵션**:
1. 설치 지침과 함께 종료
2. 시각 전용 변경 감지로 폴백 (텍스트 추출 없음)

### 프레임 추출 실패

```python
def extract_frames(self, ...):
    """오류 시 건너뛰기를 포함한 프레임 추출."""
    with self._open_video() as cap:
        while True:
            ret, frame = cap.read()
            if not ret:
                logger.warning(f"{cap.get(cv2.CAP_PROP_POS_MSEC)}ms 위치에서 프레임 추출 실패")
                break  # 비디오 끝 또는 읽기 오류

            # 처리 계속...
```

**복구**: 실패한 프레임을 건너뛰고 다음 프레임으로 계속 진행합니다.

### 데이터베이스 오류 처리

```python
@contextmanager
def transaction(self) -> Generator[sqlite3.Connection, None, None]:
    """오류 시 자동 롤백을 포함한 트랜잭션."""
    conn = self._get_connection()
    with self._lock:
        try:
            yield conn
            conn.commit()
        except sqlite3.IntegrityError as e:
            conn.rollback()
            raise DatabaseIntegrityError(f"무결성 제약 조건 위반: {e}") from e
        except sqlite3.Error as e:
            conn.rollback()
            raise DatabaseError(f"트랜잭션 실패: {e}") from e
```

**복구**: 트랜잭션을 롤백하고 심각도에 따라 계속 진행하거나 종료합니다.

---

## 최적화 팁

### 프레임 간격 조정

| 시나리오 | 기본 간격 | 변경 간격 | 참고 |
|----------|-----------------|-----------------|-------|
| 안정적인 디스플레이 | 2.0초 | 0.5초 | 느리게 변하는 산업용 디스플레이 |
| 빠른 업데이트 | 0.5초 | 0.1초 | 빠르게 변하는 숫자 값 |
| 혼합 콘텐츠 | 1.0초 | 0.17초 | 기본 균형 설정 |

```python
# 느린 디스플레이용 조정
config = ProcessingConfig(
    default_interval_sec=2.0,
    change_detection_interval_sec=0.5,
    change_threshold=0.08,  # 덜 민감하게
)

# 빠른 디스플레이용 조정
config = ProcessingConfig(
    default_interval_sec=0.5,
    change_detection_interval_sec=0.1,
    change_threshold=0.03,  # 더 민감하게
)
```

### GPU 가속

```python
# OCR용 GPU 활성화 (CUDA 필요)
ocr_config = OCRConfig(
    use_gpu=True,
    gpu_mem=500,  # MB
)

# GPU 가용성 확인
import paddle
if paddle.device.is_compiled_with_cuda():
    logger.info("GPU 가속 사용 가능")
else:
    logger.info("CPU 모드로 실행 중")
```

**성능 영향**:
| 모드 | OCR 속도 | 메모리 사용량 |
|------|-----------|--------------|
| CPU | ~200ms/이미지 | ~200MB |
| GPU | ~50ms/이미지 | ~500MB VRAM |

### 배치 처리

```python
# 더 나은 처리량을 위한 배치 프레임 처리
class FrameAnalyzer:
    def analyze_video_parallel(
        self,
        start_ms: float = 0,
        end_ms: float | None = None,
    ) -> Generator[AnalysisResult, None, None]:
        """병렬 배치 처리."""
        batch = []

        for frame_data in self._processor.extract_frames(start_ms, end_ms):
            batch.append(frame_data)

            if len(batch) >= self._config.processing.batch_size:
                # 배치를 병렬로 처리
                with ThreadPoolExecutor(max_workers=4) as executor:
                    results = list(executor.map(self._analyze_single, batch))
                    for result in results:
                        yield result
                batch = []
```

### 메모리 최적화

```python
# 프레임 리사이징으로 메모리 절감
config = ProcessingConfig(
    resize_width=640,   # 1920에서 축소
    resize_height=360,  # 1080에서 축소
)

# 캡처용 JPEG 품질 낮추기
capture_config = CaptureConfig(
    compression_quality=70,  # 85에서 축소
)
```

**해상도별 메모리 사용량**:
| 해상도 | 프레임 크기 | 처리 메모리 |
|------------|------------|-------------------|
| 1920x1080 | ~6MB | ~100MB |
| 1280x720 | ~2.7MB | ~50MB |
| 640x360 | ~0.7MB | ~15MB |

### 처리 파이프라인 최적화

```python
# 파이프라인 순서 최적화
enhancer = ImageEnhancer(PreprocessingConfig(
    # 빠른 처리를 위해 비용이 많이 드는 단계 건너뛰기
    enable_bilateral_filter=False,  # 매우 느림
    enable_denoise=False,           # 느림
    enable_sharpen=False,           # 대개 불필요

    # 필수 단계 유지
    enable_grayscale=True,
    enable_clahe=True,
    enable_binarization=True,
))
```

### 사용 사례별 권장 설정

| 사용 사례 | 프레임 간격 | GPU | 리사이즈 | 배치 크기 |
|----------|---------------|-----|--------|------------|
| 실시간 모니터링 | 0.5초 | 예 | 640x360 | 1 |
| 아카이브 분석 | 1.0초 | 선택 | 원본 | 32 |
| 빠른 스캔 | 2.0초 | 아니오 | 640x360 | 16 |
| 고정밀 | 0.25초 | 예 | 원본 | 8 |

---

## 부록

### 처리 통계 예제

```
============================================================
분석 요약
============================================================
비디오: /data/industrial_display.mp4
재생시간: 01:23:45
처리된 프레임: 5,025
변경 이벤트: 847
처리 시간: 8분 32초

ROI 분류:
  display_1 (NUMERIC): 512 이벤트
  display_2 (NUMERIC): 289 이벤트
  chart_area (CHART): 46 이벤트

성능:
  평균 FPS: 9.8 프레임/초
  최대 메모리: 1.2 GB
  GPU 사용률: 45%
============================================================
```

### 로그 출력 예제

```
2024-01-15 10:23:45 - INFO - VideoProcessor 초기화됨: video.mp4
2024-01-15 10:23:46 - INFO - 비디오 메타데이터 로드됨: 1920x1080, 30.00fps, 01:23:45
2024-01-15 10:23:47 - INFO - PaddleOCR PP-OCRv4 초기화됨 (GPU 모드)
2024-01-15 10:23:48 - INFO - 세션 생성됨: ID=42
2024-01-15 10:23:50 - INFO - ROI 감지: 3개의 안정적인 영역 발견
2024-01-15 10:23:50 - DEBUG - ROI_1: NUMERIC 위치 (120, 80, 200, 60)
2024-01-15 10:23:50 - DEBUG - ROI_2: NUMERIC 위치 (120, 160, 200, 60)
2024-01-15 10:23:50 - DEBUG - ROI_3: CHART 위치 (400, 80, 300, 200)
2024-01-15 10:23:51 - INFO - 프레임 분석 시작...
2024-01-15 10:24:05 - DEBUG - 변경 감지됨 (score=0.12) 프레임 1200에서, 간격 -> 5
2024-01-15 10:24:05 - DEBUG - OCR 결과: "1234.5" (신뢰도=0.95)
2024-01-15 10:24:05 - DEBUG - 변경: NUMERIC_INCREASE 1230.0 -> 1234.5 (델타=+4.5)
```
