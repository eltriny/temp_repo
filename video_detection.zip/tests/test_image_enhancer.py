"""이미지 전처리 파이프라인 테스트

ImageEnhancer의 모든 기능을 검증하는 테스트 모듈입니다.

테스트 범위:
    - 기본 기능: 초기화, 설정 업데이트, enhance 메서드
    - Sauvola 이진화: 아직 구현되지 않음 (xfail)
    - Deskewing: 아직 구현되지 않음 (xfail)
    - 이미지 품질 점수: 아직 구현되지 않음 (xfail)
    - 적응형 설정: 아직 구현되지 않음 (xfail)
    - 팩토리 함수: 사전 정의된 설정 생성
    - 통합 테스트: 전체 파이프라인 동작
    - 회귀 테스트: 기존 기능 정상 동작 확인
"""

import numpy as np
import pytest
import cv2

from src.preprocessing.image_enhancer import (
    ImageEnhancer,
    PreprocessingConfig,
    PreprocessingStep,
    BinarizationMethod,
    MorphologicalOperation,
    ProcessingResult,
    create_industrial_display_config,
    create_low_contrast_config,
    create_noisy_image_config,
)

# 아직 구현되지 않은 기능들 - 구현 후 import 추가 필요
# from src.preprocessing.image_enhancer import (
#     ImageQualityScore,
#     create_adaptive_config,
# )


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def sample_grayscale_image():
    """샘플 그레이스케일 이미지 (100x100)"""
    return np.random.randint(0, 256, (100, 100), dtype=np.uint8)


@pytest.fixture
def sample_color_image():
    """샘플 컬러 이미지 (100x100x3)"""
    return np.random.randint(0, 256, (100, 100, 3), dtype=np.uint8)


@pytest.fixture
def sample_text_image():
    """텍스트가 포함된 샘플 이미지"""
    img = np.ones((100, 300), dtype=np.uint8) * 255  # 흰색 배경
    cv2.putText(img, "TEST123", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.5, 0, 2)
    return img


@pytest.fixture
def tilted_text_image():
    """기울어진 텍스트 이미지 (약 10도)"""
    img = np.ones((200, 400), dtype=np.uint8) * 255
    cv2.putText(img, "TILTED TEXT", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, 0, 2)

    # 10도 회전
    h, w = img.shape[:2]
    center = (w // 2, h // 2)
    rotation_matrix = cv2.getRotationMatrix2D(center, 10, 1.0)
    return cv2.warpAffine(img, rotation_matrix, (w, h), borderValue=255)


@pytest.fixture
def low_quality_image():
    """저품질 이미지 (노이즈, 저대비)"""
    img = np.ones((100, 100), dtype=np.uint8) * 128
    # 노이즈 추가
    noise = np.random.normal(0, 30, img.shape).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    return img


@pytest.fixture
def default_enhancer():
    """기본 설정의 ImageEnhancer"""
    return ImageEnhancer()


# ============================================================================
# 기본 기능 테스트
# ============================================================================


class TestImageEnhancerBasic:
    """ImageEnhancer 기본 기능 테스트"""

    def test_init_default(self):
        """기본 초기화 테스트"""
        enhancer = ImageEnhancer()
        assert enhancer.config is not None
        assert isinstance(enhancer.config, PreprocessingConfig)

    def test_init_with_config(self):
        """커스텀 설정으로 초기화"""
        config = PreprocessingConfig(enable_clahe=False)
        enhancer = ImageEnhancer(config)
        assert enhancer.config.enable_clahe is False

    def test_update_config(self, default_enhancer):
        """설정 업데이트 테스트"""
        new_config = PreprocessingConfig(enable_binarization=False)
        default_enhancer.update_config(new_config)
        assert default_enhancer.config.enable_binarization is False

    def test_enhance_returns_result(self, default_enhancer, sample_grayscale_image):
        """enhance가 ProcessingResult 반환 확인"""
        result = default_enhancer.enhance(sample_grayscale_image)
        assert isinstance(result, ProcessingResult)
        assert result.image is not None
        assert len(result.applied_steps) > 0

    def test_enhance_empty_image_raises(self, default_enhancer):
        """빈 이미지에서 ValueError 발생"""
        with pytest.raises(ValueError, match="비어있거나 None"):
            default_enhancer.enhance(np.array([]))

    def test_enhance_none_raises(self, default_enhancer):
        """None 이미지에서 ValueError 발생"""
        with pytest.raises(ValueError, match="비어있거나 None"):
            default_enhancer.enhance(None)

    def test_enhance_preserves_original(self, default_enhancer, sample_grayscale_image):
        """원본 이미지가 변경되지 않는지 확인"""
        original_copy = sample_grayscale_image.copy()
        default_enhancer.enhance(sample_grayscale_image)
        np.testing.assert_array_equal(sample_grayscale_image, original_copy)

    def test_processing_time_measured(self, default_enhancer, sample_grayscale_image):
        """처리 시간이 측정되는지 확인"""
        result = default_enhancer.enhance(sample_grayscale_image)
        assert result.processing_time_ms > 0

    def test_original_shape_recorded(self, default_enhancer, sample_grayscale_image):
        """원본 shape이 기록되는지 확인"""
        result = default_enhancer.enhance(sample_grayscale_image)
        assert result.original_shape == sample_grayscale_image.shape


# ============================================================================
# Sauvola 이진화 테스트 (미구현 - xfail)
# ============================================================================


class TestSauvolaBinarization:
    """Sauvola 이진화 테스트

    Note: Sauvola 이진화는 아직 구현되지 않았습니다.
          구현 후 xfail 마커를 제거하세요.
    """

    @pytest.mark.xfail(reason="SAUVOLA enum 미구현")
    def test_sauvola_enum_exists(self):
        """SAUVOLA enum 값 존재 확인"""
        assert hasattr(BinarizationMethod, "SAUVOLA")
        assert BinarizationMethod.SAUVOLA.value == "sauvola"

    @pytest.mark.xfail(reason="Sauvola 설정 파라미터 미구현")
    def test_sauvola_config_params(self):
        """Sauvola 설정 파라미터 확인"""
        config = PreprocessingConfig()
        assert hasattr(config, "sauvola_window_size")
        assert hasattr(config, "sauvola_k")
        assert config.sauvola_window_size == 25
        assert config.sauvola_k == 0.2

    @pytest.mark.xfail(reason="Sauvola 이진화 미구현")
    def test_sauvola_binarization(self, sample_text_image):
        """Sauvola 이진화 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_binarization=True,
            binarization_method=BinarizationMethod.SAUVOLA,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)

        # 이진 이미지 확인 (0 또는 255만 존재)
        unique_values = np.unique(result.image)
        assert len(unique_values) == 2
        assert 0 in unique_values
        assert 255 in unique_values

    @pytest.mark.xfail(reason="Sauvola 커스텀 파라미터 미구현")
    def test_sauvola_custom_params(self, sample_text_image):
        """Sauvola 커스텀 파라미터 테스트"""
        config = PreprocessingConfig(
            enable_binarization=True,
            binarization_method=BinarizationMethod.SAUVOLA,
            sauvola_window_size=15,
            sauvola_k=0.3,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert result.image is not None


# ============================================================================
# Deskewing 테스트 (미구현 - xfail)
# ============================================================================


class TestDeskewing:
    """기울기 보정 테스트

    Note: Deskew 기능은 아직 구현되지 않았습니다.
          구현 후 xfail 마커를 제거하세요.
    """

    @pytest.mark.xfail(reason="DESKEW 전처리 단계 미구현")
    def test_deskew_step_exists(self):
        """DESKEW 전처리 단계 존재 확인"""
        assert hasattr(PreprocessingStep, "DESKEW")

    @pytest.mark.xfail(reason="Deskew 설정 파라미터 미구현")
    def test_deskew_config_params(self):
        """Deskew 설정 파라미터 확인"""
        config = PreprocessingConfig()
        assert hasattr(config, "enable_deskew")
        assert hasattr(config, "deskew_max_angle")
        assert config.enable_deskew is False
        assert config.deskew_max_angle == 15.0

    @pytest.mark.xfail(reason="Deskew 기본 비활성화 미구현")
    def test_deskew_disabled_by_default(self, tilted_text_image):
        """기본적으로 Deskew 비활성화 확인"""
        config = PreprocessingConfig()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(tilted_text_image)
        assert PreprocessingStep.DESKEW not in result.applied_steps

    @pytest.mark.xfail(reason="Deskew 활성화 미구현")
    def test_deskew_enabled(self, tilted_text_image):
        """Deskew 활성화 테스트"""
        config = PreprocessingConfig(
            enable_deskew=True,
            enable_binarization=False,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(tilted_text_image)
        assert PreprocessingStep.DESKEW in result.applied_steps

    @pytest.mark.xfail(reason="Deskew 파이프라인 순서 미구현")
    def test_deskew_in_pipeline_order(self):
        """파이프라인 순서에서 DESKEW 위치 확인"""
        config = PreprocessingConfig()
        order = config.get_pipeline_order()
        grayscale_idx = order.index(PreprocessingStep.GRAYSCALE)
        deskew_idx = order.index(PreprocessingStep.DESKEW)
        assert deskew_idx == grayscale_idx + 1  # GRAYSCALE 바로 다음


# ============================================================================
# 이미지 품질 점수 테스트 (미구현 - xfail)
# ============================================================================


class TestImageQualityScore:
    """이미지 품질 점수 테스트

    Note: ImageQualityScore 클래스는 아직 구현되지 않았습니다.
          구현 후 xfail 마커를 제거하고 import를 추가하세요.
    """

    @pytest.mark.xfail(reason="ImageQualityScore 클래스 미구현")
    def test_quality_score_class_exists(self):
        """ImageQualityScore 클래스 존재 확인"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        assert ImageQualityScore is not None

    @pytest.mark.xfail(reason="ImageQualityScore 속성 미구현")
    def test_quality_score_attributes(self):
        """품질 점수 속성 확인"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        score = ImageQualityScore(
            blur_score=0.8,
            noise_score=0.7,
            contrast_score=0.9,
            brightness_score=0.6,
            overall_score=0.75,
        )
        assert score.blur_score == 0.8
        assert score.noise_score == 0.7
        assert score.contrast_score == 0.9
        assert score.brightness_score == 0.6
        assert score.overall_score == 0.75

    @pytest.mark.xfail(reason="quality_level 속성 미구현")
    def test_quality_level_high(self):
        """고품질 등급 확인"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        score = ImageQualityScore(0.9, 0.9, 0.9, 0.9, 0.85)
        assert score.quality_level == "high"

    @pytest.mark.xfail(reason="quality_level 속성 미구현")
    def test_quality_level_medium(self):
        """중간 품질 등급 확인"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        score = ImageQualityScore(0.6, 0.6, 0.6, 0.6, 0.65)
        assert score.quality_level == "medium"

    @pytest.mark.xfail(reason="quality_level 속성 미구현")
    def test_quality_level_low(self):
        """저품질 등급 확인"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        score = ImageQualityScore(0.3, 0.3, 0.3, 0.3, 0.3)
        assert score.quality_level == "low"

    @pytest.mark.xfail(reason="get_quality_score 메서드 미구현")
    def test_get_quality_score_method(self, default_enhancer, sample_grayscale_image):
        """get_quality_score 메서드 테스트"""
        from src.preprocessing.image_enhancer import ImageQualityScore

        score = default_enhancer.get_quality_score(sample_grayscale_image)
        assert isinstance(score, ImageQualityScore)
        assert 0 <= score.overall_score <= 1

    @pytest.mark.xfail(reason="get_quality_score 메서드 미구현")
    def test_get_quality_score_empty_raises(self, default_enhancer):
        """빈 이미지에서 ValueError 발생"""
        with pytest.raises(ValueError):
            default_enhancer.get_quality_score(np.array([]))


# ============================================================================
# 적응형 설정 테스트 (미구현 - xfail)
# ============================================================================


class TestAdaptiveConfig:
    """적응형 설정 생성 테스트

    Note: create_adaptive_config 함수는 아직 구현되지 않았습니다.
          구현 후 xfail 마커를 제거하고 import를 추가하세요.
    """

    @pytest.mark.xfail(reason="create_adaptive_config 미구현")
    def test_adaptive_config_high_quality(self):
        """고품질 이미지용 설정"""
        from src.preprocessing.image_enhancer import (
            ImageQualityScore,
            create_adaptive_config,
        )

        score = ImageQualityScore(0.9, 0.9, 0.9, 0.9, 0.85)
        config = create_adaptive_config(score)
        assert config.enable_clahe is False
        assert config.enable_denoise is False
        assert config.binarization_method == BinarizationMethod.OTSU

    @pytest.mark.xfail(reason="create_adaptive_config 미구현")
    def test_adaptive_config_low_quality(self):
        """저품질 이미지용 설정"""
        from src.preprocessing.image_enhancer import (
            ImageQualityScore,
            create_adaptive_config,
        )

        score = ImageQualityScore(0.2, 0.2, 0.2, 0.2, 0.2)
        config = create_adaptive_config(score)
        assert config.enable_clahe is True
        assert config.enable_denoise is True
        assert config.enable_deskew is True
        assert config.binarization_method == BinarizationMethod.SAUVOLA

    @pytest.mark.xfail(reason="create_adaptive_config 미구현")
    def test_adaptive_config_medium_quality(self):
        """중간 품질 이미지용 설정 (산업용 설정과 동일)"""
        from src.preprocessing.image_enhancer import (
            ImageQualityScore,
            create_adaptive_config,
        )

        score = ImageQualityScore(0.6, 0.6, 0.6, 0.6, 0.65)
        config = create_adaptive_config(score)
        industrial = create_industrial_display_config()
        assert config.enable_clahe == industrial.enable_clahe


# ============================================================================
# 팩토리 함수 테스트
# ============================================================================


class TestFactoryFunctions:
    """팩토리 함수 테스트"""

    def test_industrial_display_config(self):
        """산업용 디스플레이 설정"""
        config = create_industrial_display_config()
        assert config.enable_clahe is True
        assert config.binarization_method == BinarizationMethod.ADAPTIVE_GAUSSIAN

    def test_industrial_display_config_values(self):
        """산업용 디스플레이 설정 세부값 확인"""
        config = create_industrial_display_config()
        assert config.clahe_clip_limit == 3.0
        assert config.clahe_grid_size == (8, 8)
        assert config.enable_gaussian_blur is True
        assert config.gaussian_kernel_size == (3, 3)
        assert config.enable_morphological is True
        assert config.morphological_operation == MorphologicalOperation.CLOSING

    def test_low_contrast_config(self):
        """저대비 설정"""
        config = create_low_contrast_config()
        assert config.clahe_clip_limit == 4.0
        assert config.enable_sharpen is True

    def test_low_contrast_config_values(self):
        """저대비 설정 세부값 확인"""
        config = create_low_contrast_config()
        assert config.clahe_grid_size == (4, 4)
        assert config.enable_bilateral_filter is True
        assert config.enable_denoise is True
        assert config.enable_normalize is True
        assert config.sharpen_amount == 0.5

    def test_noisy_image_config(self):
        """노이즈 이미지 설정"""
        config = create_noisy_image_config()
        assert config.enable_denoise is True
        assert config.denoise_strength == 12.0

    def test_noisy_image_config_values(self):
        """노이즈 이미지 설정 세부값 확인"""
        config = create_noisy_image_config()
        assert config.binarization_method == BinarizationMethod.OTSU
        assert config.morphological_operation == MorphologicalOperation.OPENING
        assert config.morphological_iterations == 2
        assert config.enable_sharpen is False  # 노이즈 증폭 방지


# ============================================================================
# 전처리 단계별 테스트
# ============================================================================


class TestPreprocessingSteps:
    """개별 전처리 단계 테스트"""

    def test_grayscale_conversion(self, sample_color_image):
        """그레이스케일 변환 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_color_image)

        # 결과가 2D 배열인지 확인
        assert len(result.image.shape) == 2
        assert PreprocessingStep.GRAYSCALE in result.applied_steps

    def test_clahe_application(self, sample_grayscale_image):
        """CLAHE 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=True,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CLAHE in result.applied_steps

    def test_gaussian_blur_application(self, sample_grayscale_image):
        """가우시안 블러 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=True,
            enable_binarization=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.GAUSSIAN_BLUR in result.applied_steps

    def test_binarization_application(self, sample_grayscale_image):
        """이진화 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=True,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.BINARIZATION in result.applied_steps

    def test_morphological_application(self, sample_grayscale_image):
        """형태학적 연산 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.MORPHOLOGICAL in result.applied_steps

    def test_bilateral_filter_application(self, sample_grayscale_image):
        """양방향 필터 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_bilateral_filter=True,
            enable_binarization=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.BILATERAL_FILTER in result.applied_steps

    def test_sharpen_application(self, sample_grayscale_image):
        """선명화 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_sharpen=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.SHARPEN in result.applied_steps

    def test_denoise_application(self, sample_grayscale_image):
        """노이즈 제거 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_denoise=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.DENOISE in result.applied_steps

    def test_resize_application(self, sample_grayscale_image):
        """크기 조정 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_resize=True,
            target_height=50,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.RESIZE in result.applied_steps
        assert result.image.shape[0] == 50

    def test_normalize_application(self, sample_grayscale_image):
        """정규화 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_normalize=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.NORMALIZE in result.applied_steps


# ============================================================================
# 통합 테스트
# ============================================================================


class TestIntegration:
    """통합 테스트"""

    def test_full_pipeline_grayscale(self, sample_grayscale_image):
        """전체 파이프라인 (그레이스케일)"""
        config = create_industrial_display_config()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert result.image is not None
        assert result.processing_time_ms > 0

    def test_full_pipeline_color(self, sample_color_image):
        """전체 파이프라인 (컬러)"""
        config = create_industrial_display_config()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_color_image)
        assert result.image is not None

    def test_full_pipeline_low_contrast(self, low_quality_image):
        """저대비 파이프라인 테스트"""
        config = create_low_contrast_config()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(low_quality_image)
        assert result.image is not None

    def test_full_pipeline_noisy(self, low_quality_image):
        """노이즈 제거 파이프라인 테스트"""
        config = create_noisy_image_config()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(low_quality_image)
        assert result.image is not None

    @pytest.mark.xfail(reason="create_adaptive_config 및 get_quality_score 미구현")
    def test_adaptive_pipeline(self, low_quality_image):
        """적응형 파이프라인 테스트"""
        from src.preprocessing.image_enhancer import create_adaptive_config

        enhancer = ImageEnhancer()
        score = enhancer.get_quality_score(low_quality_image)
        adaptive_config = create_adaptive_config(score)
        adaptive_enhancer = ImageEnhancer(adaptive_config)
        result = adaptive_enhancer.enhance(low_quality_image)
        assert result.image is not None

    def test_batch_processing(self, default_enhancer):
        """배치 처리 테스트"""
        images = [
            np.random.randint(0, 256, (50, 50), dtype=np.uint8) for _ in range(3)
        ]
        results = default_enhancer.enhance_batch(images)
        assert len(results) == 3
        for result in results:
            assert isinstance(result, ProcessingResult)

    def test_batch_processing_with_failure(self, default_enhancer):
        """배치 처리 중 실패 처리 테스트"""
        images = [
            np.random.randint(0, 256, (50, 50), dtype=np.uint8),
            np.array([]),  # 실패할 이미지
            np.random.randint(0, 256, (50, 50), dtype=np.uint8),
        ]
        # 빈 이미지는 실패하지만 다른 이미지는 처리됨
        results = default_enhancer.enhance_batch(images)
        assert len(results) == 3


# ============================================================================
# 회귀 테스트
# ============================================================================


class TestRegression:
    """회귀 테스트 - 기존 기능이 정상 동작하는지 확인"""

    def test_otsu_still_works(self, sample_text_image):
        """Otsu 이진화가 여전히 작동"""
        config = PreprocessingConfig(
            enable_binarization=True,
            binarization_method=BinarizationMethod.OTSU,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert PreprocessingStep.BINARIZATION in result.applied_steps

    def test_adaptive_gaussian_still_works(self, sample_text_image):
        """적응형 가우시안 이진화가 여전히 작동"""
        config = PreprocessingConfig(
            enable_binarization=True,
            binarization_method=BinarizationMethod.ADAPTIVE_GAUSSIAN,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert result.image is not None

    def test_adaptive_mean_still_works(self, sample_text_image):
        """적응형 평균 이진화가 여전히 작동"""
        config = PreprocessingConfig(
            enable_binarization=True,
            binarization_method=BinarizationMethod.ADAPTIVE_MEAN,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert result.image is not None

    def test_simple_threshold_still_works(self, sample_text_image):
        """단순 이진화가 여전히 작동"""
        config = PreprocessingConfig(
            enable_binarization=True,
            binarization_method=BinarizationMethod.SIMPLE,
            binary_threshold=128,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert result.image is not None

    def test_all_morphological_operations(self, sample_grayscale_image):
        """모든 형태학적 연산이 작동"""
        for op in MorphologicalOperation:
            config = PreprocessingConfig(
                enable_morphological=True,
                morphological_operation=op,
                enable_binarization=False,
                enable_clahe=False,
            )
            enhancer = ImageEnhancer(config)
            result = enhancer.enhance(sample_grayscale_image)
            assert result.image is not None, f"형태학적 연산 {op.name} 실패"

    def test_all_binarization_methods(self, sample_text_image):
        """모든 이진화 방법이 작동"""
        for method in BinarizationMethod:
            config = PreprocessingConfig(
                enable_binarization=True,
                binarization_method=method,
                enable_clahe=False,
                enable_gaussian_blur=False,
                enable_morphological=False,
            )
            enhancer = ImageEnhancer(config)
            result = enhancer.enhance(sample_text_image)
            assert result.image is not None, f"이진화 방법 {method.name} 실패"


# ============================================================================
# 영역 처리 테스트
# ============================================================================


class TestRegionProcessing:
    """영역(ROI) 처리 테스트"""

    def test_enhance_region_valid(self, sample_grayscale_image):
        """유효한 영역 처리"""
        enhancer = ImageEnhancer()
        region = (10, 10, 50, 50)  # x, y, width, height
        result = enhancer.enhance_region(sample_grayscale_image, region)
        assert result.image is not None
        assert result.original_shape == (50, 50)

    def test_enhance_region_invalid_negative(self, sample_grayscale_image):
        """음수 좌표 영역 오류"""
        enhancer = ImageEnhancer()
        region = (-10, 10, 50, 50)
        with pytest.raises(ValueError, match="유효하지 않은 영역"):
            enhancer.enhance_region(sample_grayscale_image, region)

    def test_enhance_region_invalid_zero_size(self, sample_grayscale_image):
        """0 크기 영역 오류"""
        enhancer = ImageEnhancer()
        region = (10, 10, 0, 50)
        with pytest.raises(ValueError, match="유효하지 않은 영역"):
            enhancer.enhance_region(sample_grayscale_image, region)

    def test_enhance_region_out_of_bounds(self, sample_grayscale_image):
        """이미지 범위를 벗어난 영역 오류"""
        enhancer = ImageEnhancer()
        region = (80, 80, 50, 50)  # 100x100 이미지에서 범위 초과
        with pytest.raises(ValueError, match="벗어남"):
            enhancer.enhance_region(sample_grayscale_image, region)


# ============================================================================
# 단일 단계 적용 테스트
# ============================================================================


class TestSingleStepApplication:
    """단일 전처리 단계 적용 테스트"""

    def test_apply_single_step_grayscale(self, sample_color_image):
        """단일 그레이스케일 단계 적용"""
        enhancer = ImageEnhancer()
        result = enhancer.apply_single_step(
            sample_color_image, PreprocessingStep.GRAYSCALE
        )
        assert len(result.shape) == 2

    def test_apply_single_step_clahe(self, sample_grayscale_image):
        """단일 CLAHE 단계 적용"""
        enhancer = ImageEnhancer()
        result = enhancer.apply_single_step(
            sample_grayscale_image, PreprocessingStep.CLAHE
        )
        assert result is not None
        assert result.shape == sample_grayscale_image.shape

    def test_apply_single_step_invalid(self, sample_grayscale_image):
        """유효하지 않은 단계에서 오류 발생"""
        enhancer = ImageEnhancer()
        # 존재하지 않는 단계를 만들 수 없으므로,
        # 핸들러가 없는 상황을 시뮬레이션
        # 현재 구현에서는 모든 PreprocessingStep에 핸들러가 있음
        # 이 테스트는 미래의 확장을 위한 것
        pass


# ============================================================================
# 파이프라인 순서 테스트
# ============================================================================


class TestPipelineOrder:
    """파이프라인 순서 테스트"""

    def test_default_pipeline_order(self):
        """기본 파이프라인 순서 확인"""
        config = PreprocessingConfig()
        order = config.get_pipeline_order()

        assert order[0] == PreprocessingStep.GRAYSCALE
        assert PreprocessingStep.BINARIZATION in order
        assert PreprocessingStep.MORPHOLOGICAL in order

        # BINARIZATION이 MORPHOLOGICAL보다 먼저 와야 함
        bin_idx = order.index(PreprocessingStep.BINARIZATION)
        morph_idx = order.index(PreprocessingStep.MORPHOLOGICAL)
        assert bin_idx < morph_idx

    def test_custom_pipeline_order(self, sample_grayscale_image):
        """커스텀 파이프라인 순서 적용"""
        custom_order = (
            PreprocessingStep.GRAYSCALE,
            PreprocessingStep.CLAHE,
            PreprocessingStep.BINARIZATION,
        )
        config = PreprocessingConfig(
            pipeline_order=custom_order,
            enable_grayscale=True,
            enable_clahe=True,
            enable_binarization=True,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)

        # 적용된 단계가 순서대로인지 확인
        assert result.applied_steps[0] == PreprocessingStep.GRAYSCALE
        assert result.applied_steps[1] == PreprocessingStep.CLAHE
        assert result.applied_steps[2] == PreprocessingStep.BINARIZATION


# ============================================================================
# 색상 반전 테스트
# ============================================================================


class TestColorInversion:
    """색상 반전 테스트"""

    def test_invert_colors_enabled(self, sample_text_image):
        """색상 반전 활성화 테스트"""
        config = PreprocessingConfig(
            enable_binarization=True,
            invert_colors=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)

        # 색상 반전 후 결과가 유효한지 확인
        assert result.image is not None
        unique_values = np.unique(result.image)
        assert len(unique_values) <= 256  # 유효한 픽셀 값

    def test_invert_colors_disabled(self, sample_text_image):
        """색상 반전 비활성화 테스트"""
        config = PreprocessingConfig(
            enable_binarization=True,
            invert_colors=False,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_morphological=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)
        assert result.image is not None


# ============================================================================
# repr 테스트
# ============================================================================


class TestRepr:
    """문자열 표현 테스트"""

    def test_repr_default(self):
        """기본 설정 repr"""
        enhancer = ImageEnhancer()
        repr_str = repr(enhancer)
        assert "ImageEnhancer" in repr_str
        assert "활성화된_단계" in repr_str

    def test_repr_custom_config(self):
        """커스텀 설정 repr"""
        config = PreprocessingConfig(
            enable_clahe=False,
            enable_gaussian_blur=False,
        )
        enhancer = ImageEnhancer(config)
        repr_str = repr(enhancer)
        assert "CLAHE" not in repr_str or "ImageEnhancer" in repr_str


# ============================================================================
# CHARACTER_BRIDGING 테스트
# ============================================================================


class TestCharacterBridging:
    """문자 브리징 테스트 클래스"""

    def test_character_bridging_application(self, sample_grayscale_image):
        """문자 브리징 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps

    def test_character_bridging_horizontal_kernel(self, sample_grayscale_image):
        """수평 커널 브리징 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
            bridging_kernel_shape="horizontal",
            bridging_kernel_size=(5, 1),
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps
        assert result.image.shape == sample_grayscale_image.shape

    def test_character_bridging_vertical_kernel(self, sample_grayscale_image):
        """수직 커널 브리징 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
            bridging_kernel_shape="vertical",
            bridging_kernel_size=(1, 5),
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps

    def test_character_bridging_cross_kernel(self, sample_grayscale_image):
        """십자 커널 브리징 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
            bridging_kernel_shape="cross",
            bridging_kernel_size=(3, 3),
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps

    def test_character_bridging_iterations(self, sample_grayscale_image):
        """브리징 반복 횟수 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
            bridging_iterations=2,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps

    def test_character_bridging_with_binary_image(self, sample_text_image):
        """이진 이미지에 브리징 적용 테스트"""
        # 먼저 이진화
        _, binary = cv2.threshold(sample_text_image, 127, 255, cv2.THRESH_BINARY)

        config = PreprocessingConfig(
            enable_grayscale=False,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_character_bridging=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(binary)

        # Dilation으로 인해 밝은 영역이 확장됨
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps


# ============================================================================
# EDGE_ENHANCEMENT 테스트
# ============================================================================


class TestEdgeEnhancement:
    """엣지 강조 테스트 클래스"""

    def test_edge_enhancement_application(self, sample_grayscale_image):
        """엣지 강조 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_edge_enhancement=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps

    def test_edge_enhancement_laplacian(self, sample_grayscale_image):
        """Laplacian 엣지 강조 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_edge_enhancement=True,
            edge_method="laplacian",
            edge_weight=0.3,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps
        assert result.image.shape == sample_grayscale_image.shape

    def test_edge_enhancement_sobel(self, sample_grayscale_image):
        """Sobel 엣지 강조 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_edge_enhancement=True,
            edge_method="sobel",
            edge_weight=0.25,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)
        assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps

    def test_edge_enhancement_weight_variation(self, sample_text_image):
        """다양한 가중치로 엣지 강조 테스트"""
        for weight in [0.1, 0.3, 0.5]:
            config = PreprocessingConfig(
                enable_grayscale=True,
                enable_clahe=False,
                enable_gaussian_blur=False,
                enable_binarization=False,
                enable_morphological=False,
                enable_edge_enhancement=True,
                edge_weight=weight,
            )
            enhancer = ImageEnhancer(config)
            result = enhancer.enhance(sample_text_image)
            assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps

    def test_edge_enhancement_on_color_image(self, sample_color_image):
        """컬러 이미지에 엣지 강조 적용 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=False,  # 그레이스케일 변환 없이
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_edge_enhancement=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_color_image)
        # 핸들러 내부에서 그레이스케일로 변환됨
        assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps


# ============================================================================
# OCR 최적화 설정 테스트
# ============================================================================


class TestOCROptimizedConfig:
    """OCR 최적화 설정 테스트 클래스"""

    def test_ocr_optimized_config_creation(self):
        """OCR 최적화 설정 생성 테스트"""
        from src.preprocessing.image_enhancer import create_ocr_optimized_config

        config = create_ocr_optimized_config()
        assert config.enable_edge_enhancement is True
        assert config.enable_character_bridging is True

    def test_ocr_optimized_config_values(self):
        """OCR 최적화 설정 세부값 확인"""
        from src.preprocessing.image_enhancer import create_ocr_optimized_config

        config = create_ocr_optimized_config()
        assert config.edge_method == "laplacian"
        assert config.edge_weight == 0.25
        assert config.bridging_kernel_shape == "cross"
        assert config.bridging_kernel_size == (3, 3)

    def test_7segment_config_with_bridging(self):
        """7-세그먼트 설정에 브리징 포함 확인"""
        from src.preprocessing.image_enhancer import create_7segment_config

        config = create_7segment_config()
        assert config.enable_character_bridging is True
        assert config.bridging_kernel_shape == "horizontal"

    def test_low_contrast_config_with_edge_enhancement(self):
        """저대비 설정에 엣지 강조 포함 확인"""
        config = create_low_contrast_config()
        assert config.enable_edge_enhancement is True
        assert config.edge_method == "laplacian"


# ============================================================================
# 통합 테스트: 새 전처리 단계
# ============================================================================


class TestNewPreprocessingIntegration:
    """새 전처리 단계 통합 테스트"""

    def test_full_pipeline_with_new_steps(self, sample_text_image):
        """새 전처리 단계 포함 전체 파이프라인 테스트"""
        from src.preprocessing.image_enhancer import create_ocr_optimized_config

        config = create_ocr_optimized_config()
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_text_image)

        # 새 단계들이 적용되었는지 확인
        assert PreprocessingStep.EDGE_ENHANCEMENT in result.applied_steps
        assert PreprocessingStep.CHARACTER_BRIDGING in result.applied_steps

        # 결과가 유효한지 확인
        assert result.image is not None
        assert result.image.size > 0

    def test_pipeline_order_new_steps(self, sample_grayscale_image):
        """새 단계들의 파이프라인 순서 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=True,
            enable_morphological=False,
            enable_edge_enhancement=True,
            enable_character_bridging=True,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)

        # 파이프라인 순서 확인:
        # EDGE_ENHANCEMENT → BINARIZATION → CHARACTER_BRIDGING
        steps = list(result.applied_steps)
        edge_idx = steps.index(PreprocessingStep.EDGE_ENHANCEMENT)
        binary_idx = steps.index(PreprocessingStep.BINARIZATION)
        bridging_idx = steps.index(PreprocessingStep.CHARACTER_BRIDGING)

        assert edge_idx < binary_idx < bridging_idx

    def test_disabled_new_steps(self, sample_grayscale_image):
        """새 단계 비활성화 테스트"""
        config = PreprocessingConfig(
            enable_grayscale=True,
            enable_clahe=False,
            enable_gaussian_blur=False,
            enable_binarization=False,
            enable_morphological=False,
            enable_edge_enhancement=False,
            enable_character_bridging=False,
        )
        enhancer = ImageEnhancer(config)
        result = enhancer.enhance(sample_grayscale_image)

        assert PreprocessingStep.EDGE_ENHANCEMENT not in result.applied_steps
        assert PreprocessingStep.CHARACTER_BRIDGING not in result.applied_steps
