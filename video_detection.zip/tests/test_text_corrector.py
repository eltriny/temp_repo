"""텍스트 교정 모듈 테스트

TextCorrector 클래스의 기능을 검증하는 테스트 모듈입니다.

테스트 범위:
    - 공백 정규화
    - 컨텍스트 감지
    - 유사 문자 교정
    - 산업용 패턴 검증
    - 단위 정규화
    - 통합 테스트
"""

import pytest

from src.ocr.text_corrector import (
    CorrectionResult,
    CorrectionStep,
    TextContext,
    TextCorrectionConfig,
    TextCorrector,
    create_default_correction_config,
    create_minimal_correction_config,
    create_numeric_only_correction_config,
)


# ========================================
# 테스트 픽스처
# ========================================


@pytest.fixture
def default_corrector() -> TextCorrector:
    """기본 설정의 TextCorrector 인스턴스를 반환합니다."""
    return TextCorrector()


@pytest.fixture
def numeric_corrector() -> TextCorrector:
    """숫자 전용 교정 설정의 TextCorrector 인스턴스를 반환합니다."""
    config = create_numeric_only_correction_config()
    return TextCorrector(config)


@pytest.fixture
def minimal_corrector() -> TextCorrector:
    """최소 설정의 TextCorrector 인스턴스를 반환합니다."""
    config = create_minimal_correction_config()
    return TextCorrector(config)


# ========================================
# 공백 정규화 테스트
# ========================================


class TestSpaceNormalization:
    """공백 정규화 테스트 클래스"""

    def test_word_internal_space_removal(self, default_corrector: TextCorrector) -> None:
        """단어 내부 공백 제거 테스트"""
        result = default_corrector.correct("Temper ature")
        assert result.corrected_text == "Temperature"
        assert "단어내부공백제거" in result.applied_corrections

    def test_camel_case_space_removal(self, default_corrector: TextCorrector) -> None:
        """CamelCase 내부 공백 제거 테스트"""
        result = default_corrector.correct("T emperature")
        assert result.corrected_text == "Temperature"
        assert "대소문자연결" in result.applied_corrections

    def test_digit_internal_space_removal(self, default_corrector: TextCorrector) -> None:
        """숫자 내부 공백 제거 테스트"""
        result = default_corrector.correct("123 45")
        assert result.corrected_text == "12345"
        assert "숫자내부공백제거" in result.applied_corrections

    def test_consecutive_space_normalization(self, default_corrector: TextCorrector) -> None:
        """연속 공백 단일화 테스트"""
        result = default_corrector.correct("Temperature:   25.5")
        assert "  " not in result.corrected_text
        assert "연속공백단일화" in result.applied_corrections

    def test_leading_trailing_space_removal(self, default_corrector: TextCorrector) -> None:
        """선행/후행 공백 제거 테스트"""
        result = default_corrector.correct("  Temperature  ")
        assert result.corrected_text == "Temperature"
        assert "선후행공백제거" in result.applied_corrections

    def test_no_change_for_correct_spacing(self, default_corrector: TextCorrector) -> None:
        """올바른 공백은 변경하지 않음"""
        result = default_corrector.correct("Temperature: 25.5")
        # 콜론 뒤 공백은 유지됨
        assert ": " in result.corrected_text or ":" in result.corrected_text

    def test_upper_upper_space_removal(self, default_corrector: TextCorrector) -> None:
        """대문자-공백-대문자 패턴 제거 테스트"""
        # 순수 대문자-공백-대문자 패턴
        result = default_corrector.correct("AB CD")
        assert result.corrected_text == "ABCD"
        assert "대문자연결" in result.applied_corrections

    def test_lower_upper_space_removal(self, default_corrector: TextCorrector) -> None:
        """소문자-공백-대문자 패턴 제거 테스트"""
        result = default_corrector.correct("pPeOr IXJgJC")
        assert result.corrected_text == "pPeOrIXJgJC"
        assert "소대문자연결" in result.applied_corrections

    def test_digit_alpha_space_removal(self, default_corrector: TextCorrector) -> None:
        """숫자-공백-영문자 패턴 제거 테스트"""
        result = default_corrector.correct("Q8 Ky")
        assert result.corrected_text == "Q8Ky"
        assert "숫자영문연결" in result.applied_corrections

    def test_alpha_digit_space_removal(self, default_corrector: TextCorrector) -> None:
        """영문자-공백-숫자 패턴 제거 테스트"""
        result = default_corrector.correct("Ky 8")
        assert result.corrected_text == "Ky8"
        assert "영문숫자연결" in result.applied_corrections

    def test_complex_mixed_pattern(self, default_corrector: TextCorrector) -> None:
        """복합 혼합 패턴 테스트 - 실제 문제 사례"""
        # 실제 문제: VYLvQ8Ky Lxzv4pPeOr IXJgJC
        result = default_corrector.correct("VYLvQ8Ky Lxzv4pPeOr IXJgJC")
        # 모든 공백이 제거되어야 함
        assert " " not in result.corrected_text
        assert result.corrected_text == "VYLvQ8KyLxzv4pPeOrIXJgJC"


# ========================================
# 컨텍스트 감지 테스트
# ========================================


class TestContextDetection:
    """컨텍스트 감지 테스트 클래스"""

    def test_detect_numeric_context(self, default_corrector: TextCorrector) -> None:
        """순수 숫자 컨텍스트 감지"""
        result = default_corrector.correct("123.45")
        assert result.detected_context == TextContext.NUMERIC

    def test_detect_measurement_context(self, default_corrector: TextCorrector) -> None:
        """측정값 컨텍스트 감지"""
        result = default_corrector.correct("25.5°C")
        assert result.detected_context == TextContext.MEASUREMENT

    def test_detect_error_code_context(self, default_corrector: TextCorrector) -> None:
        """에러 코드 컨텍스트 감지"""
        # E01 패턴
        result = default_corrector.correct("E01")
        assert result.detected_context == TextContext.ERROR_CODE

        # ERR-001 패턴
        result = default_corrector.correct("ERR-001")
        assert result.detected_context == TextContext.ERROR_CODE

    def test_detect_label_context(self, default_corrector: TextCorrector) -> None:
        """라벨 컨텍스트 감지"""
        result = default_corrector.correct("Temperature")
        assert result.detected_context == TextContext.LABEL

    def test_detect_mixed_context(self, default_corrector: TextCorrector) -> None:
        """혼합 컨텍스트 감지"""
        result = default_corrector.correct("Temperature: 25.5")
        assert result.detected_context == TextContext.MIXED


# ========================================
# 유사 문자 교정 테스트
# ========================================


class TestSimilarCharCorrection:
    """유사 문자 교정 테스트 클래스"""

    def test_exclamation_to_one_in_numeric(self, default_corrector: TextCorrector) -> None:
        """숫자 문맥에서 ! → 1 교정"""
        result = default_corrector.correct("!23.45")
        assert result.corrected_text == "123.45"
        assert any("!→1" in c for c in result.applied_corrections)

    def test_lowercase_l_to_one_in_numeric(self, default_corrector: TextCorrector) -> None:
        """숫자 문맥에서 l → 1 교정"""
        result = default_corrector.correct("l23.45")
        assert result.corrected_text == "123.45"

    def test_uppercase_o_to_zero_in_numeric(self, default_corrector: TextCorrector) -> None:
        """숫자 문맥에서 O → 0 교정"""
        result = default_corrector.correct("1O0")
        assert result.corrected_text == "100"

    def test_uppercase_s_to_five_in_numeric(self, default_corrector: TextCorrector) -> None:
        """숫자 문맥에서 S → 5 교정"""
        result = default_corrector.correct("1S0")
        assert result.corrected_text == "150"

    def test_uppercase_b_to_eight_in_numeric(self, default_corrector: TextCorrector) -> None:
        """숫자 문맥에서 B → 8 교정"""
        result = default_corrector.correct("1B0")
        assert result.corrected_text == "180"

    def test_error_code_correction(self, default_corrector: TextCorrector) -> None:
        """에러 코드 교정 (E0l → E01)"""
        result = default_corrector.correct("E0l")
        # 에러 코드 패턴이므로 숫자 부분만 교정
        assert result.corrected_text == "E01"

    def test_mixed_context_correction(self, default_corrector: TextCorrector) -> None:
        """혼합 컨텍스트 교정"""
        result = default_corrector.correct("Temperature: l23.45")
        # 콜론 뒤의 값은 숫자 컨텍스트로 교정
        assert "123.45" in result.corrected_text

    def test_preserve_text_in_label(self, default_corrector: TextCorrector) -> None:
        """라벨 텍스트 보존"""
        result = default_corrector.correct("Temperature")
        # 순수 라벨에서는 숫자→문자 교정만 적용
        assert result.corrected_text == "Temperature"


# ========================================
# 단위 정규화 테스트
# ========================================


class TestUnitNormalization:
    """단위 정규화 테스트 클래스"""

    def test_normalize_temperature_unit(self, default_corrector: TextCorrector) -> None:
        """온도 단위 정규화"""
        result = default_corrector.correct("25.5 0C")
        # 0C → °C 변환 확인
        assert "°C" in result.corrected_text or "0C" not in result.corrected_text

    def test_normalize_frequency_unit(self, default_corrector: TextCorrector) -> None:
        """주파수 단위 정규화"""
        result = default_corrector.correct("100 HZ")
        # HZ → Hz 변환 확인
        assert "Hz" in result.corrected_text or "HZ" not in result.corrected_text


# ========================================
# 신뢰도 조정 테스트
# ========================================


class TestConfidenceAdjustment:
    """신뢰도 조정 테스트 클래스"""

    def test_penalty_applied_for_corrections(self, default_corrector: TextCorrector) -> None:
        """교정 시 페널티 적용"""
        result = default_corrector.correct("l23.45")  # l→1 교정 발생
        # 교정이 적용되면 음수 delta
        if result.was_corrected:
            assert result.confidence_delta < 0

    def test_no_penalty_without_corrections(self, default_corrector: TextCorrector) -> None:
        """교정 없으면 페널티 없음 또는 보너스"""
        result = default_corrector.correct("123.45")
        # 교정이 없으면 delta >= 0 (패턴 매치 보너스 가능)
        assert result.confidence_delta >= -0.01 or not result.was_corrected

    def test_max_penalty_limit(self) -> None:
        """최대 페널티 제한 확인"""
        config = TextCorrectionConfig(max_confidence_penalty=0.05)
        corrector = TextCorrector(config)

        # 많은 교정이 발생하는 텍스트
        result = corrector.correct("OOOO")  # 4번 교정
        # 최대 페널티 이하인지 확인
        assert abs(result.confidence_delta) <= 0.05 + config.pattern_match_bonus


# ========================================
# 통합 테스트
# ========================================


class TestIntegration:
    """통합 테스트 클래스"""

    def test_full_pipeline_measurement(self, default_corrector: TextCorrector) -> None:
        """측정값 전체 파이프라인 테스트"""
        result = default_corrector.correct("Temper ature: l23.45°C")

        # 공백 정규화 확인
        assert "Temper ature" not in result.corrected_text

        # 유사 문자 교정 확인
        assert "l23" not in result.corrected_text
        assert "123" in result.corrected_text

        # 컨텍스트 확인 (공백 제거 후 측정값 패턴으로 감지될 수 있음)
        assert result.detected_context in (TextContext.MIXED, TextContext.MEASUREMENT)

    def test_full_pipeline_error_code(self, default_corrector: TextCorrector) -> None:
        """에러 코드 전체 파이프라인 테스트"""
        result = default_corrector.correct("ERR-O0l")

        # 에러 코드 숫자 부분 교정
        assert "001" in result.corrected_text or "O0l" not in result.corrected_text

    def test_empty_string_handling(self, default_corrector: TextCorrector) -> None:
        """빈 문자열 처리"""
        result = default_corrector.correct("")
        assert result.corrected_text == ""
        assert result.detected_context == TextContext.UNKNOWN
        assert result.confidence_delta == 0.0

    def test_whitespace_only_handling(self, default_corrector: TextCorrector) -> None:
        """공백만 있는 문자열 처리"""
        result = default_corrector.correct("   ")
        assert result.corrected_text == ""


# ========================================
# 설정 테스트
# ========================================


class TestConfiguration:
    """설정 테스트 클래스"""

    def test_default_config_creation(self) -> None:
        """기본 설정 생성"""
        config = create_default_correction_config()
        assert config.enable_space_normalize is True
        assert config.enable_similar_char_correction is True

    def test_numeric_only_config_creation(self) -> None:
        """숫자 전용 설정 생성"""
        config = create_numeric_only_correction_config()
        assert config.enable_context_detection is False

    def test_minimal_config_creation(self) -> None:
        """최소 설정 생성"""
        config = create_minimal_correction_config()
        assert config.enable_similar_char_correction is False
        assert config.enable_space_normalize is True

    def test_custom_pipeline_order(self) -> None:
        """커스텀 파이프라인 순서"""
        custom_order = (CorrectionStep.SPACE_NORMALIZE,)
        config = TextCorrectionConfig(pipeline_order=custom_order)

        assert config.get_pipeline_order() == custom_order

    def test_disabled_steps(self) -> None:
        """비활성화된 단계 확인"""
        config = TextCorrectionConfig(
            enable_space_normalize=False,
            enable_similar_char_correction=False,
        )
        corrector = TextCorrector(config)

        result = corrector.correct("Temper ature: l23.45")

        # 공백 정규화가 비활성화되어 있으므로 공백 유지
        assert "Temper ature" in result.corrected_text
        # 유사 문자 교정도 비활성화되어 있으므로 l 유지
        assert "l23" in result.corrected_text


# ========================================
# CorrectionResult 테스트
# ========================================


class TestCorrectionResult:
    """CorrectionResult 테스트 클래스"""

    def test_was_corrected_true(self) -> None:
        """교정 여부 확인 (True)"""
        result = CorrectionResult(
            original_text="l23",
            corrected_text="123",
        )
        assert result.was_corrected is True

    def test_was_corrected_false(self) -> None:
        """교정 여부 확인 (False)"""
        result = CorrectionResult(
            original_text="123",
            corrected_text="123",
        )
        assert result.was_corrected is False

    def test_correction_count(self) -> None:
        """교정 개수 확인"""
        result = CorrectionResult(
            original_text="l23",
            corrected_text="123",
            applied_corrections=("l→1", "공백제거"),
        )
        assert result.correction_count == 2


# ========================================
# 엣지 케이스 테스트
# ========================================


class TestEdgeCases:
    """엣지 케이스 테스트 클래스"""

    def test_unicode_handling(self, default_corrector: TextCorrector) -> None:
        """유니코드 문자 처리"""
        result = default_corrector.correct("25.5°C")
        assert "°" in result.corrected_text

    def test_special_characters(self, default_corrector: TextCorrector) -> None:
        """특수 문자 처리"""
        result = default_corrector.correct("100%")
        assert "%" in result.corrected_text

    def test_negative_numbers(self, default_corrector: TextCorrector) -> None:
        """음수 처리"""
        result = default_corrector.correct("-l23.45")
        assert result.corrected_text == "-123.45"

    def test_decimal_numbers(self, default_corrector: TextCorrector) -> None:
        """소수 처리"""
        result = default_corrector.correct("0.l23")
        assert result.corrected_text == "0.123"

    def test_hint_context_override(self, default_corrector: TextCorrector) -> None:
        """힌트 컨텍스트 오버라이드"""
        # 숫자 힌트를 주면 숫자 컨텍스트로 처리
        result = default_corrector.correct("ABC", hint_context=TextContext.NUMERIC)
        # ABC에서 B→8 교정이 적용될 수 있음
        assert result.detected_context == TextContext.NUMERIC
