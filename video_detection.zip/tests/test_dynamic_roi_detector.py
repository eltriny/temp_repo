"""동적 ROI 탐지 오케스트레이터 통합 테스트

DynamicROIDetector의 통합 동작을 검증합니다:
    - 텍스트 + 파형 탐지기 조합
    - IoU 기반 중복 ROI 병합
    - 고유 ID 할당
    - 개별 탐지기 비활성화
    - 빈 입력 / 에러 처리
"""

from unittest.mock import MagicMock, patch

import cv2
import numpy as np
import pytest

from src.detection.dynamic_roi_detector import (
    DynamicROIConfig,
    DynamicROIDetector,
)
from src.detection.roi_types import BoundingBox, ROI, ROIType
from src.detection.text_roi_detector import TextROIDetectorConfig
from src.detection.waveform_detector import WaveformDetectorConfig


# ========================================
# Mock 헬퍼
# ========================================


def _make_text_roi(roi_id: str, x: int, y: int, w: int, h: int,
                   text: str = "25.5°C", confidence: float = 0.9) -> ROI:
    """텍스트 탐지 결과 ROI 생성"""
    return ROI(
        id=roi_id,
        bbox=BoundingBox(x=x, y=y, width=w, height=h),
        roi_type=ROIType.NUMERIC,
        confidence=confidence,
        label=f"temperature: {text}",
        metadata={
            "source": "auto_detected",
            "detection_method": "text",
            "pattern_category": "temperature",
            "original_text": text,
        },
    )


def _make_waveform_roi(roi_id: str, x: int, y: int, w: int, h: int,
                        confidence: float = 0.7) -> ROI:
    """파형 탐지 결과 ROI 생성"""
    return ROI(
        id=roi_id,
        bbox=BoundingBox(x=x, y=y, width=w, height=h),
        roi_type=ROIType.CHART,
        confidence=confidence,
        label=f"waveform_0",
        metadata={
            "source": "auto_detected",
            "detection_method": "waveform",
            "pattern_category": "waveform",
        },
    )


# ========================================
# 테스트 픽스처
# ========================================


@pytest.fixture
def sample_frame():
    """테스트용 빈 프레임 (BGR)"""
    return np.zeros((480, 640, 3), dtype=np.uint8)


@pytest.fixture
def frame_with_content():
    """텍스트와 파형이 포함된 합성 프레임"""
    frame = np.full((480, 640, 3), (30, 30, 30), dtype=np.uint8)

    # 텍스트 영역 시뮬레이션 (흰 텍스트)
    cv2.putText(frame, "25.5C", (100, 50), cv2.FONT_HERSHEY_SIMPLEX,
                0.8, (255, 255, 255), 2)

    # 파형 시뮬레이션 (사인파)
    for x in range(50, 590):
        y = int(300 + 20 * np.sin(2 * np.pi * 3 * x / 540))
        cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)

    return frame


# ========================================
# 조합 탐지 테스트
# ========================================


class TestCombinedDetection:
    """텍스트 + 파형 조합 탐지"""

    def test_both_detectors_combined(self, sample_frame):
        """두 탐지기 결과가 합산됨 (mock)"""
        text_rois = [_make_text_roi("t0", 100, 50, 150, 30)]
        waveform_rois = [_make_waveform_roi("w0", 50, 280, 540, 60)]

        with patch.object(
            DynamicROIDetector, "__init__", lambda self, **kw: None
        ):
            detector = DynamicROIDetector.__new__(DynamicROIDetector)
            detector.config = DynamicROIConfig()
            detector._text_detector = MagicMock()
            detector._waveform_detector = MagicMock()
            detector._text_detector.detect.return_value = text_rois
            detector._waveform_detector.detect.return_value = waveform_rois

            rois = detector.detect(sample_frame)

        assert len(rois) == 2
        # ID 재할당 확인
        ids = {r.id for r in rois}
        assert "auto_text_0" in ids
        assert "auto_waveform_0" in ids

    def test_text_only_mode(self, sample_frame):
        """파형 탐지 비활성화"""
        config = DynamicROIConfig(enable_waveform_detection=False)
        mock_engine = MagicMock()

        with patch(
            "src.detection.text_roi_detector.TextROIDetector.detect"
        ) as mock_detect:
            mock_detect.return_value = [_make_text_roi("t0", 100, 50, 150, 30)]

            detector = DynamicROIDetector(config=config, ocr_engine=mock_engine)
            rois = detector.detect(sample_frame)

        assert len(rois) == 1
        assert rois[0].metadata["detection_method"] == "text"

    def test_waveform_only_mode(self, sample_frame):
        """텍스트 탐지 비활성화"""
        config = DynamicROIConfig(enable_text_detection=False)

        with patch(
            "src.detection.waveform_detector.WaveformDetector.detect"
        ) as mock_detect:
            mock_detect.return_value = [_make_waveform_roi("w0", 50, 280, 540, 60)]

            detector = DynamicROIDetector(config=config)
            rois = detector.detect(sample_frame)

        assert len(rois) == 1
        assert rois[0].metadata["detection_method"] == "waveform"


# ========================================
# 중복 병합 테스트
# ========================================


class TestOverlapMerging:
    """_merge_overlapping_rois IoU 기반 병합"""

    def test_no_overlap_keeps_all(self):
        """겹치지 않는 ROI는 모두 보존"""
        config = DynamicROIConfig()
        detector = DynamicROIDetector.__new__(DynamicROIDetector)
        detector.config = config

        rois = [
            _make_text_roi("t0", 100, 50, 150, 30),
            _make_waveform_roi("w0", 100, 300, 400, 60),
        ]
        merged = detector._merge_overlapping_rois(rois)
        assert len(merged) == 2

    def test_overlapping_text_absorbs_waveform(self):
        """텍스트 ROI가 겹치는 파형 ROI를 흡수"""
        config = DynamicROIConfig(iou_merge_threshold=0.3)
        detector = DynamicROIDetector.__new__(DynamicROIDetector)
        detector.config = config

        # 거의 같은 영역
        rois = [
            _make_text_roi("t0", 100, 100, 200, 50, confidence=0.9),
            _make_waveform_roi("w0", 110, 105, 190, 45, confidence=0.7),
        ]
        merged = detector._merge_overlapping_rois(rois)
        assert len(merged) == 1
        # 텍스트 ROI가 우선
        assert merged[0].metadata["detection_method"] == "text"

    def test_partial_overlap_below_threshold(self):
        """IoU가 임계값 미만이면 병합 안 됨"""
        config = DynamicROIConfig(iou_merge_threshold=0.5)
        detector = DynamicROIDetector.__new__(DynamicROIDetector)
        detector.config = config

        # 약간만 겹침
        rois = [
            _make_text_roi("t0", 100, 100, 100, 50),
            _make_waveform_roi("w0", 180, 100, 100, 50),
            # 겹치는 영역: x=180~200 (20px 폭) * 50 높이 = 1000
            # union = 100*50 + 100*50 - 1000 = 9000
            # IoU = 1000/9000 ≈ 0.11 < 0.5
        ]
        merged = detector._merge_overlapping_rois(rois)
        assert len(merged) == 2

    def test_single_roi_passthrough(self):
        """단일 ROI는 그대로 통과"""
        config = DynamicROIConfig()
        detector = DynamicROIDetector.__new__(DynamicROIDetector)
        detector.config = config

        rois = [_make_text_roi("t0", 100, 50, 150, 30)]
        merged = detector._merge_overlapping_rois(rois)
        assert len(merged) == 1

    def test_empty_list_passthrough(self):
        """빈 리스트 통과"""
        config = DynamicROIConfig()
        detector = DynamicROIDetector.__new__(DynamicROIDetector)
        detector.config = config

        merged = detector._merge_overlapping_rois([])
        assert merged == []


# ========================================
# ID 할당 테스트
# ========================================


class TestAssignIds:
    """_assign_ids 순차적 ID 할당"""

    def test_sequential_text_ids(self):
        rois = [
            _make_text_roi("old_0", 100, 50, 150, 30),
            _make_text_roi("old_1", 100, 150, 150, 30),
        ]
        result = DynamicROIDetector._assign_ids(rois)
        assert result[0].id == "auto_text_0"
        assert result[1].id == "auto_text_1"

    def test_sequential_waveform_ids(self):
        rois = [
            _make_waveform_roi("old_0", 50, 280, 540, 60),
            _make_waveform_roi("old_1", 50, 380, 540, 60),
        ]
        result = DynamicROIDetector._assign_ids(rois)
        assert result[0].id == "auto_waveform_0"
        assert result[1].id == "auto_waveform_1"

    def test_mixed_ids(self):
        """텍스트와 파형이 섞인 경우 각자 카운터 사용"""
        rois = [
            _make_text_roi("old_0", 100, 50, 150, 30),
            _make_waveform_roi("old_1", 50, 280, 540, 60),
            _make_text_roi("old_2", 100, 150, 150, 30),
        ]
        result = DynamicROIDetector._assign_ids(rois)
        assert result[0].id == "auto_text_0"
        assert result[1].id == "auto_waveform_0"
        assert result[2].id == "auto_text_1"

    def test_preserves_metadata(self):
        """ID 할당 시 기존 메타데이터 보존"""
        roi = _make_text_roi("old", 100, 50, 150, 30, text="42.0°C")
        result = DynamicROIDetector._assign_ids([roi])
        assert result[0].metadata["original_text"] == "42.0°C"
        assert result[0].confidence == 0.9

    def test_empty_list(self):
        result = DynamicROIDetector._assign_ids([])
        assert result == []


# ========================================
# 에러 처리 테스트
# ========================================


class TestErrorHandling:
    """에러 발생 시 안전한 처리"""

    def test_text_detector_error_continues(self, sample_frame):
        """텍스트 탐지 에러 시 파형 탐지 계속"""
        with patch.object(
            DynamicROIDetector, "__init__", lambda self, **kw: None
        ):
            detector = DynamicROIDetector.__new__(DynamicROIDetector)
            detector.config = DynamicROIConfig()
            detector._text_detector = MagicMock()
            detector._waveform_detector = MagicMock()
            detector._text_detector.detect.side_effect = RuntimeError("OCR 에러")
            detector._waveform_detector.detect.return_value = [
                _make_waveform_roi("w0", 50, 280, 540, 60)
            ]

            rois = detector.detect(sample_frame)

        # 텍스트 에러에도 파형 결과 반환
        assert len(rois) == 1
        assert rois[0].metadata["detection_method"] == "waveform"

    def test_waveform_detector_error_continues(self, sample_frame):
        """파형 탐지 에러 시 텍스트 탐지 결과만 반환"""
        with patch.object(
            DynamicROIDetector, "__init__", lambda self, **kw: None
        ):
            detector = DynamicROIDetector.__new__(DynamicROIDetector)
            detector.config = DynamicROIConfig()
            detector._text_detector = MagicMock()
            detector._waveform_detector = MagicMock()
            detector._text_detector.detect.return_value = [
                _make_text_roi("t0", 100, 50, 150, 30)
            ]
            detector._waveform_detector.detect.side_effect = RuntimeError("CV 에러")

            rois = detector.detect(sample_frame)

        assert len(rois) == 1
        assert rois[0].metadata["detection_method"] == "text"

    def test_both_detectors_error_returns_empty(self, sample_frame):
        """양쪽 모두 에러 시 빈 리스트"""
        with patch.object(
            DynamicROIDetector, "__init__", lambda self, **kw: None
        ):
            detector = DynamicROIDetector.__new__(DynamicROIDetector)
            detector.config = DynamicROIConfig()
            detector._text_detector = MagicMock()
            detector._waveform_detector = MagicMock()
            detector._text_detector.detect.side_effect = RuntimeError("에러1")
            detector._waveform_detector.detect.side_effect = RuntimeError("에러2")

            rois = detector.detect(sample_frame)

        assert rois == []

    def test_none_frame_returns_empty(self):
        """None 프레임 → 빈 리스트"""
        detector = DynamicROIDetector(
            config=DynamicROIConfig(
                enable_text_detection=False,
                enable_waveform_detection=False,
            )
        )
        rois = detector.detect(None)
        assert rois == []

    def test_empty_frame_returns_empty(self):
        """빈 프레임 → 빈 리스트"""
        detector = DynamicROIDetector(
            config=DynamicROIConfig(
                enable_text_detection=False,
                enable_waveform_detection=False,
            )
        )
        empty = np.array([], dtype=np.uint8)
        rois = detector.detect(empty)
        assert rois == []


# ========================================
# 설정 테스트
# ========================================


class TestDynamicROIConfig:
    """DynamicROIConfig 설정 검증"""

    def test_default_config(self):
        config = DynamicROIConfig()
        assert config.enable_text_detection is True
        assert config.enable_waveform_detection is True
        assert config.iou_merge_threshold == 0.5
        assert config.default_threshold == 0.1

    def test_custom_sub_configs(self):
        """서브 탐지기 설정 전달"""
        text_cfg = TextROIDetectorConfig(confidence_threshold=0.8)
        wave_cfg = WaveformDetectorConfig(min_area=1000)

        config = DynamicROIConfig(
            text_config=text_cfg,
            waveform_config=wave_cfg,
        )
        assert config.text_config.confidence_threshold == 0.8
        assert config.waveform_config.min_area == 1000

    def test_disable_both_detectors(self):
        """둘 다 비활성화해도 에러 없음"""
        config = DynamicROIConfig(
            enable_text_detection=False,
            enable_waveform_detection=False,
        )
        detector = DynamicROIDetector(config=config)

        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        rois = detector.detect(frame)
        assert rois == []
