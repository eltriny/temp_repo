"""pytest 설정 및 공용 fixture

이 파일은 모든 테스트에서 공유되는 fixture와 pytest 설정을 포함합니다.
"""

import sys
from pathlib import Path

import pytest

# 프로젝트 루트를 PYTHONPATH에 추가
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


def pytest_configure(config):
    """pytest 설정 시 실행되는 훅"""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )


@pytest.fixture(scope="session")
def project_root_path():
    """프로젝트 루트 경로 반환"""
    return project_root


@pytest.fixture(scope="session")
def test_data_path(project_root_path):
    """테스트 데이터 경로 반환"""
    return project_root_path / "data"
