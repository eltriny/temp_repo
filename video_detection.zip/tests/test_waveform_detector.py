"""파형 ROI 탐지기 단위 테스트

WaveformDetector의 핵심 기능을 검증합니다:
    - 합성 파형 이미지에서 탐지
    - 프로젝션 프로파일 분석
    - 연결 성분 분석
    - 중복 BoundingBox 병합
    - 빈/무효 입력 처리
"""

import numpy as np
import cv2
import pytest

from src.detection.waveform_detector import WaveformDetector, WaveformDetectorConfig
from src.detection.roi_types import BoundingBox, ROIType


# ========================================
# 합성 이미지 생성 헬퍼
# ========================================


def create_blank_frame(
    width: int = 640, height: int = 480, color: tuple = (30, 30, 30)
) -> np.ndarray:
    """단색 배경 프레임 생성"""
    frame = np.full((height, width, 3), color, dtype=np.uint8)
    return frame


def draw_sine_wave(
    frame: np.ndarray,
    y_center: int,
    amplitude: int = 20,
    frequency: float = 2.0,
    x_start: int = 50,
    x_end: int = 590,
    color: tuple = (0, 255, 0),
    thickness: int = 2,
) -> np.ndarray:
    """프레임에 사인파 그리기"""
    result = frame.copy()
    points = []
    for x in range(x_start, x_end):
        t = (x - x_start) / (x_end - x_start)
        y = int(y_center + amplitude * np.sin(2 * np.pi * frequency * t))
        points.append((x, y))

    for i in range(len(points) - 1):
        cv2.line(result, points[i], points[i + 1], color, thickness)

    return result


def draw_horizontal_line(
    frame: np.ndarray,
    y: int,
    x_start: int = 50,
    x_end: int = 590,
    color: tuple = (0, 200, 200),
    thickness: int = 2,
) -> np.ndarray:
    """프레임에 수평선 그리기"""
    result = frame.copy()
    cv2.line(result, (x_start, y), (x_end, y), color, thickness)
    return result


def add_noise(frame: np.ndarray, intensity: int = 15) -> np.ndarray:
    """프레임에 가우시안 노이즈 추가"""
    noise = np.random.normal(0, intensity, frame.shape).astype(np.int16)
    noisy = np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    return noisy


# ========================================
# 테스트 픽스처
# ========================================


@pytest.fixture
def detector() -> WaveformDetector:
    """기본 설정의 WaveformDetector"""
    return WaveformDetector()


@pytest.fixture
def sensitive_detector() -> WaveformDetector:
    """민감한 설정의 WaveformDetector"""
    config = WaveformDetectorConfig(
        min_component_width_ratio=0.05,
        min_area=200,
        min_band_height_px=3,
    )
    return WaveformDetector(config=config)


@pytest.fixture
def frame_with_sine_wave():
    """사인파가 포함된 테스트 프레임"""
    frame = create_blank_frame(640, 480)
    frame = draw_sine_wave(frame, y_center=240, amplitude=30, frequency=3.0)
    return frame


@pytest.fixture
def frame_with_horizontal_line():
    """수평선이 포함된 테스트 프레임"""
    frame = create_blank_frame(640, 480)
    frame = draw_horizontal_line(frame, y=200)
    return frame


@pytest.fixture
def frame_with_multiple_waves():
    """여러 파형이 포함된 테스트 프레임"""
    frame = create_blank_frame(640, 480)
    frame = draw_sine_wave(frame, y_center=100, amplitude=15, frequency=4.0,
                           color=(0, 255, 0))
    frame = draw_sine_wave(frame, y_center=350, amplitude=20, frequency=2.0,
                           color=(255, 100, 0))
    return frame


@pytest.fixture
def blank_frame():
    """빈 (단색 배경) 프레임"""
    return create_blank_frame(640, 480)


# ========================================
# 기본 탐지 테스트
# ========================================


class TestBasicDetection:
    """기본 파형 탐지 기능"""

    def test_detect_sine_wave(self, sensitive_detector, frame_with_sine_wave):
        """사인파 탐지"""
        rois = sensitive_detector.detect(frame_with_sine_wave)
        assert len(rois) >= 1
        for roi in rois:
            assert roi.roi_type == ROIType.CHART
            assert roi.metadata["detection_method"] == "waveform"

    def test_detect_horizontal_line(self, sensitive_detector, frame_with_horizontal_line):
        """수평선 탐지"""
        rois = sensitive_detector.detect(frame_with_horizontal_line)
        assert len(rois) >= 1

    def test_no_detection_on_blank(self, detector, blank_frame):
        """빈 프레임에서는 탐지 없음"""
        rois = detector.detect(blank_frame)
        assert len(rois) == 0

    def test_empty_array_input(self, detector):
        """빈 배열 입력 시 빈 리스트 반환"""
        empty = np.array([], dtype=np.uint8)
        rois = detector.detect(empty)
        assert rois == []

    def test_none_input(self, detector):
        """None 입력 시 빈 리스트 반환"""
        rois = detector.detect(None)
        assert rois == []


# ========================================
# ROI 속성 검증
# ========================================


class TestROIProperties:
    """탐지된 ROI의 속성 검증"""

    def test_roi_has_correct_type(self, sensitive_detector, frame_with_sine_wave):
        rois = sensitive_detector.detect(frame_with_sine_wave)
        for roi in rois:
            assert roi.roi_type == ROIType.CHART

    def test_roi_has_confidence(self, sensitive_detector, frame_with_sine_wave):
        rois = sensitive_detector.detect(frame_with_sine_wave)
        for roi in rois:
            assert 0.0 < roi.confidence <= 1.0

    def test_roi_has_waveform_metadata(self, sensitive_detector, frame_with_sine_wave):
        rois = sensitive_detector.detect(frame_with_sine_wave)
        for roi in rois:
            assert roi.metadata["source"] == "auto_detected"
            assert roi.metadata["detection_method"] == "waveform"
            assert roi.metadata["pattern_category"] == "waveform"

    def test_roi_id_format(self, sensitive_detector, frame_with_sine_wave):
        rois = sensitive_detector.detect(frame_with_sine_wave)
        for roi in rois:
            assert roi.id.startswith("auto_waveform_")

    def test_roi_bbox_within_frame(self, sensitive_detector, frame_with_sine_wave):
        """ROI bbox가 프레임 경계 안에 있어야 함"""
        h, w = frame_with_sine_wave.shape[:2]
        rois = sensitive_detector.detect(frame_with_sine_wave)
        for roi in rois:
            assert roi.bbox.x >= 0
            assert roi.bbox.y >= 0
            assert roi.bbox.x + roi.bbox.width <= w
            assert roi.bbox.y + roi.bbox.height <= h


# ========================================
# 노이즈 환경 테스트
# ========================================


class TestNoiseResilience:
    """노이즈 환경에서의 탐지 능력"""

    def test_detect_with_light_noise(self, sensitive_detector):
        """가벼운 노이즈 환경에서 파형 탐지"""
        frame = create_blank_frame(640, 480)
        frame = draw_sine_wave(frame, y_center=240, amplitude=25,
                               color=(0, 255, 0), thickness=3)
        frame = add_noise(frame, intensity=10)

        rois = sensitive_detector.detect(frame)
        assert len(rois) >= 1

    def test_detect_with_heavy_noise(self, sensitive_detector):
        """강한 노이즈에서도 굵은 파형 탐지 시도"""
        frame = create_blank_frame(640, 480)
        frame = draw_sine_wave(frame, y_center=240, amplitude=30,
                               color=(0, 255, 0), thickness=4)
        frame = add_noise(frame, intensity=30)

        # 강한 노이즈에서는 탐지 실패할 수 있음 (정상적인 동작)
        rois = sensitive_detector.detect(frame)
        # 탐지되거나 안 되거나 둘 다 유효한 결과
        assert isinstance(rois, list)


# ========================================
# 프로젝션 프로파일 테스트
# ========================================


class TestProjectionAnalysis:
    """_detect_by_projection 내부 메서드 테스트"""

    def test_find_active_bands_single(self):
        """단일 활성 밴드 탐지"""
        projection = np.zeros(100, dtype=np.float64)
        projection[30:50] = 0.5  # 30~49 행 활성
        bands = WaveformDetector._find_active_bands(projection, threshold=0.3)
        assert len(bands) == 1
        assert bands[0] == (30, 50)

    def test_find_active_bands_multiple(self):
        """복수 활성 밴드 탐지"""
        projection = np.zeros(200, dtype=np.float64)
        projection[20:40] = 0.6
        projection[100:130] = 0.8
        bands = WaveformDetector._find_active_bands(projection, threshold=0.3)
        assert len(bands) == 2

    def test_find_active_bands_none(self):
        """활성 밴드 없음"""
        projection = np.zeros(100, dtype=np.float64)
        bands = WaveformDetector._find_active_bands(projection, threshold=0.3)
        assert len(bands) == 0

    def test_find_active_bands_at_end(self):
        """프로파일 끝에서 밴드 종료"""
        projection = np.zeros(100, dtype=np.float64)
        projection[80:] = 0.5
        bands = WaveformDetector._find_active_bands(projection, threshold=0.3)
        assert len(bands) == 1
        assert bands[0] == (80, 100)


# ========================================
# BoundingBox 병합 테스트
# ========================================


class TestMergeOverlappingBboxes:
    """_merge_overlapping_bboxes 메서드 테스트"""

    def test_no_overlap_no_merge(self, detector):
        """겹치지 않는 bbox는 병합 안 됨"""
        bboxes = [
            BoundingBox(x=0, y=0, width=100, height=50),
            BoundingBox(x=200, y=200, width=100, height=50),
        ]
        result = detector._merge_overlapping_bboxes(bboxes)
        assert len(result) == 2

    def test_full_overlap_merge(self, detector):
        """완전히 겹치는 bbox는 병합"""
        bboxes = [
            BoundingBox(x=100, y=100, width=200, height=100),
            BoundingBox(x=120, y=110, width=160, height=80),
        ]
        result = detector._merge_overlapping_bboxes(bboxes)
        assert len(result) == 1

    def test_single_bbox(self, detector):
        """단일 bbox는 그대로 반환"""
        bboxes = [BoundingBox(x=10, y=20, width=100, height=50)]
        result = detector._merge_overlapping_bboxes(bboxes)
        assert len(result) == 1
        assert result[0] == bboxes[0]

    def test_empty_list(self, detector):
        """빈 리스트"""
        result = detector._merge_overlapping_bboxes([])
        assert result == []

    def test_merged_bbox_encompasses_all(self, detector):
        """병합된 bbox가 원본들을 모두 감싸야 함"""
        bboxes = [
            BoundingBox(x=100, y=100, width=200, height=100),
            BoundingBox(x=150, y=120, width=200, height=80),
        ]
        # IoU가 충분히 높으면 병합됨
        result = detector._merge_overlapping_bboxes(bboxes)

        if len(result) == 1:
            merged = result[0]
            # 병합 결과가 원본 모두를 감싸야 함
            assert merged.x <= 100
            assert merged.y <= 100
            assert merged.x + merged.width >= 350  # max(300, 350)
            assert merged.y + merged.height >= 200  # max(200, 200)


# ========================================
# 설정 변경 테스트
# ========================================


class TestConfiguration:
    """WaveformDetectorConfig 설정 영향 테스트"""

    def test_high_min_area_filters_small_waveforms(self):
        """min_area 높이면 작은 파형 필터링"""
        config = WaveformDetectorConfig(min_area=50000)
        detector = WaveformDetector(config=config)

        frame = create_blank_frame(640, 480)
        frame = draw_sine_wave(frame, y_center=240, amplitude=15)

        rois = detector.detect(frame)
        # 높은 min_area로 대부분 필터링됨
        # 작은 파형은 면적 조건 미달
        assert isinstance(rois, list)

    def test_default_config_values(self):
        """기본 설정값 확인"""
        config = WaveformDetectorConfig()
        assert config.blur_kernel_size == (5, 5)
        assert config.canny_threshold1 == 50
        assert config.canny_threshold2 == 150
        assert config.min_component_aspect_ratio == 2.0
        assert config.iou_merge_threshold == 0.3
