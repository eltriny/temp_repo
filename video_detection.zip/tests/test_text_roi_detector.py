"""텍스트 ROI 탐지기 단위 테스트

TextROIDetector의 핵심 기능을 검증합니다:
    - 패턴 분류 (_classify_text)
    - OCR BoundingBox → detection BoundingBox 변환
    - 같은 줄 인접 ROI 병합
    - 전체 detect 흐름 (OCR 엔진 모킹)
"""

from unittest.mock import MagicMock, patch
from dataclasses import dataclass

import numpy as np
import pytest

from src.detection.text_roi_detector import (
    PatternCategory,
    TextPattern,
    TextROIDetector,
    TextROIDetectorConfig,
)
from src.detection.roi_types import BoundingBox, ROI, ROIType


# ========================================
# Mock OCR 결과 헬퍼
# ========================================


@dataclass
class MockOCRBoundingBox:
    """OCR 엔진의 BoundingBox를 모방하는 mock 객체"""
    x_min: int
    y_min: int
    x_max: int
    y_max: int


@dataclass
class MockOCRResult:
    """OCR 엔진의 OCRResult를 모방하는 mock 객체"""
    text: str
    confidence: float
    bounding_box: MockOCRBoundingBox
    raw_text: str = ""


# ========================================
# 테스트 픽스처
# ========================================


@pytest.fixture
def detector() -> TextROIDetector:
    """기본 설정의 TextROIDetector (OCR 엔진은 None)"""
    return TextROIDetector(ocr_engine=MagicMock())


@pytest.fixture
def strict_detector() -> TextROIDetector:
    """높은 신뢰도 임계값의 TextROIDetector"""
    config = TextROIDetectorConfig(confidence_threshold=0.9)
    return TextROIDetector(config=config, ocr_engine=MagicMock())


# ========================================
# 패턴 분류 테스트
# ========================================


class TestClassifyText:
    """_classify_text 메서드 테스트"""

    def test_temperature_celsius(self, detector):
        cat, rt = detector._classify_text("25.5°C")
        assert cat == PatternCategory.TEMPERATURE
        assert rt == ROIType.NUMERIC

    def test_temperature_fahrenheit(self, detector):
        cat, _ = detector._classify_text("98.6F")
        assert cat == PatternCategory.TEMPERATURE

    def test_temperature_with_label(self, detector):
        cat, _ = detector._classify_text("Temperature: 72.3°C")
        assert cat == PatternCategory.TEMPERATURE

    def test_negative_temperature(self, detector):
        cat, _ = detector._classify_text("-15.2°C")
        assert cat == PatternCategory.TEMPERATURE

    def test_percentage(self, detector):
        cat, rt = detector._classify_text("85.3%")
        assert cat == PatternCategory.PERCENTAGE
        assert rt == ROIType.NUMERIC

    def test_percentage_negative(self, detector):
        cat, _ = detector._classify_text("-2.5%")
        assert cat == PatternCategory.PERCENTAGE

    def test_timestamp_hhmm(self, detector):
        cat, rt = detector._classify_text("14:30")
        assert cat == PatternCategory.TIMESTAMP
        assert rt == ROIType.TEXT

    def test_timestamp_hhmmss(self, detector):
        cat, _ = detector._classify_text("14:30:05")
        assert cat == PatternCategory.TIMESTAMP

    def test_pressure_bar(self, detector):
        cat, _ = detector._classify_text("2.5 bar")
        assert cat == PatternCategory.PRESSURE

    def test_pressure_kpa(self, detector):
        cat, _ = detector._classify_text("101.3 kPa")
        assert cat == PatternCategory.PRESSURE

    def test_frequency_hz(self, detector):
        cat, _ = detector._classify_text("60 Hz")
        assert cat == PatternCategory.FREQUENCY

    def test_frequency_mhz(self, detector):
        cat, _ = detector._classify_text("2.4 GHz")
        assert cat == PatternCategory.FREQUENCY

    def test_labeled_value_english(self, detector):
        cat, _ = detector._classify_text("Speed: 1500")
        assert cat == PatternCategory.LABELED_VALUE

    def test_labeled_value_korean(self, detector):
        cat, _ = detector._classify_text("온도=25.5")
        assert cat == PatternCategory.LABELED_VALUE

    def test_labeled_value_with_equals(self, detector):
        cat, _ = detector._classify_text("RPM=3200")
        assert cat == PatternCategory.LABELED_VALUE

    def test_status_text_running(self, detector):
        cat, rt = detector._classify_text("RUNNING")
        assert cat == PatternCategory.STATUS_TEXT
        assert rt == ROIType.TEXT

    def test_status_text_error(self, detector):
        cat, _ = detector._classify_text("ERROR")
        assert cat == PatternCategory.STATUS_TEXT

    def test_status_text_standby(self, detector):
        cat, _ = detector._classify_text("STANDBY")
        assert cat == PatternCategory.STATUS_TEXT

    def test_numeric_value_decimal(self, detector):
        cat, rt = detector._classify_text("123.456")
        assert cat == PatternCategory.NUMERIC_VALUE
        assert rt == ROIType.NUMERIC

    def test_unknown_random_text(self, detector):
        cat, rt = detector._classify_text("Hello World")
        assert cat == PatternCategory.UNKNOWN
        assert rt == ROIType.UNKNOWN

    def test_unknown_empty_string(self, detector):
        cat, _ = detector._classify_text("")
        assert cat == PatternCategory.UNKNOWN

    def test_unknown_whitespace(self, detector):
        cat, _ = detector._classify_text("   ")
        assert cat == PatternCategory.UNKNOWN

    def test_priority_temperature_over_numeric(self, detector):
        """온도 패턴이 단순 숫자보다 우선"""
        cat, _ = detector._classify_text("25.5°C")
        assert cat == PatternCategory.TEMPERATURE

    def test_priority_percentage_over_numeric(self, detector):
        """퍼센트 패턴이 단순 숫자보다 우선"""
        cat, _ = detector._classify_text("99.9%")
        assert cat == PatternCategory.PERCENTAGE


# ========================================
# BoundingBox 변환 테스트
# ========================================


class TestConvertOCRBbox:
    """_convert_ocr_bbox 메서드 테스트"""

    def test_basic_conversion(self, detector):
        ocr_bbox = MockOCRBoundingBox(x_min=100, y_min=200, x_max=300, y_max=250)
        frame_shape = (1080, 1920, 3)

        bbox = detector._convert_ocr_bbox(ocr_bbox, frame_shape)

        # padding=5 기본값 적용
        assert bbox.x == 95  # 100 - 5
        assert bbox.y == 195  # 200 - 5
        assert bbox.width == 210  # (300+5) - (100-5)
        assert bbox.height == 60  # (250+5) - (200-5)

    def test_clipping_at_origin(self, detector):
        """좌상단 모서리 근처에서 음수 방지 클리핑"""
        ocr_bbox = MockOCRBoundingBox(x_min=2, y_min=3, x_max=50, y_max=30)
        frame_shape = (1080, 1920, 3)

        bbox = detector._convert_ocr_bbox(ocr_bbox, frame_shape)

        assert bbox.x == 0  # max(0, 2-5)
        assert bbox.y == 0  # max(0, 3-5)

    def test_clipping_at_frame_edge(self, detector):
        """우하단 프레임 경계에서 클리핑"""
        ocr_bbox = MockOCRBoundingBox(x_min=1900, y_min=1060, x_max=1920, y_max=1080)
        frame_shape = (1080, 1920, 3)

        bbox = detector._convert_ocr_bbox(ocr_bbox, frame_shape)

        # x2 = min(1920, 1920+5) = 1920, y2 = min(1080, 1080+5) = 1080
        assert bbox.x + bbox.width <= 1920
        assert bbox.y + bbox.height <= 1080

    def test_custom_padding(self):
        """사용자 지정 패딩 적용"""
        config = TextROIDetectorConfig(padding=10)
        det = TextROIDetector(config=config, ocr_engine=MagicMock())

        ocr_bbox = MockOCRBoundingBox(x_min=100, y_min=200, x_max=300, y_max=250)
        frame_shape = (1080, 1920, 3)

        bbox = det._convert_ocr_bbox(ocr_bbox, frame_shape)

        assert bbox.x == 90  # 100 - 10
        assert bbox.y == 190  # 200 - 10


# ========================================
# 인접 ROI 병합 테스트
# ========================================


class TestMergeAdjacentOnSameLine:
    """_merge_adjacent_on_same_line 메서드 테스트"""

    @staticmethod
    def _make_roi(roi_id, x, y, w, h, text="test"):
        return ROI(
            id=roi_id,
            bbox=BoundingBox(x=x, y=y, width=w, height=h),
            roi_type=ROIType.NUMERIC,
            confidence=0.9,
            label=f"test: {text}",
            metadata={
                "detection_method": "text",
                "pattern_category": "temperature",
                "original_text": text,
            },
        )

    def test_single_roi_unchanged(self, detector):
        rois = [self._make_roi("r0", 100, 200, 80, 30)]
        result = detector._merge_adjacent_on_same_line(rois)
        assert len(result) == 1
        assert result[0].id == "r0"

    def test_empty_list(self, detector):
        result = detector._merge_adjacent_on_same_line([])
        assert result == []

    def test_merge_same_line_adjacent(self, detector):
        """같은 줄의 인접 ROI 2개 → 1개로 병합"""
        rois = [
            self._make_roi("r0", 100, 200, 80, 30, "Temperature:"),
            self._make_roi("r1", 190, 200, 60, 30, "25.5°C"),
            # x_gap = 190 - (100+80) = 10 → 30 이하 → 병합
        ]
        result = detector._merge_adjacent_on_same_line(rois)
        assert len(result) == 1
        # 합친 bbox가 두 ROI를 감싸야 함
        assert result[0].bbox.x == 100
        assert result[0].bbox.x + result[0].bbox.width == 250  # 190 + 60

    def test_no_merge_different_lines(self, detector):
        """다른 줄의 ROI는 병합 안 됨"""
        rois = [
            self._make_roi("r0", 100, 100, 80, 30, "Temp: 25°C"),
            self._make_roi("r1", 100, 250, 80, 30, "Press: 1.5bar"),
            # y 차이 = |115 - 265| = 150 → 15 초과 → 별개 줄
        ]
        result = detector._merge_adjacent_on_same_line(rois)
        assert len(result) == 2

    def test_no_merge_far_apart_horizontally(self, detector):
        """수평 간격이 먼 ROI는 병합 안 됨"""
        rois = [
            self._make_roi("r0", 100, 200, 80, 30, "Value1"),
            self._make_roi("r1", 300, 200, 60, 30, "Value2"),
            # x_gap = 300 - (100+80) = 120 → 30 초과 → 병합 안 됨
        ]
        result = detector._merge_adjacent_on_same_line(rois)
        assert len(result) == 2

    def test_merge_three_sequential(self, detector):
        """같은 줄의 3개 연속 ROI → 1개로 병합"""
        rois = [
            self._make_roi("r0", 50, 200, 60, 30, "Label:"),
            self._make_roi("r1", 120, 200, 50, 30, "25.5"),
            self._make_roi("r2", 180, 200, 40, 30, "°C"),
            # gap r0→r1 = 120-110 = 10, gap r1→r2 = 180-170 = 10
        ]
        result = detector._merge_adjacent_on_same_line(rois)
        assert len(result) == 1
        assert "Label: 25.5 °C" in result[0].label

    def test_merged_confidence_is_max(self, detector):
        """병합 시 최대 confidence 사용"""
        r0 = ROI(
            id="r0", bbox=BoundingBox(x=100, y=200, width=80, height=30),
            roi_type=ROIType.NUMERIC, confidence=0.7,
            metadata={"detection_method": "text", "pattern_category": "temperature", "original_text": "Temp:"},
        )
        r1 = ROI(
            id="r1", bbox=BoundingBox(x=190, y=200, width=60, height=30),
            roi_type=ROIType.NUMERIC, confidence=0.95,
            metadata={"detection_method": "text", "pattern_category": "temperature", "original_text": "25.5°C"},
        )
        result = detector._merge_adjacent_on_same_line([r0, r1])
        assert len(result) == 1
        assert result[0].confidence == 0.95


# ========================================
# 전체 detect 흐름 테스트
# ========================================


class TestDetect:
    """detect() 메서드 통합 테스트 (OCR 엔진 모킹)"""

    def test_detect_with_matching_text(self):
        """OCR이 온도 텍스트를 반환하면 ROI 1개 탐지"""
        mock_engine = MagicMock()
        mock_engine.recognize.return_value = (
            MockOCRResult(
                text="25.5°C",
                confidence=0.95,
                bounding_box=MockOCRBoundingBox(100, 200, 250, 240),
            ),
        )

        detector = TextROIDetector(ocr_engine=mock_engine)
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        rois = detector.detect(frame)

        assert len(rois) == 1
        assert rois[0].roi_type == ROIType.NUMERIC
        assert rois[0].metadata["pattern_category"] == "temperature"

    def test_detect_filters_low_confidence(self):
        """신뢰도 낮은 OCR 결과는 무시"""
        mock_engine = MagicMock()
        mock_engine.recognize.return_value = (
            MockOCRResult(
                text="25.5°C",
                confidence=0.3,  # 기본 임계값 0.6 미만
                bounding_box=MockOCRBoundingBox(100, 200, 250, 240),
            ),
        )

        detector = TextROIDetector(ocr_engine=mock_engine)
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        rois = detector.detect(frame)

        assert len(rois) == 0

    def test_detect_filters_unknown_pattern(self):
        """패턴 매칭 실패 텍스트는 무시"""
        mock_engine = MagicMock()
        mock_engine.recognize.return_value = (
            MockOCRResult(
                text="Hello World",
                confidence=0.95,
                bounding_box=MockOCRBoundingBox(100, 200, 300, 240),
            ),
        )

        detector = TextROIDetector(ocr_engine=mock_engine)
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        rois = detector.detect(frame)

        assert len(rois) == 0

    def test_detect_multiple_patterns(self):
        """여러 패턴이 동시에 탐지"""
        mock_engine = MagicMock()
        mock_engine.recognize.return_value = (
            MockOCRResult(
                text="25.5°C",
                confidence=0.9,
                bounding_box=MockOCRBoundingBox(100, 100, 200, 130),
            ),
            MockOCRResult(
                text="85.3%",
                confidence=0.88,
                bounding_box=MockOCRBoundingBox(100, 300, 200, 330),
            ),
            MockOCRResult(
                text="RUNNING",
                confidence=0.92,
                bounding_box=MockOCRBoundingBox(500, 100, 650, 130),
            ),
        )

        detector = TextROIDetector(ocr_engine=mock_engine)
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        rois = detector.detect(frame)

        assert len(rois) == 3
        categories = {r.metadata["pattern_category"] for r in rois}
        assert "temperature" in categories
        assert "percentage" in categories
        assert "status_text" in categories

    def test_detect_empty_frame(self):
        """빈 프레임 입력 시 빈 리스트 반환"""
        mock_engine = MagicMock()
        detector = TextROIDetector(ocr_engine=mock_engine)

        empty_frame = np.array([], dtype=np.uint8)
        rois = detector.detect(empty_frame)
        assert rois == []

    def test_detect_none_frame(self):
        """None 프레임 입력 시 빈 리스트 반환"""
        mock_engine = MagicMock()
        detector = TextROIDetector(ocr_engine=mock_engine)

        rois = detector.detect(None)
        assert rois == []

    def test_detect_filters_small_area(self):
        """min_text_area 이하 bbox는 필터링"""
        mock_engine = MagicMock()
        mock_engine.recognize.return_value = (
            MockOCRResult(
                text="25.5°C",
                confidence=0.9,
                bounding_box=MockOCRBoundingBox(100, 200, 105, 205),
                # 영역: (105+5)-(100-5)=15 x (205+5)-(200-5)=15 = 225
                # min_text_area=100 → 통과
            ),
        )

        # min_text_area를 높게 설정
        config = TextROIDetectorConfig(min_text_area=500)
        detector = TextROIDetector(config=config, ocr_engine=mock_engine)
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        rois = detector.detect(frame)

        assert len(rois) == 0


# ========================================
# TextPattern 커스텀 패턴 테스트
# ========================================


class TestCustomPatterns:
    """사용자 정의 패턴 적용 테스트"""

    def test_custom_pattern_only(self):
        """기본 패턴 대신 커스텀 패턴만 사용"""
        custom_patterns = (
            TextPattern(
                category=PatternCategory.NUMERIC_VALUE,
                pattern=r"RPM:\s*\d+",
                roi_type=ROIType.NUMERIC,
                priority=10,
            ),
        )
        config = TextROIDetectorConfig(patterns=custom_patterns)
        detector = TextROIDetector(config=config, ocr_engine=MagicMock())

        cat, rt = detector._classify_text("RPM: 3200")
        assert cat == PatternCategory.NUMERIC_VALUE

        # 기본 패턴은 매칭되지 않아야 함
        cat2, _ = detector._classify_text("25.5°C")
        assert cat2 == PatternCategory.UNKNOWN
