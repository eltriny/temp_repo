# 산업용 비디오 모니터링 분석 프로그램

산업용 장비 모니터링 비디오에서 숫자 변화를 감지하고, 텍스트 및 그래프 데이터를 추출하는 Python 프로그램입니다.

## 빠른 시작 (Quick Start)

```bash
# 설치
pip install -r requirements.txt

# 기본 실행
python src/main.py --video input.mp4 --output ./results

# GPU 모드
python src/main.py --video input.mp4 --output ./results --gpu
```

## 주요 기능

| 기능 | 설명 |
|------|------|
| **자동 ROI 감지** | 비디오 프레임에서 숫자 영역을 자동으로 식별 |
| **SSIM 기반 변화 감지** | 구조적 유사도 지수를 활용한 정밀 변화 감지 |
| **PaddleOCR 숫자 인식** | 산업용 디스플레이에 최적화된 OCR 엔진 |
| **차트 영역 감지** | 선형 차트(Trend Chart) 존재 여부 자동 감지 |
| **SQLite 데이터 저장** | 분석 결과를 체계적으로 저장 및 관리 |

## 시스템 요구사항

| 구분 | 최소 사양 | 권장 사양 |
|------|----------|----------|
| **CPU** | 4코어 | 8코어 이상 |
| **RAM** | 4GB | 8GB 이상 |
| **GPU** | - | NVIDIA RTX 2060 이상 |
| **Python** | 3.10 | 3.10+ |
| **저장공간** | 10GB | 50GB 이상 |

## 설치

```bash
# 저장소 클론
cd /home/eltriny/Workspace/projects/video_detection

# 의존성 설치
pip install -r requirements.txt

# GPU 사용 시 (선택)
# pip install paddlepaddle-gpu
```

## 사용법

### 기본 사용

```bash
cd src
python main.py --video /path/to/video.mp4 --output ./results
```

### 전체 옵션

```bash
python main.py \
  --video input.mp4 \      # 분석할 비디오 파일
  --output ./data \        # 결과 저장 디렉토리
  --gpu \                  # GPU 가속 사용
  --interval 0.5 \         # 프레임 분석 간격 (초)
  --ssim-threshold 0.95 \  # 변화 감지 임계값
  --confidence 0.7 \       # OCR 신뢰도 임계값
  --debug                  # 디버그 모드
```

### 결과 출력

```
./data/
├── captures/           # 캡쳐된 이미지들
│   └── 2024/01/19/
│       ├── session_1_roi_1_143025_123456.jpg
│       └── ...
├── analysis.db         # SQLite 데이터베이스
└── video_analyzer.log  # 로그 파일
```

## 프로젝트 구조

```
src/
├── main.py           # 메인 진입점
├── config.py         # 설정 관리
├── core/             # 비디오 처리
│   ├── video_processor.py     # 비디오 프레임 추출
│   └── frame_analyzer.py      # 분석 오케스트레이터
├── detection/        # 감지 모듈
│   ├── roi_detector.py        # ROI 자동 감지
│   ├── change_detector.py     # 숫자 변화 감지
│   └── chart_detector.py      # 차트 감지
├── ocr/              # OCR 엔진
│   └── ocr_engine.py          # PaddleOCR 래퍼
├── preprocessing/    # 이미지 전처리
│   └── image_enhancer.py      # 이미지 전처리
└── storage/          # 저장소 관리
    ├── database.py            # SQLite 관리
    └── capture_manager.py     # 이미지 저장
```

## 기술 스택

- **Python 3.10+**
- **OpenCV**: 비디오 프레임 처리
- **PaddleOCR**: 산업용 숫자 인식에 최적화된 OCR
- **scikit-image**: SSIM 기반 변화 감지
- **SQLite**: 경량 데이터베이스

## 문서

| 문서 | 설명 |
|------|------|
| [시스템 아키텍처](docs/ARCHITECTURE.md) | 전체 시스템 구조 및 컴포넌트 설계 |
| [API 레퍼런스](docs/API_REFERENCE.md) | 모듈별 API 상세 문서 |
| [설정 가이드](docs/CONFIGURATION.md) | 설정 옵션 및 커스터마이징 방법 |
| [워크플로우](docs/WORKFLOW.md) | 데이터 처리 파이프라인 설명 |
| [문제 해결](docs/TROUBLESHOOTING.md) | 일반적인 문제 및 해결 방법 |
| [하드웨어 요구사항](docs/hardware_requirements.md) | 상세 하드웨어 사양 안내 |

## 데이터베이스 스키마

### sessions (분석 세션)

| 컬럼 | 타입 | 설명 |
|------|------|------|
| id | INTEGER | 기본 키 |
| name | TEXT | 세션 이름 |
| source_path | TEXT | 비디오 파일 경로 |
| started_at | TIMESTAMP | 시작 시간 |
| ended_at | TIMESTAMP | 종료 시간 |

### roi_definitions (관심 영역)

| 컬럼 | 타입 | 설명 |
|------|------|------|
| id | INTEGER | 기본 키 |
| session_id | INTEGER | 세션 ID (FK) |
| name | TEXT | ROI 이름 |
| roi_type | TEXT | 유형 (numeric/text/chart) |
| x, y, width, height | INTEGER | 좌표 |

### change_events (변화 이벤트)

| 컬럼 | 타입 | 설명 |
|------|------|------|
| id | INTEGER | 기본 키 |
| session_id | INTEGER | 세션 ID (FK) |
| roi_id | INTEGER | ROI ID (FK) |
| previous_value | TEXT | 이전 값 |
| current_value | TEXT | 현재 값 |
| frame_path | TEXT | 캡쳐 이미지 경로 |
| extracted_text | TEXT | 추출된 텍스트 |
| is_chart | BOOLEAN | 차트 감지 여부 |
| confidence | REAL | OCR 신뢰도 |
| created_at | TIMESTAMP | 감지 시간 |

## 성능 특성

- **장시간 비디오 지원**: Generator 패턴으로 메모리 효율적 처리
- **적응형 프레임 스킵**: 기본 1초 간격, 변화 시 0.17초로 자동 전환
- **예상 처리 속도**: 5-10 FPS (분석 기준)
- **메모리 사용량**: < 1GB (1시간 비디오 기준)

## 라이선스

MIT License
