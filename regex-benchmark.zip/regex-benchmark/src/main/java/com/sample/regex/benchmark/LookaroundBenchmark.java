package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lookahead/Lookbehind 성능 측정.
 *
 * Zero-width assertion은 캡처 그룹이나 \b 같은 단순 대안과 비교하여
 * 추가적인 오버헤드가 있다. 특히 Lookbehind는 Java에서 폭을 결정해야 하므로
 * Lookahead보다 비용이 더 크다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class LookaroundBenchmark {

    private Pattern lookbehind;
    private Pattern capturingGroupAlt;
    private Pattern lookahead;
    private Pattern combinedLookaround;
    private Pattern negativeLookaround;
    private Pattern wordBoundary;

    private String input;

    @Setup(Level.Trial)
    public void setup() {
        lookbehind = Pattern.compile("(?<=@)\\w+");
        capturingGroupAlt = Pattern.compile("@(\\w+)");
        lookahead = Pattern.compile("\\w+(?=@)");
        combinedLookaround = Pattern.compile("(?<=<)\\w+(?=>)");
        negativeLookaround = Pattern.compile("(?<!\\w)\\d+(?!\\w)");
        wordBoundary = Pattern.compile("\\b\\d+\\b");

        input = TestDataGenerator.emailList(1000);
    }

    @Benchmark
    public int lookbehindFind() {
        return countMatches(lookbehind, input);
    }

    @Benchmark
    public int capturingGroupFind() {
        return countMatches(capturingGroupAlt, input);
    }

    @Benchmark
    public int lookaheadFind() {
        return countMatches(lookahead, input);
    }

    @Benchmark
    public int combinedLookaroundFind() {
        String htmlInput = "<div>content</div><span>text</span>";
        return countMatches(combinedLookaround, htmlInput.repeat(100));
    }

    @Benchmark
    public int negativeLookaroundFind() {
        return countMatches(negativeLookaround, input);
    }

    @Benchmark
    public int wordBoundaryFind() {
        return countMatches(wordBoundary, input);
    }

    private static int countMatches(Pattern p, String input) {
        Matcher m = p.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }
}
