package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Named Group, Unnamed Group, Non-capturing Group 성능 비교.
 *
 * 날짜 패턴(YYYY-MM-DD)을 대상으로 그룹 유형별 매칭 및 캡처 접근 비용을 측정한다.
 * group(int) vs group(String) 접근 방식의 차이도 비교한다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class GroupBenchmark {

    private Pattern namedGroup;
    private Pattern unnamedGroup;
    private Pattern nonCapturing;
    private Pattern noGroup;

    private String input;

    @Setup(Level.Trial)
    public void setup() {
        namedGroup = Pattern.compile("(?<year>\\d{4})-(?<month>\\d{2})-(?<day>\\d{2})");
        unnamedGroup = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})");
        nonCapturing = Pattern.compile("(?:\\d{4})-(?:\\d{2})-(?:\\d{2})");
        noGroup = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");

        input = TestDataGenerator.dateList(2000);
    }

    @Benchmark
    public int namedGroupFindOnly() {
        return countMatches(namedGroup, input);
    }

    @Benchmark
    public int unnamedGroupFindOnly() {
        return countMatches(unnamedGroup, input);
    }

    @Benchmark
    public int nonCapturingFindOnly() {
        return countMatches(nonCapturing, input);
    }

    @Benchmark
    public int noGroupFindOnly() {
        return countMatches(noGroup, input);
    }

    @Benchmark
    public int namedGroupAccessByName() {
        Matcher m = namedGroup.matcher(input);
        int hash = 0;
        while (m.find()) {
            hash += m.group("year").hashCode();
            hash += m.group("month").hashCode();
            hash += m.group("day").hashCode();
        }
        return hash;
    }

    @Benchmark
    public int namedGroupAccessByIndex() {
        Matcher m = namedGroup.matcher(input);
        int hash = 0;
        while (m.find()) {
            hash += m.group(1).hashCode();
            hash += m.group(2).hashCode();
            hash += m.group(3).hashCode();
        }
        return hash;
    }

    @Benchmark
    public int unnamedGroupAccessByIndex() {
        Matcher m = unnamedGroup.matcher(input);
        int hash = 0;
        while (m.find()) {
            hash += m.group(1).hashCode();
            hash += m.group(2).hashCode();
            hash += m.group(3).hashCode();
        }
        return hash;
    }

    private static int countMatches(Pattern p, String input) {
        Matcher m = p.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }
}
