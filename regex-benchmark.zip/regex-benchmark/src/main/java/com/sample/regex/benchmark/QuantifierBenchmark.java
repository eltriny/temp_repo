package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import com.sample.regex.data.TestDataGenerator.InputSize;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Greedy, Lazy(Reluctant), Possessive 수량자 성능 비교.
 *
 * Greedy(.*): 전체를 소비한 뒤 백트래킹으로 후퇴
 * Lazy(.*?): 최소부터 시작하여 확장
 * Possessive(.*+): 백트래킹 없이 전체 소비, 실패 시 즉시 포기
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class QuantifierBenchmark {

    @Param({"SMALL", "MEDIUM", "LARGE"})
    private String inputSize;

    private Pattern greedy;
    private Pattern lazy;
    private Pattern possessive;
    private String input;

    @Setup(Level.Trial)
    public void setup() {
        greedy = Pattern.compile("<.*>");
        lazy = Pattern.compile("<.*?>");
        possessive = Pattern.compile("<[^>]*+>");
        input = TestDataGenerator.htmlLikeTags(InputSize.fromString(inputSize));
    }

    @Benchmark
    public int greedyFindAll() {
        Matcher m = greedy.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    @Benchmark
    public int lazyFindAll() {
        Matcher m = lazy.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    @Benchmark
    public int possessiveFindAll() {
        Matcher m = possessive.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    @Benchmark
    public String greedyReplaceAll() {
        return greedy.matcher(input).replaceAll("[TAG]");
    }

    @Benchmark
    public String lazyReplaceAll() {
        return lazy.matcher(input).replaceAll("[TAG]");
    }
}
