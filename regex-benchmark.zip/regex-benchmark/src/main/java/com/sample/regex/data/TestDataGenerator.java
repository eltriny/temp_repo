package com.sample.regex.data;

import java.util.Random;

public final class TestDataGenerator {

    private static final long SEED = 42L;
    private static final String ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGITS = "0123456789";
    private static final String ALPHANUMERIC = ALPHA + DIGITS;
    private static final String SPECIALS = "!@#$%^&*()-_=+[]{}|;:',.<>?/`~";
    private static final String ALL_CHARS = ALPHANUMERIC + SPECIALS + " \t\n";

    private TestDataGenerator() {}

    public enum InputSize {
        TINY(100),
        SMALL(1_000),
        MEDIUM(10_000),
        LARGE(100_000),
        HUGE(1_000_000);

        public final int length;

        InputSize(int length) {
            this.length = length;
        }

        public static InputSize fromString(String s) {
            return valueOf(s.toUpperCase());
        }
    }

    // --- 기본 문자열 생성기 ---

    public static String alphabetic(InputSize size) {
        return randomFrom(ALPHA, size.length);
    }

    public static String alphanumeric(InputSize size) {
        return randomFrom(ALPHANUMERIC, size.length);
    }

    public static String mixedWithSpecials(InputSize size) {
        return randomFrom(ALL_CHARS, size.length);
    }

    public static String alphabetic(int length) {
        return randomFrom(ALPHA, length);
    }

    // --- 반복 패턴 ---

    public static String repeatingPattern(String unit, int repeats) {
        StringBuilder sb = new StringBuilder(unit.length() * repeats);
        for (int i = 0; i < repeats; i++) {
            sb.append(unit);
        }
        return sb.toString();
    }

    // --- 실전 데이터 생성 ---

    public static String emailList(int count) {
        Random rnd = new Random(SEED);
        String[] domains = {"gmail.com", "yahoo.co.kr", "naver.com", "company.org", "test.io"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append('\n');
            String user = randomAlpha(rnd, 5 + rnd.nextInt(10));
            if (rnd.nextInt(10) < 8) {
                // 유효한 이메일 (80%)
                sb.append(user).append('@').append(domains[rnd.nextInt(domains.length)]);
            } else {
                // 무효한 이메일 (20%)
                sb.append(user).append(rnd.nextBoolean() ? "@@broken" : "@.invalid.");
            }
        }
        return sb.toString();
    }

    public static String urlList(int count) {
        Random rnd = new Random(SEED);
        String[] hosts = {"example.com", "api.service.io", "cdn.images.net", "docs.dev.kr"};
        String[] paths = {"/api/v1/users", "/search?q=test", "/index.html", "/data/2026/report.json", ""};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append('\n');
            String protocol = rnd.nextBoolean() ? "https" : "http";
            if (rnd.nextInt(10) < 8) {
                sb.append(protocol).append("://").append(hosts[rnd.nextInt(hosts.length)])
                  .append(paths[rnd.nextInt(paths.length)]);
            } else {
                sb.append("htp://broken url here!");
            }
        }
        return sb.toString();
    }

    public static String ipAddressList(int count) {
        Random rnd = new Random(SEED);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append('\n');
            if (rnd.nextInt(10) < 8) {
                sb.append(rnd.nextInt(256)).append('.')
                  .append(rnd.nextInt(256)).append('.')
                  .append(rnd.nextInt(256)).append('.')
                  .append(rnd.nextInt(256));
            } else {
                sb.append("999.999.999.999");
            }
        }
        return sb.toString();
    }

    public static String logLines(int count) {
        Random rnd = new Random(SEED);
        String[] levels = {"INFO", "WARN", "ERROR", "DEBUG", "TRACE"};
        String[] classes = {"UserService", "AuthController", "DBPool", "CacheManager", "HttpClient"};
        String[] messages = {
            "Request processed successfully",
            "Connection timeout after 30s",
            "NullPointerException at line 42",
            "Cache miss for key=user:1234",
            "Retrying operation attempt 3/5"
        };
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append('\n');
            sb.append(String.format("2026-03-%02dT%02d:%02d:%02d",
                    1 + rnd.nextInt(28), rnd.nextInt(24), rnd.nextInt(60), rnd.nextInt(60)));
            sb.append(' ').append(levels[rnd.nextInt(levels.length)]);
            sb.append(" [").append(classes[rnd.nextInt(classes.length)]).append(']');
            sb.append(' ').append(messages[rnd.nextInt(messages.length)]);
        }
        return sb.toString();
    }

    public static String htmlLikeTags(InputSize size) {
        Random rnd = new Random(SEED);
        String[] tags = {"div", "span", "p", "a", "img", "table", "tr", "td", "h1", "ul"};
        StringBuilder sb = new StringBuilder();
        while (sb.length() < size.length) {
            String tag = tags[rnd.nextInt(tags.length)];
            sb.append('<').append(tag);
            if (rnd.nextBoolean()) {
                sb.append(" class=\"").append(randomAlpha(rnd, 5)).append('"');
            }
            sb.append('>');
            sb.append(randomAlpha(rnd, 10 + rnd.nextInt(50)));
            sb.append("</").append(tag).append('>');
            if (rnd.nextInt(3) == 0) sb.append('\n');
        }
        return sb.substring(0, Math.min(sb.length(), size.length));
    }

    public static String dateList(int count) {
        Random rnd = new Random(SEED);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append('\n');
            sb.append(String.format("%04d-%02d-%02d",
                    2000 + rnd.nextInt(30), 1 + rnd.nextInt(12), 1 + rnd.nextInt(28)));
        }
        return sb.toString();
    }

    public static String phoneNumbers(int count) {
        Random rnd = new Random(SEED);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append(' ');
            sb.append(String.format("%03d-%03d-%04d",
                    rnd.nextInt(1000), rnd.nextInt(1000), rnd.nextInt(10000)));
            if (rnd.nextInt(3) == 0) {
                sb.append(" some text here ");
            }
        }
        return sb.toString();
    }

    // --- 백트래킹 전용 입력 ---

    public static String pathologicalInput(int length) {
        return "a".repeat(length) + "!";
    }

    public static String nestedQuantifierInput(int length) {
        return "a".repeat(length);
    }

    // --- 유니코드 혼합 입력 ---

    public static String unicodeMixed(InputSize size) {
        Random rnd = new Random(SEED);
        String koreanChars = "가나다라마바사아자차카타파하";
        String japaneseChars = "あいうえおかきくけこ";
        String pool = ALPHA + koreanChars + japaneseChars + DIGITS;
        StringBuilder sb = new StringBuilder();
        while (sb.length() < size.length) {
            sb.append(pool.charAt(rnd.nextInt(pool.length())));
        }
        return sb.substring(0, size.length);
    }

    // --- 내부 유틸 ---

    private static String randomFrom(String pool, int length) {
        Random rnd = new Random(SEED);
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(pool.charAt(rnd.nextInt(pool.length())));
        }
        return sb.toString();
    }

    private static String randomAlpha(Random rnd, int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(ALPHA.charAt(rnd.nextInt(ALPHA.length())));
        }
        return sb.toString();
    }
}
