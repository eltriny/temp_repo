package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import com.sample.regex.data.TestDataGenerator.InputSize;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 입력 크기(100B ~ 1MB) × 패턴 복잡도 매트릭스 벤치마크.
 *
 * 단순 리터럴은 거의 O(n)이지만, 백트래킹이 필요한 복잡 패턴은
 * 입력 크기에 따라 초선형(super-linear)으로 증가할 수 있다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class InputSizeBenchmark {

    @Param({"TINY", "SMALL", "MEDIUM", "LARGE"})
    private String inputSize;

    private Pattern simpleLiteral;
    private Pattern moderateIp;
    private Pattern complexEmail;

    private String input;

    @Setup(Level.Trial)
    public void setup() {
        simpleLiteral = Pattern.compile("error");
        moderateIp = Pattern.compile("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");
        complexEmail = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");

        InputSize size = InputSize.fromString(inputSize);
        input = TestDataGenerator.mixedWithSpecials(size);
    }

    @Benchmark
    public int simpleLiteralFindAll() {
        return countMatches(simpleLiteral, input);
    }

    @Benchmark
    public int moderateIpFindAll() {
        return countMatches(moderateIp, input);
    }

    @Benchmark
    public int complexEmailFindAll() {
        return countMatches(complexEmail, input);
    }

    @Benchmark
    public boolean simpleLiteralFindFirst() {
        return simpleLiteral.matcher(input).find();
    }

    @Benchmark
    public boolean moderateIpFindFirst() {
        return moderateIp.matcher(input).find();
    }

    @Benchmark
    public boolean complexEmailFindFirst() {
        return complexEmail.matcher(input).find();
    }

    @Benchmark
    public String simpleLiteralReplaceAll() {
        return simpleLiteral.matcher(input).replaceAll("ERROR");
    }

    private static int countMatches(Pattern p, String input) {
        Matcher m = p.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }
}
