package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pattern.compile() 사전 컴파일 vs String.matches() 매번 컴파일 성능 비교.
 *
 * String.matches()는 내부적으로 매 호출마다 Pattern.compile()을 수행한다.
 * 이 벤치마크는 사전 컴파일의 성능 이점을 정량적으로 측정한다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class PatternCompileBenchmark {

    private static final String PHONE_REGEX = "\\d{3}-\\d{3}-\\d{4}";

    private Pattern precompiled;
    private Pattern precompiledCaseInsensitive;
    private String input;

    @Setup(Level.Trial)
    public void setup() {
        precompiled = Pattern.compile(PHONE_REGEX);
        precompiledCaseInsensitive = Pattern.compile("[a-z]+@[a-z]+\\.[a-z]{2,}",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        input = TestDataGenerator.phoneNumbers(500);
    }

    @Benchmark
    public boolean stringMatches() {
        return input.matches(".*" + PHONE_REGEX + ".*");
    }

    @Benchmark
    public boolean precompiledFind() {
        return precompiled.matcher(input).find();
    }

    @Benchmark
    public int precompiledFindAll() {
        Matcher m = precompiled.matcher(input);
        int count = 0;
        while (m.find()) {
            count++;
        }
        return count;
    }

    @Benchmark
    public boolean compileEveryTime() {
        Pattern p = Pattern.compile(PHONE_REGEX);
        return p.matcher(input).find();
    }

    @Benchmark
    public boolean precompiledWithFlags() {
        return precompiledCaseInsensitive.matcher(input).find();
    }
}
