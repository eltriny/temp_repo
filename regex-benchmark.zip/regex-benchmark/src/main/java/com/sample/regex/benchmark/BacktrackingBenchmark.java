package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * 카타스트로픽 백트래킹(Catastrophic Backtracking) 시연 및 해결책 비교.
 *
 * (a+)+$ 같은 패턴은 매칭 실패 시 지수적 시간 복잡도를 가진다.
 * Possessive 수량자나 Atomic Group으로 이를 방지할 수 있다.
 *
 * 주의: catastrophic 메서드는 의도적으로 타임아웃될 수 있다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 3, time = 1)
@Fork(1)
@Timeout(time = 5)
public class BacktrackingBenchmark {

    @Param({"10", "15", "20", "25"})
    private int inputLength;

    private Pattern catastrophicNested;
    private Pattern catastrophicAlternation;
    private Pattern fixedPossessive;
    private Pattern fixedAtomic;
    private Pattern safeEmail;
    private Pattern unsafeEmail;

    private String pathologicalInput;
    private String emailInput;

    @Setup(Level.Trial)
    public void setup() {
        catastrophicNested = Pattern.compile("(a+)+$");
        catastrophicAlternation = Pattern.compile("(a|aa)+$");
        fixedPossessive = Pattern.compile("(a++)+$");
        fixedAtomic = Pattern.compile("(?>a+)+$");

        // 안전하지 않은 이메일 패턴 (백트래킹 취약)
        unsafeEmail = Pattern.compile("([a-zA-Z0-9]+\\.)*[a-zA-Z0-9]+@([a-zA-Z0-9]+\\.)+[a-zA-Z]{2,}");
        // 안전한 이메일 패턴 (Possessive 사용)
        safeEmail = Pattern.compile("([a-zA-Z0-9]++\\.)*+[a-zA-Z0-9]++@([a-zA-Z0-9]++\\.)++[a-zA-Z]{2,}");

        pathologicalInput = TestDataGenerator.pathologicalInput(inputLength);
        emailInput = "user.name.test.long.prefix@sub.domain.example.com!";
    }

    @Benchmark
    public boolean catastrophicNestedMatch() {
        return catastrophicNested.matcher(pathologicalInput).matches();
    }

    @Benchmark
    public boolean catastrophicAlternationMatch() {
        return catastrophicAlternation.matcher(pathologicalInput).matches();
    }

    @Benchmark
    public boolean fixedPossessiveMatch() {
        return fixedPossessive.matcher(pathologicalInput).matches();
    }

    @Benchmark
    public boolean fixedAtomicMatch() {
        return fixedAtomic.matcher(pathologicalInput).matches();
    }

    @Benchmark
    public boolean unsafeEmailMatch() {
        return unsafeEmail.matcher(emailInput).matches();
    }

    @Benchmark
    public boolean safeEmailMatch() {
        return safeEmail.matcher(emailInput).matches();
    }
}
