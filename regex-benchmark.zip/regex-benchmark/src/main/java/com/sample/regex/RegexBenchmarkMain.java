package com.sample.regex;

import com.sample.regex.report.BenchmarkReporter;
import org.openjdk.jmh.results.RunResult;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.runner.options.TimeValue;

import java.nio.file.Path;
import java.util.Collection;

/**
 * Java 정규 표현식 퍼포먼스 테스트 프로그램 진입점.
 *
 * 사용법:
 *   java -jar regex-benchmark-1.0.jar [옵션]
 *
 * 옵션:
 *   --quick              축소 실행 (warmup=2, measurement=3, forks=1)
 *   --full               전체 실행 (warmup=5, measurement=10, forks=3)
 *   --include=<패턴>     지정 패턴과 매칭되는 벤치마크만 실행
 *   --csv=<경로>         결과를 CSV 파일로 내보내기
 *   --list               사용 가능한 벤치마크 목록 출력
 *   --help               도움말 출력
 */
public class RegexBenchmarkMain {

    private static final String BASE_PACKAGE = "com.sample.regex.benchmark";

    public static void main(String[] args) throws RunnerException {
        CliOptions cli = parseArgs(args);

        if (cli.help) {
            printHelp();
            return;
        }

        if (cli.list) {
            listBenchmarks();
            return;
        }

        System.out.println("╔══════════════════════════════════════════════════╗");
        System.out.println("║   Java Regex Performance Benchmark (JMH)        ║");
        System.out.printf("║   Mode: %-41s║%n", cli.profile.toUpperCase());
        if (cli.include != null) {
            System.out.printf("║   Filter: %-39s║%n", cli.include);
        }
        System.out.println("╚══════════════════════════════════════════════════╝");
        System.out.println();

        OptionsBuilder builder = new OptionsBuilder();

        // 벤치마크 필터 설정
        String includePattern = BASE_PACKAGE + ".*";
        if (cli.include != null) {
            includePattern = BASE_PACKAGE + ".*" + cli.include + ".*";
        }
        builder.include(includePattern);

        // 프로파일 설정
        switch (cli.profile) {
            case "quick" -> {
                builder.warmupIterations(2)
                       .warmupTime(TimeValue.seconds(1))
                       .measurementIterations(3)
                       .measurementTime(TimeValue.seconds(1))
                       .forks(1);
            }
            case "full" -> {
                builder.warmupIterations(5)
                       .warmupTime(TimeValue.seconds(2))
                       .measurementIterations(10)
                       .measurementTime(TimeValue.seconds(2))
                       .forks(3);
            }
            default -> {
                // 기본값: 중간 수준
                builder.warmupIterations(3)
                       .warmupTime(TimeValue.seconds(1))
                       .measurementIterations(5)
                       .measurementTime(TimeValue.seconds(1))
                       .forks(2);
            }
        }

        builder.shouldDoGC(true);

        Options opt = builder.build();
        Collection<RunResult> results = new Runner(opt).run();

        // 커스텀 리포트 출력
        Path csvDir = cli.csvPath != null ? Path.of(cli.csvPath).getParent() : null;
        if (cli.csvPath != null) {
            BenchmarkReporter.printSummaryTable(results, System.out);
            BenchmarkReporter.exportCsv(results, Path.of(cli.csvPath));
        } else {
            BenchmarkReporter.generateReport(results, null);
        }
    }

    private static CliOptions parseArgs(String[] args) {
        CliOptions cli = new CliOptions();
        for (String arg : args) {
            if ("--quick".equals(arg)) {
                cli.profile = "quick";
            } else if ("--full".equals(arg)) {
                cli.profile = "full";
            } else if (arg.startsWith("--include=")) {
                cli.include = arg.substring("--include=".length());
            } else if (arg.startsWith("--csv=")) {
                cli.csvPath = arg.substring("--csv=".length());
            } else if ("--list".equals(arg)) {
                cli.list = true;
            } else if ("--help".equals(arg) || "-h".equals(arg)) {
                cli.help = true;
            }
        }
        return cli;
    }

    private static void printHelp() {
        System.out.println("Java Regex Performance Benchmark");
        System.out.println();
        System.out.println("Usage: java -jar regex-benchmark-1.0.jar [options]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  --quick              축소 실행 (warmup=2, measurement=3, forks=1)");
        System.out.println("  --full               전체 실행 (warmup=5, measurement=10, forks=3)");
        System.out.println("  --include=<pattern>  지정 패턴과 매칭되는 벤치마크만 실행");
        System.out.println("  --csv=<path>         결과를 CSV 파일로 내보내기");
        System.out.println("  --list               사용 가능한 벤치마크 목록 출력");
        System.out.println("  --help, -h           이 도움말 출력");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  java -jar regex-benchmark-1.0.jar --quick");
        System.out.println("  java -jar regex-benchmark-1.0.jar --include=PatternCompile --quick");
        System.out.println("  java -jar regex-benchmark-1.0.jar --full --csv=results/output.csv");
    }

    private static void listBenchmarks() {
        System.out.println("Available Benchmarks:");
        System.out.println();
        System.out.println("  PatternCompileBenchmark   - Pattern.compile() 사전 컴파일 vs String.matches()");
        System.out.println("  QuantifierBenchmark       - Greedy vs Lazy vs Possessive 수량자");
        System.out.println("  BacktrackingBenchmark     - 카타스트로픽 백트래킹 시연 및 해결책");
        System.out.println("  CharClassBenchmark        - 문자 클래스 표현 방식별 비교");
        System.out.println("  LookaroundBenchmark       - Lookahead/Lookbehind 오버헤드 측정");
        System.out.println("  GroupBenchmark            - Named/Unnamed/Non-capturing 그룹 비교");
        System.out.println("  InputSizeBenchmark        - 입력 크기별 스케일링 측정");
        System.out.println("  RealWorldBenchmark        - 실전 패턴 (Email, URL, IP 등)");
        System.out.println();
        System.out.println("Usage: --include=<name> 으로 특정 벤치마크만 실행");
    }

    private static class CliOptions {
        String profile = "default";
        String include = null;
        String csvPath = null;
        boolean list = false;
        boolean help = false;
    }
}
