package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import com.sample.regex.data.TestDataGenerator.InputSize;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 문자 클래스(Character Class) 표현 방식별 성능 비교.
 *
 * [a-zA-Z], \w, \p{Alpha}, \p{L}(유니코드) 등의 성능 차이를 측정한다.
 * 유니코드 인식 패턴은 ASCII 전용보다 느릴 수 있다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class CharClassBenchmark {

    @Param({"SMALL", "MEDIUM", "LARGE"})
    private String inputSize;

    private Pattern explicitRange;
    private Pattern posixAlpha;
    private Pattern wordChar;
    private Pattern unicodeLetter;
    private Pattern unicodeLetterOrNumber;
    private Pattern caseInsensitiveFlag;

    private String asciiInput;
    private String unicodeInput;

    @Setup(Level.Trial)
    public void setup() {
        explicitRange = Pattern.compile("[a-zA-Z]+");
        posixAlpha = Pattern.compile("\\p{Alpha}+");
        wordChar = Pattern.compile("\\w+");
        unicodeLetter = Pattern.compile("\\p{L}+");
        unicodeLetterOrNumber = Pattern.compile("[\\p{L}\\p{N}]+");
        caseInsensitiveFlag = Pattern.compile("[a-z]+", Pattern.CASE_INSENSITIVE);

        InputSize size = InputSize.fromString(inputSize);
        asciiInput = TestDataGenerator.alphanumeric(size);
        unicodeInput = TestDataGenerator.unicodeMixed(size);
    }

    @Benchmark
    public int explicitRangeAscii() {
        return countMatches(explicitRange, asciiInput);
    }

    @Benchmark
    public int posixAlphaAscii() {
        return countMatches(posixAlpha, asciiInput);
    }

    @Benchmark
    public int wordCharAscii() {
        return countMatches(wordChar, asciiInput);
    }

    @Benchmark
    public int unicodeLetterAscii() {
        return countMatches(unicodeLetter, asciiInput);
    }

    @Benchmark
    public int unicodeLetterUnicode() {
        return countMatches(unicodeLetter, unicodeInput);
    }

    @Benchmark
    public int unicodeLetterOrNumberUnicode() {
        return countMatches(unicodeLetterOrNumber, unicodeInput);
    }

    @Benchmark
    public int caseInsensitiveFlagAscii() {
        return countMatches(caseInsensitiveFlag, asciiInput);
    }

    private static int countMatches(Pattern p, String input) {
        Matcher m = p.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }
}
