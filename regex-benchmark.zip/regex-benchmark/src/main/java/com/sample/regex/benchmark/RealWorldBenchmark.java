package com.sample.regex.benchmark;

import com.sample.regex.data.TestDataGenerator;
import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 실전에서 자주 사용되는 정규 표현식 패턴 벤치마크.
 *
 * Email, URL, IPv4, ISO 날짜, 로그 파싱, CSV 필드, HTML 태그 등
 * 실무에서 마주치는 대표적인 패턴들의 성능을 측정한다.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 5, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class RealWorldBenchmark {

    private Pattern emailSimple;
    private Pattern emailStrict;
    private Pattern url;
    private Pattern ipv4;
    private Pattern isoDate;
    private Pattern logLine;
    private Pattern htmlTag;
    private Pattern javaIdentifier;

    private String emailInput;
    private String urlInput;
    private String ipInput;
    private String dateInput;
    private String logInput;
    private String htmlInput;

    @Setup(Level.Trial)
    public void setup() {
        emailSimple = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
        emailStrict = Pattern.compile(
            "(?:[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*" +
            "|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]" +
            "|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")" +
            "@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?" +
            "|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}" +
            "(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:" +
            "(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]" +
            "|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])");

        url = Pattern.compile("https?://[\\w.-]+(?:/[\\w./-]*)?(?:\\?[\\w=&]*)?");

        ipv4 = Pattern.compile(
            "(?:(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)");

        isoDate = Pattern.compile(
            "\\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\\d|3[01])");

        logLine = Pattern.compile(
            "^(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})\\s+(\\w+)\\s+\\[(.+?)]\\s+(.+)$",
            Pattern.MULTILINE);

        htmlTag = Pattern.compile("<([a-zA-Z][a-zA-Z0-9]*)\\b[^>]*>");

        javaIdentifier = Pattern.compile("[a-zA-Z_$][a-zA-Z0-9_$]*");

        emailInput = TestDataGenerator.emailList(1000);
        urlInput = TestDataGenerator.urlList(1000);
        ipInput = TestDataGenerator.ipAddressList(1000);
        dateInput = TestDataGenerator.dateList(1000);
        logInput = TestDataGenerator.logLines(1000);
        htmlInput = TestDataGenerator.htmlLikeTags(TestDataGenerator.InputSize.MEDIUM);
    }

    @Benchmark
    public int emailSimpleFind() {
        return countMatches(emailSimple, emailInput);
    }

    @Benchmark
    public int emailStrictFind() {
        return countMatches(emailStrict, emailInput);
    }

    @Benchmark
    public int urlFind() {
        return countMatches(url, urlInput);
    }

    @Benchmark
    public int ipv4Find() {
        return countMatches(ipv4, ipInput);
    }

    @Benchmark
    public int isoDateFind() {
        return countMatches(isoDate, dateInput);
    }

    @Benchmark
    public int logLineFind() {
        return countMatches(logLine, logInput);
    }

    @Benchmark
    public int htmlTagFind() {
        return countMatches(htmlTag, htmlInput);
    }

    @Benchmark
    public int javaIdentifierFind() {
        return countMatches(javaIdentifier, htmlInput);
    }

    private static int countMatches(Pattern p, String input) {
        Matcher m = p.matcher(input);
        int count = 0;
        while (m.find()) count++;
        return count;
    }
}
