package com.sample.regex.report;

import org.openjdk.jmh.results.RunResult;
import org.openjdk.jmh.results.Result;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class BenchmarkReporter {

    private static final String SEPARATOR = "─".repeat(100);
    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    public static void generateReport(Collection<RunResult> results, Path outputDir) {
        printSummaryTable(results, System.out);
        if (outputDir != null) {
            String filename = "benchmark-" + LocalDateTime.now().format(FILE_TS) + ".csv";
            exportCsv(results, outputDir.resolve(filename));
        }
    }

    public static void printSummaryTable(Collection<RunResult> results, PrintStream out) {
        if (results.isEmpty()) {
            out.println("결과가 없습니다.");
            return;
        }

        out.println();
        out.println(SEPARATOR);
        out.println("  REGEX BENCHMARK RESULTS");
        out.println(SEPARATOR);

        Map<String, List<RunResult>> grouped = groupByClass(results);

        for (Map.Entry<String, List<RunResult>> entry : grouped.entrySet()) {
            String className = entry.getKey();
            List<RunResult> groupResults = entry.getValue();

            out.println();
            out.printf("  [%s]%n", className);
            out.println("  " + "─".repeat(96));
            out.printf("  %-45s %12s %12s %8s %10s%n",
                    "Benchmark", "Score", "Error(±)", "Unit", "Relative");
            out.println("  " + "─".repeat(96));

            double baselineScore = groupResults.get(0).getPrimaryResult().getScore();

            for (RunResult rr : groupResults) {
                Result<?> primary = rr.getPrimaryResult();
                String benchName = extractMethodName(rr.getParams().getBenchmark());
                double score = primary.getScore();
                double error = primary.getStatistics().getMeanErrorAt(0.99);
                String unit = primary.getScoreUnit();

                double relative = score / baselineScore;
                String relStr;
                if (Math.abs(relative - 1.0) < 0.01) {
                    relStr = "baseline";
                } else if (relative < 1.0) {
                    relStr = String.format("%.2fx faster", 1.0 / relative);
                } else {
                    relStr = String.format("%.2fx slower", relative);
                }

                // 고 오차 경고 (CV > 10%)
                String warning = "";
                double cv = (error / score) * 100;
                if (cv > 10 && score > 0) {
                    warning = " ⚠";
                }

                out.printf("  %-45s %12.2f %12.2f %8s %10s%s%n",
                        truncate(benchName, 45), score, error, unit, relStr, warning);
            }
        }

        out.println();
        out.println(SEPARATOR);
        out.println("  ⚠ = 높은 오차 (CV > 10%), 결과 신뢰도 주의");
        out.println(SEPARATOR);
        out.println();
    }

    public static void exportCsv(Collection<RunResult> results, Path csvFile) {
        try {
            Files.createDirectories(csvFile.getParent());

            List<String> lines = new ArrayList<>();
            lines.add("Class,Benchmark,Score,Error,Unit,Params");

            for (RunResult rr : results) {
                Result<?> primary = rr.getPrimaryResult();
                String fullName = rr.getParams().getBenchmark();
                String className = extractClassName(fullName);
                String methodName = extractMethodName(fullName);
                double score = primary.getScore();
                double error = primary.getStatistics().getMeanErrorAt(0.99);
                String unit = primary.getScoreUnit();

                // 파라미터 수집
                StringBuilder params = new StringBuilder();
                for (String key : rr.getParams().getParamsKeys()) {
                    if (!params.isEmpty()) params.append(';');
                    params.append(key).append('=').append(rr.getParams().getParam(key));
                }

                lines.add(String.format("%s,%s,%.4f,%.4f,%s,%s",
                        className, methodName, score, error, unit,
                        params.toString().replace(",", ";")));
            }

            Files.write(csvFile, lines);
            System.out.printf("CSV 결과 저장: %s (%d건)%n", csvFile, results.size());
        } catch (IOException e) {
            System.err.println("CSV 저장 실패: " + e.getMessage());
        }
    }

    private static Map<String, List<RunResult>> groupByClass(Collection<RunResult> results) {
        return results.stream()
                .collect(Collectors.groupingBy(
                        rr -> extractClassName(rr.getParams().getBenchmark()),
                        LinkedHashMap::new,
                        Collectors.toList()));
    }

    private static String extractClassName(String fullBenchmarkName) {
        int lastDot = fullBenchmarkName.lastIndexOf('.');
        if (lastDot <= 0) return fullBenchmarkName;
        String withoutMethod = fullBenchmarkName.substring(0, lastDot);
        int prevDot = withoutMethod.lastIndexOf('.');
        return prevDot >= 0 ? withoutMethod.substring(prevDot + 1) : withoutMethod;
    }

    private static String extractMethodName(String fullBenchmarkName) {
        int lastDot = fullBenchmarkName.lastIndexOf('.');
        return lastDot >= 0 ? fullBenchmarkName.substring(lastDot + 1) : fullBenchmarkName;
    }

    private static String truncate(String s, int maxLen) {
        return s.length() <= maxLen ? s : s.substring(0, maxLen - 2) + "..";
    }
}
